﻿CREATE TABLE [ODS].[FKConstrantTable] (
    [Id]                      INT           IDENTITY (1, 1) NOT NULL,
    [FKConstraintName]        VARCHAR (255) NULL,
    [FKConstraintTableSchema] VARCHAR (255) NULL,
    [FKConstraintTableName]   VARCHAR (255) NULL,
    [FKConstraintColumnName]  VARCHAR (255) NULL,
    [PKConstraintName]        VARCHAR (255) NULL,
    [PKConstraintTableSchema] VARCHAR (255) NULL,
    [PKConstraintTableName]   VARCHAR (255) NULL,
    [PKConstraintColumnName]  VARCHAR (255) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

