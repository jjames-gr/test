﻿CREATE TABLE [ODS].[DataExports] (
    [RowID]           BIGINT         IDENTITY (1, 1) NOT FOR REPLICATION NOT NULL,
    [DataValues]      VARCHAR (2500) NULL,
    [StoredProcedure] VARCHAR (100)  NULL,
    CONSTRAINT [PK_DataExports] PRIMARY KEY CLUSTERED ([RowID] ASC)
);

