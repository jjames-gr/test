﻿


CREATE view [DWV].[dimCreditMemo]
as 
SELECT [CreditMemoSK]
      ,[CreditMemoNK]
      ,ISNULL(ClaimCheckSK,-1)ClaimCheckSK
      ,[CreditMemo]
      ,[SourceClaimAdjudicationNumber]
      ,[AppliedClaimAdjudicationNumber]
      ,[ETLCreatedDate]
      ,[ETLModifiedDate]
      ,[ETLChecksumType1]
      ,[ETLInsertProjectExecutionID]
      ,[ETLUpdateProjectExecutionID]  
  FROM DW.factCreditMemo