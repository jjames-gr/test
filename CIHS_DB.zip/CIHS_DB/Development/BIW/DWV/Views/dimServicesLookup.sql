﻿

CREATE view [DWV].[dimServicesLookup] as
select
ServicesSK, ServiceCode,
--following logic is used for linking TARS to services
--for those service id's with a -2, the lookup needs to be based on 
-- a concatenation of the Service ID and Service Definition ID
case when ServicesNK < -2 then convert(int, '-2' + CONVERT(varchar, ServiceDefinitionID)) else ServicesNK end ServicesNK, 
ServiceDefinitionID, ServiceDefinition, ServiceSummaryID,
ETLCurrentRow, ETLEffectiveFrom, ETLEffectiveTo
from
dw.dimServices