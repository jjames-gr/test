﻿

------------------------------
-- Claim Check Dimension  
-- For SSAS DSV Named Query dimClaimCheck
-- View Name: DMV.dimClaimCheck
------------------------------
CREATE view [DWV].[dimClaimCheck]
as 
SELECT cc.ClaimCheckSK
       ,cc.ClaimCheckNK
      ,cc.ClaimCheckNumber
      ,cc.[ETLCreatedDate]
      ,cc.[ETLModifiedDate]
      ,cc.[ETLChecksumType1]
      ,cc.[ETLInsertProjectExecutionID]
      ,cc.[ETLUpdateProjectExecutionID]  
  FROM  DW.factClaimCheck  as cc