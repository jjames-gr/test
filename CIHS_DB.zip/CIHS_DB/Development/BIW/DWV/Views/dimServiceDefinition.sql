﻿Create View dwv.dimServiceDefinition as
SELECT Distinct
	ServiceDefinitionID ServiceDefinitionSK,
	ServiceDefinitionID,
	ServiceDefinition
from biw.dw.dimServices
union
SELECT  0,
		0,
		'All Services'