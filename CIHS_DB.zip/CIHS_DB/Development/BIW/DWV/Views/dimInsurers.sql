﻿Create view dwv.dimInsurers
as
select distinct
	InsurerID InsurerSK,
	InsurerID InsurerNK,
	Insurer,
	InsurerShort
from
	biw.dw.dimBenefitPlan