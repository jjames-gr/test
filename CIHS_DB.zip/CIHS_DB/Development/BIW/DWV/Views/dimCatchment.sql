﻿
CREATE view dwv.dimCatchment
as
Select
	CatchmentID CatchmentSK, CatchmentID, Catchment
from
	dw.dimOrganization
group by 
	CatchmentID, Catchment
Union
select	-1, -1, 'Unknown'