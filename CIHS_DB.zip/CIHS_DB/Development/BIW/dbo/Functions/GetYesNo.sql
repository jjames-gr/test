


CREATE FUNCTION [dbo].[GetYesNo] 
(	
	@FullText varchar(max)
)
RETURNS varchar(20)  
AS
/*------------------------------------------------------------------------------
-- Title:	GetYesNo
-- File:	[dbo].[GetYesNo]
-- Author:	Brian Angelo
-- Date:	9/9/2013
-- Desc:	Removes all text to the left of the last space
--			This is done to get just the yes and no of the junk value field
--			
-- CalledBy:
-- 		Reports: "RI CI By Provider Summary"
--
-- 		Stored Procs: Rep.RICIByProviderSummary
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			Description
-- ---		----------	---------------		----------------------------
-- 1.0	  	09/9/2013  Brian Angelo		initial creation
--------------------------------------------------------------------------------*/
BEGIN

DECLARE @Result varchar(20)
SET @Result = SUBSTRING(@FullText,len(@FullText)-charindex(' ',REVERSE(@FullText))+2,len(@FullText)-charindex(' ',REVERSE(@FullText)))
RETURN @Result
END



