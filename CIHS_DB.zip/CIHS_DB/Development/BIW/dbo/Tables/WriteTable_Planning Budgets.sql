﻿CREATE TABLE [dbo].[WriteTable_Planning Budgets] (
    [BudgetAmount_0]      FLOAT (53)     NULL,
    [BudgetSK_1]          INT            NULL,
    [GLAccountSK_2]       INT            NULL,
    [ServiceSummaryID_3]  INT            NULL,
    [CatchmentID_4]       INT            NULL,
    [FiscalYear_5]        SMALLINT       NULL,
    [FiscalMonthInYear_6] TINYINT        NULL,
    [MS_AUDIT_TIME_7]     DATETIME       NULL,
    [MS_AUDIT_USER_8]     NVARCHAR (255) NULL
);

