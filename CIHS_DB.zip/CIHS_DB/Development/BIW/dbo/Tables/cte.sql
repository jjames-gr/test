﻿CREATE TABLE [dbo].[cte] (
    [ConsumerSK] INT          NOT NULL,
    [auth_id]    VARCHAR (16) NULL
);

