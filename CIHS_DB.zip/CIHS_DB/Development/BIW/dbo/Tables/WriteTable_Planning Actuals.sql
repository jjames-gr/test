﻿CREATE TABLE [dbo].[WriteTable_Planning Actuals] (
    [PlanningActual_0]    FLOAT (53)     NULL,
    [ServiceSummaryID_1]  INT            NULL,
    [CatchmentID_2]       INT            NULL,
    [GLAccountSK_3]       INT            NULL,
    [FiscalYear_4]        SMALLINT       NULL,
    [FiscalMonthInYear_5] TINYINT        NULL,
    [MS_AUDIT_TIME_6]     DATETIME       NULL,
    [MS_AUDIT_USER_7]     NVARCHAR (255) NULL
);

