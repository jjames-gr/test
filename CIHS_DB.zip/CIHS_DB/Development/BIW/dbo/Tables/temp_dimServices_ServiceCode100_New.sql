﻿CREATE TABLE [dbo].[temp_dimServices_ServiceCode100_New] (
    [ServicesSK]          INT NULL,
    [ServicesNK]          INT NULL,
    [ServiceDefinitionID] INT NULL
);

