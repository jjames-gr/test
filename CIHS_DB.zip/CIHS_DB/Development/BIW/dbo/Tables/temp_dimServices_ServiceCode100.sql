﻿CREATE TABLE [dbo].[temp_dimServices_ServiceCode100] (
    [ServicesSK]          INT NULL,
    [ServicesNK]          INT NULL,
    [ServiceDefinitionID] INT NULL
);

