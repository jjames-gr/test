﻿
create procedure [csp_report_statecomprehensive_exception]
as

select distinct
	a.ConsumerSK
	, a.LastName
	, a.FirstName
	, a.MiddleName
from
	[BIW].[DW].[dimConsumers] a
	inner join [BIW].[DW].[factClaims] b on a.ConsumerSK = b.ConsumerSK
where
	b.BenefitPlanSK = 0
order by
	a.ConsumerSK