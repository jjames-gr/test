﻿CREATE SCHEMA [DWV]
    AUTHORIZATION [dbo];












GO
GRANT VIEW CHANGE TRACKING
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT VIEW DEFINITION
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT UPDATE
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT TAKE OWNERSHIP
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT SELECT
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT REFERENCES
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT INSERT
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT EXECUTE
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT DELETE
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT CONTROL
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];


GO
GRANT ALTER
    ON SCHEMA::[DWV] TO [PBHC\BIW Access]
    AS [dbo];

