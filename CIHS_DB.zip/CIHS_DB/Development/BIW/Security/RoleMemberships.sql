﻿EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'PBHC\SQLServerSVS';


GO
EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'PBHC\SQLAgentSVS';


GO
EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'PBHC\svc_SPFarmAdmin';

