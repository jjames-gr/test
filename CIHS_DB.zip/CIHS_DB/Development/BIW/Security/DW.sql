﻿CREATE SCHEMA [DW]
    AUTHORIZATION [dbo];



















