﻿CREATE USER [PBHC\svc_SPFarmAdmin] FOR LOGIN [PBHC\svc_SPFarmAdmin];



