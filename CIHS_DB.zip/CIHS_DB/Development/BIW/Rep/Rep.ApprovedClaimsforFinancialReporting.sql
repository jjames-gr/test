USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ApprovedClaimsforFinancialReporting]    Script Date: 08/26/2013 15:22:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO














-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ApprovedClaimsforFinancialReporting]
	@Status int, /* 1 = Approved, 2 = Paid */
	@StartDate datetime,
	@EndDate datetime,
	@Catchment int,
	@BenefitPlan int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	/*
	/****Test Parameters****/
	DECLARE @Status int, /* 1 = Approved, 2 = Paid */
			@StartDate datetime,
			@EndDate datetime,
			@Catchment int,
			@BenefitPlan int
			
	SET @Status = 1
	SET @StartDate = '7/1/13'
	SET @EndDate = '7/31/13'
	SET @Catchment = -300
	SET @BenefitPlan = -1
	--*/

	DECLARE @Counter int = 29, 
			@Max int = 34
			
	IF OBJECT_ID('tempdb..#tempApprovedStatus') IS NOT NULL
		DROP TABLE #tempApprovedStatus

	CREATE TABLE #tempApprovedStatus(ApprovedStatus int)

	WHILE @Counter <= @Max
		BEGIN
			INSERT INTO #tempApprovedStatus VALUES (@Counter)
			SET @Counter = @Counter + 1
		END

	--If Paid only remove unpaid statuses
	IF @Status = 2
		DELETE FROM #tempApprovedStatus WHERE ApprovedStatus IN (29,30,31)

	IF OBJECT_ID('tempdb..#tempInsurances') IS NOT NULL
		DROP TABLE #tempInsurances

	SELECT DISTINCT InsurerID INTO #tempInsurances FROM [BIW].[DW].[dimBenefitPlan] WHERE InsurerID IN (-1,1,2,99)

	/* Remove InsuranceID's based on Benefit Plan parameter */
	/* Only Medicaid */
	IF @BenefitPlan = 1 
		DELETE FROM #tempInsurances WHERE InsurerID != 2

	/* Not Medicaid */
	IF @BenefitPlan = 2
		DELETE FROM #tempInsurances WHERE InsurerID = 2

IF @Status = 1 
BEGIN

	SELECT 
	MasterDate, 
	MasterDateMonth, 
	MasterDateYear, 
	DateofService, 
	DateofServiceMonth, 
	DateofServiceYear, 
	Catchment, 
	ClaimStatus, 
	COUNT(DISTINCT ClaimAdjudicationNumber) as ClaimCount,
	SUM(ClaimAmount)  as ClaimAmount
	FROM
	(
		SELECT 
		ddDOS.[MonthAndYearAbbr_en-US] as DateOfService
		,ddDOS.MonthInYear as DateOfServiceMonth
		,ddDos.YearValue as DateOfServiceYear
		,ddAD.[MonthAndYearAbbr_en-US] as MasterDate
		,ddAD.[MonthInYear]  as MasterDateMonth
		,ddAD.[YearValue] as MasterDateYear
		,catchment.Catchment
		,CASE WHEN fac.ApprovedStatusSK IN (29,30,31) THEN 'UNPAID' ELSE 'PAID' END as ClaimStatus
		,fac.ApprovedClaimAmount as ClaimAmount
		,fch.ClaimAdjudicationNumber
		FROM [BIW].[DW].[factClaimsHistorical] fch
		LEFT JOIN [BIW].[DW].[factApprovedClaims] fac WITH(NOLOCK) ON fac.factClaimsHistoricalSK = fch.factClaimsHistoricalSK
		LEFT JOIN #tempApprovedStatus tas WITH(NOLOCK) ON tas.ApprovedStatus = fac.ApprovedStatusSK
		INNER JOIN [BIW].[DW].[dimDate] ddAD WITH(NOLOCK) ON ddAD.DateSK = fac.ApprovedTRansactionDateSK
		INNER JOIN [BIW].[DW].[dimDate] ddPD WITH(NOLOCK) ON ddPD.DateSK = fch.PaidDateSK
		INNER JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fch.DateOfServiceSK
		INNER JOIN [BIW].[DW].[dimOrganization] catchment WITH(NOLOCK) ON catchment.OrganizationSK = fch.OrganizationSK
		INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fch.BenefitPlanSK
		INNER JOIN #tempInsurances ti WITH(NOLOCK) ON ti.InsurerID = dbp.InsurerID
		WHERE 
		ddAD.DateValue BETWEEN @StartDate AND @EndDate
		AND fch.StatusSK IN (1,2,4,5)
		AND (catchment.CatchmentID = @Catchment OR @Catchment = -300)
	) a
	GROUP BY
	MasterDate, 
	MasterDateMonth, 
	MasterDateYear, 
	DateofService, 
	DateofServiceMonth, 
	DateofServiceYear, 
	Catchment, 
	ClaimStatus
END

IF @Status = 2
BEGIN

	SELECT 
	MasterDate, 
	MasterDateMonth, 
	MasterDateYear, 
	DateofService, 
	DateofServiceMonth, 
	DateofServiceYear, 
	Catchment, 
	ClaimStatus, 
	COUNT(ClaimAdjudicationNumber) as ClaimCount,
	SUM(ClaimAmount)  as ClaimAmount
	FROM
	(
		SELECT DISTINCT
		ddDOS.[MonthAndYearAbbr_en-US] as DateOfService
		,ddDOS.MonthInYear as DateOfServiceMonth
		,ddDos.YearValue as DateOfServiceYear
		,ddPD.[MonthAndYearAbbr_en-US] as MasterDate
		,ddPD.[MonthInYear] as MasterDateMonth
		,ddPD.[YearValue] as MasterDateYear
		,catchment.Catchment
		,CASE WHEN fac.ApprovedStatusSK IN (29,30,31) THEN 'UNPAID' ELSE 'PAID' END as ClaimStatus
		,fch.PaidAmount as ClaimAmount
		,fch.ClaimAdjudicationNumber
		FROM [BIW].[DW].[factClaimsHistorical] fch
		LEFT JOIN [BIW].[DW].[factApprovedClaims] fac WITH(NOLOCK) ON fac.factClaimsHistoricalSK = fch.factClaimsHistoricalSK
		LEFT JOIN #tempApprovedStatus tas WITH(NOLOCK) ON tas.ApprovedStatus = fac.ApprovedStatusSK
		LEFT JOIN [BIW].[DW].[dimDate] ddAD WITH(NOLOCK) ON ddAD.DateSK = fac.ApprovedTRansactionDateSK
		INNER JOIN [BIW].[DW].[dimDate] ddPD WITH(NOLOCK) ON ddPD.DateSK = fch.PaidDateSK
		INNER JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fch.DateOfServiceSK
		INNER JOIN [BIW].[DW].[dimOrganization] catchment WITH(NOLOCK) ON catchment.OrganizationSK = fch.OrganizationSK
		INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fch.BenefitPlanSK
		INNER JOIN #tempInsurances ti WITH(NOLOCK) ON ti.InsurerID = dbp.InsurerID
		WHERE 
		ddPD.DateValue BETWEEN @StartDate AND @EndDate
		AND fch.PaidSK = 9
		AND (catchment.CatchmentID = @Catchment OR @Catchment = -300)
	) a
	GROUP BY
	MasterDate, 
	MasterDateMonth, 
	MasterDateYear, 
	DateofService, 
	DateofServiceMonth, 
	DateofServiceYear, 
	Catchment, 
	ClaimStatus
	
END


END














GO


