USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ProviderAndLinkedClinicianNPI]    Script Date: 08/05/2013 08:23:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO













CREATE PROCEDURE [REP].[ProviderAndLinkedClinicianNPI]
    (
		@ProviderID varchar(100)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Provider NPI and Linked Clinician NPI
-- File:	[REP].[ProviderAndLinkedClinicianNPI]
-- Author:	Divya Lakshmi
-- Date:	05/21/2013
-- Desc:	Report to display all clinicians linked to that 
--          provider in the system.			
--                                          
-- CalledBy:
--          Reports: FIN012 - ProviderAndClinicianNPI.rdl
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		05/21/2013  Divya Lakshmi	6488	  Created
--------------------------------------------------------------------------------
*/

--DECLARE @ProviderID varchar(100)
--	SET @ProviderID=-2
	
select distinct 
 p1.ProviderNK,
 p1.ProviderName,
 n.NPINumber,
 n.NPIDescription,
 c.ClinicianNK,
 c.LastName + ', ' +c.FirstName As ClinicianName,
 c.NPI as CLIN_NPI,
 eff.DateValue AS ClinicianProviderEffectiveDate,
 expdt.DateValue AS ClinicianProviderExpireDate

from dw.dimProvider p1 inner join dw.dimProvider p on p.ParentProviderNK = p1.ProviderNK
 left outer join dw.factClinicianProvider cp on p.ProviderSK = cp.ProviderSK 
 left outer join dw.dimClinician c on c.ClinicianSK = cp.ClinicianSK and c.Active = 1
 left outer join dw.factProviderNPIMedicaidID n on n.ProviderSK = p.ProviderSK and n.ActiveFlag = 1
 left outer join DW.dimDate eff with(nolock) ON cp.ClinicianProviderEffectiveDateSK = eff.DateSK
 left outer join DW.dimDate expdt with(nolock) ON cp.ClinicianProviderExpireDateSK = expdt.DateSK

where
 p.Active = 1
 AND 	
		(
			(p.ProviderNK=@ProviderID) OR 
			( @ProviderID= -2 )
		)








GO


