﻿USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[FollowUpAfterCrisisService]    Script Date: 09/19/2013 09:14:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [REP].[FollowUpAfterCrisisService]
	@StartDate			datetime,
	@EndDate			datetime,
	@Catchment			varchar(50),
	@BenefitPlan		int,
	@DiagnosisGroup		int,
	@ServiceDefinition	int,
	@NumberOfDays		int
AS 
 /*-----------------------------------------------------------------------------
-- Title:  Follow-up After Crisis Service
-- File:    
-- Author:        Brian Angelo
-- Date: 7/1/2013
-- Desc:  [Rep].FollowUpAfterCrisisService
-- CalledBy:
--                           Reports: Follow-up After Hospitalization
--
--                           Stored Procs: None
	Notes:	
		Condition 1:	"Not Seen" means a publically-funded (Medicaid or IPRS) claim for services was not paid during the period reviewed.
						It is possible that these individuals may have received a service paid by another payer.
                       
		Condition 2:	Uses both Medicaid and State claims data for discharges
                       
		Condition 3:	The data excludes inpatient readmissions within 5 days of discharge from both the numerator and denominator.
						(Re)admissions to a community hospital that occur ≥ 6 days following discharge are included as a first service
						in the numerator.
                 
		Condition 4:	The data excludes as a first service following discharge: emergency department visits, mobile crisis (H2011), 
						admissions to a state facility, and inpatient CPT codes:
						ServiceNK's
						17,18,19,20,21,22,23,25,27,1192,1193,1194,1195,1196,1197,1198,1199,1200,1201,
						1221,1222,1223,1224,1226,1227,1277,1278,1279,1280,1281,1349,1350,1351,1352,1353,
						1354,1355,1356,1357,1415,1416,1417,1418,1419,1420,1421,1422,1423,1424,1425,1426,
						1427,1433,1434,1435,1436,1437,1438,1439,1440,1441,1442,1475,1476,2360,2361,2362,
						2363,2364,2393,2394,2933,2934,2935,2936
                 
		Condition 5:	Persons who received ACTT within the month of discharge are credited with having been seen in 2 days following
						discharge, regardless of the date of service on the claim.

--------------------------------------------------------------------------------
-- Change                History
-- Ver                   Date                     Author                     TixNo        Description
-- ---               ----------               ---------------				-----		--------------
-- 1.0                  7/29/2013				Brian Angelo                 8962 		 Initial Development
	
--------------------------------------------------------------------------------
*/

/**
/** Testing Parameters **/
DECLARE @StartDate			datetime,
		@EndDate			datetime,
		@Catchment			varchar(50),
		@BenefitPlan		int,
		@DiagnosisGroup		int,
		@ServiceDefinition	int,
		@NumberOfDays		int
		
SET @StartDate = '1/1/13'
SET @EndDate = '1/31/13'
SET @Catchment = -300
SET @BenefitPlan = -200
SET @DiagnosisGroup = -1
SET @ServiceDefinition = -2
SET @NumberOfDays = 2
--*/
 
-- Drop any existing temp tables
if object_id('tempdb..#InpatientStay') is not null
begin
	drop table #InpatientStay
end

if object_id('tempdb..#PatientsWithFollowup') is not null
begin
	drop table #PatientsWithFollowup
end 


IF(@NumberOfDays<30)
	SET @NumberOfDays = 30


-- Populate #InpatientStay with all Inpatient Hospitalization records
select distinct
	dc.ConsumerNK as ClientID
	, dc.LastName as ClientLastName
	, dc.FirstName as ClientFirstName
	, dc.MiddleName as ClientMiddleName
	, convert(char(10),dc.DOB,101) as DateOfBirth
	, dc.AgeValue as ClientAge
	, dc.County as ClientCounty
	, dbp.InsurerShort as Insurance
	, dg.DiagnosisGroupName as InpDiagnosisGroup
	, ddLOS.DateValue as InpDischargeDate
	, dp.ProviderName as InpProviderName
	, fc.ClaimNumber as InpClaimID
	, fc.ClaimDetailNumber as InpClailDetailID
	, ds.ServiceCode as InpServiceCode
	, ds.ServiceDescriptionShort as InpServiceDescription
	, ds.ServiceSummary as InpServiceSummary
	, DATEADD(dd, -(fLOS.LengthOfStay+1), ddLOS.DateValue) as InpClaimStartDate
	, ddLOS.DateValue as InpClaimEndDate
	, DOS.DateValue as InpDateOfService
	, CASE  WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'FBC') THEN 'Facility Based Crisis'
			WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK) 
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'Mobile') THEN 'Mobile Crisis'
			WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK) 
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'NonHospDetox') THEN 'Non-Hospital Detox'
			END as InpServiceType
	, do.OrganizationNK as InpCountyID
	, do.County as InpCounty
	, do.CatchmentID as InpCatchmentID
	, do.Catchment as InpCatchment
	, fLOS.LengthOfStay as InpLengthOfStay
	, ROW_NUMBER () OVER (PARTITION BY dc.ConsumerNK ORDER BY dc.ConsumerNK, ddDOS.DateValue) as InpRowNumber
INTO #InpatientStay
FROM [BIW].[DW].[factClaims] fc WITH(NOLOCK)
LEFT JOIN [BIW].[DW].[factLengthOfStay] fLOS WITH(NOLOCK) ON fLOS.ClaimAdjudicationNumber = fc.ClaimAdjudicationNumber
LEFT JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fc.DateOfServiceSK
LEFT JOIN [BIW].[DW].[dimDate] ddLOS WITH(NOLOCK) ON ddLOS.DateSK = fLOS.DateSK
INNER JOIN [BIW].[DW].[dimDate] DOS WITH(NOLOCK) ON DOS.DateSK = fc.DateOfServiceSK
INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fc.ProviderSK
INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fc.ConsumerSK
INNER JOIN [BIW].[DW].[dimDiagnosis] dg WITH(NOLOCK) ON dg.DiagnosisSK = fc.Diagnosis1SK
INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fc.OrganizationSK
INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
WHERE
      ds.ServicesNK in (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
						WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup') -- srvc_codes YP495, YP921, S9484, S9484HA, H2001HF, H0010
      --and ds.ServiceDefinitionID <> 10 --Don't include Emergency Department services
      and fc.StatusSK = 1 -- only approved records
      --Date of service for mobile crisis else use discharge date
      and CASE WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'Mobile') THEN DOS.DateValue ELSE ddLOS.DateValue END between @StartDate and @EndDate -- all claims between the start and end dates
      and ( @catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
      and ( @DiagnosisGroup = -1 or dg.DiagnosisGroupID = @DiagnosisGroup ) -- by diagnosis group (MH,SA,DD)
      and ( @BenefitPlan = -200 or dbp.BenefitPlanNK = @BenefitPlan or (dbp.InsurerID = 2 AND @BenefitPlan = -100) ) -- by insurer (medicaid or state comprehensive)
      and	--Service definition parameter
			(
			--Only 1 service definition
			(CASE  WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'FBC') THEN 1
			WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'Mobile') THEN 2
			WHEN ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'NonHospDetox')  THEN 3
			END = @ServiceDefinition )
			--Both FBC and Detox
			OR (ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND (CustomGroupValue = 'FBC' OR CustomGroupValue = 'NonHospDetox'))
			
				AND @ServiceDefinition = -1)
			--All service definitions
			OR (@ServiceDefinition = -2)
			
			) --End service definition parameter

--Update dates if mobile crisis service
UPDATE #InpatientStay SET
InpDischargeDate = InpDateOfService,
InpClaimStartDate = InpDateOfService,
InpClaimEndDate = InpDateOfService
WHERE InpServiceType = 'Mobile Crisis'

-- Per Condition 3, remove facility based crisis and non-hospital medical detox readmissions within 5 days from #InpatientStay
delete a
from #InpatientStay a
      left outer join #InpatientStay b on a.ClientID = b.ClientID and (a.InpRowNumber + 1) = b.InpRowNumber
where DATEDIFF(dd,a.InpDischargeDate,b.InpDischargeDate) <= 5

-- Populate #PatientsWithFollowup with patients from #InpatientStay who had a followup within the @numDays parameter range
select
	a.ClientID
	, a.InpRowNumber
	, a.FURowNumber
	, a.ClientLastName
	, a.ClientFirstName
	, a.ClientMiddleName
	, a.ClientAge
	, a.ClientCounty
	, a.DateOfBirth 
	, a.Insurance
	, a.InpDiagnosisGroup
	, a.InpDischargeDate
	, a.InpProviderName
	, a.InpClaimID
	, a.InpClailDetailID
	, a.InpServiceCode
	, a.InpServiceDescription
	, a.InpServiceSummary
	, a.InpClaimStartDate
	, a.InpClaimEndDate
	, a.InpServiceType
	, a.InpCountyID
	, a.InpCounty
	, a.InpCatchmentID
	, a.InpCatchment
	, a.FUClaimID
	, a.FUClaimDetailID
	, a.FUProviderName
	, a.FUProviderID
	, a.FUDiagnosisGroup
	, a.FUServiceID
	, a.FUServiceCode
	, a.FUServiceDescription
	, a.FUServiceSummary
	, a.FUDOS
	, a.FUCountyID
	, a.FUCounty
	, a.FUCatchmentID
	, a.FUCatchment
	, a.DaysUntilFollowup
into #PatientsWithFollowup
from
	(
	select
		inp.ClientID
		, inp.InpRowNumber
		, inp.ClientLastName
		, inp.ClientFirstName
		, inp.ClientMiddleName
		, inp.ClientAge
		, inp.ClientCounty
		, inp.DateOfBirth 
		, inp.Insurance
		, inp.InpDiagnosisGroup
		, inp.InpDischargeDate
		, inp.InpProviderName
		, inp.InpClaimID
		, inp.InpClailDetailID
		, inp.InpServiceCode
		, inp.InpServiceDescription
		, inp.InpServiceSummary
		, inp.InpClaimStartDate
		, inp.InpClaimEndDate
		, inp.InpServiceType
		, inp.InpCountyID
		, inp.InpCounty
		, inp.InpCatchmentID
		, inp.InpCatchment
		, fc.ClaimNumber as FUClaimID
		, fc.ClaimDetailNumber as FUClaimDetailID
		, dp.ProviderName as FUProviderName
		, dp.ProviderNK as FUProviderID
		, dd.DiagnosisGroup as FUDiagnosisGroup
		, ds.ServicesNK as FUServiceID
		, ds.ServiceCode as FUServiceCode
		, ds.ServiceDescription as FUServiceDescription
		, ds.ServiceSummary as FUServiceSummary
		, ddDOS.DateValue as FUDOS
		, do.OrganizationNK as FUCountyID
		, do.County as FUCounty
		, do.CatchmentID as FUCatchmentID
		, do.Catchment as FUCatchment
		, DATEDIFF(dd,inp.InpDischargeDate,ddDOS.DateValue) as DaysUntilFollowup
		, ROW_NUMBER () OVER (PARTITION BY inp.ClientID,inp.InpDischargeDate ORDER BY inp.ClientID, ddDOS.DateValue) as FURowNumber
	FROM
	#InpatientStay inp 
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerNK = inp.ClientID
	INNER JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK) ON  fc.ConsumerSK = dc.ConsumerSK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd WITH(NOLOCK) ON dd.DiagnosisSK = fc.Diagnosis1SK
	INNER JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fc.DateOfServiceSK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fc.ProviderSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fc.OrganizationSK
where 1=1
		and ds.ServiceSummaryID <> 10
		and inp.InpClaimID <> fc.ClaimNumber
		and fc.StatusSK = 1 -- approved
		and ddDOS.DateValue between DATEADD(dd,1,inp.InpDischargeDate) and DATEADD(dd,@NumberOfDays,inp.InpDischargeDate)
		--Followup service for mobile crisis can not be another mobile crisis service
		and CASE WHEN inp.InpServiceType = 'Mobile Crisis' THEN ds.ServiceCode ELSE '9999999999' END
			NOT IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'CrisisServiceFollowupCustomGroup'
										AND CustomGroupValue = 'Mobile')
	) a
where a.FURowNumber = 1


insert into #PatientsWithFollowup
select
	inp.ClientID
	, inp.InpRowNumber
	, pwf.FURowNumber
	, inp.ClientLastName
	, inp.ClientFirstName
	, inp.ClientMiddleName
	, inp.ClientAge
	, inp.ClientCounty
	, inp.DateOfBirth 
	, inp.Insurance
	, inp.InpDiagnosisGroup
	, inp.InpDischargeDate
	, inp.InpProviderName
	, inp.InpClaimID
	, inp.InpClailDetailID
	, inp.InpServiceCode
	, inp.InpServiceDescription
	, inp.InpServiceSummary
	, inp.InpClaimStartDate
	, inp.InpClaimEndDate
	, inp.InpServiceType
	, inp.InpCountyID
	, inp.InpCounty
	, inp.InpCatchmentID
	, inp.InpCatchment
	, IsNull(pwf.FUClaimID,'')
	, IsNull(pwf.FUClaimDetailID,'')
	, IsNull(pwf.FUProviderName,'')
	, IsNull(pwf.FUProviderID,'')
	, IsNull(pwf.FUDiagnosisGroup, '')
	, IsNull(pwf.FUServiceID,'')
	, IsNull(pwf.FUServiceCode,'')
	, IsNull(pwf.FUServiceDescription,'')
	, IsNull(pwf.FUServiceSummary,'')
	, IsNull(pwf.FUDOS,'')
	, IsNull(pwf.FUCountyID,'')
	, IsNull(pwf.FUCounty,'')
	, IsNull(pwf.FUCatchmentID, -1)
	, IsNull(pwf.FUCatchment, '')
	, IsNull(pwf.DaysUntilFollowup,'')
from
	#InpatientStay inp 
	left outer join #PatientsWithFollowup pwf on inp.ClientID = pwf.ClientID
											 and inp.InpClaimID = pwf.InpClaimID
where
	pwf.FUClaimID is null

--Per condition 5
update #PatientsWithFollowup set
DaysUntilFollowup = 2
WHERE DaysUntilFollowup BETWEEN 2 AND 30
AND FUServicecode = 'H0040'

update #PatientsWithFollowup set
DaysUntilFollowup = -1
where FURowNumber is null

--Display results
select
	* 
from
#PatientsWithFollowup a

















GO


