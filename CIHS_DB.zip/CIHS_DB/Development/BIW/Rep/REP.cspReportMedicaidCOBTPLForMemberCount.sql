use BIW
GO

CREATE PROCEDURE [REP].[cspReportMedicaidCOBTPLForMemberCount] 
	@end_dt datetime
AS

/*------------------------------------------------------------------------------
-- Title:	Medicaid COB and TPL
-- File:	[Rep].[cspReportMedicaidCOBTPLForMemberCount]
-- Author:	Tim Amerson
-- Date:	08/16/2013
-- Desc:	COB and TPL counts for Medicaid
--			
-- CalledBy:
-- 		Reports: "Medicaid COB and TPL"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/16/2013  Tim Amerson			8510	initial creation
--------------------------------------------------------------------------------*/

SELECT
	COBMemberCount = COUNT(DISTINCT dc.consumernk)
	,COBInsuranceType =
		CASE
			WHEN cob.COBOtherInsurance LIKE '%Medicare%' THEN 'Medicare'
			ELSE 'Commercial'
		END
FROM
	dw.factcob cob WITH(NOLOCK)
	INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON cob.ConsumerSK = dc.ConsumerSK
	INNER JOIN dw.dimDate dExp WITH(NOLOCK) ON cob.COBExpirationDateSK = dexp.DateSK
	
	INNER JOIN dw.dimConsumers cElig WITH(NOLOCK) ON dc.ConsumerNK = cElig.ConsumerNK
	INNER JOIN dw.factEligibility fe WITH(NOLOCK) ON cElig.ConsumerSK = fe.ConsumerSK
	INNER JOIN dw.dimBenefitPlan bp WITH(NOLOCK) ON fe.BenefitPlanSK = bp.BenefitPlanSK
	INNER JOIN dw.dimDate dElig WITH(NOLOCK) ON fe.ExpirationDateSK = dElig.DateSK
	
WHERE
	dExp.DateValue >= @end_dt
	AND dElig.DateValue >= @end_dt
	AND bp.InsurerID = 2
	
GROUP BY
	CASE
		WHEN cob.COBOtherInsurance LIKE '%Medicare%' THEN 'Medicare'
		ELSE 'Commercial'
	END