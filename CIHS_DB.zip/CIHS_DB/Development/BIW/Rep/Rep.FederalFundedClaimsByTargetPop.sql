USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[FederalFundedClaimsByTargetPop]    Script Date: 07/11/2013 13:57:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [Rep].[FederalFundedClaimsByTargetPop]
@StartDate DateTime,
@EndDate DateTime ,
@Provider int,
@BenefitPlan int
AS

/*------------------------------------------------------------------------------
	Title:		Federal Funded claims by Target Pop (DOS)				
	File:		[Rep].[FederalFundedClaimsByTargetPop]
	Author:		Kevin Hamilton	
	Date:		08/5/2013
	Desc:		To compare CI State funded claims to results of claims submitted to IPRS by date of service.	
			

                                        
	Called By:
                        Reports:        CLM025-FederalFundedClaimsByTargetPop.rdl
			


                       
	-----------------------------------------------------------------------------------
	Version History:()
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/5/2013		Kevin Hamilton     		8942			Created

--------------------------------------------------------------------------------------*/


--DECLARE @StartDate DateTime,
--		@EndDate DateTime ,
--		@Provider int,
--		@BenefitPlan int
--SET	@StartDate = '2/1/2012'
--SET	@EndDate = '2/24/2012'
--SET @Provider = -2 
--SET @BenefitPlan = -2


SELECT
p.ProviderName,
p.ProviderNK ProviderID,
c.ConsumerNK ConsumerID,
c.FullName ConsumerName,
clin.NPI,
clin.FullName ClinicianName,
fc.claimNumber,
dd.DateValue DateOfService,
s.ServiceCode,
fc.UnitsBilled,
fc.ClaimAmount BilledAmount,
fc.AdjudicatedAmount ApprovedAmount  ,
fc.AdjustedAmount DeniedAmount

FROM
DW.factClaims fc with(nolock) 
INNER JOIN DW.dimProvider p with(nolock) ON p.ProviderSK = fc.ProviderSK 
INNER JOIN DW.dimConsumers c with(nolock) ON c.ConsumerSK = fc.ConsumerSK 
INNER JOIN DW.dimClinician clin with(nolock) ON clin.ClinicianSK = fc.ClinicianSK 
INNER JOIN DW.dimServices s with(nolock) ON s.ServicesSK = fc.ServicesSK
INNER JOIN DW.dimBenefitPlan bp with(nolock) ON bp.BenefitPlanSK = fc.BenefitPlanSK 
INNER JOIN DW.dimDate dd with(nolock) ON fc.DateOfServiceSK = dd.DateSK
WHERE 
(dd.DateValue > @StartDate 
AND dd.DateValue < @EndDate)
--AND ( @BenefitPlan = bp.BenefitPlanNK  OR -- 1 specific Plan
--	  @BenefitPlan = -100 AND bp.InsurerID = 2  OR -- ALL Medicaid
--	  @BenefitPlan = -200 )-- ALL PLANS
--AND(
--		p.ProviderNK=@Provider OR 
--			@Provider= -2 
--	)
AND c.ConsumerNK <> -1




