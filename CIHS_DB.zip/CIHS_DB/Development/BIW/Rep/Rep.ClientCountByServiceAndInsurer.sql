USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ClientCountByServiceAndInsurer]    Script Date: 09/19/2013 14:22:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [REP].[ClientCountByServiceAndInsurer]
@str_dt datetime,
@end_dt datetime,
@catchment int 
   
AS

/*------------------------------------------------------------------------------
	Title:		Client Count by Service and Insurer			

	File:		[Rep].[ClientCountByServiceAndInsurer]
	Author:		Kevin Hamilton	
	Date:		05/13/2013
	Desc:		Client Count by Service and Insurer			

                                        
	Called By:
                        Reports:         Client Count by Service and Insurer			


                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/13/2013		Kevin Hamilton     		6344			Created

	-----------------------------------------------------------------------------------*/
--DECLARE     @str_dt datetime,
--            @end_dt datetime,
--            @catchment int
    
            
--SET @str_dt = '1/1/13'
--SET @end_dt = '1/31/13'
--SET @catchment = -300


If Object_ID('tempdb.dbo.#Counts') IS NOT NULL
	DROP TABLE #tempCounts



	SELECT DISTINCT
	bfp.InsurerShort,
	ds.ServiceSummary, 
	ds.ServiceDescription,
	ds.ServiceCode,
	dc.ConsumerNK,
	ddDos.DateValue,
	dc.DOB,
	CASE WHEN DATEDIFF(year, dc.DOB, ddDOS.DateValue) < '18' and InsurerShort = 'State' THEN 'Child'
		  WHEN DATEDIFF(year, dc.DOB, ddDOS.DateValue) >= '18' and InsurerShort = 'State' THEN 'Adult'
		  WHEN DATEDIFF(year, dc.DOB, ddDOS.DateValue) < '21' and InsurerShort = 'Medicaid' THEN 'Child'
		  WHEN DATEDIFF(year, dc.DOB, ddDOS.DateValue) >= '21' and InsurerShort = 'Medicaid' THEN 'Adult'
	END As AgeGroup,
	dd1.DiagnosisGroup
	INTO #temp1
	FROM [BIW].[DW].[factClaims] fc
	INNER JOIN [BIW].[DW].[dimServices] ds with(nolock) ON ds.ServicesSK = fc.ServicesSK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd1 with(nolock) ON dd1.DiagnosisSK = fc.Diagnosis1SK
	INNER JOIN [BIW].[DW].[dimConsumers] dc with(nolock) ON dc.ConsumerSK = fc.ConsumerSK
	INNER JOIN [BIW].[DW].[dimDate] ddDOS with(nolock) ON ddDOS.DateSK = fc.DateOfServiceSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan]bfp with(nolock) ON bfp.BenefitPlanSK = fc.BenefitPlanSK 
	INNER JOIN dw.dimOrganization AS dorg with(nolock) ON fc.OrganizationSK = dorg.OrganizationSK
	WHERE 
		ddDos.DateValue between @str_dt and @end_dt
		AND ( @catchment = -2 OR -- All Catchments
			  dorg.CatchmentID = @catchment  -- Specific Catchment
			)
		AND dd1.DiagnosisGroup In ('DD', 'MH', 'SA', 'AO')
		AND dc.ConsumerSK <> -1
		AND ds.ServiceDefinitionID <> -1
		AND dc.Active = 1
		AND InsurerShort <> 'Unknown'
		AND fc.StatusSK = 1
		
		
		ORDER BY InsurerShort, dc.ConsumerNK
		
	SELECT  InsurerShort,
            ServiceSummary,
            DiagnosisGroup,
            AgeGroup,
            COUNT(DISTINCT ( ConsumerNK )) cnt ,
            0 AS Totals
    INTO    #temp2
    FROM    #temp1
	group by InsurerShort,
            ServiceSummary,
            DiagnosisGroup,
            AgeGroup
            
      INSERT  INTO #temp2
            SELECT  InsurerShort ,
                    'Total' ServiceSummary ,
                    DiagnosisGroup ,
                    AgeGroup ,
                    COUNT(DISTINCT ( ConsumerNK )) cnt ,
                    0
            FROM    #temp1
            GROUP BY InsurerShort ,
                    DiagnosisGroup,
                    AgeGroup;      
            
        ;WITH    cte_distCount
                  AS ( SELECT   InsurerShort ,
                                ServiceSummary,
                                COUNT(DISTINCT ( ConsumerNK )) cnts
                       FROM     #temp1
                       GROUP BY InsurerShort ,
                                ServiceSummary
                     )
UPDATE  t
SET     t.Totals = t2.cnts
FROM    cte_distCount t2 ,
        ( SELECT    InsurerShort ,
                    ServiceSummary,
                    Totals ,
                    RANK() OVER ( PARTITION BY InsurerShort, ServiceSummary ORDER BY NEWID() ) rank
          FROM      #temp2
        ) t
WHERE   t2.InsurerShort = t.InsurerShort
        AND t2.ServiceSummary = t.ServiceSummary
        AND rank = 1;
        WITH    cte_distCountTotal
                  AS ( SELECT   InsurerShort ,
                                ServiceSummary ,
                                SUM(cnt) cnts
                       FROM     #temp2
                       WHERE    ServiceSummary = 'Total'
                       GROUP BY InsurerShort ,
                                ServiceSummary
                                )
                                
                                
                                
                                
UPDATE  t
SET     t.Totals = t2.cnts
FROM    cte_distCountTotal t2 ,
        ( SELECT    InsurerShort ,
                    ServiceSummary ,
                    Totals ,
                    RANK() OVER ( PARTITION BY InsurerShort, ServiceSummary ORDER BY NEWID() ) rank
          FROM      #temp2
        ) t
WHERE   t2.InsurerShort = t.InsurerShort
        AND t2.ServiceSummary = t.ServiceSummary
        AND rank = 1
        AND t.ServiceSummary = 'Total'


    SELECT  *
    FROM    #temp2



    DROP TABLE #temp1
    DROP TABLE #temp2

