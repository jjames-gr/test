USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[CWaiverAnnual]    Script Date: 07/16/2013 13:08:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO










CREATE PROCEDURE [REP].[CWaiverAnnual]
	@str_dt	datetime,
	@end_dt datetime,
	@catchment nvarchar(50)
AS
/*------------------------------------------------------------------------------
-- Title:	C Waiver Annual Report
-- File:	Rep.CWaiverAnnual
-- Author:	Brian Angelo
-- Date:	05/29/2013
-- Desc:	C Waiver Annual Report stored proc
--			
-- CalledBy:
-- 		Reports: "C Waiver Annual Report"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	05/29/2013  Brian Angelo		6287	initial creation
--------------------------------------------------------------------------------*/
BEGIN

	SET NOCOUNT ON;

	/* Testing Parameters
    DECLARE @catchment nvarchar(50),
		@str_dt	datetime,
		@end_dt datetime
		
	SET @catchment = '1021,1022,1023,1024'--'-300'
	SET @str_dt = '1/1/12'
	SET @end_dt = '12/31/12'
	--*/

    
    SELECT DISTINCT
	do.Catchment, 
	do.County, 
	fc.ClaimNumber,
	CASE WHEN IsNull(fc.PaidAmount,0) != 0 THEN 1 ELSE 0 END as AuthorizedAndPaid
	FROM [BIW].[DW].[factAuthorizations] fa
	INNER JOIN [BIW].[DW].[factClaims] fc WITH (NOLOCK) ON fc.AuthorizationNumber = fa.AuthorizationNumber
	INNER JOIN [BIW].[DW].[dimDate] dd WITH (NOLOCK) ON dd.DateSK = fa.CreateDateSK 
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH (NOLOCK) ON dbp.BenefitPlanSK = fa.BenefitPlanSK						
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH (NOLOCK) ON fc.OrganizationSK = do.OrganizationSK 
	INNER JOIN [BIW].[DW].[dimServices] ds WITH (NOLOCK) ON ds.ServicesSK = fc.ServicesSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH (NOLOCK) ON dp.ProviderSK = fc.ProviderSK
	WHERE dd.DateValue BETWEEN @str_dt AND @end_dt
	AND dbp.BenefitPlanNK = 4
	AND (@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				)
	AND ds.ServicesNK NOT IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WHERE CustomGroupName = 'CWaiverAnnualServices')
	AND dp.ProviderNK NOT IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WHERE CustomGroupName = 'CWaiverAnnualProvider')


END









GO


