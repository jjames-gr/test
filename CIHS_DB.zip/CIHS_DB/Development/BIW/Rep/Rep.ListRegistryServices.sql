USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListRegistryServices] AS

	/*------------------------------------------------------------------------------
	Title:		List Registry Services
	File:		rep.ListRegistryServices
	Author:		Doug Cox
	Date:		08/20/2013
	Desc:		This listing of Registry services can be used to fill the available 
					values for a registry service Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/20/2013		Doug Cox				6509			Created
			1.1		09/17/2013		Doug Cox				6509			Added 'Awaiting Innovations'
	
	Usage directions:
	--Declare variable as VARCHAR(MAX)
	-- Add the following to your WHERE CLAUSE:
		
		AND ( 
			( fRWL.AwaitingInnovationsFlag = 0 AND dS.ServicesNK IN ( SELECT fn.element FROM dbo.cfn_split(@RegistryService , ',') AS fn ) )
			OR ( fRWL.AwaitingInnovationsFlag = 1 AND -400 IN ( SELECT fn.element FROM dbo.cfn_split(@RegistryService , ',') AS fn ) )
			)

	-----------------------------------------------------------------------------------*/
SELECT	DISTINCT 
		ds.ServicesNK AS ServiceID,
		ds.ServiceDescription AS ServiceDesc
FROM	DW.factRegistryWaitingList AS fRWL with(nolock)
		INNER JOIN dw.dimServices ds WITH(NOLOCK) ON ds.ServicesSK = fRWL.ServicesSK
UNION
SELECT	-400 AS ServiceID,
		'Awaiting Innovations' AS ServiceDesc
ORDER BY ServiceID