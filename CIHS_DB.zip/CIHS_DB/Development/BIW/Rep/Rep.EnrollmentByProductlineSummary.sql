USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [Rep].[EnrollmentByProductlineSummary]

@strDate datetime ,
@endDate datetime,
@insurance int,
@Catchment varchar(max)

AS
/*------------------------------------------------------------------------------
	Title:		Enrollment by Product Line Summary

	File:		[EnrollmentByProductlineSummary]
	Author:		Karen Roslund
	Date:		8/9/2013
	Desc:		Summary for the enrollment by Product Line			
                                        
	Called By:
                        Reports:          Coming Soon....
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		8/9/2013		Karen Roslund    			6539			Created
			1.1     9/19/2013       Karen Roslund               6539            Changed memeber months logic to use tim's logic and added detail to the report.

--	-----------------------------------------------------------------------------------*/


--declare 
--@strDate DATETIME ='1/1/13',
--	@endDate DATETIME = '9/30/13',
--	@srcDef INT = -300,
--	@insurance INT = -100,
--	@diagCat INT = 4,
--	@catchment NVARCHAR(MAX) = '-300'

--Consumer ID	DW.dimConsumers.ConsumerNK
--Consumer Name	DW.dimConsumers.FullName
--Age 1	DW.dimConsumers.AgeValue
--Age 2	DW.dimConsumers.AgeValue
--Gender	DW.dimConsumers.Gender
--DOB	DW.dimConsumers.DOB
--Benefit Plan	DW.dimBenefitPlan
--Medicaid Aid Category	DW.dimMediciadAidCategory.CategoryName
--Member months Contribution Age 1	SUM(Total number of months of eligibility for each Consumer)
--Member months Contribution Age 2	SUM(Total number of months of eligibility for each Consumer)


select distinct
  
	dc.ConsumerNK as Consumer_ID,
	dc.FullName as Consumer_Name,
	Gender =
		CASE
			WHEN dc.Gender = 'Unspecified' THEN 'Unknown'
			ELSE dc.Gender
		END,
	delig.DateValue  dateelig,
	dbp.InsurerID,
	dbp.InsurerShort, 
		dc.DOB,
	1 as member_count,
	AgeValue =
		CASE
			WHEN datepart(mm,dc.DOB) <> datepart(mm,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
			WHEN datepart(dd,dc.DOB) = datepart(dd,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
			ELSE DATEDIFF(mm,dc.dob,delig.datevalue)/12 - 1
		END,
	cast('' as varchar(10)) as medicare,
	cast('' as varchar(15)) as [disabled]
	
into
	#temp1

from
	dw.factEligibility fe with (nolock)
	Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
	Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
	Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
	inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
	inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK
	inner join dw.dimAge da with(nolock) on fe.AgeSK = da.AgeSK 
	inner join dw.dimJunk dj with (nolock) on fe.ActionSK = dj.JunkSK
	

Where 1=1
	
	AND delig.DateValue between @strDate and @endDate
	and
	(
		@catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)
	and dbp.InsurerID = 2
		
	and dc.ConsumerNK <> -1
	and dj.JunkValue = 'Active'

IF @insurance IN (1,-200)
	BEGIN

		insert into #temp1

		select distinct
		   
			dc.ConsumerNK as Consumer_ID,
			dc.FullName as Consumer_Name,
			Gender =
				CASE
					WHEN dc.Gender = 'Unspecified' THEN 'Unknown'
					ELSE dc.Gender
				END,
			delig.DateValue  dateelig,
			dbp.InsurerID,
			dbp.InsurerShort, 
			dc.DOB,
			
			1 as member_count,
			AgeValue =
				CASE
					WHEN datepart(mm,dc.DOB) <> datepart(mm,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
					WHEN datepart(dd,dc.DOB) = datepart(dd,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
					ELSE DATEDIFF(mm,dc.dob,delig.datevalue)/12 - 1
				END,
					cast('' as varchar(10)) as medicare,
	cast('' as varchar(15)) as [disabled]
				
				

		from
			dw.factEligibility fe with (nolock)
			Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
			Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
			Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
			inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
			inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK
			inner join dw.dimAge da with(nolock) on fe.AgeSK = da.AgeSK 
			inner join dw.dimJunk dj with (nolock) on fe.ActionSK = dj.JunkSK
			
		Where 1=1

			AND dc.ConsumerNK NOT IN ( SELECT t.Consumer_ID FROM #temp1 t )
			
			AND delig.DateValue between @strDate and @endDate
			and
			(
				@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
			and dbp.InsurerID = 1
				
			and dc.ConsumerNK <> -1
			and dj.JunkValue = 'Active'
	END
       
       
CREATE CLUSTERED INDEX idx_tmpConsumer ON #temp1 (Consumer_ID);

--select * from #temp1 where consumer_id = 13948



--drop table #temp1 

;with cte_medicare as 
(select distinct 
 Consumer_Id,
 cob.cobotherinsurance  as medicare
 from #temp1 t
 inner join
					(select distinct ConsumerNK,  'yes' cobotherinsurance
     						from dw.factCOB fcob with (nolock) 
						Inner join DW.dimConsumers dc2 with (nolock) on fcob.ConsumerSK  = dc2.ConsumersK 
						where       fcob.COBOtherInsurance like '%medicare%'
							) cob on cob.ConsumerNK = t.Consumer_ID  
 )
update #temp1 Set medicare = c.medicare 
from #temp1 t inner join cte_medicare c on t.Consumer_ID = c.Consumer_ID 


;with cte_disabled as
(select distinct
consumer_id,
'Disabled'  [Disabled]

from #temp1 t
inner join dw.dimConsumers dc with (nolock) on t.Consumer_ID = dc.ConsumerNK  
inner join dw.dimBenefitPlan dbp with (nolock) on t.InsurerID = dbp.InsurerID 
inner Join DW.factEligibility fe with (nolock) on dc.ConsumerSK = fe.ConsumerSK and dbp.BenefitPlanSK = fe.BenefitPlanSK 
inner join dw.dimDate dd with (nolock) on fe.DateSK = dd.DateSK and dd.DateValue = t.dateelig 
inner join DW.dimMedicaidAidCategory daid with (nolock) on fe.MedicaidAidCategorySK = daid.MedicaidAidCategorySK 
where daid.CategoryNumberNK in (2,3)
)

update #temp1 Set [disabled]  = c.[disabled]
from #temp1 t inner join cte_disabled  c on t.Consumer_ID = c.Consumer_ID 
where t.medicare = ''

--select * from cte_disabled where Consumer_ID in (select Consumer_ID from #temp3)

--select * from #temp1 where medicare = 'yes' and disabled = 'disabled'



			   
			   create table #temp_final
			(
			Consumer_Count int,
			typed varchar(200),
			Ages varchar(500),
			Gender varchar(100),
			Summary_type varchar(500),
			Report_type varchar(100),
			customgroupId int,
			consumer_id int,
			consumer_Name varchar(2000),
			DOB datetime,
			age1 int,
			age2 int,
			InsurerShort varchar(200),
			[Disabled] varchar(200),
			Member_contribution_1 int,
			Member_contribution_2 int
				
			)
			
			--create table #temp_final
			--(
			--consumer_count int,
			--Medicare int,
			--[disabled] int,
			--Other_low_income int,
			--Total int,
			--Ages varchar(500),
			--Gender varchar(100),
			--summary_type varchar(100))
			
			
		    
			   
			   
	 ----get count for age group dual (medicare and Medicaid)
	;with cte_dual as (		
			select 
			COUNT(distinct(consumer_ID)) cons,
			'dual' Dual,
			CustomGroupValue,gender,'Member count' member_count,EndAttributeCodeRange,'Summary' Summary
				
				from #temp1 t
				Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'CustomAgeGroupsEnrollProdLine' and t.AgeValue  between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
				Where medicare = 'yes' 
				group by Gender,
				CustomGroupValue,EndAttributeCodeRange 
				)
				
	insert into #temp_final(Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type) select * from cte_dual 
	
	
; with	cte_Disabled as (		
			select 
			COUNT(distinct(consumer_ID)) cons,
			'Disabled' disabled,
			CustomGroupValue,gender,'Member count' member_count,EndAttributeCodeRange,'Summary' Summary 
				
				
				from #temp1 t
				Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'CustomAgeGroupsEnrollProdLine' and t.AgeValue between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
				Where disabled = 'disabled'
				group by Gender,
							CustomGroupValue,EndAttributeCodeRange 
				)
	insert into #temp_final(Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type) select * from cte_Disabled 
	; with cte_low_income as (		
			select 
			COUNT(distinct(consumer_ID)) cons,
			'Low Income' Low_income,
			CustomGroupValue,gender,'Member count' member_count,EndAttributeCodeRange,'Summary' Summary 
				
				
				from #temp1 t
				Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'CustomAgeGroupsEnrollProdLine' and t.AgeValue between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
				Where medicare = ''  and disabled = ''
				group by Gender,
	CustomGroupValue ,EndAttributeCodeRange 
				)
				insert into #temp_final(Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type) select * from cte_low_income 
	--select * from #temp_final 		
	--select * from #temp1 
			
				;with cte_dual_months as (		
			select 
			sum(member_count) cons,
			'dual' Dual,
			CustomGroupValue,gender,'Member months' member_count,EndAttributeCodeRange,'Summary' Summary 
				
				from #temp1 t
				Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'CustomAgeGroupsEnrollProdLine' and t.AgeValue between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
				Where medicare = 'yes' 
				group by Gender,
				CustomGroupValue,EndAttributeCodeRange 
				)
				
				insert into #temp_final(Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type) select * from cte_dual_months 
				
				; with	cte_Disabled_months as (		
			select 
			sum(member_count ) cons,
			'Disabled' disabled,
			CustomGroupValue,gender,'Member months' member_count,EndAttributeCodeRange,'Summary' Summary 
				
				
				from #temp1 t
				Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'CustomAgeGroupsEnrollProdLine' and t.AgeValue between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
				Where disabled = 'disabled'
				group by Gender,
							CustomGroupValue,EndAttributeCodeRange 
				)
	insert into #temp_final(Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type) select * from cte_Disabled_months  
	
		; with cte_low_income_months as (		
			select 
			sum(member_count ) cons,
			'Low Income' Low_income,
			CustomGroupValue,gender,'Member months' member_count,EndAttributeCodeRange ,'Summary' Summary
				
				
				from #temp1 t
				Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'CustomAgeGroupsEnrollProdLine' and t.AgeValue between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
				Where medicare = '' and disabled = ''
				group by Gender,
	CustomGroupValue ,EndAttributeCodeRange 
				)
				insert into #temp_final(Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type) select * from cte_low_income_months 
				
				
				
				
				
				
				select consumer_id, Consumer_Name ,Gender, DOB , AgeValue,InsurerShort,[disabled], SUM(member_count) member_months into #temp2  from #temp1 group by
				Consumer_ID,Consumer_Name,gender,dob,AgeValue,insurershort,[disabled] order by Consumer_ID 
				
				select 
				*,
				IDENTITY(int, 1,1) rowid
				into #temp3				 
				from
				#temp2 
				
				select Consumer_Count,typed,Ages,Gender,Summary_type,customgroupId,Report_type,consumer_id,consumer_Name ,DOB ,age1 ,age2,InsurerShort ,Disabled ,Member_contribution_1 ,Member_contribution_2    from #temp_final 
				union all
				select 
				0,'','',f1.Gender,'',0,'Detail',f1.consumer_id,f1.Consumer_Name,  F1.dob, f1.AgeValue age1,isnull(F2.AgeValue,0) age2, F1.InsurerShort,f1.[disabled], isnull(f1.member_months,0) member1, isnull(F2.member_months,0) member2
				from #temp3  F1
			    Left outer join #temp3 F2 on F1.Consumer_ID = F2.Consumer_ID and f1.rowid = f2.rowid - 1
			    --Left outer join #temp3 F3 on F1.Consumer_ID = F2.Consumer_ID and f1.rowid = f2.rowid - 1
				
				drop table #temp1
				drop table #temp2 
				drop table #temp3
				drop table #temp_final 