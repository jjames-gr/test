USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[RegistrySearch]    Script Date: 09/17/2013 09:20:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[RegistrySearch]
	@ServiceType varchar(50),
	@Gender int,
	@Status varchar(50),
	@AgeGroup int,
	@StartDate datetime,
	@EndDate datetime,
	@BenefitPlan int,
	@Catchment varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /*
	/*** Test Parameters ***/
	DECLARE @ServiceType varchar(50) = -1,
			@Gender int = -2,
			@Status varchar(50) = -1,
			@AgeGroup int = -2,
			@StartDate datetime = '6/1/13',
			@EndDate datetime = '6/30/13',
			@BenefitPlan int = -200,
			@Catchment varchar(50) = -300
	--*/

	SELECT DISTINCT
	CASE WHEN frwl.AwaitingInnovationsFlag = 1 THEN 'Awaiting Innovations' ELSE ds.ServiceDescription END as ServiceDescription
	,dcwl.ConsumerNK
	,dcwl.FirstName
	,dcwl.LastName
	,IsNull(dcwl.AddressLine1,'') + IsNull(dcwl.AddressLine2,'') as StreetAddress
	,dcwl.City
	,dcwl.State
	,dcwl.PostalCode
	,dcwl.County
	,dcwl.PhoneNumber
	,dcwl.GenderCode as Gender
	,dcwl.AgeValue as CurrentAge
	,dcwl.County as CountyofResidence
	,ddwlEff.DateValue as DateWaiting
	,rcStatus.JunkValue as Status
	,dcwl.DOB
	,CASE WHEN frwl.NonAmbulatoryFlag = 1 THEN 'Non-Ambulatory' ELSE 'Ambulatory' END as AmbulatoryStatus
	,dcwl.Guardian as LegalGuardian
	,do.County as MedicaidCounty
	FROM [BIW].[DW].[factRegistryWaitingList] frwl WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimDate] ddwlEff WITH(NOLOCK) ON ddwlEff.DateSK = frwl.DateWaitingSK
	INNER JOIN [BIW].[DW].[dimConsumers] dcwl WITH(NOLOCK) ON dcwl.ConsumerSK = frwl.ConsumerSK
	INNER JOIN [BIW].[DW].[dimAge] da WITH(NOLOCK) ON da.AgeSK = dcwl.AgeValue
	INNER JOIN [BIW].[DW].[dimJunk] rcStatus WITH(NOLOCK) ON rcStatus.JunkSK = frwl.RegistryClientStatusSK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = frwl.ServicesSK
	INNER JOIN [BIW].[DW].[dimConsumers] dcFE WITH(NOLOCK) ON dcFE.ConsumerNK = dcwl.ConsumerNK
	LEFT JOIN [BIW].[DW].[factEligibility] fe WITH(NOLOCK) ON fe.ConsumerSK = dcFE.ConsumerSK
	LEFT JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fe.OrganizationSK
	LEFT JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fe.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimConsumers] dcCOB WITH(NOLOCK) ON dcCOB.ConsumerNK = dcwl.ConsumerNK
	LEFT JOIN [BIW].[DW].[factCOB] fCOB WITH(NOLOCK) ON fCOB.ConsumerSK = dcCOB.ConsumerSK
	WHERE 1=1
	/* Global Filters */
	AND IsNull(frwl.RemovedByUserSK, -1) = -1 
	/* Parameters */
	AND (
		(@ServiceType = -1 AND (ds.ServicesNK in (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
													WHERE CustomGroupName = 'DDRegistrySearchResidentalServices'
													OR CustomGroupName = 'DDRegistrySearchADVPServices') or frwl.AwaitingInnovationsFlag = 1))
		OR
		(@ServiceType = 1 AND ds.ServicesNK in (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
													WHERE CustomGroupName = 'DDRegistrySearchResidentalServices'))
		OR
		(@ServiceType = 2 AND ds.ServicesNK in (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
													WHERE CustomGroupName = 'DDRegistrySearchADVPServices'))
		OR
		(@ServiceType = 3 AND frwl.AwaitingInnovationsFlag = 1)
		)
	AND (dcwl.GenderID = @Gender OR @Gender = -2)
	AND (da.GroupID = @AgeGroup or @AgeGroup = -2)
	AND (rcStatus.JunkNK = @Status Or @Status = -1)
	AND ddwlEff.DateValue BETWEEN @StartDate AND @EndDate
	
	AND (
			( @BenefitPlan = -300 AND fCOB.OtherInsurance is not null ) OR -- Other Insurance
			( @BenefitPlan = -400 AND fCOB.OtherInsurance is null and (dbp.BenefitPlanNK is null or dbp.BenefitPlanNK = -1) ) OR --No insurance
			( @BenefitPlan = dbp.BenefitPlanNK ) OR -- 1 specific Plan
			( @BenefitPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
			( @BenefitPlan = -200 ) -- ALL PLANS
		)	
	AND (@catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') ))


END








GO


