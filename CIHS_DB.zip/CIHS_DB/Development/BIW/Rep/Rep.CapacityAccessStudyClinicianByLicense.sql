USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [rep].[CapacityAccessStudyClinicianByLicense] 
( @StartDate DATE, @EndDate DATE , @LicenseID VARCHAR(MAX), @County VARCHAR(MAX), @ProviderID VARCHAR(MAX) ) AS

/*------------------------------------------------------------------------------
	Title:		CapacityAccessStudyClinicianByLicense
	File:		rep.CapacityAccessStudyClinicianByLicense.sql
	Author:		Doug Cox
	Date:		07/11/2013
	Desc:		Provider Data Dump for use with the Capacity Study and/or Accessibility Study.			
                                        
	Called By:
                        Reports:          CapacityAccessStudyClinicianByLicenseDataDump.rdl
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/11/2013		Doug Cox     			6289			Created

	-----------------------------------------------------------------------------------*/

/*	TESTING	*/
--DECLARE 
--@StartDate DATE = getdate(),
--@EndDate DATE = getdate(),
--@LicenseID VARCHAR(MAX) = '1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,37,38,39,40,41,42,43,44,45,46,47,48',
--@County VARCHAR(MAX) = 'Durham',
--@ProviderID VARCHAR(MAX) = '20742';
/*	END TESTING	*/

    BEGIN
	
		IF object_id('tempdb..#Temp1') is not null
			BEGIN
				DROP TABLE #Temp1
			END
		IF object_id('tempdb..#Temp2') is not null
			BEGIN
				DROP TABLE #Temp2
			END
		IF object_id('tempdb..#Temp3') is not null
			BEGIN
				DROP TABLE #Temp3
			END
				
		SELECT	DISTINCT 
				dmainprov.ProviderNK,
				dMainProv.ProviderName,
				dProv.ProviderName AS SiteName,
				dProv.AddressLine1,
				dProv.AddressLine2,
				dProv.City,
				dProv.[State],
				dProv.PostalCode,
				dProv.County,
				dClinician.ClinicianSK,
				dClinician.ClinicianNK,
				dClinician.FirstName,
				dClinician.MiddleName,
				dClinician.LastName,
				dClinician.AddressLine1 AS ClinicianAddr1,
				dClinician.AddressLine2 AS ClinicianAddr2,
				dClinician.City AS ClinicianCity,
				dClinician.[State] AS ClinicianState,
				dClinician.PostalCode AS ClinicianZIP,
				dClinician.County AS ClinicianCounty,
				dClinician.dob,
				dClinician.SSN,
				dClinician.Phone,
				dClinician.NPI,
				dClinician.MCD,
				(SELECT MIN(MinCredsIssueDate.DateValue) FROM dw.factClinicianCredentials AS MINfCC with(nolock) INNER JOIN dw.dimDate AS MinCredsIssueDate with(nolock) ON MinCredsIssueDate.DateSK = MINfCC.CredentialIssueDateSK WHERE MINfCC.ClinicianSK = dClinician.ClinicianSK) AS FirstCredDate
		INTO	#Temp1
		FROM	dw.dimClinician AS dClinician with(nolock)
				INNER JOIN dw.factClinicianProvider as fC2P with(nolock) ON dClinician.ClinicianNK = fc2p.ClinicianNK
				INNER JOIN dw.dimProvider AS dProv with(nolock) ON fC2P.ProviderNK = dProv.ProviderNK 
																	AND dProv.ProviderNK BETWEEN 2 and 999999 
																	AND dProv.StatusID = 49 -- Contracted Providers
				INNER JOIN dw.dimProvider AS dMainProv with(nolock) ON dMainProv.ProviderNK = dProv.ParentProviderNK
																	AND dMainProv.StatusID = 49 -- Contracted Providers
				INNER JOIN dw.dimDate AS dC2PEffectiveDate with(nolock) ON dC2PEffectiveDate.DateSK = fC2P.ClinicianProviderEffectiveDateSK
																	AND dC2PEffectiveDate.DateValue <= @EndDate
				INNER JOIN dw.dimDate AS dC2PExpireDate with(nolock) ON dC2PExpireDate.DateSK = fC2P.ClinicianProviderExpireDateSK
																	AND dC2PExpireDate.DateValue  >= @StartDate
				INNER JOIN dbo.cfn_split(@ProviderID , ',') fnp ON fnp.element = dProv.ParentProviderNK
				INNER JOIN dbo.cfn_split(@County , ',') fnc ON fnc.element = dProv.County
		WHERE	dClinician.Active = 1

		SELECT  t1.*,
				CredsIssueDate.DateValue AS CredsIssueDate,
				CredsExpireDate.DateValue AS CredsExpireDate
		INTO	#Temp2
		FROM	#Temp1 AS t1
				INNER JOIN dw.factClinicianCredentials AS fCC with(nolock) ON fCC.ClinicianSK = t1.ClinicianSK
				INNER JOIN dw.dimDate AS CredsIssueDate with(nolock) ON CredsIssueDate.DateSK = fCC.CredentialIssueDateSK
				INNER JOIN dw.dimDate AS CredsExpireDate with(nolock) ON CredsExpireDate.DateSK = fCC.CredentialExpireDateSK
																	AND CredsExpireDate.DateValue >= @StartDate

		SELECT  t2.ProviderName,
				t2.ProviderNK,
				t2.SiteName,
				t2.AddressLine1,
				t2.AddressLine2,
				t2.City,
				t2.[State],
				t2.PostalCode,
				t2.County,
				t2.ClinicianNK,
				t2.FirstName,
				t2.MiddleName,
				t2.LastName,
				t2.ClinicianAddr1,
				t2.ClinicianAddr2,
				t2.ClinicianCity,
				t2.ClinicianState,
				t2.ClinicianZIP,
				t2.ClinicianCounty,
				t2.dob,
				t2.SSN,
				t2.Phone,
				t2.NPI,
				t2.MCD,
				t2.FirstCredDate,
				t2.CredsIssueDate,
				t2.CredsExpireDate,
				dLic.LicenseID,
				MAX(fCL.LicenseNumber) AS LicenseNumber,
				dLic.Licensecode AS License,
				MAX(LicIssueDate.DateValue) AS LicIssueDate,
				MAX(LicExpireDate.DateValue) AS LicExpireDate
		INTO	#Temp3
		FROM	#Temp2 AS t2
				INNER JOIN dw.factClinicianLicense AS fCL with(nolock) ON fCL.ClinicianSK = t2.ClinicianSK
				INNER JOIN dw.dimLicense AS dLic with(nolock) ON dLic.LicenseSK = fCL.LicenseSK AND dLic.Active = 1
				INNER JOIN dw.dimDate AS LicIssueDate with(nolock) ON LicIssueDate.DateSK = fCL.LicenseIssueDateSK
				INNER JOIN dw.dimDate AS LicExpireDate with(nolock) ON LicExpireDate.DateSK = fCL.LicenseExpireDateSK
				INNER JOIN dbo.cfn_split(@LicenseID , ',') lnp ON lnp.element = dLic.LicenseID
		GROUP BY t2.ProviderName,
				t2.ProviderNK,
				t2.SiteName,
				t2.AddressLine1,
				t2.AddressLine2,
				t2.City,
				t2.[State],
				t2.PostalCode,
				t2.County,
				t2.ClinicianNK,
				t2.FirstName,
				t2.MiddleName,
				t2.LastName,
				t2.ClinicianAddr1,
				t2.ClinicianAddr2,
				t2.ClinicianCity,
				t2.ClinicianState,
				t2.ClinicianZIP,
				t2.ClinicianCounty,
				t2.dob,
				t2.SSN,
				t2.Phone,
				t2.NPI,
				t2.MCD,
				t2.FirstCredDate,
				t2.CredsIssueDate,
				t2.CredsExpireDate,
				dLic.LicenseID,
				dLic.Licensecode

		SELECT	* 
		FROM	#Temp3 AS t3
		WHERE	( t3.CredsExpireDate >= @StartDate OR t3.LicExpireDate >= @StartDate )
		ORDER BY t3.ProviderName

	END