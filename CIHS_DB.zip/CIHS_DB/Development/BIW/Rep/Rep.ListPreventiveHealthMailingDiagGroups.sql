USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListPreventiveHealthMailingDiagGroups]
AS

/*------------------------------------------------------------------------------
	Title:		List Preventive Health Mailing Diagnosis Groups
	File:		[Rep].[ListPreventiveHealthMailingDiagGroups]
	Author:		Doug Cox
	Date:		09/19/13
	Desc:		This listing of Preventive Health Mailing Diagnosis Groups can 
					be used to fill the available values for the 
					Preventive Health Mailing Diagnosis Groups Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author				TixNo	Description
			---		----------		---------------		-----	-----------
			1.0		09/19/13		Doug Cox					Created
	
	Usage directions:
	-- Add the following to your JOIN CLAUSE:
		
		INNER JOIN dw.dimCustomReportGroups AS dCRG with(nolock) ON dCRG.CustomGroupName = 'PreventiveHealthMailingDiagGroups' AND dCRG.CustomGroupValue = @Diagnosis

	-----------------------------------------------------------------------------------*/

	SELECT	DISTINCT
			dCRG.CustomGroupValue
	FROM	dw.dimCustomReportGroups AS dCRG with(nolock) 
	WHERE	dCRG.CustomGroupName = 'PreventiveHealthMailingDiagGroups'
