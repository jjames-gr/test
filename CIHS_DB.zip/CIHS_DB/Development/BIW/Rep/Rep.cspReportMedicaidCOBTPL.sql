USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[cspReportMedicaidCOBTPL]    Script Date: 08/09/2013 14:44:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[cspReportMedicaidCOBTPL] 
@str_dt datetime,
@end_dt datetime
AS
BEGIN
/*------------------------------------------------------------------------------
-- Title:	Medicaid COB and TPL
-- File:	[Rep].[MedicaidCOBTPLReport]
-- Author:	Brian Angelo
-- Date:	04/15/2013
-- Desc:	COB and TPL counts for Medicaid
--			
-- CalledBy:
-- 		Reports: "Medicaid COB and TPL"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	04/15/2013  Brian Angelo		8510	initial creation
--------------------------------------------------------------------------------*/

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/*
	/* Test Parameters */
	DECLARE @str_dt datetime,
			@end_dt datetime
			
	SET @str_dt = '7/1/13'
	SET @end_dt = '7/31/13'
	--*/
	
	
	SELECT DISTINCT
		con.ConsumerNK,
		cob.COBOtherInsurance,
		EffDt = DEff.DateValue,
		ExpDt = CASE
					WHEN cob.COBExpirationDateSK = -1 THEN '12/31/2099'
					ELSE DExp.DateValue
				END
		
	INTO #tmpCOB
	FROM
		BIW.DW.factCOB cob
		INNER JOIN BIW.DW.dimConsumers con ON cob.ConsumerSK = con.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDate] DEff WITH (nolock) ON DEff.DateSK = cob.COBEffectiveDateSK
		INNER JOIN [BIW].[DW].[dimDate] DExp WITH (nolock) ON DExp.DateSK = cob.COBExpirationDateSK

	CREATE CLUSTERED INDEX idx_tmpCOBdata ON #tmpCOB (ConsumerNK);
	
	SELECT
		SubQ.CustomGroupName
		,SubQ.ClaimNumber
		,SubQ.ClaimDetailNumber
		,SubQ.ClaimAdjudicationNumber
		,SubQ.ConsumerNK
		,SubQ.ServiceSummary
		,COBInsurance = CASE WHEN SubQ.COBTable LIKE '%Medicare%' OR SubQ.COBTable LIKE '%Medicaid%'  THEN 'Medicare' ELSE 'Commercial' END
		,SubQ.StatusSK
		,SubQ.AmountBilled
		,SubQ.PaidAmount
		,SubQ.CalcdPaidAmount
		,SubQ.CreditAmount
		,SubQ.ClaimCheckNumber
		,SubQ.OtherInsurancePaid
		,SubQ.DOS
		,CostAvoidedFlag = CASE WHEN SubQ.StatusSK = 2 and SubQ.COBTable NOT LIKE '%Medicare%' AND SubQ.CustomGroupName = 'MedicaidCOBAndTPLDenials' THEN 1 ELSE 0 END
		--,SubQ.ClaimCheckNumber
		
	FROM
	(
		SELECT DISTINCT
			fc.ClaimNumber
			,fc.ClaimDetailNumber
			,fc.ClaimAdjudicationNumber
			,dc.ConsumerNK
			,ServiceSummary = CASE WHEN ds.ServiceSummary = 'Inpatient' THEN ds.ServiceSummary ELSE 'Other Services' END
			,fc.StatusSK
			,fc.PaidAmount
			,CalcdPaidAmount = CASE WHEN ( fc.CreditAmount > 0 AND dcch.ClaimCheckNumber <> '0' AND dcch.ClaimCheckNumber IS NOT NULL ) THEN fc.PaidAmount + fc.CreditAmount ELSE fc.PaidAmount END
			,dcch.ClaimCheckNumber
			,fc.ClaimAmount as AmountBilled
			,fc.CreditAmount
			,fc.COBAmount as OtherInsurancePaid
			,DOS = dos.DateValue
			,dcrg.CustomGroupName
			,COBTable = 
				REPLACE
				(
					REPLACE
					(
						  (
								SELECT DISTINCT
									REPLACE(RTRIM(cob.COBOtherInsurance),' ', CHAR(127)) AS [data()]
								FROM
									#tmpCOB cob
								WHERE
									dc.ConsumerNK = cob.ConsumerNK
									AND dos.DateValue BETWEEN cob.EffDt AND cob.ExpDt                             
								FOR XML PATH('') 
						  ),
						  ' ', '; '
					),
					CHAR(127), ' '
				)
				
		FROM 
			[BIW].[DW].[factClaimsHistorical] fc WITH (nolock)
			inner join [BIW].[DW].[dimBenefitPlan] dbp WITH (nolock) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
			inner join [BIW].[DW].[dimServices] ds WITH (nolock) ON ds.ServicesSK = fc.ServicesSK
			inner join [BIW].[DW].[dimConsumers] dc WITH (nolock) ON fc.ConsumerSK = dc.ConsumerSK
			inner join [BIW].[DW].[dimDate] dd WITH (nolock) ON dd.DateSK = fc.AdjudicationDateSK
			inner join [BIW].[DW].[dimDate] dos WITH (nolock) ON dos.DateSK = fc.DateOfServiceSK
			inner join [BIW].[DW].[dimReasonCodes] drc WITH (nolock) ON fc.ReasonCodeSK = drc.ReasonCodeSK
			left join [BIW].[DW].[dimCustomReportGroups] dcrg WITH (nolock) ON drc.ReasonCodeNK = dcrg.AttributeID
				AND ( dcrg.CustomGroupName = 'MedicaidCOBAndTPLDenials' OR dcrg.CustomGroupName = 'OverrideException' )
			left join dwv.dimClaimCheck dcch on fc.ClaimCheckSK = dcch.ClaimCheckSK
			
		WHERE 
			dbp.InsurerID = 2 --Medicaid only
			and dd.DateValue between @str_dt and @end_dt
			and fc.CapitatedSK = 10
			and 
			(
				fc.StatusSK IN ( 1 , 2 , 5 )
				--OR
				--(
				--	fc.StatusSK IN ( 5 )
				--	AND dcrg.CustomGroupName <> 'OverrideException'
				--)
			)
	) SubQ
	
	WHERE
		SubQ.COBTable IS NOT NULL
		AND 
		(
			(
				CASE WHEN SubQ.StatusSK = 2 and SubQ.COBTable NOT LIKE '%Medicare%' AND SubQ.CustomGroupName = 'MedicaidCOBAndTPLDenials' THEN 1 ELSE 0 END = 1
				AND StatusSK = 2
			)
			OR
			(
				CASE WHEN SubQ.StatusSK = 2 and SubQ.COBTable NOT LIKE '%Medicare%' AND SubQ.CustomGroupName = 'MedicaidCOBAndTPLDenials' THEN 1 ELSE 0 END = 0
				AND StatusSK <> 2
			)
		)
		
		AND 
		(
			SubQ.CustomGroupName IS NULL
			OR SubQ.CustomGroupName <> 'OverrideException'
		)

	ORDER BY ClaimAdjudicationNumber
	
	DROP TABLE #tmpCOB





END
