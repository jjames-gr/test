USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[TARComplianceSummary]
	@StartDate DATE,
	@EndDate DATE,
	@DateType INT, -- 1 = 'Processed Date', 2 = 'Received Date'
	@Catchment VARCHAR(MAX), -- = -300,
	@BenefitPlan INT, -- = -200,
	@DisabilityType VARCHAR(MAX) -- = 'DD,MH,SA'
AS

/*	------------------------------------------------------------------------------
	Title:		TAR Compliance Summary
	File:		[Rep].[TARComplianceSummary]
	Author:		Doug Cox
	Date:		09/06/2013
	Desc:		Summary of processed TAR information.
                                        
	Called By:
                Reports:	UMA029 - TARComplianceSummary.RDL
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/06/2013		Doug Cox				6530			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATE = '1/1/13',
--	@EndDate DATE = '1/31/13',
--	@DateType INT = 1, -- 1 = 'Processed Date', 2 = 'Received Date'
--	@Catchment VARCHAR(MAX) = -300,
--	@BenefitPlan INT = -200,
--	@DisabilityType VARCHAR(MAX) = 'DD,MH,SA'

IF object_id('tempdb..#temp') is not null
BEGIN
	DROP TABLE #temp
END

SELECT	fs2d.TarServiceID,
		ActionTaken.JunkValue AS ActionTaken,
		DATEDIFF("DAY",SubmitDate.DateValue,UpdateDate.DateValue) AS DaysUntilAction,
		dCRG.CustomGroupValue AS DaysUntilActionDesc,
		1 AS TotalCompleted,
		CASE WHEN ActionTaken.JunkValue IN ('APPR','DENY','DENYPT','DISCHRG') THEN 1 ELSE 0 END AS TotalExcDen,
		CASE WHEN ActionTaken.JunkValue = 'APPR' THEN 1 ELSE 0 END AS Approved,
		CASE WHEN ActionTaken.JunkValue = 'DENY' THEN 1 ELSE 0 END AS ClinicalDenial,
		CASE WHEN ActionTaken.JunkValue = 'DENYPT' THEN 1 ELSE 0 END AS PartDenial,
		CASE WHEN ActionTaken.JunkValue = 'ADMDENY' THEN 1 ELSE 0 END AS AdminDenial,
		CASE WHEN ActionTaken.JunkValue = 'DISCHRG' THEN 1 ELSE 0 END AS DischargeFromService,
		CASE WHEN ActionTaken.JunkValue IN ('APPR','DISCHRG') THEN 1 ELSE 0 END AS TotalApproved
INTO	#temp
FROM	dw.factTreatmentAuthorizationRequest AS fTAR with(nolock) 
		INNER JOIN dw.factTARServiceToDiagnosis AS fS2D with(nolock) ON fS2D.TreatmentAuthorizationRequestSK = fTAR.FactTreatmentAuthorizationRequestSK
		INNER JOIN dw.dimBenefitPlan AS dBPlan with(nolock) ON dBPlan.BenefitPlanSK = fS2D.BenefitPlanSK
		INNER JOIN dw.dimConsumers AS dConsumers with(nolock) ON fTAR.ConsumerSK = dConsumers.ConsumerSK
		INNER JOIN dw.dimConsumers AS dCurrentConsumer with(nolock) ON dCurrentConsumer.ConsumerNK = dConsumers.ConsumerNK AND dCurrentConsumer.ETLCurrentRow = 1
		INNER JOIN dw.dimOrganization AS do with(nolock) ON do.County = dCurrentConsumer.County
		INNER JOIN dw.dimJunk AS ActionTaken with(nolock) ON ActionTaken.JunkSK = fS2D.ActionTakenSK AND ActionTaken.JunkEntity = 'ActionTaken'
		INNER JOIN dw.dimJunk AS ReviewProgCode with(nolock) ON ReviewProgCode.JunkSK = fTAR.ReviewProgCodeSK AND ReviewProgCode.JunkEntity = 'ReviewProgCode'
		INNER JOIN dw.dimJunk AS SpecialtyCode with(nolock) ON SpecialtyCode.JunkSK = fTAR.SpecialtyCodeSK AND SpecialtyCode.JunkEntity = 'SpecialtyCode'
		INNER JOIN dw.dimDate AS SubmitDate with(nolock) ON SubmitDate.DateSK = fTAR.OriginalSubmitDateSK
		INNER JOIN dw.dimDate AS UpdateDate with(nolock) ON UpdateDate.DateSK = fS2D.TARServiceUpdateDateSK
		INNER JOIN dw.dimCustomReportGroups AS dCRG with(nolock) ON dCRG.CustomGroupName = 'DaysTillUMAction'
								AND DATEDIFF("DAY",SubmitDate.DateValue,UpdateDate.DateValue) BETWEEN dCRG.BeganAttributeCodeRange AND dCRG.EndAttributeCodeRange
		INNER JOIN dbo.cfn_split(@DisabilityType , ',') fnDisability ON fnDisability.element = SpecialtyCode.JunkValue
WHERE	dConsumers.ConsumerNK <> -1
		AND ReviewProgCode.JunkValue <> 'VOID'
		AND ActionTaken.JunkValue <> 'NR'
		AND fTAR.OriginalSubmitDateSK <> -1
		AND ( 
				( @DateType = 1 AND UpdateDate.DateValue BETWEEN @StartDate AND @EndDate ) -- By Processed Date
				OR
				( @DateType = 2 AND SubmitDate.DateValue BETWEEN @StartDate AND @EndDate ) -- By Received Date
			)
		AND (
				@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
		AND (
				( @BenefitPlan = dBPlan.BenefitPlanNK ) OR -- 1 specific Plan
				( @BenefitPlan = -100 AND dBPlan.InsurerID = 2 ) OR -- ALL Medicaid
				( @BenefitPlan = -200 ) -- ALL PLANS
			)

SELECT	t1.*,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t ) AS AvgTotalCompleted,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken IN ('APPR','DENY','DENYPT','DISCHRG') ) AS AvgTotalExcDen,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken = 'APPR' ) AS AvgApproved,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken = 'DENY' ) AS AvgClinicalDenial,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken = 'DENYPT' ) AS AvgPartDenial,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken = 'ADMDENY' ) AS AvgAdminDenial,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken = 'DISCHRG' ) AS AvgDischargeFromService,
		( SELECT AVG(t.DaysUntilAction) FROM #temp AS t WHERE t.ActionTaken IN ('APPR','DISCHRG') ) AS AvgTotalApproved,
		( SELECT SUM(t.TotalExcDen) FROM #temp AS t ) AS TotalTotal
FROM	#temp AS t1