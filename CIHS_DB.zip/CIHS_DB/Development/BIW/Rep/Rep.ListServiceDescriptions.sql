USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListServiceDescriptions]
AS

/*------------------------------------------------------------------------------
	Title:		List Service Descriptions
	File:		[Rep].[ListServiceDescriptions]
	Author:		Doug Cox
	Date:		09/12/13
	Desc:		This listing of Service Descriptions can be used to fill the available 
					values for the Services Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author				TixNo	Description
			---		----------		---------------		-----	-----------
			1.0		09/12/13		Doug Cox					Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		( dServices.ServiceCode = @Services OR @Services = -2 )

	-----------------------------------------------------------------------------------*/

	/*Services By Description*/

	SELECT	DISTINCT
			ds.ServicesNK,
			ds.ServiceCode,
			ds.ServiceDescription,
			ds.ServiceDescriptionShort,
			2 AS OrderBy
	FROM	dw.dimServices ds WITH(NOLOCK)
			INNER JOIN dw.factClaims AS fc with(nolock) ON fc.ServicesSK = ds.ServicesSK
	UNION
	SELECT	-2 AS ServicesNK,
			'-2' AS ServiceCode,
			'All' as ServiceDescription,
			'All' as ServiceDescriptionShort,
			1 AS OrderBy
	ORDER BY OrderBy, ServiceDescription
