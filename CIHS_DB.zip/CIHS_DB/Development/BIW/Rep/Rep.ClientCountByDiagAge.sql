USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ClientCountByDiagAge]    Script Date: 08/27/2013 15:31:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ClientCountByDiagAge]
	@StartDate datetime,
	@EndDate datetime,
	@Catchment varchar(50),
	@PlanID int
AS
/*------------------------------------------------------------------------------
-- Title:	Client Count by Diagnosis and Age Group
-- File:	Rep.ClientCountByDiagAge
-- Author:	Brian Angelo
-- Date:	08/16/2013
-- Desc:	Client Count by Diagnosis and Age Group stored proc
--			
-- CalledBy:
-- 		Reports: "Client Count by Diagnosis and Age Group"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/16/2013  	Brian Angelo	6317	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
    
	/*
	/*** Test Parameters ***/
	DECLARE @StartDate datetime = '6/1/13',
			@EndDate datetime = '6/30/13',
			@Catchment varchar(50) = -300,
			@PlanID int = -200
	--*/

	IF OBJECT_ID('tempdb..#tempConsumerDiagnosis') IS NOT NULL
			DROP TABLE #tempConsumerDiagnosis

	SELECT
	dcfc.ConsumerNK
	,SUBSTRING(customgroupvalue,len(customgroupvalue)-charindex(' ',REVERSE(customgroupvalue))+2,len(customgroupvalue)-charindex(' ',REVERSE(customgroupvalue))) as AgeGroup
	,dd1.DiagnosisCode as DiagnosisCode1
	,dd1.Diagnosis as Diagnosis1
	,dd2.DiagnosisCode as DiagnosisCode2
	,dd2.Diagnosis as Diagnosis2
	,dd3.DiagnosisCode as DiagnosisCode3
	,dd3.Diagnosis as Diagnosis3
	,dd4.DiagnosisCode as DiagnosisCode4
	,dd4.Diagnosis as Diagnosis4
	INTO #tempConsumerDiagnosis
	FROM [BIW].[DW].[factClaims] fc WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fc.DateOfServiceSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fc.OrganizationSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimConsumers] dcfc WITH(NOLOCK) ON dcfc.ConsumerSK = fc.ConsumerSK
	INNER JOIN [BIW].[DW].[dimAge] da WITH(NOLOCK) ON da.AgeSK = fc.AgeSK
	INNER JOIN [BIW].[DW].[dimJunk] dj WITH(NOLOCK) ON dj.JunkSK = fc.StatusSK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd1 WITH(NOLOCK) ON dd1.DiagnosisSK = fc.Diagnosis1SK
	LEFT JOIN [BIW].[DW].[dimDiagnosis] dd2 WITH(NOLOCK) ON dd2.DiagnosisSK = fc.Diagnosis2SK
	LEFT JOIN [BIW].[DW].[dimDiagnosis] dd3 WITH(NOLOCK) ON dd3.DiagnosisSK = fc.Diagnosis3SK
	LEFT JOIN [BIW].[DW].[dimDiagnosis] dd4 WITH(NOLOCK) ON dd4.DiagnosisSK = fc.Diagnosis4SK
	INNER JOIN [BIW].[DW].[dimCustomReportGroups] dcrg WITH(NOLOCK) ON da.AgeValue BETWEEN cast(dcrg.BeganAttributeCodeRange as int) AND cast(dcrg.EndAttributeCodeRange as int) AND dcrg.CustomGroupName = 'UtilizationRateAgeGroup'
	WHERE 1=1
	AND dcfc.ConsumerNK != -1
	AND dj.JunkNK = '1' --Approved Claims only
	AND ddDOS.DateValue BETWEEN @StartDate AND @EndDate
	AND (
		@catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		)
	AND (
		( @PlanID = dbp.BenefitPlanNK ) OR -- 1 specific Plan
		( @PlanID = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
		( @PlanID = -200 ) -- ALL PLANS
		)

	--Get total distinct count of consumers
	;WITH cteCount as 
	(
	SELECT
	COUNT(DISTINCT ConsumerNK) as TotalCount
	FROM #tempConsumerDiagnosis
	)
	
	--Get distinct count of consumers by age group
	,cteAgeGroupCount as
	(
	SELECT 
	AgeGroup,
	COUNT(DISTINCT ConsumerNK) as TotalAgeCount
	FROM #tempConsumerDiagnosis
	GROUP BY 
	AgeGroup
	)
	
	--Pivot all diagnosis from a claim into a vertical table
	,cteDiagnosis as (
		SELECT ConsumerNK, AgeGroup, Diagnosis1 as Diagnosis, DiagnosisCode1 as DiagnosisCode
		FROM #tempConsumerDiagnosis
		WHERE Diagnosis1 not in ('ALL', 'Unknown')
		UNION
		SELECT ConsumerNK, AgeGroup, Diagnosis2 as Diagnosis, DiagnosisCode2 as DiagnosisCode
		FROM #tempConsumerDiagnosis
		WHERE Diagnosis2 not in ('ALL', 'Unknown')
		UNION
		SELECT ConsumerNK, AgeGroup, Diagnosis3 as Diagnosis, DiagnosisCode3 as DiagnosisCode
		FROM #tempConsumerDiagnosis
		WHERE Diagnosis3 not in ('ALL', 'Unknown')
		UNION
		SELECT ConsumerNK, AgeGroup, Diagnosis4 as Diagnosis, DiagnosisCode4 as DiagnosisCode
		FROM #tempConsumerDiagnosis
		WHERE Diagnosis4 not in ('ALL', 'Unknown')
	)


	SELECT 
	Count(DISTINCT cd.ConsumerNK) as ConsumerCount
	,cd.DiagnosisCode
	,cd.Diagnosis
	,cd.AgeGroup
	,cagc.TotalAgeCount
	,cc.TotalCount
	FROM cteDiagnosis cd
	INNER JOIN cteAgeGroupCount cagc ON cd.AgeGroup = cagc.AgeGroup
	INNER JOIN cteCount cc ON 1=1
	GROUP BY 
	cd.DiagnosisCode
	,cd.Diagnosis
	,cd.AgeGroup
	,cagc.TotalAgeCount
	,cc.TotalCount


	DROP TABLE #tempConsumerDiagnosis
    
END







GO


