USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[GrievanceByProvOrEntityDetail]    Script Date: 07/23/2013 17:23:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [REP].[GrievanceByProvOrEntityDetail]
	@Provider int,
	@EntityID int,
	@StartDate date,
	@EndDate date
AS

/*------------------------------------------------------------------------------
	Title:		Grievances By Provider or Entity Detail				
	File:		[REP].[GrievanceByProvOrEntityDetail]
	Author:		Kevin Hamilton	
	Date:		08/16/2013
	Desc:		Grievances By Provider Detail
			

                                        
	Called By:
                        Reports:        QMA00X-Grievances By Provider or Entity Detail
                        	
           
	-----------------------------------------------------------------------------------
	Version History:()
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/16/2013		Kevin Hamilton     		6399			Created

--	-----------------------------------------------------------------------------------*/

--DECLARE
--@Provider int,
--@EntityID int,
--@StartDate date,
--@EndDate date

--SET @Provider = '-2 '
--SET @EntityID = 1
--SET @StartDate = '1/1/2012 '
--SET @EndDate = '6/1/2013'


      
SELECT DISTINCT
fg.GrievanceID,
p.ProviderName,
p.ProviderNK,
gt.GrievanceTypeDescription,
fg.GrievanceReceivedTimeSK,
fg.GrievanceServiceTypeSK,
fg.GrievanceStatusSK,
fg.StaffAssignedToGrievanceSK,
fg.GrievanceInvestigationSK,
drec.DateValue,
CASE WHEN jinv.JunkValue = 'Investigation' Then 'Yes'
  Else 'No'
End as Investigation,
jinvout.JunkValue as InvestigationOutcome,
jact.JunkValue as ActionTaken,
jdis.JunkValue as Disposition,
e.FullName as DispositionCompletedBy,
gc.ResolutionComments,
jrestype.JunkValue as ResolutionType,
gt.CategoryDescription,
jstat.JunkValue as Status 






FROM dw.factGrievances fg with(nolock)
INNER JOIN dw.dimProvider p with(nolock) ON fg.ProviderSK = p.ProviderSK 
INNER JOIN dw.dimEmployee e with(nolock) ON fg.StaffAssignedToGrievanceSK = e.EmployeeSK
INNER JOIN dw.dimGrievanceComments gc with(nolock) ON gc.GrievanceCommentsSK = fg.GrievanceCommentsSK 
INNER JOIN dw.dimGrievanceType gt with(nolock) ON gt.GrievanceTypeSK = fg.PrimaryGrievanceTypeSK 
INNER JOIN dw.dimDate drec with(nolock) ON fg.GrievanceReceivedDateSK = drec.DateSK
INNER JOIN dw.dimJunk jinv with(nolock) ON fg.GrievanceInvestigationSK = jinv.JunkSK
INNER JOIN dw.dimJunk jinvout with(nolock) ON fg.GrievanceInvestigationOutcomeSK = jinvout.JunkSK 
INNER JOIN dw.dimJunk jact with(nolock) ON fg.GrievanceActionsTakenSK = jact.JunkSK 
INNER JOIN dw.dimJunk jdis with(nolock) ON fg.GrievanceFinalDispositionSK = jdis.JunkSK 
INNER JOIN dw.dimJunk jstat with(nolock) ON fg.GrievanceStatusSK  = jstat.JunkSK
LEFT JOIN dw.dimJunk jdiscom with(nolock) ON fg.StaffAssignedToGrievanceSK = jdiscom.JunkSK
LEFT JOIN dw.dimJunk jrestype with(nolock) ON fg.GrievanceResolutionTypeSK = jrestype.JunkSK

WHERE 
p.ProviderNK <> -1
AND (
	(p.ProviderNK= @Provider) OR 
	( @Provider = -2 )
		)
AND (drec.DateValue >= @StartDate 
	AND drec.DateValue <= @EndDate )
AND (
		(p.EntityTypeID = @EntityID ) OR 
		( @EntityID = -2 )
	)

	
	
ORDER BY fg.GrievanceID 










