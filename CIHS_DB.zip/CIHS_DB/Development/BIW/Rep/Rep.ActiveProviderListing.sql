USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[ActiveProviderListing]    Script Date: 06/28/2013 15:39:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE procedure [Rep].[ActiveProviderListing]
        @Str_Dt DATETIME,
        @End_Dt DATETIME,
		@Contract_type NVARCHAR (MAX),
		@Entity_type NVARCHAR (MAX), 
		@Insurer varchar(100)
AS	
   
/*------------------------------------------------------------------------------
	Title:		Active Provider Listing				
    File:		[REP].[ActiveProviderListing]
	Author:		Divya Lakshmi	
	Date:		06/24/2013
	Desc:		Active Provider Listing Report
			

                                        
	Called By:
                        Reports:      FINXXX - Active Provider Listing Report


                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/24/2013		Divya Lakshmi     		9182			Created

--	-----------------------------------------------------------------------------------*/
--DECLARE 
--        @Str_Dt DATETIME,
--        @End_Dt DATETIME,
--		@Contract_type NVARCHAR (MAX),
--		@Entity_type NVARCHAR (MAX),
--		@Insurer varchar(100)
	
		
--SET @Str_Dt = '1/1/2012'
--SET @End_Dt = '1/31/2012'
--SET @Contract_type = 49--'49,52,58,59,60'
--SET @Entity_type =22
--SET	@Insurer = 2



SELECT DISTINCT 
    COUNT(fc.ClaimNumber) ClaimsCount,
	p.ProviderNK,
	p.ProviderName,
	p.AddressLine1,
	p.AddressLine2,
	p.County,
	p.EntityType,
	p.StatusName
	

	
 FROM  
	DW.factClaims fc WITH(NOLOCK) 
	INNER JOIN DW.dimDate dt WITH(NOLOCK) ON fc.CreateDateSK = dt.DateSK
	INNER JOIN DW.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK
    INNER JOIN DW.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK = bp.BenefitPlanSK
	INNER JOIN dbo.cfn_split(@Contract_type , ',') fn ON fn.element = p.StatusID
    INNER JOIN dbo.cfn_split(@Entity_type , ',') fn1 ON fn1.element = p.EntityTypeID
	INNER JOIN dbo.cfn_split(@Insurer , ',') fn2 ON fn2.element = bp.InsurerID


		
WHERE
    p.Active=1
AND p.ETLCurrentRow=1
AND dt.DateValue between @Str_Dt and @End_Dt
 
 GROUP BY
 	p.ProviderNK,
	p.ProviderName,
	p.AddressLine1,
	p.AddressLine2,
	p.County,
	p.EntityType,
	p.StatusName
    
	





GO


