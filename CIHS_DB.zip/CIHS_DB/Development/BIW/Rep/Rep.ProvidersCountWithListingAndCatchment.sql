USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ProvidersCountWithListingAndCatchment]    Script Date: 07/26/2013 12:44:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [REP].[ProvidersCountWithListingAndCatchment]
		@catchment NVARCHAR (MAX),
		@availStatus NVARCHAR (MAX), 
		@contractStatus NVARCHAR(MAX) 
AS	
   
/*------------------------------------------------------------------------------
	Title:		Providers Count with Listing and Catchment				
    File:		[REP].[ProvidersCountWithListingAndCatchment]
	Author:		Divya Lakshmi	
	Date:		06/18/2013
	Desc:		Lists provider information and their contract dates based on their contract status and their availability.
			

                                        
	Called By:
                        Reports:      PVD001 - Providers Count with Listing and Catchment


                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/18/2013		Divya Lakshmi     		6495			Created

--	-----------------------------------------------------------------------------------*/
--DECLARE 
--		@catchment NVARCHAR (MAX),
--		@availStatus NVARCHAR (MAX), 
--		@contractStatus NVARCHAR(MAX) 
	
		

--SET @catchment = -2
--SET @availStatus = '9,8,10,18,1,14,15,17,5,22,21,20,19,4,6'
--SET @contractStatus = '60,59,-1,52,49,58'




SELECT DISTINCT 
 --   DisCont.eff_dt as ContractRateEffectiveDate,
	--DisCont.end_dt as ContractRateExpirationDate,
	dProv.eff_dt as ContractEffectiveDate,
	dProv.end_dt as ContractExpirationDate,
	p1.ProviderNK,
	p1.ProviderName,
	p1.StatusName,
	p1.EntityType,
	p1.AvailableStatus,
	p1.AddressLine1,
	p1.AddressLine2,
	p1.City,
	p1.State,
	p1.PostalCode,
	p1.County,
	p.ProviderNK as SiteID,
	p.ProviderName as SiteName,
	p.AddressLine1 as SiteAddress1,
	p.AddressLine2 as SiteAddress2,
	p.City as SiteCity,
	p.State as SiteState,
	p.PostalCode as SiteZipCode,
	junk.JunkValue as CatchmentServed,
	p.County as SiteCounty
	

	
 FROM  
	DW.dimProvider p WITH(NOLOCK)
    left outer JOIN dw.dimProvider p1 WITH(NOLOCK)ON  p.ParentProviderNK = p1.ProviderNK 
	left outer JOIN DW.factProviderCatchmentServed fpcs WITH(NOLOCK)ON  p1.ProviderSK = fpcs.ProviderSK  
    left outer JOIN DW.dimJunk junk WITH(NOLOCK)ON fpcs.CatchmentSK  = junk.JunkSK 
   -- left outer  JOIN
			--(
			--	SELECT DISTINCT r.ProviderSK, MAX(deff.DateValue ) as eff_dt, MAX(dexp.DateValue) as end_dt, r.ActiveContractRateFlag
			--	FROM DW.factProviderContractRates r 
			--	INNER JOIN DW.dimDate deff with(nolock)ON deff.DateSK = r.ContractRateEffectiveDateSK   
	  --          INNER JOIN DW.dimDate dexp with(nolock)ON dexp.DateSK = r.ContractRateExpirationDateSK

			--	WHERE r.ActiveContractRateFlag = -1 AND
			--	 r.ProviderSK > 1 
			--	 GROUP BY r.ProviderSK, r.ActiveContractRateFlag 
			--) AS DisCont ON p1.ProviderSK = DisCont.ProviderSK
   
   left outer join 
    (
    SELECT DISTINCT fpc.providersk,P.ProviderNK, MAX(dpc.ContractEffectiveDate ) as eff_dt, MAX(dpc.ContractExpirationDate) as end_dt, dpc.ActiveContractFlag
    from dw.dimProviderContract dpc WITH(NOLOCK)
    inner join dw.factProviderContract fpc WITH(NOLOCK)ON  fpc.ProviderContractSK=dpc.ProviderContractSK
    inner join dw.dimProvider p WITH(NOLOCK)ON  fpc.MainProviderSK=p.ProviderSK
    where dpc.ActiveContractFlag=1
    group by dpc.ActiveContractFlag,fpc.ProviderSK,p.ProviderNK-- order by ProviderSK
 )as dProv on p1.ProviderNK=dProv.ProviderNK

		
WHERE
p1.Active = 1
 AND p1.ProviderNK > 1
 AND p.ProviderNK >1
 AND p.Active=1
 AND p1.ETLCurrentRow=1
 AND p.ETLCurrentRow =1 
 AND CONVERT(NVARCHAR, p1.AvailableStatusID) IN ( SELECT element FROM dbo.cfn_split(@availStatus, ',') )
 AND CONVERT(NVARCHAR, p1.StatusID) IN ( SELECT element FROM dbo.cfn_split(@contractStatus, ',') )
 AND ((junk.JunkNK = @catchment and junk.JunkEntity='ProviderCatchments')
                  OR @catchment = -2
                )
	 AND junk.JunkValue is not null
ORDER BY p1.ProviderNK
    
    
    
	





GO


