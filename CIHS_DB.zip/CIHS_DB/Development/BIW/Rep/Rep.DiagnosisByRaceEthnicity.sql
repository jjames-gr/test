USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[DiagnosisByRaceEthnicity] ( @ProviderID VARCHAR(MAX), @ServiceID VARCHAR(MAX), @BenefitPlanID INT, @CountyCatchmentID VARCHAR(MAX), @BegDate DATE, @EndDate DATE ) AS

	/*------------------------------------------------------------------------------
	Title:		Diagnosis By Race/Ethnicity
	File:		Rep.DiagnosisByRaceEthnicity.sql
	Author:		Doug Cox
	Date:		04/29/2013
	Desc:		Displays Key Performance Indicators (KPIs)- DMH
                                        
	Called By:
                        Reports:          UMA005 - Diagnosis by Race-Ethnicity.rdl
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/29/2013		Doug Cox     			6364			Created

	-----------------------------------------------------------------------------------*/

/*	TESTING	*/
--DECLARE 
--@ProviderID VARCHAR(MAX) = '22934,21921,20482,24747' ,
--@ServiceID VARCHAR(MAX) = '0,5,6,7,8,15,21,23,24,25,31,32,33' , 
--@BenefitPlanID INT = -200 , 
--@CountyCatchmentID VARCHAR(MAX) = '1021,1022,1023,1024' ,
--@BegDate DATE = '1/1/13', 
--@EndDate DATE = '1/31/13';
/*	END TESTING	*/

    BEGIN
	
		-- I use 2 temp tables here instead of a CTE because I need to query the resultsets multiple times
		
		IF object_id('tempdb..#Temp1') is not null
			BEGIN
				DROP TABLE #Temp1
			END
		IF object_id('tempdb..#Temp2') is not null
			BEGIN
				DROP TABLE #Temp2
			END
		
		SELECT  DISTINCT
				do.Catchment ,
				do.County ,
				dc.ConsumerNK AS ClientID ,
				-- This report redefines Hispanic as a race
				CASE WHEN dc.RaceID IN (184, 185) AND dc.EthnicityID IN (76, 77) THEN 'Other' 
					WHEN dc.RaceID IN (184, 185) AND dc.EthnicityID NOT IN (76, 77) THEN 'Hispanic'
					ELSE dc.Race END AS Race ,
				dcrg.CustomGroupValue AS DiagnosisSubGroup,
				dp.ProviderNK
		INTO	#Temp1
		FROM	DW.dimConsumers AS dc with(nolock)
				INNER JOIN DW.factClaims AS fc with(nolock) ON dc.ConsumerSK = fc.ConsumerSK
				INNER JOIN dw.dimProvider as dp with(nolock) ON fc.ProviderSK = dp.ProviderSK
				INNER JOIN dw.dimDate as DOS with(nolock) ON fc.DateOfServiceSK = DOS.DateSK
				INNER JOIN DW.dimDiagnosis as dd with(nolock) ON fc.Diagnosis1SK = dd.DiagnosisSK
				INNER JOIN dw.dimBenefitPlan AS dbp with(nolock) ON fc.BenefitPlanSK = dbp.BenefitPlanSK
				INNER JOIN dw.dimOrganization as do with(nolock) ON fc.OrganizationSK = do.OrganizationSK
				INNER JOIN dw.dimServices as ds with(nolock) ON fc.ServicesSK = ds.ServicesSK
				INNER JOIN dbo.cfn_split(@ServiceID , ',') AS srvc ON srvc.element = ds.ServiceDefinitionID
				INNER JOIN dbo.cfn_split(@ProviderID , ',') AS prov ON prov.element = dp.ProviderNK
				INNER JOIN dw.dimCustomReportGroups AS dcrg ON dd.DiagnosisCode between dcrg.BeganAttributeCodeRange and dcrg.EndAttributeCodeRange
                                                        and dcrg.CustomGroupName = 'DiagnosisMentalHealthSubGroup'     
		WHERE	dc.ConsumerSK > 0
				AND (	@CountyCatchmentID = '-300'
						  OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID, ',') )
						  OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID, ',') )
					)
				AND ( 
						( @BenefitPlanID = dbp.BenefitPlanSK ) OR -- Specific Plan
						( @BenefitPlanID = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
						( @BenefitPlanID = -200 ) -- ALL PLANS
					)
				AND DOS.DateValue BETWEEN @BegDate AND @EndDate
				AND fc.PaidSK = 9 -- Paid
				AND fc.StatusSK = 1 -- Approved
				AND do.OrganizationNK <> -1
			
		SELECT	COUNT(t.ClientID) AS Clients ,
				t.Race ,
				t.DiagnosisSubGroup
		INTO #temp2
		FROM #Temp1 AS t
		GROUP BY 
				t.Race ,
				t.DiagnosisSubGroup

	-- Main Logic

		SELECT	1 AS SortOrder ,
				t2.Race ,
				t2.DiagnosisSubGroup ,
				SUM(t2.Clients) AS Clients ,
				( SELECT SUM(st2.Clients) FROM #temp2 as st2 WHERE t2.Race = st2.Race ) AS TotalRace ,
				( SELECT SUM(st2.Clients) FROM #temp2 AS st2 WHERE t2.DiagnosisSubGroup = st2.DiagnosisSubGroup ) AS TotalDiags 
		FROM	#temp2 as t2
		GROUP BY 
				T2.Race,
				T2.DiagnosisSubGroup
		UNION
			SELECT	1 AS SortOrder ,
					t2.Race ,
					'Total' AS DiagnosisSubGroup ,
					SUM(t2.Clients) AS Clients ,
					( SELECT SUM(st2.Clients) FROM #temp2 as st2 WHERE t2.Race = st2.Race ) AS TotalRace ,
					( SELECT SUM(st2.Clients) FROM #temp2 as st2 ) AS TotalDiags 
			FROM #temp2 AS t2
		GROUP BY 
				t2.Race	
		UNION
			SELECT	3 AS SortOrder ,
					'Total' AS Race ,
					t2.DiagnosisSubGroup ,
					SUM(t2.Clients) AS Clients ,
					( SELECT SUM(st2.Clients) FROM #temp2 as st2 ) as TotalRace ,
					( SELECT SUM(st2.Clients) FROM #temp2 AS st2 WHERE t2.DiagnosisSubGroup = st2.DiagnosisSubGroup ) AS TotalDiags 
			FROM #temp2 AS t2
		GROUP BY 
				t2.DiagnosisSubGroup	
		UNION
			SELECT	4 AS SortOrder ,
					'Total' AS Race ,
					'Total' AS DiagnosisSubGroup ,
					SUM(t2.Clients) AS Clients ,
					( SELECT SUM(st2.Clients) FROM #temp2 as st2 ) as TotalRace ,
					( SELECT SUM(st2.Clients) FROM #temp2 as st2 ) AS TotalDiags 
			FROM #temp2 AS t2		
	
	END