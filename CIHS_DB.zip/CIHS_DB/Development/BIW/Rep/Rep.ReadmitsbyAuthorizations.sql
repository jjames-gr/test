USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--CREATE PROCEDURE [REP].[ReadmitsByAuthorizations]
--	@StartDate DATE ,
--	@EndDate DATE,
--	@ServiceDef VARCHAR(35), 
--	@BenPlan INT,
--	@DiagGroup INT, 
--	@Catchment VARCHAR(MAX),
--	@Days INT
--AS

/*	------------------------------------------------------------------------------
	Title:		Readmits by Authorizations
	File:		[Rep].[ReadmitsByAuthorizations]
	Author:		Tim Amerson
	Date:		06/18/2013
	Desc:		Inpatient Readmit Authorization (detail and summary) for 'x' amount of days.
				For the staff to identify the individuals that have been readmitted additional times.
                                        
	Called By:
                        Reports:	UMA011 - ReadmitsByAuthorizations
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/18/2013		Tim Amerson     		6416			Created
			1.1		07/01/2013		Karissa Martindale		6416			Written
			1.2		08/19/2013		Doug Cox				6416			Changed Length of Stay to use
																			Authorized Length of Stay
			1.3		09/04/2013		Doug Cox				6416			Reversed Where Clause Statement to be 
																			DATEADD(dd, @LOCAL_days, auth.EffFrom) > auth.EffTo

	-----------------------------------------------------------------------------------*/

DECLARE
	@StartDate DATE = '1/1/13',
	@EndDate DATE = '1/31/13',
	@ServiceDef VARCHAR(35) = '-1',--'ReadmitsbyAuthorizationsInpatient',
	@BenPlan INT = -200,
	@DiagGroup INT = -300,
	@Catchment VARCHAR(MAX) = '-300',
	@Days INT = 30

IF object_id('tempdb..#tempFinal') is not null
BEGIN
	DROP TABLE #tempFinal
END
IF object_id('tempdb..#summaryTemp') is not null
BEGIN
	DROP TABLE #summaryTemp
END
IF object_id('tempdb..#tempdisCount') is not null
BEGIN
	DROP TABLE #tempdisCount
END
IF object_id('tempdb..#tempSumm1') is not null
BEGIN
	DROP TABLE #tempSumm1
END
IF object_id('tempdb..#tempCare') is not null
BEGIN
	DROP TABLE #tempCare
END

DECLARE
	@LOCAL_StartDate DATE = @StartDate,
	@LOCAL_EndDate DATE = @EndDate,
	@LOCAL_ServiceDef VARCHAR(35) = @ServiceDef,
	@LOCAL_BenPlan INT = @BenPlan,
	@LOCAL_DiagGroup INT = @DiagGroup,
	@LOCAL_Catchment VARCHAR(MAX) = @Catchment,
	@LOCAL_Days INT = @Days

SELECT DISTINCT
	auth.EffFrom,
	auth.EffTo,
	auth.Insurer,
	auth.ServiceDefinition,
	auth.DiagnosisGroup,
	auth.Catchment,
	@LOCAL_Days as dayspast,
	auth.LastName,
	auth.FirstName,
	auth.ConsumerNK,
	auth.DOB,
	auth.ProviderName,
	--lengthfact.LengthOfStay,						--	Removed - DVC
	auth.AuthorizedLengthOfStay AS LengthOfStay,	--	Added - DVC
	auth.authorizationNumber,
	auth.authConsumers,
	auth.claimsConsumers,
	coord.careConNK,
	auth.AgeGroup,
	0 as numReadmits,
	0 as distinctReadmittedConsumers,
	0 as totalAdmissions,
	0 as averageLOS,
	auth.createDate,
	auth.ServiceDefinitionID
INTO #tempFinal
FROM
    (
	SELECT DISTINCT
		dEffFROM.DateValue as EffFrom,
		dEffTO.DateValue as EffTo,
		dbp.Insurer,
		ds.ServiceDefinition,
		dd.DiagnosisGroup,
		do.Catchment,
		dc.LastName,
		dc.FirstName,
		dc.ConsumerNK,
		dc.DOB,
		dp.ProviderName,
		fa.authorizationNumber,
		fa.ConsumerSK as authConsumers,
		fClaims.ConsumerSK as claimsConsumers,
		fa.AgeSK,
		AgeGroup.CustomGroupValue AS AgeGroup,
		creatDate.DateValue as createDate,
		dbp.BenefitPlanNK,
		dbp.InsurerID,
		do.CatchmentID,
		do.OrganizationNK,
		ds.ServicesNK,
		dp.EntityTypeID,
		dd.DiagnosisGroupID,
		dS.ServiceDefinitionID,
		fa.AuthorizedLengthOfStay	--	Added - DVC
	FROM
		dw.factAuthorizations fa WITH(NOLOCK)
		INNER JOIN dw.dimBenefitPlan dbp WITH(NOLOCK) ON fa.BenefitPlanSK = dbp.BenefitPlanSK
		INNER JOIN dw.dimServices ds WITH(NOLOCK) ON fa.ServicesSK = ds.ServicesSK
		INNER JOIN dw.dimDiagnosis dd WITH(NOLOCK) ON fa.DiagnosisSK = dd.DiagnosisSK
		INNER JOIN dw.dimOrganization do WITH(NOLOCK) ON fa.OrganizationSK = do.OrganizationSK
		INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fa.ConsumerSK = dc.ConsumerSK
		INNER JOIN dw.dimProvider dp WITH(NOLOCK) ON fa.ProviderSK = dp.ProviderSK
		INNER JOIN dw.dimDate dEffFROM WITH(NOLOCK) ON fa.EffectiveFromDateSK = dEffFROM.DateSK
		INNER JOIN dw.dimDate dEffTO WITH(NOLOCK) ON fa.EffectiveToDateSK = dEffTO.DateSK
		INNER JOIN dw.dimDate creatDate WITH(NOLOCK) ON fa.CreateDateSK = creatDate.DateSK
		INNER JOIN dw.dimCustomReportGroups AgeGroup WITH(NOLOCK) ON AgeGroup.CustomGroupName = 'DMAReadmitAgeGroups'
							AND fa.AgeSK BETWEEN AgeGroup.BeganAttributeCodeRange AND AgeGroup.EndAttributeCodeRange
		LEFT JOIN dw.factClaims fClaims WITH(NOLOCK) ON fClaims.AuthorizationNumber = fa.AuthorizationNumber
	)auth  
	INNER JOIN (
		SELECT DISTINCT
			dc.ConsumerNK as careConNK
		FROM
			dw.factCareCoordAdmissions fcca 
			INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON dc.ConsumerSK = fcca.ConsumerSK
			INNER JOIN dw.dimDate carecoordDate WITH(NOLOCK) ON fcca.CareCoordAdmissionsDateSK = carecoordDate.DateSK
	)coord ON coord.careConNK = auth.ConsumerNK
WHERE
	auth.EffFrom <= @LOCAL_EndDate
	AND auth.EffTo >= @LOCAL_StartDate
	AND ( auth.DiagnosisGroupID = @LOCAL_DiagGroup or @LOCAL_DiagGroup = -300 )
	AND
	(
		( @LOCAL_BenPlan = auth.BenefitPlanNK ) OR -- 1 specific Plan
		( @LOCAL_BenPlan = -100 AND auth.InsurerID = 2 ) OR -- ALL Medicaid
		( @LOCAL_BenPlan = -200 ) -- ALL PLANS
	)
	AND
	(
		@LOCAL_catchment = '-300'
		OR auth.CatchmentID IN ( SELECT element FROM dbo.cfn_split(@LOCAL_catchment, ',') )
		OR auth.OrganizationNK IN ( SELECT element FROM dbo.cfn_split(@LOCAL_catchment, ',') )
	)
	AND auth.EntityTypeID <> 13
	AND DATEADD(dd, @LOCAL_days, auth.EffFrom) > auth.EffTo
	AND DATEDIFF(dd, auth.EffFrom, auth.EffTO) BETWEEN 2 AND @LOCAL_days
	AND 
	(	auth.ServicesNK in (SELECT AttributeID FROM biw.dw.dimCustomReportGroups
							WHERE CustomGroupName = @LOCAL_ServiceDef)
	    OR
		@LOCAL_ServiceDef = '-1' AND auth.ServicesNK in (SELECT AttributeID FROM biw.dw.dimCustomReportGroups
							WHERE CustomGroupName = 'ReadmitsbyAuthorizationsInpatient' OR CustomGroupName = 'ReadmitsbyAuthorizationsDetox' )
	)	
	
SELECT 
	ageGroup,
	DiagnosisGroup,
	authConsumers as distinctCount,
	COUNT(DISTINCT AuthorizationNumber) as authnumCount
INTO #tempdisCount
FROM 
	#tempFinal
WHERE
	createDate BETWEEN @LOCAL_StartDate AND @LOCAL_EndDate
GROUP BY ageGroup, DiagnosisGroup, authConsumers 

DELETE FROM #tempdisCount WHERE authnumCount = 1

SELECT 
	ageGroup,
	DiagnosisGroup,
	COUNT(distinctCount) as disCount
INTO #tempSumm1
FROM #tempdisCount
GROUP BY ageGroup, DiagnosisGroup

SELECT
	ageGroup,
	DiagnosisGroup,
	COUNT(authorizationNumber) as totalAdmiss
INTO #tempCare
FROM #tempFinal
GROUP BY ageGroup, DiagnosisGroup

SELECT
	ageGroup,
	DiagnosisGroup,
	COUNT(DISTINCT careConNK) as numReadmitsSum,
	(SUM(LengthOfStay)/COUNT(DISTINCT careConNK)) as alosSum
INTO #summaryTemp
FROM
	#tempFinal
GROUP BY 
	ageGroup,
	DiagnosisGroup
		
UPDATE #tempFinal
SET numReadmits = numReadmitsSum, averageLOS = alosSum--, percentReadmits = percReadmits
FROM #summaryTemp st
WHERE #tempFinal.ageGroup = st.ageGroup AND #tempFinal.DiagnosisGroup = st.DiagnosisGroup

UPDATE #tempFinal
SET distinctReadmittedConsumers = disCount
FROM #tempSumm1 tc
WHERE #tempFinal.ageGroup = tc.ageGroup AND #tempFinal.DiagnosisGroup = tc.DiagnosisGroup

UPDATE #tempFinal
SET totalAdmissions = totalAdmiss
FROM #tempCare tc
WHERE #tempFinal.ageGroup = tc.ageGroup AND #tempFinal.DiagnosisGroup = tc.DiagnosisGroup

SELECT * FROM #tempFinal AS tf ORDER BY ConsumerNK