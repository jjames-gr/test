USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ClaimedServicesReceivedAfterDeceasedDate]    Script Date: 08/13/2013 15:31:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








CREATE PROCEDURE [REP].[ClaimedServicesReceivedAfterDeceasedDate]
    (
		@StartDate DATETIME,
		@EndDate DATETIME
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Claimed Services Received After Deceased Date
-- File:	[Rep].[ClaimedServicesReceivedAfterDeceasedDate]
-- Author:	Divya Lakshmi
-- Date:	06/26/2013
-- Desc:	 Report to monitor and check for claimed services received after a client's deceased date
--                                          
-- CalledBy:
--          Reports: FIN009 Claimed Services Received After Deceased Date
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		06/26/2013  Divya Lakshmi	6298	  Created
--------------------------------------------------------------------------------
*/


--Declare	@StartDate DATETIME
--	SET @StartDate ='1/1/2012'
--Declare	@EndDate DATETIME
--	SET @EndDate = '6/30/2012'	



select distinct 
        c.LastName  AS LastName ,
        c.FirstName AS FirstName,
        c.ConsumerNK AS ConsumerID,
        fe.InsuranceNumber AS InsuranceNumber,
       -- c.DOD AS ConsumerDeceasedDate,
          MAX(c.DOD) AS ConsumerDeceasedDate,
        c.DeceasedUpdateDate AS ConsumerDeceasedDateCI,
        c.DeceasedUpdatedByEmployee AS UpdatedBy,
        p.ProviderName AS Provider,
        fc.ClaimNumber AS ClaimNumber,
        dt.DateValue AS DateOfService,
        s.ServicesNK AS ServiceCode,
        s.ServiceDescription AS ServiceDescription,
       -- fc.AdjudicatedAmount AS AdjudicatedAmount,
        fc.PaidAmount AS PaidAmount,
        bp.BenefitPlan AS BenefitPlan
FROM 
		DW.factClaims fc   WITH(NOLOCK)
		INNER JOIN DW.dimServices s WITH(NOLOCK) on fc.ServicesSK = s.ServicesSK
		INNER JOIN DW.dimConsumers c WITH(NOLOCK) on fc.ConsumerSK = c.ConsumerSK
		INNER JOIN DW.dimBenefitPlan bp WITH(NOLOCK) on fc.BenefitPlanSK = bp.BenefitPlanSK
		INNER JOIN DW.dimProvider p WITH(NOLOCK) on  fc.ProviderSK = p.ProviderSK 
	    INNER JOIN DW.dimDate Dt ON fc.DateOfServiceSK = Dt.DateSK  
	 	INNER JOIN DW.dimConsumers c1 WITH(NOLOCK) on c.ConsumerNK = c1.ConsumerNK
		INNER JOIN DW.dimBenefitPlan bp1 WITH(NOLOCK) on bp.BenefitPlanNK = bp1.BenefitPlanNK
        INNER JOIN dw.factEligibility fe on fe.consumersk=c1.ConsumerSK and fe.BenefitPlanSK=bp1.BenefitPlanSK
		

--
Where
       p.active = 1
       AND  fc.StatusSK = 1
       AND  p.ETLCurrentRow=1
       AND  dt.DateValue >= c.dod
       AND  fc.PaidAmount>0.0
       AND  c.DOD BETWEEN @StartDate and @EndDate
       AND  c.active=1

group by 
        c.ConsumerNK ,
        c.LastName  ,
        c.FirstName,
        fe.InsuranceNumber ,
        c.DeceasedUpdateDate ,
        c.DeceasedUpdatedByEmployee,
        p.ProviderName,
        fc.ClaimNumber ,
        dt.DateValue ,
        s.ServicesNK ,
        s.ServiceDescription ,
       -- fc.AdjudicatedAmount AS AdjudicatedAmount,
        fc.PaidAmount ,
        bp.BenefitPlan
order by c.ConsumerNK





GO


