USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [rep].[ConsumerListbyInsurance] ( @BenefitPlanID INT, @CountyCatchmentID VARCHAR(MAX), @EffDate DATE, @ExpDate DATE ) AS

/*------------------------------------------------------------------------------
	Title:		Consumer List by Insurance
	File:		rep.csp_report_ConsumerListbyInsurance.sql
	Author:		Doug Cox
	Date:		04/23/2013
	Desc:		Displays a listing of consumers grouped by insurance and insurance effective date.  
				Allows business to determine what insurance was in effect at the time of service.			
                                        
	Called By:
                        Reports:          rpt_ConsumerListbyInsurance.rdl
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/23/2013		Doug Cox     			6339			Created
			1.1		07/11/2013		Doug Cox				6339			Changed @CountyCatchmentID

	-----------------------------------------------------------------------------------*/

/*	TESTING	*/
--DECLARE 
--@BenefitPlanID INT = 7, 
--@CountyCatchmentID VARCHAR(MAX) = -300, 
--@EffDate DATE = '1/1/13', 
--@ExpDate DATE = '3/31/13';
/*	END TESTING	*/

    BEGIN
		SELECT  
				dc.LastName ,
				dc.FirstName ,
				dc.MiddleName ,
				dc.ConsumerNK ,
				dc.DOB ,
				dc.Gender ,
				dbp.BenefitPlanShort ,
				fe.InsuranceNumber ,
				MIN(EffDate.DateValue) AS EffectiveDate ,
				MAX(ExpDate.DateValue) AS ExpirationDate ,
				do.County ,
				do.Catchment
		FROM    dw.dimConsumers AS dc with(nolock)
				INNER JOIN dw.factEligibility as fe with(nolock) ON dc.ConsumerSK = fe.ConsumerSK
				INNER JOIN dw.dimBenefitPlan AS dbp with(nolock) ON fe.BenefitPlanSK = dbp.BenefitPlanSK
				INNER JOIN dw.dimOrganization as do with(nolock) ON fe.OrganizationSK = do.OrganizationSK
				INNER JOIN dw.dimDate as EffDate with(nolock) ON fe.DateSK = EffDate.DateSK
				LEFT OUTER JOIN dw.dimDate as ExpDate with(nolock) ON fe.ExpirationDateSK = ExpDate.DateSK
		WHERE	dc.ConsumerSK > 0
				AND (
						@CountyCatchmentID = '-300'
						OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID, ',') )
						OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID, ',') )
					)
				AND ( 
						( @BenefitPlanID = dbp.BenefitPlanNK ) OR -- Specific Plan
						( @BenefitPlanID = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
						( @BenefitPlanID = -200 ) -- ALL PLANS
					)
				AND EffDate.DateValue <= @ExpDate
				AND isnull(ExpDate.DateValue,'12/31/2099') >= @EffDate 
		GROUP BY
				dc.LastName ,
				dc.FirstName ,
				dc.MiddleName ,
				dc.ConsumerNK ,
				dc.DOB ,
				dc.Gender ,
				dbp.BenefitPlanShort ,
				fe.InsuranceNumber ,
				do.County ,
				do.Catchment
	END
GO


