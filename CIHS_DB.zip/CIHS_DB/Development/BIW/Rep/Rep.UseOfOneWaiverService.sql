USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[UseOfOneWaiverService]    Script Date: 08/23/2013 13:15:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO











CREATE PROCEDURE [REP].[UseOfOneWaiverService]
    (
		@StartDate DATETIME,
		@EndDate DATETIME,
		@Consumer_Id VARCHAR(100),
		@Catchment NVARCHAR(MAX)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Use of One Waiver Service
-- File:	[Rep].[UseOfOneWaiverService]
-- Author:	Divya Lakshmi
-- Date:	06/14/2013
-- Desc:	 Report to identify the Medicaid C clients who have not filed a claim 
             for an innovation service in the past month. 
--                                          
-- CalledBy:
--          Reports: UMA010 - Use Of One Waiver Service
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		06/14/2013  Divya Lakshmi	6540	  Created
--------------------------------------------------------------------------------
*/


--Declare	@StartDate DATETIME
--	SET @StartDate ='1/1/2013'
--Declare	@EndDate DATETIME
--	SET @EndDate = '1/31/2013'	
--DECLARE @Consumer_Id VARCHAR(100)
--	SET @Consumer_Id='All'
--DECLARE @Catchment NVARCHAR(MAX)
--  SET @Catchment =-300

SELECT	distinct
    junk.JunkNK AS 'Status ID',
    junk.JunkValue,
    --CASE WHEN Junk.JunkValue = 'Approved' THEN 'Approved'
    --     WHEN Junk.JunkValue = 'Denied' THEN 'Denied'
    --     WHEN Junk.JunkValue = 'Revert/Readjudicated' THEN 'Reverts'
    --     ELSE 'No Claim'  
    --END AS 'Status',
	c.ConsumerNK	AS	'Consumer ID' ,
	c.FirstName AS 'First Name',
	c.LastName AS 'Last Name',
	dt.YearValue AS 'Year',
	dt.[MonthName_en-US] AS 'Month',
	--s.ServiceDefinitionID,
	--s.ServicesSK,
	s.ServicesNK AS 'Service ID',
	s.ServiceCode AS 'Service Code',
	s.ServiceDescription AS 'Service Description',
	p.ProviderName AS 'Provider Name',
	o.Catchment AS 'Catchment'
	into #main
FROM 
		DW.factClaims fc   WITH(NOLOCK)
		INNER JOIN DW.dimServices s WITH(NOLOCK) ON fc.ServicesSK = s.ServicesSK
		INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK = c.ConsumerSK
		INNER JOIN DW.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK = bp.BenefitPlanSK
		INNER JOIN DW.dimProvider p WITH(NOLOCK) ON  fc.ProviderSK = p.ProviderSK 
		INNER JOIN DW.dimOrganization o with(nolock) ON fc.OrganizationSK= o.OrganizationSK
		INNER JOIN DW.dimJunk junk WITH(NOLOCK) ON fc.STATUSSK = junk.JUNKSK
		INNER JOIN DW.dimDate Dt WITH(NOLOCK) ON fc.DateOfServiceSK = Dt.DateSK  


Where Dt.DateValue BETWEEN @StartDate and @EndDate 
      AND bp.BenefitPlanNK=4
      AND c.Active=1
      AND s.ServiceSummaryID =4
      AND c.ConsumerNK = COALESCE(NULLIF(CASE WHEN @Consumer_Id = 'All'
                                                   THEN 0
                                                   ELSE CONVERT(INT, @Consumer_Id)
                                              END, 0), c.ConsumerNK)  
	AND (
	 @Catchment = '-300' OR -- All Catchments 
	 CONVERT(NVARCHAR, o.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )  OR -- Specific County  
	 CONVERT(NVARCHAR, o.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )   -- Specific Catchment                                
      )             
                  
order by ConsumerNK

----- Get providers for clients----
;with lv (consumernk,consumersk , lastvisit )
as
(
    select c.ConsumerNK, c.ConsumerSk, MAX(fc.DateOfServiceSK) lastvisit
    from dw.factClaims fc WITH(NOLOCK) INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK=c.ConsumerSK
    where fc.ConsumerSK IN
(
    Select distinct fe.consumerSK from dw.factEligibility fe WITH(NOLOCK) 
	INNER JOIN DW.dimDate Dt WITH(NOLOCK) ON fe.DateSK = Dt.DateSK  
	INNER JOIN DW.dimDate Dt1 WITH(NOLOCK) ON fe.ExpirationDateSK = Dt1.DateSK  
	where       ISNULL(dt.DateValue, '1/1/1900') <= @EndDate
            AND ISNULL(dt1.DateValue, '12/31/2099') >= @StartDate
    and fe.BenefitPlanSK = 3 
)
    group by c.ConsumerSK,c.ConsumerNK
) 
     select distinct c.consumernk,c.consumersk, fc.ProviderSK, DateOfServiceSK,p.ProviderName--,s.ServicesNK,s.ServiceDefinitionID,s.ServiceCode,s.ServiceDescriptionShort
     into #lastProvider
     from lv l INNER JOIN dw.factClaims fc WITH(NOLOCK) INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK=c.ConsumerSK
     on fc.DateOfServiceSK = l.lastvisit and fc.consumersk = l.consumersk
     INNER JOIN dw.dimProvider p WITH(NOLOCK) ON fc.ProviderSK=p.ProviderSK
   --  INNER JOIN dw.dimServices s WITH(NOLOCK) ON fc.ServicesSK=s.ServicesSK
     order by c.ConsumerNK 

------end get providers-----
------cte get eligible consumers-------
  ;WITH cte_no_claims as(  SELECT DISTINCT
            c.ConsumerNK ,
            c.FirstName ,
            c.LastName,
            do.catchment
    FROM    dw.factEligibility fe WITH(NOLOCK)
            INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON fe.ConsumerSK=c.ConsumerSK
            INNER JOIN DW.dimDate Dt WITH(NOLOCK) ON fe.DateSK = Dt.DateSK  
            INNER JOIN DW.dimOrganization do WITH(NOLOCK) ON fe.OrganizationSK= do.OrganizationSK
            INNER JOIN DW.dimDate Dt1 WITH(NOLOCK) ON fe.ExpirationDateSK = Dt1.DateSK  
    WHERE   
             c.active = 1
            AND fe.BenefitPlanSK= 3
            AND ISNULL(dt.DateValue, '1/1/1900') <= @EndDate
            AND ISNULL(dt1.DateValue, '12/31/2099') >= @StartDate
            AND c.ConsumerNK = COALESCE(NULLIF(CASE WHEN @consumer_Id = 'All'
                                                   THEN 0
                                                   ELSE CONVERT(INT, @Consumer_Id)
                                              END, 0), c.consumernk)
             
             AND (
	 @Catchment = '-300' OR -- All Catchments 
	 CONVERT(NVARCHAR, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )  OR -- Specific County  
	 CONVERT(NVARCHAR, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )   -- Specific Catchment                                
      ) 
     )      
     
     ----end get eligible consumers------------
     ----get no claims data--------------------                                
      INSERT  INTO #main ( [Consumer ID], [First Name], [Last Name] ,  [Status ID],  [Catchment], [Service ID],[Service Code],[Service Description],
      [Provider Name],JunkValue)
      SELECT  c1.ConsumerNK ,FirstName,lastname,0, Catchment,0,0,0,lp.ProviderName,0
      FROM    cte_no_claims c1 join #lastProvider lp on lp.ConsumerNK=c1.ConsumerNK
      WHERE   c1.ConsumerNK NOT IN ( SELECT   [Consumer ID] FROM     #main )

 ------cte get authorised service-----------
  ;WITH cte_auth as(SELECT DISTINCT	s1.ServiceCode AS 'Auth Service Code',
	                                s1.ServiceDescription AS 'Auth Service Description',
	                               -- s1.ServicesSK,
	                                dc.ConsumerNK
          FROM DW.factAuthorizations fa WITH(NOLOCK) 
          INNER JOIN DW.dimServices s1 WITH(NOLOCK) ON s1.ServicesSK= fa.ServicesSK
          INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fa.ConsumerSK = dc.ConsumerSK
          INNER JOIN DW.dimDate FromDt WITH(NOLOCK) ON fa.EffectiveFromDateSK = FromDt.DateSK  
		  INNER JOIN DW.dimDate ToDt WITH(NOLOCK) ON fa.EffectiveToDateSK = ToDt.DateSK

                    --where FromDt.DateValue<=@StartDate and ToDt.DateValue>=@EndDate
                   where  FromDt.DateValue<=@EndDate and ToDt.DateValue>=@StartDate



                    ) 
 ---------end get authorised service-------------                                      
SELECT  DISTINCT * ,    
        CASE WHEN m.JunkValue = 'Approved' THEN 'Approved'
             WHEN m.JunkValue = 'Denied' THEN 'Denied'
             WHEN m.JunkValue = 'Revert/Readjudicated' THEN 'Reverts'
         ELSE 'No Claim'  
        END AS 'Status' 
        into #final
FROM #main m
         LEFT OUTER JOIN cte_auth c1 ON m.[Consumer ID] = c1.ConsumerNK 
ORDER BY m.[Consumer ID]

select distinct  [Consumer ID] ,[Status ID],Status, [First Name],[Last Name],[year],[month]
,[Service ID],[Service Code],[Service Description],[Provider Name],Catchment,'' as[Auth Service Code],''as [Auth Service Description]  from #final  group by [Consumer ID] ,[Status ID],[First Name],Status, [Last Name],[year],[month]
,[Service ID],[Service Code],[Service Description],[Provider Name],Catchment
having [Status ID]in(1,2,3,4)
union 
select distinct  [Consumer ID] ,[Status ID],Status, [First Name],[Last Name],[year],[month]
,[Service ID],[Service Code],[Service Description],[Provider Name],Catchment,[Auth Service Code],[Auth Service Description] from #final  group by [Consumer ID] ,[Status ID],Status, [First Name],[Last Name],[year],[month]
,[Service ID],[Service Code],[Service Description],[Provider Name],Catchment,[Auth Service Code],[Auth Service Description]
having Status='No Claim'


DROP TABLE #main
DROP TABLE #lastProvider
DROP TABLE #final






GO


