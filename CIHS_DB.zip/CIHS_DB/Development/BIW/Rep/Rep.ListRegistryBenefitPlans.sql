USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ListRegistryBenefitPlans]    Script Date: 08/21/2013 12:51:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [REP].[ListRegistryBenefitPlans]
AS

/*------------------------------------------------------------------------------
	Title:		List Registry Benefit Plans
	File:		rep.ListRegistryBenefitPlans
	Author:		Brian Angelo
	Date:		08/21/2013
	Desc:		This listing of benefit plans can be used to fill the available 
					values for a benefit plan Parameter in DD Registry Search.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/21/2013		Brian Angelo			6358			initial creation
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
	--Join factEligibility to dimBenefitPlans with a Left join
	--Join factCOB using a left join	
		(
			( @BenefitPlan = -300 AND fCOB.OtherInsurance is not null ) OR -- Other Insurance
			( @BenefitPlan = -400 AND fCOB.OtherInsurance is null and (dbp.BenefitPlanNK is null or dbp.BenefitPlanNK = -1) ) OR --No insurance
			( @BenefitPlan = dbp.BenefitPlanNK ) OR -- 1 specific Plan
			( @BenefitPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
			( @BenefitPlan = -200 ) -- ALL PLANS
		)

	-----------------------------------------------------------------------------------*/

/* Get Listing of available Benefit Plans */
SELECT dbp.BenefitPlanNK,
	dbp.BenefitPlanSK,
	dbp.BenefitPlanShort
FROM DW.dimBenefitPlan as dbp with(nolock)
/* Add item for All Medicaid Plans */
UNION
SELECT -100 AS BenefitPlanNK,
	-100 AS BenefitPlanSK,
	'All Medicaid Plans'
/* Add item for All Plans */
UNION
SELECT -200 AS BenefitPlanNK,
	-200 AS BenefitPlanSK,
	'All Plans'
UNION
SELECT -300 as BenefitPlanNK,
	-300 as BenefitPlanSK,
	'Other Insurance'
UNION
SELECT -400 as BenefitPlanNK,
	-400 as BenefitPlanSK,
	'No Insurance'



GO


