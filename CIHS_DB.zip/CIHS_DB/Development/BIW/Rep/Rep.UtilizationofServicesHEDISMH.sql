USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [Rep].[UtilizationofServicesHEDISMH] 
	@Start_dt datetime ,
@end_dt datetime,
@Benefit_plan int,
@Catchment varchar(max) 
AS
/*------------------------------------------------------------------------------
	Title:		UtilizationofServicesHEDISMH
	File:		UtilizationofServicesHEDISMH
	Author:		Karen Roslund
	Date:		8/21/2013
	Desc:		The number and percentage of members receiving the following Mental Health services during the measurement year:  Any Service, Inpatient, Intensive outpatient or partial hospitalization, outpatient or ED			
                                        
	Called By:
                        Reports:          Coming Soon....
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		8/21/2013		Karen Roslund    			9192			Created
			1.1		9/23/2013		Karen Roslund				9192			Added logic to add any service and just consider the first service for that service type
--	-----------------------------------------------------------------------------------*/
--declare @eligibility_Start_dt datetime = '1/1/2012',
--@eligibility_end_dt datetime = '3/31/2012',
--@Benefit_plan int = -200,
--@Catchment varchar(max) = '-300'


select distinct
	dc.ConsumerNK as Consumer_ID,
	dc.FullName as Consumer_Name,
	Gender =
		CASE
			WHEN dc.Gender = 'Unspecified' THEN 'Unknown'
			ELSE dc.Gender
		END,
	delig.DateValue  dateelig,
	--dbp.BenefitPlanNK,
	--dbp.BenefitPlan,
	dc.DOB,
	1 as member_count,
	AgeValue =
		CASE
			WHEN datepart(mm,dc.DOB) <> datepart(mm,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
			WHEN datepart(dd,dc.DOB) = datepart(dd,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
			ELSE DATEDIFF(mm,dc.dob,delig.datevalue)/12 - 1
		END
	
into
	#temp1

from
	dw.factEligibility fe with (nolock)
	Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
	Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
	Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
	inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
	inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK
	inner join dw.dimAge da with(nolock) on fe.AgeSK = da.AgeSK 
	inner join dw.dimJunk dj with (nolock) on fe.ActionSK = dj.JunkSK

Where 1=1
	
	AND delig.DateValue between @Start_dt  and @end_dt 
	and
	(
		@catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)
	and dbp.InsurerID = 2
		
	and dc.ConsumerNK <> -1
	and dj.JunkValue = 'Active'

IF @Benefit_plan  IN (1,-200)
	BEGIN

		insert into #temp1

		select distinct
			dc.ConsumerNK as Consumer_ID,
			dc.FullName as Consumer_Name,
			Gender =
				CASE
					WHEN dc.Gender = 'Unspecified' THEN 'Unknown'
					ELSE dc.Gender
				END,
			delig.DateValue  dateelig,
			--dbp.BenefitPlanNK,
			--dbp.BenefitPlan,
			dc.DOB,
			1 as member_count,
			AgeValue =
				CASE
					WHEN datepart(mm,dc.DOB) <> datepart(mm,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
					WHEN datepart(dd,dc.DOB) = datepart(dd,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
					ELSE DATEDIFF(mm,dc.dob,delig.datevalue)/12 - 1
				END

		from
			dw.factEligibility fe with (nolock)
			Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
			Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
			Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
			inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
			inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK
			inner join dw.dimAge da with(nolock) on fe.AgeSK = da.AgeSK 
			inner join dw.dimJunk dj with (nolock) on fe.ActionSK = dj.JunkSK

		Where 1=1

			AND dc.ConsumerNK NOT IN ( SELECT t.Consumer_ID FROM #temp1 t )
			
			AND delig.DateValue between @Start_dt  and @end_dt 
			and
			(
				@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
			and dbp.InsurerID = 1
				
			and dc.ConsumerNK <> -1
			and dj.JunkValue = 'Active'
	END
          
CREATE CLUSTERED INDEX idx_tmpConsumer ON #temp1 (Consumer_ID);
			
--;WITH cteEligAgg AS
--(
--	SELECT
--		elig.Consumer_ID
--		,SUM(elig.member_count) as MemberMonths
--	FROM
--		#temp1 elig
--	GROUP BY
--		elig.Consumer_ID
--)			
			   
			   
			   select distinct 
dcon.ConsumerNK,
dcon.FullName,
dbp.BenefitPlanShort,
dcon.County,
dcon.DOB,
fc.ClaimNumber,
t.AgeValue ,
CASE
			WHEN dcon .Gender = 'Unspecified' THEN 'Unknown'
			ELSE dcon.Gender
		END Gender,
ddate.DateValue as date_of_service,
--fc.PlaceOfServiceSK ,
'Age ' + dg.CustomGroupValue Age_group,
ddiag.DiagnosisCode,
rtrim(ddserv.ServiceDescription) + ' / ' + rtrim(ddserv .ServiceCode) as ServiceCode ,--
dcrgdiagValues = dcrgdiag.CustomGroupValue,
--dcrservnopos=dcrservnopos.CustomGroupValue ,
--dcrintoutpatpos=dcrintoutpatpos.customgroupvalue,
--dcrintoutpatsrvc=dcrintoutpatsrvc.customgroupvalue,
--dcroutpatpos=dcroutpatpos.customgroupvalue,
--dcroutpatsrvc=dcroutpatsrvc.customgroupvalue,

----isnull(dcrservnopos.CustomGroupValue,ISNULL(dcrintoutpatpos.customgroupvalue,ISNULL(dcrintoutpatsrvc.customgroupvalue,isnull(dcroutpatpos.customgroupvalue,dcroutpatsrvc.customgroupvalue))))--dcrservnoposValues = dcrservnopos.CustomGroupValue,
Coalesce(dcrservnopos.CustomGroupValue,dcrintoutpatpos.customgroupvalue,dcrintoutpatsrvc.customgroupvalue,dcroutpatpos.customgroupvalue,dcroutpatsrvc.customgroupvalue)service_Type
--dcrintoutpatposValues = dcrintoutpatpos.CustomGroupValue,
--dcroutpatposValues = dcroutpatpos.CustomGroupValue
,ROW_NUMBER() OVER (Partition by dcon.ConsumerNK,Coalesce(dcrservnopos.CustomGroupValue,dcrintoutpatpos.customgroupvalue,dcrintoutpatsrvc.customgroupvalue,dcroutpatpos.customgroupvalue,dcroutpatsrvc.customgroupvalue) ORDER BY ddate.datevalue ASC) as anyVisit  

--dcrservnopos ,dcrintoutpatpos,dcrintoutpatsrvc,dcroutpatpos,dcroutpatsrvc
into #temprec

from 
dw.factClaims fc with (nolock)
Inner join DW.dimConsumers dcon with (nolock) on fc.ConsumerSK = dcon.ConsumerSK 
Inner join #temp1 t on t.Consumer_ID = dcon.ConsumerNK 
Inner join dw.dimServices ddserv with (nolock) on fc.ServicesSK = ddserv.ServicesSK 
 inner join dw.dimDiagnosis ddiag  with (nolock) on fc.Diagnosis1SK = ddiag.DiagnosisSK 
 Inner join DW.dimDate ddate with (nolock) on fc.DateOfServiceSK = ddate.DateSK 
 inner join dw.dimServices dserv with (nolock) on fc.ServicesSK = dserv.ServicesSK 
 inner join DW.dimPlaceOfService dpos with (nolock) on fc.PlaceOfServiceSK = dpos.PlaceOfServiceSK 
 inner join DW.dimBenefitPlan dbp with (nolock) on fc.BenefitPlanSK = dbp.BenefitPlanSK
Inner join DW.dimJunk djunk with (nolock) on fc.StatusSK = djunk.JunkSK
Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'HedisUtlizationAgeGroup' and t.AgeValue  between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)   
inner  join DW.dimCustomReportGroups dcrgdiag with (nolock) on dcrgdiag.CustomGroupName  =  'HedisUntilizationDiagnosisGroupMH' and ddiag .DiagnosisnK  = dcrgdiag.AttributeID  
left outer join DW.dimCustomReportGroups dcrservnopos   with (nolock) on dcrservnopos.CustomGroupName = 'HedisUntilizationServiceCodeNoPOSMH' and dserv.ServicesNK  = dcrservnopos.AttributeID 
left outer join dw.dimPlaceOfService dplaceintoutpat with (nolock) on fc.PlaceOfServiceSK = dplaceintoutpat.PlaceOfServiceSK 
left outer join dw.dimCustomReportGroups dcrintoutpatpos with (nolock) on  dcrintoutpatpos.customgroupname = 'HedisUntilizationIntensiveOutpatientPOSMH' and dplaceintoutpat.PlaceOfServiceNK =dcrintoutpatpos.AttributeID
left outer join dw.dimServices dservintoutsrvc with (nolock) on fc.ServicesSK = dservintoutsrvc.ServicesSK 
left outer join dw.dimCustomReportGroups dcrintoutpatsrvc with (nolock) on dcrintoutpatsrvc.CustomGroupName = 'HedisUntilizationServiceCodeWithIntensiveOutpatientPOSMH' and dservintoutsrvc.ServicesNK =dcrintoutpatsrvc .AttributeID 
left outer join dw.dimPlaceOfService doutpatpos with (nolock) on fc.PlaceOfServiceSK = doutpatpos.PlaceOfServiceSK 
left outer join dw.dimcustomreportgroups dcroutpatpos with (nolock) on dcroutpatpos.CustomGroupName ='HedisUntilizationOutpatientPOSMH' and doutpatpos.PlaceOfServiceNK = dcroutpatpos.AttributeID 
left outer join dw.dimServices dservoutpatsrvc with (nolock) on fc.ServicesSK = dservoutpatsrvc.ServicesSK 
left outer join dw.dimcustomreportgroups dcroutpatsrvc with (nolock) on dcroutpatsrvc.CustomGroupName ='HedisUntilizationServiceCodeWithOutpatientPOSMH' and dservoutpatsrvc.ServicesNK = dcroutpatsrvc.AttributeID 
INNER JOIN BIW.DW.dimOrganization dOrg WITH(NOLOCK) ON fc.OrganizationSK = dOrg.OrganizationSK

--dcrservnopos ,dcrintoutpatpos,dcrintoutpatsrvc,dcroutpatpos,dcroutpatsrvc
 --left join dw.dimCustomReportGroups dcroutpatpos with (nolock) on dcroutpatpos.CustomGroupName in ( 'HedisUntilizationOutpatientPOS','HedisUntilizationServiceCodeWithOutpatientPOS') and dpos.PlaceOfServiceNK = dcroutpatpos.AttributeID and dserv.ServicesNK = dcroutpatpos.AttributeID 
																																																																											
 where
ddate.DateValue between @Start_dt  and @end_dt  
 and  djunk.JunkValue  = 'Approved'

 and Coalesce(dcrservnopos.CustomGroupValue,dcrintoutpatpos.customgroupvalue,dcrintoutpatsrvc.customgroupvalue,dcroutpatpos.customgroupvalue,dcroutpatsrvc.customgroupvalue) is not  null 
and (
	
					@catchment = '-300'
					OR CONVERT(nvarchar, dOrg .CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					OR CONVERT(nvarchar, dOrg .OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

				)
				
and ((@Benefit_plan  = -200)--all plans
        or (@Benefit_plan  = -100 and dbp.BenefitPlanNK >=2 )
        or (dbp.BenefitPlanNK   = @Benefit_plan))
         --and dc.ConsumerNK <> -1
--and dcon.ConsumerNK  = 311
order by dcon.ConsumerNK , service_Type 

delete from  #temprec  where anyVisit <> 1

select *,ROW_NUMBER() OVER (Partition by ConsumerNK ORDER BY date_of_service ASC) as firstVisit into #temprec1  from #temprec 


 

insert into #temprec 
select 
ConsumerNK,
FullName,
BenefitPlanShort,
County,
DOB,
ClaimNumber,
AgeValue,
Gender,
date_of_service,
Age_group,
DiagnosisCode,ServiceCode,dcrgdiagValues,'Any Service',1
from #temprec1 where firstVisit = 1 

drop table #temprec1 

CREATE TABLE #temp900
        (
          age VARCHAR(20) ,
          gender varCHAR(100) ,
          type VARCHAR(100) ,
          cnt FLOAT ,
          eligible_month FLOAT ,
          Report_type varchar(200),
          Client_ID int,
          Client_Name varchar(2000),
          Client_Insurance varchar(2000),
          Client_County varchar(2000),
          Client_DOB datetime,
          Client_Age int,
          Client_Age_Group varchar(200),
          Client_gender_Group varchar(200),
          Client_DX  varchar(100),
          Client_DX_Group varchar(10),
          DOS varchar(20),
          Service_code varchar(5000),
          Service_category varchar(2000)
          
          
        )
        

        
        
        --Client Name
--Client Insurance
--Client County
--Client DOB
--Client Age
--Client Age Group
--Gender
--Client DX
--Client DX code
--DOS
--Service Description/Service Code
--Service Category


--Insert blank values that ensure every group shows on report even if no data exists
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Male', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Male', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Male', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Male', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Male', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Male', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Female', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Female', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Female', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Female', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Female', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Female', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Male', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Male', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Male', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Male', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Male', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Male', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Female', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Female', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Female', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Female', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Female', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Female', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Male', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Male', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Male', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Male', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Male', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Male', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Female', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Female', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Female', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Female', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Female', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Female', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )


    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown', 'Any Service', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown', 'OUTPATIENT AND ED', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown', 'Inpatient', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 0-12', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 13-17', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 18-24', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 25-34', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 35-64', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Age 65+', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
              
              
     
              
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Unknown',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )      
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Male',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' )
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Female',
              'Intensive Outpatient/Partial Hospitalization', 0, 0,'Summary' ) 
              
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Unknown',
              'OUTPATIENT AND ED', 0, 0,'Summary' )      
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Male',
              'OUTPATIENT AND ED', 0, 0,'Summary' )
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Female',
              'OUTPATIENT AND ED', 0, 0,'Summary' ) 
              
              
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Unknown',
              'Inpatient', 0, 0,'Summary' )      
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Male',
              'Inpatient', 0, 0,'Summary' )
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Female',
              'Inpatient', 0, 0,'Summary' ) 
      
    INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Unknown',
              'Any Service', 0, 0,'Summary' )      
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Male',
              'Any Service', 0, 0,'Summary' )
     INSERT  INTO #temp900 (age,gender,type,cnt,eligible_month,Report_type)
    VALUES  ( 'Total', 'Female',
              'Any Service', 0, 0,'Summary' )      

--select * from #temp900 

;with cte as (select SUM(member_count) cnt, 'Age ' +dg.CustomGroupValue age_group ,Gender from #temp1  t
Inner join DW.dimCustomReportGroups dg with (nolock) on dg.CustomGroupName = 'HedisUtlizationAgeGroup' and t.AgeValue  between   cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)   
group by 'Age ' +dg.CustomGroupValue, Gender)

update t set eligible_month = c.cnt 
from #temp900 t 
inner join cte c on t.gender = c.Gender and t.age = c.age_group  and t.Report_type = 'Summary'

--select * from #temp1 

;with cte_total as (
select 
sum(eligible_month ) as eligible_mnth,
Gender,
'Total' type
from #temp900 
group by
Gender )

--select * from cte_rec_any_service_total 

update t set eligible_month   = c.eligible_mnth 
from #temp900 t 
inner join cte_total    c on t.gender = c.Gender and t.age = 'Total'  and t.Report_type = 'Summary'  


; with cte_rec_service as (
select 
COUNT(distinct(ConsumerNK)) as cnt,
Gender,
Age_group,
service_Type  
from #temprec
group by
Gender,Age_group,service_Type )

update t set cnt  = c.cnt 
from #temp900 t 
inner join cte_rec_service  c on t.gender = c.Gender and t.age = c.age_group and type = service_Type and t.Report_type = 'Summary'

--;with cte_rec_any_service as (
--select 
--COUNT(distinct(ConsumerNK)) as cnt,
--Gender,
--Age_group
--from #temprec
--group by
--Gender,Age_group )

--update t set cnt  = c.cnt 
--from #temp900 t 
--inner join cte_rec_any_service   c on t.gender = c.Gender and t.age = c.age_group and type = 'Any Service' and t.Report_type = 'Summary'

;with cte_rec_any_service_total as (
select 
sum(cnt) as cnt,
Gender,
'Total' age,type
from #temp900 
group by
Gender,type )

--select * from cte_rec_any_service_total 

update t set cnt  = c.cnt 
from #temp900 t 
inner join cte_rec_any_service_total    c on t.gender = c.Gender and t.age = 'Total' and 
t.type = c.type  and t.Report_type = 'Summary'  



--insert into #temp900 (Client_Age,Client_Age_Group,Client_County,Client_DOB,Client_DX,Client_DX_Group,Client_ID,Client_Insurance,Client_Name,Client_gender_Group,DOS,Report_type,Service_category,Service_code     )
--(Select ages,Age_group,County,DOB,DiagnosisCode,dcrgdiagValues,ConsumerNK,BenefitPlanShort,FullName,Gender,date_of_service,'Detail', service_Type,ServiceCode 
--from #temprec )

select age,gender,type,cnt,eligible_month,Report_type,Client_ID,Client_Name,Client_Insurance,Client_County,Client_DOB,Client_Age,Client_Age_Group,Client_gender_Group,Client_DX,Client_DX_Group,DOS,Service_code,Service_category     from #temp900
union
 
Select '','','',0,0,'Detail',consumernk,FullName,BenefitPlanShort,County,DOB, AgeValue ,Age_group,Gender,DiagnosisCode,dcrgdiagValues,date_of_service, ServiceCode ,service_Type 
from #temprec

 




drop table #temp1 
drop table #temp900 
drop table #temprec 
--drop table #memberMonthSplit 