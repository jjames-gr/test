USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[HighCostConsumers]
	( @StartDate DATE, @EndDate DATE , @InsurerID INT, @Age VARCHAR(MAX), @DiagGroup INT, @PCT INT, @Catchment VARCHAR(MAX) ) AS

/*------------------------------------------------------------------------------
	Title:		High Cost Consumers
	File:		Rep.HighCostConsumers.sql
	Author:		Doug Cox
	Date:		08/02/2013
	Desc:		High Cost Consumers
                                        
	Called By:
                        Reports:          QMA007 - High Cost Consumers.rdl
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/02/2013		Doug Cox     			6401			Created

	-----------------------------------------------------------------------------------*/

	/*	TESTING	*/
	--DECLARE 
	--@StartDate DATE = '1/1/13',
	--@EndDate DATE = '1/31/13',
	--@InsurerID INT = -2,
	--@Age VARCHAR(MAX) = 'Child 0-17,Adult 18-20,Adult 21+',
	--@DiagGroup INT = -300,
	--@PCT INT = 10,
	--@Catchment VARCHAR(MAX) = '-300'
	/*	END TESTING	*/

	-- I had to use temp tables to reference multiple times

	IF object_id('tempdb..#temp1') is not null
		BEGIN
			DROP TABLE #temp1
		END
	IF object_id('tempdb..#temp2') is not null
		BEGIN
			DROP TABLE #temp2
		END
	
	SELECT	dConsumer.ConsumerNK AS ConsumerID,
			dConsumer.LastName,
			dConsumer.FirstName,
			dConsumer.MiddleName,
			dConsumer.DOB,
			SUM(fClaims.AdjudicatedAmount) AS AdjudicatedAmount,
			AgeGroup.CustomGroupValue AS AgeGroup,
			dPlan.Insurer,
			dOrg.County,
			dServ.ServiceDefinition,
			dServ.ServiceDescription,
			dServ.ServiceDescriptionShort,
			dServ.ServiceCode,
			dServ.Modifier1 AS ModCode
	INTO	#temp1
	FROM	dw.factClaims AS fClaims with(nolock)
			INNER JOIN dw.dimBenefitPlan AS dPlan with(nolock) ON dPlan.BenefitPlanSK = fclaims.BenefitPlanSK
			INNER JOIN dw.dimDiagnosis AS dDiag with(nolock) ON dDiag.DiagnosisSK = fClaims.Diagnosis1SK
			INNER JOIN dw.dimConsumers AS dConsumer with(nolock) ON dConsumer.ConsumerSK = fClaims.ConsumerSK
			INNER JOIN dw.dimServices AS dServ with(nolock) ON fClaims.ServicesSK = dServ.ServicesSK
			INNER JOIN dw.dimDate AS dDOS with(nolock) ON dDOS.DateSK = fClaims.DateOfServiceSK
			INNER JOIN dw.dimOrganization AS dOrg with(nolock) ON dOrg.OrganizationSK = fClaims.OrganizationSK
			INNER JOIN dw.dimJunk AS dApprovedClaims with(nolock) ON dApprovedClaims.JunkSK = fClaims.StatusSK 
												AND dApprovedClaims.JunkEntity = 'ClaimAdjudicatedStatus'
												AND dApprovedClaims.JunkValue = 'Approved'
			INNER JOIN dw.dimAge AS dAge with(nolock) ON dAge.AgeSK = fClaims.AgeSK
			INNER JOIN dw.dimCustomReportGroups AS AgeGroup with(nolock) ON AgeGroup.CustomGroupName = 'CSPRChildResidentialAgeGroups'
									AND fClaims.AgeSK BETWEEN AgeGroup.BeganAttributeCodeRange AND AgeGroup.EndAttributeCodeRange
									AND AgeGroup.CustomGroupValue IN ( SELECT element FROM dbo.cfn_split(@Age, ',') )
	WHERE	dDOS.DateValue BETWEEN @StartDate AND @EndDate
			AND (
				( @InsurerID = dPlan.InsurerID ) OR -- 1 specific Plan
				( @InsurerID = -2 ) -- ALL Plans
				)
			AND (
				( @DiagGroup = dDiag.DiagnosisGroupID ) OR -- 1 specific Diag Group
				( @DiagGroup = -300 ) -- ALL Diag Groups
				)
			AND (
				@Catchment = '-300'
				OR CONVERT(nvarchar, dOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
				OR CONVERT(nvarchar, dOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
				)
	GROUP BY dConsumer.ConsumerNK,
			dConsumer.LastName,
			dConsumer.FirstName,
			dConsumer.MiddleName,
			dConsumer.DOB,
			AgeGroup.CustomGroupValue,
			dPlan.Insurer,
			dOrg.County,
			dServ.ServiceDefinition,
			dServ.ServiceDescription,
			dServ.ServiceDescriptionShort,
			dServ.ServiceCode,
			dServ.Modifier1
			
	SELECT	t1.ConsumerID,
			SUM(t1.AdjudicatedAmount) AS ClientTotal
	INTO	#temp2
	FROM	#temp1 AS t1
	GROUP BY t1.ConsumerID
		
	SELECT	t1.ConsumerID,
			t1.LastName,
			t1.FirstName,
			t1.MiddleName,
			t1.DOB,
			t1.AdjudicatedAmount,
			t1.AgeGroup,
			t1.Insurer,
			t1.County,
			t1.ServiceDefinition,
			t1.ServiceDescription,
			t1.ServiceDescriptionShort,
			t1.ServiceCode,
			t1.ModCode,
			t2.ClientTotal
	FROM	#temp1 AS t1
			INNER JOIN ( SELECT TOP (@PCT) PERCENT * FROM #temp2 ORDER BY ClientTotal DESC, ConsumerID ) AS t2 ON t1.ConsumerID = t2.ConsumerID
	ORDER BY t2.ClientTotal DESC, t1.ConsumerID