USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ServiceUsageBasedOnMaxLimits]    Script Date: 10/01/2013 10:16:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ServiceUsageBasedOnMaxLimits]
    (
      @MaxLim int 
	 ,@InsurerID int
	 ,@catchmentID varchar(max)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:   Service Usage Histogram based on Max Service Limits
-- File:    [REP].[ServiceUsageBasedOnMaxLimits]
-- Author:  Ammar Ahmed
-- Date:    08/15/2013
-- Desc:    Shows the percent utilization for services based on maxium allowable unit. 
--    Business reason:Identifies services which are being under utilized comapred to service limits
--                                          
-- CalledBy:
--          Reports: 
--          Stored Procs: 
--------------------------------------------------------------------------------
-- Change   Hisory
-- Ver      Date        Author                  TixNo    Description
-- ---      ----------  --------------- -----    ----------------------------
-- 1.0      08/15/2013  Ammar Ahmed     6526    Created
-- 2.0		10/1/2013	Justin Ward		6526	Added Service Descr and Order By Service Code
--------------------------------------------------------------------------------
--*/        

--Insurer
--Catchment
--Max Limits
----"Daily Max
----Weekly Max
----Monthly Max
----Yearly Max"

--Declare @MaxLim int ,@InsurerID int, @catchmentID varchar(max)
--set @MaxLim = 4
--set @InsurerID = -2
--set @catchmentID = '-300' --all

            
--Get the count 
select      
            DISTINCT
            s.ServicesNK
            ,s.ServiceCode
            ,s.ServiceDescriptionShort
            ,FC.ClaimAdjudicationNumber
            ,UnitsBilled
            ,Fsbp.DailyMaxServices 
            ,fsbp.WeeklyMaxServices
            ,fsbp.MonthlyMaxServices
            ,fsbp.YearlyMaxServices
            ,bp.BenefitPlanShort, bp.Insurer, bp.InsurerID
            ,JunkNK
            ,JunkValue
            ,fc.UnitsClaimed
            ,s.Modifier1
            ,s.Modifier2
            ,fc.OrganizationSK
            
           into   #temp  
from DW.factClaims fc with(nolock)
		INNER JOIN DW.dimDate DateOfService with(nolock)on fc.DateOfServiceSK = DateOfService.DateSK
		INNER JOIN DW.dimOrganization org with(nolock)on  org.OrganizationSK = fc.OrganizationSK
									--and (@catchmentID= -2 or org.CatchmentID= @catchmentID)
									
									
									
		INNER JOIN DW.dimServices s with(nolock)on s.ServicesSK = fc.ServicesSK
		INNER JOIN DW.dimServices s2 with(nolock)on s.ServicesNK = s2.ServicesNK
		INNER JOIN DW.dimServices s3 with(nolock)on s.ServicesNK = s3.ServicesNK
		Inner JOIN DW.factServicesBenefitPlan fsbp with(nolock)on fsbp.ServicesSK = s2.ServicesSK
		INNER JOIN dw.factServicesToInsurance fsti with(nolock)on fsti.ServicesSK = s3.ServicesSK			                                                                      
		inner join dw.dimBenefitPlan bp with(nolock)on fc.BenefitPlanSK = bp.BenefitPlanSK
		inner join dw.dimJunk jstat with(nolock)on fc.StatusSK = jstat.JunkSK


where			1=1
				  and fsbp.DiagnosticRelatedGroupingFlag = 0 
                  AND fsbp.RoomBoardFlag = 0 
                  AND fsbp.BillableFlag  = 1 
                  --AND DailyMaxServices  > 0 --this filter was used on the old query
                  --AND WeeklyMaxServices > 0 
                  AND (bp.InsurerID = @InsurerID or @InsurerID = -2)
                  AND jstat.JunkNK = '1' 
				  AND DateOfService.DateValue BETWEEN DATEADD(year, -1, GETDATE())AND GETDATE() --For the last year
 
         and (
			@catchmentID = '-300'
			OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchmentID, ',') )
			OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchmentID, ',') )
			)

--select * from #temp t
--where t.ServicesNK = 2


SELECT distinct
		A.ServicesNK
		,LTRIM(RTRIM(SERVICECODE)) SERVICECODE
		,A.ServiceDescriptionShort
		,COUNT(UnitsBilled) totalUnits
		,A.Modifier1  + ' ' +  A.Modifier2  as Modifiers
		
		,( select COUNT(t.UnitsBilled) from #temp t 
		where (cast(cast(UnitsBilled as float)/cast(nullif(
					(case(@MaxLim)
			when 1 then DailyMaxServices
			when 2 then WeeklyMaxServices 
			when 3 then MonthlyMaxServices
			when 4 then YearlyMaxServices
		 END),0)as float)as float))between 0.0 and 0.20 and t.ServicesNK=A.ServicesNK )as prct20
		

		,( select COUNT(t.UnitsBilled) from #temp t 
		where (cast(cast(UnitsBilled as float)/cast(nullif(
						(case(@MaxLim)
			when 1 then DailyMaxServices
			when 2 then WeeklyMaxServices 
			when 3 then MonthlyMaxServices
			when 4 then YearlyMaxServices
		 END),0)as float)as float)) between 0.21 and 0.40 and t.ServicesNK=A.ServicesNK )as prct40

		,( select COUNT(t.UnitsBilled) from #temp t 
		where (cast(cast(UnitsBilled as float)/cast(nullif(
						(case(@MaxLim)
			when 1 then DailyMaxServices
			when 2 then WeeklyMaxServices 
			when 3 then MonthlyMaxServices
			when 4 then YearlyMaxServices
		 END),0)as float)as float)) between 0.41 and 0.60 and t.ServicesNK=A.ServicesNK )as prct60

		,( select COUNT(t.UnitsBilled) from #temp t 
		where (cast(cast(UnitsBilled as float)/cast(nullif(
						(case(@MaxLim)
			when 1 then DailyMaxServices
			when 2 then WeeklyMaxServices 
			when 3 then MonthlyMaxServices
			when 4 then YearlyMaxServices
		 END),0)as float)as float)) between 0.61 and 0.80 and t.ServicesNK=A.ServicesNK )as prct80

		,( select COUNT(t.UnitsBilled) from #temp t 
		where (cast(cast(UnitsBilled as float)/cast(nullif
						(case(@MaxLim)
			when 1 then DailyMaxServices
			when 2 then WeeklyMaxServices 
			when 3 then MonthlyMaxServices
			when 4 then YearlyMaxServices
		 END,0)as float)as float)) between 0.81 and 1.00 and t.ServicesNK=A.ServicesNK )as prct100
			
		,( select COUNT(t.UnitsBilled) from #temp t 
		where (cast(cast(UnitsBilled as float)/cast(nullif(
						(case(@MaxLim)
			when 1 then DailyMaxServices
			when 2 then WeeklyMaxServices 
			when 3 then MonthlyMaxServices
			when 4 then YearlyMaxServices
		 END),0)as float)as float))> 1.01  and t.ServicesNK=A.ServicesNK )as prct100plus
			
		,( select MAX(t.UnitsBilled) from #temp t 
		where t.ServicesNK=A.ServicesNK )as max_used	
					
		,case WHEN @MaxLim = 1 THEN DailyMaxServices	ELSE	0 END as DailyMaxServices
		,case WHEN @MaxLim = 2 THEN WeeklyMaxServices	ELSE	0 END as WeeklyMaxServices
		,case WHEN @MaxLim = 3 THEN MonthlyMaxServices	ELSE	0 END as MonthlyMaxServices
		,case WHEN @MaxLim = 4 THEN YearlyMaxServices	ELSE	0 END as YearlyMaxServices
		
from		
			#temp A
group by	
			A.ServiceCode 
			,A.ServicesNK 
			,A.ServiceDescriptionShort
			,DailyMaxServices
			,WeeklyMaxServices
			,MonthlyMaxServices
			,YearlyMaxServices
			,A.Modifier1 ,A.Modifier2

order by  
			SERVICECODE

drop table #temp