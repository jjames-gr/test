USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[LateNoteSubmission]    Script Date: 09/10/2013 08:43:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [REP].[LateNoteSubmission] 
	@startDate datetime 
	,@endDate datetime 
	,@catchments varchar(512)
	,@disability varchar(100)
	,@CareContact int 
AS
/*------------------------------------------------------------------------------
-- Title:	CC Late Note Submission
-- File:	[Rep].[LateNoteSubmission]
-- Author:	Brian Angelo
-- Date:	08/15/2013
-- Desc:	Display the Care Coordinator / Support Facilitator that has submitted a note more than 4 days after date of service.
--			
-- CalledBy:
-- 		Reports: CC Late Note Submission
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/15/2013  Brian Angelo		8943	initial creation
 
--------------------------------------------------------------------------------*/

BEGIN

/*
/*** Test Parameters ***/
DECLARE
	@startDate datetime = '5/1/13'
	,@endDate datetime = '5/31/13'
	,@catchments varchar(512) = '1039,1040,1041,1042,1043'
	,@disability varchar(50) = -2
	,@CareContact varchar(50) = -2
--*/ 

-- return the full data set

SELECT DISTINCT 
emp.FullName as CaseManager
,fpn.ProgressNoteID as ProgressNoteID
,dos.DateValue as ServiceDate
,nsd.DateValue as SubmittedDate
,dcFPN.FullName as ConsumerName
FROM [BIW].[DW].[factProgressNotes] fpn WITH(NOLOCK)  
INNER JOIN [BIW].[DW].[dimEmployee] emp WITH(NOLOCK) ON  fpn.CaseManagerSK = emp.EmployeeSK
INNER JOIN [BIW].[DW].[dimDate] dos WITH(NOLOCK) ON  dos.DateSK = fpn.DateOfServiceSK
INNER JOIN [BIW].[DW].[dimDate] nsd WITH(NOLOCK) ON  nsd.DateSK = fpn.NotesSubmittedDateSK
INNER JOIN [BIW].[DW].[dimJunk] djps WITH(NOLOCK) ON  djps.JunkSK = fpn.ProgressStatusSK
INNER JOIN [BIW].[DW].[dimJunk] jc WITH(NOLOCK) ON jc.JunkSK = fpn.CatchmentSK
INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fpn.ServicesSK
INNER JOIN [BIW].[DW].[dimConsumers] dcFPN WITH(NOLOCK) ON dcFPN.ConsumerSK = fpn.ConsumerSK
INNER JOIN [BIW].[DW].[dimConsumers] dcFCCA WITH(NOLOCK) ON dcFCCA.ConsumerNK = dcFPN.ConsumerNK
INNER JOIN [BIW].[DW].[factCareCoordAdmissions] fcca WITH(NOLOCK) ON fcca.ConsumerSK = dcFCCA.ConsumerSK
INNER JOIN [BIW].[DW].[dimJunk] djCD WITH(NOLOCK) ON djCD.JunkSK = fcca.CareDisabilityGroupSK
where 1=1
and (djps.JunkNK = 'SUBMITTED' OR djps.JunkNK = 'APPROVED')
and DATEDIFF(day, dos.dateValue, nsd.dateValue) > 4
and ds.ServicesNK = 1386 
and fpn.TotalMinutesWithClient >= 8
AND (emp.EmployeeNK = @CareContact OR @CareContact = -2)
and nsd.dateValue between @startDate and @endDate
and jc.JunkNK in (select rtrim(ltrim(element)) from dbo.cfn_split(@catchments, ','))
AND (djCD.JunkNK = @disability OR @disability = -2)

order by emp.FullName

END



GO


