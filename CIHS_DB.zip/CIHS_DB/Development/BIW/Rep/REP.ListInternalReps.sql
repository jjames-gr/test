USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ListInternalReps]    Script Date: 08/06/2013 14:57:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ListInternalReps]
AS

/*------------------------------------------------------------------------------
	Title:		List Internal Reps
	File:		[Rep].[ListInternalReps]
	Author:		Tim Amerson
	Date:		07/29/13
	Desc:		This listing of Internal Reps can be used to fill the available 
					values for the Internal Reps Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/29/2013		Tim Amerson				----			Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
			(e.EmployeeNK = @InternalRep) OR 
			( @InternalRep = -2 )
		)

	-- OR FOR Multi-select:
		1. Filter in your Parameter to eliminate e.EmployeeNK = -2 
		2. Add the following to your FROM Clause:
			
			INNER JOIN dbo.cfn_split(@InternalRep , ',') AS IntRep ON IntRep.element = e.EmployeeNK
		
	-----------------------------------------------------------------------------------*/

	select distinct
		e.EmployeeNK,
		IsNull(e.LastName,'') + ', ' + IsNull(e.FirstName,'') + ' ' + IsNull(e.MiddleInitial,'') as [description],
		e.LastName,
		2 as eOrder,
		CASE	
			WHEN dj.JunkNK = NetSpecJobs.AttributeID
			THEN 1
			ELSE 0
		END as ProvActiveSumFlag
	from
		dw.dimEmployee e
		inner join dw.factProviderRep pr on e.EmployeeSK = pr.EmployeeSK
		inner join dw.dimJunk dj on pr.JobSK = dj.JunkSK and dj.JunkEntity = 'ProviderRepJobs'
		LEFT OUTER JOIN DW.dimCustomReportGroups NetSpecJobs WITH(NOLOCK) ON dj.JunkNK = NetSpecJobs.AttributeID
		AND CustomGroupName = 'NetworkSpecialistJobs'
	where
		e.Active = 1 
	
	UNION
	
	SELECT
		-2 AS EmployeeNK ,
		'All Internal Reps' as [description],
		'' as LastName,
		1 as eOrder,
		1 as ProvActiveSumFlag
	
	ORDER BY
		eOrder, LastName