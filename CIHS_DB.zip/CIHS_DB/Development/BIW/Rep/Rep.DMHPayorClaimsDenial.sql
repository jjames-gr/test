USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[DMHPayorClaimsDenial]    Script Date: 09/18/2013 10:34:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO









CREATE PROCEDURE [REP].[DMHPayorClaimsDenial]
    (
		@ServiceStartDt DATETIME,
		@ServiceEndDt DATETIME,
		@ProcessedStartDt DATETIME,
		@ProcessedEndDt DATETIME,
		@SentStartDt DATETIME,
		@SentEndDt DATETIME,
		@DMHResaoncode VARCHAR(MAX)
		
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	DMH Payor Claims Denial
-- File:	[Rep].[DMHPayorClaimsDenial]
-- Author:	Divya Lakshmi
-- Date:	9/3/2013
-- Desc:	NC Tracks Payor Claims Denials
--                                          
-- CalledBy:
--          Reports: DMH002 - DMHPayorClaimsDenial.rdl
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		9/3/2013  Divya Lakshmi	    6451	  Created
--------------------------------------------------------------------------------
*/

--Variables 
--DECLARE
--@ServiceStartDt DATETIME,
--		@ServiceEndDt DATETIME,
--		@ProcessedStartDt DATETIME,
--		@ProcessedEndDt DATETIME,
--		@SentStartDt DATETIME,
--		@SentEndDt DATETIME,
--		@DMHResaoncode VARCHAR(MAX)
		
--SET   @ServiceStartDt ='1/1/2012'
--SET	  @ServiceEndDt ='1/31/2012'
--SET	  @ProcessedStartDt ='1/1/2012'
--SET	  @ProcessedEndDt ='1/31/2012'
--SET	  @SentStartDt ='1/1/2012'
--SET	  @SentEndDt ='1/31/2012'
--SET	  @DMHResaoncode =-1

SELECT	DISTINCT
	fc.ClaimNumber	AS	'Claim Number',
	srvDate.DateValue AS 'Claim Date',
	fc.ClaimAdjudicationNumber AS 'Adjudication Number',
	c.ConsumerNK	AS	'Consumer ID' ,
	c.LastName+''+c.FirstName	AS	'Consumer Name' ,
	fc.BillingNPINumber AS 'Billing NPI Id',
	s.ServiceCode AS 'Service Code',
	s.Modifier1 AS 'Modifier 1',
	s.Modifier2 AS 'Modifier 2',
	s.DMHStateServiceCode AS 'State Service Code',
	s.DMHStateServiceModifier1 AS 'State Modifier 1',
	s.DMHStateServiceModifier1 AS 'State Modifier 2',
	pos.PlaceOfServiceCode AS 'Place Of Service Code',
	fc.UnitsClaimed As 'Units Claimed',
	tc.TaxonomyCode AS 'Taxanomy Code',
	fc.AdjudicatedAmount AS 'Adjudicated Amount',
	fc.RenderingNPINumber AS 'Rendering NPI Number',
	fc.DMHSentDateSK AS 'Sent Date',
	r.DMHReasonCode AS 'DMH Reason Code',
	r.DMHReason AS 'DMH Reason Description',
	c.LastName+'' + c.FirstName AS 'Clinician Name',
	p.ProviderNK AS 'Provider ID',
    p.ProviderName AS ProviderName,
    p1.ParentProviderNK,
  --  fpm.MedicaidNumber AS 'MCD Number'  ,
    MCDNumber = 
                  
                  REPLACE
                  (
                        REPLACE
                        (
                              (
                              
								  SELECT DISTINCT
								  REPLACE(RTRIM(fpm.MedicaidNumber),' ', CHAR(127)) AS [data()]
								  FROM DW.factProviderNPIMedicaidID fpm
								  WHERE fpm.ProviderSK = p.ProviderSK and fpm.ActiveFlag=1
                                  FOR XML PATH('') 
                              ),
                              ' ', '; '
                        ),
                        CHAR(127), ' '
                  )

FROM 
		DW.factClaims fc   WITH(NOLOCK)
		LEFT OUTER JOIN DW.dimServices s WITH(NOLOCK) ON fc.ServicesSK = s.ServicesSK
		LEFT OUTER JOIN DW.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK = c.ConsumerSK
        LEFT OUTER JOIN DW.dimDiagnosis diag WITH(NOLOCK) ON fc.Diagnosis1SK= diag.DiagnosisSK
		LEFT OUTER JOIN DW.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK 
        LEFT OUTER JOIN DW.dimProvider p1 WITH(NOLOCK) ON  p.ProviderNK = p1.ParentProviderNK 
		LEFT OUTER JOIN DW.dimPlaceOfService pos WITH(NOLOCK) ON  fc.PlaceOfServiceSK = pos.PlaceOfServiceSK
		LEFT OUTER JOIN DW.dimTaxonomyCodes tc WITH(NOLOCK) ON  fc.TaxonomyCodeSK = tc.TaxonomyCodeSK 
		LEFT OUTER JOIN DW.dimclinician cl WITH(NOLOCK) ON  fc.ClinicianSK = cl.ClinicianSK 
		LEFT OUTER JOIN DW.dimDate srvDate WITH(NOLOCK) ON fc.DateOfServiceSK = srvDate.DateSK  
	    LEFT OUTER JOIN DW.dimDate ProcessDate WITH(NOLOCK)ON fc.AdjudicationDateSK = ProcessDate.DateSK 
	    LEFT OUTER JOIN DW.dimDate SentDate WITH(NOLOCK) ON fc.DMHSentDateSK = SentDate.DateSK   

		LEFT OUTER JOIN DW.factProviderNPIMedicaidID fpm WITH(NOLOCK) ON p.ProviderSK= fpm.ProviderSK and fpm.ActiveFlag=1
		LEFT OUTER JOIN DW.dimDMHReason r WITH(NOLOCK) ON fc.DMHReasonSK = r.DMHReasonSK
		LEFT OUTER JOIN DW.dimJunk djunk WITH(NOLOCK) ON fc.DMHCrossoverMedicaidClaimSK = djunk.JunkSK 
					
WHERE 
1=1
AND fc.DMHSentStatusCode = 'D'
AND ((srvDate.DateValue BETWEEN @ServiceStartDt AND @ServiceEndDt)
OR  (ProcessDate.DateValue BETWEEN @ProcessedStartDt AND dateadd(dd,1,@ProcessedEndDt))
OR  (SentDate.DateValue BETWEEN @SentStartDt AND dateadd(dd,1,@SentEndDt))
OR  (DateOfServiceSK =-1)
)
AND (r.DMHReasonCode=@DMHResaoncode or @DMHResaoncode = -1)
AND s.Active=1
AND djunk.JunkNK <> '1'

ORDER BY ConsumerNK












GO

