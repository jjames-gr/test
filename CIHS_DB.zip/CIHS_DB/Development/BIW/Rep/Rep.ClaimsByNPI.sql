USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ClaimsByNPI]    Script Date: 09/11/2013 17:13:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ClaimsByNPI]
    (
		@StartDate DATETIME,
		@EndDate DATETIME,
		@NPIType int, 
		@NPINumber varchar(100)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Claims by NPI
-- File:	[Rep].[ClaimsByNPI]
-- Author:	Divya Lakshmi
-- Date:	05/21/2013
-- Desc:	Claim detail listed by NPI.
--			Provides claims detail by NPI.  Used to  list claim detail by service, client/consumer, date, county, insurance and provider
--                                          
-- CalledBy:
--          Reports: CLM335 Claims By NPI
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		05/21/2013  Divya Lakshmi	6305	  Created
-- 2.0		8/26/2013	Ammar Ahmed		6305	  found provider npi by BillingNPINumber
--------------------------------------------------------------------------------
*/

--Variables 
--Declare	@StartDate DATETIME
--	SET @StartDate ='1/1/2013'-- '1/1/2012'	
--Declare	@EndDate DATETIME
--	SET @EndDate = '1/2/2013' --'1/31/2013'	
--DECLARE @NPIType int
--	SET @NPIType = 1 --20150
--DECLARE @NPINumber varchar(100)
--	SET @NPINumber = '1114080181'--'1114080181'--'1508857699' --20150

SELECT	distinct
    p.ProviderNK,
    p.ProviderName,
   	JunkValue,
	c.CONSUMERNK	AS	'Consumer ID' ,
	fc.PROVIDERSK	AS	'Site ID',
	fc.CLAIMNUMBER	AS	'Claim Number',
	srvDate.DateValue AS 'DateOfService',
	receivedDate.DateValue As 'Received Date',
	s.SERVICECODE	AS	'Srvc Code',
	fc.UNITSCLAIMED	AS	'Billed Units',
	--CASE 
	--	WHEN (fc.StatusSK = 1 )
	--	THEN 'Approved Units' 
	--	WHEN  (fc.StatusSK = 2 OR fc.StatusSK = 3)
	--	THEN ''
 --   END as UnitsBilled,
    Case when cl.npi=p.npi then 'prov' else 'Rendering Npi' end as npi,
	fc.UNITSBILLED	AS	'Approved Units',
	(fc.CLAIMAMOUNT /NULLIF(fc.UNITSCLAIMED,0))	AS	'CalcRate',
	fc.ContractRate	AS	'Contract Rate',
	fc.CLAIMAMOUNT	AS	'Billed Amount',
	fc.AdjudicatedAmount	AS	'ApprovedAmount',
	fc.AdjustedAmount AS 'AdjustedAmount',
	fc.ADJUSTEDAMOUNT	AS	'Denied',
	fc.PAIDAMOUNT	AS	'PaidAmount',
	fc.CAPITATEDAMOUNT	AS	'Capitated Amount',
	rc.ReasonCodeNK	AS	'Reason',
	b.BENEFITPLANSHORT 	AS	'Funding Plan'
	--,p.NPI
	,cl.NPI clnpi
	,fc.BillingNPINumber as NPI
	,cl.FullName

	
FROM 
		DW.factClaims fc   WITH(NOLOCK)
		INNER JOIN DW.dimServices s WITH(NOLOCK) on s.ServicesSK = fc.ServicesSK
		INNER JOIN DW.dimConsumers c WITH(NOLOCK) on c.ConsumerSK = fc.ConsumerSK
		INNER JOIN DW.dimBenefitPlan b WITH(NOLOCK) on b.BenefitPlanSK = fc.BenefitPlanSK
		INNER JOIN DW.DIMPROVIDER p WITH(NOLOCK) on  fc.ProviderSK = p.ProviderSK 
		INNER JOIN DW.dimClinician cl with(nolock) ON fc.ClinicianSK= cl.ClinicianSK
		INNER JOIN DW.dimJunk junk WITH(NOLOCK) on fc.STATUSSK = junk.JUNKSK
		
		INNER JOIN DW.dimReasonCodes rc on rc.REASONCODESK = fc.REASONCODESK
		
		--Get the dates
		INNER JOIN DW.dimDate srvDate ON fc.DateOfServiceSK = srvDate.DateSK  
		INNER JOIN DW.dimDate receivedDate ON fc.ReceivedDateSK = receivedDate.DateSK 				
--
Where 
srvDate.DateValue BETWEEN @StartDate and @EndDate 
AND   
(
		(@NPIType = 1  AND (cl.NPI = @NPINumber or p.NPI = @NPINumber))-- Rendering NPI
			OR (@NPIType = 2 AND fc.BillingNPINumber=@NPINumber) --Provider NPIc
 )


order by ConsumerNK

