USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ClaimsMissingClientCOB]    Script Date: 06/20/2013 13:00:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ClaimsMissingClientCOB]
	@DateSearchType bit,
	@StartDate datetime,
	@EndDate datetime,
	@ProviderID int,
	@ConsumerID int
AS
/*------------------------------------------------------------------------------
-- Title:	Claims Missing Client COB
-- File:	[Rep].[ClaimsMissingClientCOB]
-- Author:	Brian Angelo
-- Date:	06/7/2013
-- Desc:	Claims Missing Client COB stored proc
--			
-- CalledBy:
-- 		Reports: "Claims Missing Client COB"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	06/7/2013	Brian Angelo		8214	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	/*
	/*** Test Parameters ***/
	DECLARE @DateSearchType bit,
		@StartDate datetime,
		@EndDate datetime,
		@ProviderID int,
		@ConsumerID int
	
	SET @DateSearchType = 1
	SET @StartDate = '1/1/12'
	SET @EndDate = '12/31/12'
	SET @ProviderID = 21630
	SET @ConsumerID = null
	--*/

	IF @ConsumerID is null
		SET @ConsumerID = -1
    
    ;WITH cteHasCOB AS 
	(	
		SELECT DISTINCT ConsumerNK
		FROM [BIW].[DW].[factCOB] fCOB
		INNER JOIN [BIW].[DW].[dimConsumers] dc on dc.ConsumerSK = fCOB.ConsumerSK
	)
    
    SELECT 
    dp.ProviderNK as ProviderID
    ,dp.ProviderName
    ,dc.ConsumerNK as ConsumerID
    ,fc.ClaimNumber
    ,ddAD.[DateName_en-US] as AdjudicatedDate
    ,ddDOS.[DateName_en-US] as DateOfService
    ,fc.ServiceLineRevenueCode
    ,ds.ServiceCode
    ,fc.UnitsBilled
    ,fc.UnitsClaimed as UnitsAdjudicated
    ,fc.ContractRate
    ,fc.ClaimAmount as BilledAmount
    ,fc.AdjudicatedAmount*fc.UnitsClaimed as AdjudicatedAmount
    ,fc.COBAmount
    ,fc.AdjustedAmount as DeniedAmount
    ,drc.ReasonCodeNK as DenialReasonCode
    ,dbp.BenefitPlanShort as FundingSource
    ,dbt.BillTypeCodeNK
    FROM [BIW].[DW].[factClaims] fc
    INNER JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fc.DateofServiceSK
    INNER JOIN [BIW].[DW].[dimDate] ddRD WITH(NOLOCK) ON ddRD.DateSK = fc.ReceivedDateSK
    INNER JOIN [BIW].[DW].[dimDate] ddAD WITH(NOLOCK) ON ddAD.DateSK = fc.AdjudicationDateSK
    INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fc.ProviderSK
    INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fc.ConsumerSK
    INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
	INNER JOIN [BIW].[DW].[dimReasonCodes] drc WITH(NOLOCK) ON drc.ReasonCodeSK = fc.ReasonCodeSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimBillType] dbt WITH(NOLOCK) ON dbt.BillTypeSK = fc.BillTypeSK
    WHERE fc.COBAmount > 0
    AND dc.ConsumerNK not in (SELECT ConsumerNK FROM cteHasCOB)
    AND (CASE WHEN @DateSearchType = 1 THEN ddDOS.DateValue ELSE ddRD.DateValue END) BETWEEN @StartDate AND @EndDate
    AND (@ProviderID = -2 OR dp.ProviderNK = @ProviderID)
    AND (@ConsumerID = -1 OR dc.ConsumerNK = @ConsumerID)

    
END




GO


