USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[CCServiceHistory]    Script Date: 09/11/2013 10:50:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[CCServiceHistory] 
(
	@strDate DATE,
	@endDate DATE,
	@consumerID INT,
	@dateType INT, --1 Date of Service 2 Date of Submission
	@disability varchar(100), --MHSA DD All
	@careCoord INT,
	@service INT,--1386,2351
	@catchment VARCHAR(100)
)
AS


/*------------------------------------------------------------------------------
	Title:		CC Service History
	File:		[REP].[CCServiceHistory] 
	Author:		Karissa Martindale
	Date:		08/2/13
	Desc:		Consumer History of Service
                                        
	Called By:
                        Reports:          
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/2/2013		Karissa Martindale   	8948			 Creation
-----------------------------------------------------------------------------------*/


--DECLARE
--	@strDate DATE = '5/1/13',
--	@endDate DATE = '5/31/13',
--	@consumerID INT = null,
--	@dateType INT = 1, --1 Date of Service 2 Date of Submission
--	@disability varchar(100) = '-300', --MHSA DD All
--	@careCoord INT = 692,
--	@service INT = -300,--1386,2351
--	@catchment VARCHAR(100) = '1039, 1040, 1041, 1042, 1043'
	
	
Select distinct 
	C.ConsumerNK,
	--CONVERT(VARCHAR(6), GETDATE(), 112) + '01' AS [YYYYMMDD],
	MAX(e.DateSK) as maxdate, 
	BenefitPlanSK
into #benPlan
from 
	dw.factEligibility e
	inner join dw.dimConsumers c WITH(NOLOCK) on e.ConsumerSK = c.ConsumerSK
	inner join dw.dimJunk j WITH(NOLOCK) on e.ActionSK = j.JunkSK
	INNER JOIN dw.dimDate d WITH(NOLOCK) ON e.DateSK = d.DateSK
where 
	j.JunkValue in ('Effective','Active')
	and d.DateValue BETWEEN @strDate AND @endDate--= CONVERT(VARCHAR(6), GETDATE(), 112) + '01'
group by ConsumerNK, BenefitPlanSK

SELECT DISTINCT
	fProgN.ProgressNoteID,
	dCon.ConsumerNK,
	dCon.LastName + ',' + dCon.FirstName as Name,
	CASE 
	WHEN dBenPlan.BenefitPlanNK = 4 THEN 'Y'
	ELSE 'N'
	END as Innovations,
    BenefitPlan = 
      REPLACE
      (
        REPLACE
        (
          (
			  SELECT DISTINCT
			  REPLACE(RTRIM(dBenPlan.BenefitPlanShort),' ', CHAR(127)) AS [data()]
			  FROM #benPlan bp
				INNER JOIN 	dw.dimBenefitPlan dBenPlan WITH(NOLOCK) ON bp.BenefitPlanSK = dBenPlan.BenefitPlanSK
			  WHERE bp.ConsumerNK = dCon.ConsumerNK 
              FOR XML PATH('') 
		  ),
		  ' ', '; '
		),
		CHAR(127), ' '
	  ),
	dServ.ServiceDescription,
	DOS.DateValue as DOSDate,
	SubDate.DateValue as subDate,
	fProgN.DaysElaspsedNotesSubmitted,
	fProgN.TotalMinutesWithClient,
	dCareCord.LastName + ',' + dCareCord.FirstName as careCoordName,
	CASE
	WHEN dJunkCare.JunkNK = '1037' THEN 'Care Coord'
	WHEN dJunkCare.JunkNK = '1038' THEN 'Supp Facil'
	ELSE ''
	END as caretype
FROM
	dw.factProgressNotes fProgN WITH(NOLOCK) 
	INNER JOIN dw.dimJunk dJunkCatch WITH(NOLOCK) ON fProgN.CatchmentSK = dJunkCatch.JunkSK AND dJunkCatch.JunkEntity = 'AreaCatchments'
	INNER JOIN dw.dimConsumers dCon WITH(NOLOCK) ON fProgN.ConsumerSK = dCon.ConsumerSK
	INNER JOIN dw.dimBenefitPlan dBenPlan WITH(NOLOCK) ON fProgN.BenefitPlanSK = dBenPlan.BenefitPlanSK
	INNER JOIN dw.dimServices dServ WITH(NOLOCK) ON fProgN.ServicesSK = dServ.ServicesSK
	LEFT JOIN dw.dimEmployee dCareCord WITH(NOLOCK) ON fProgN.CaseManagerSK = dCareCord.EmployeeSK 
		LEFT JOIN dw.dimJunk dJunkCare WITH(NOLOCK) ON fProgN.CareContactTypeSK = dJunkCare.JunkSK 
	INNER JOIN dw.dimDate DOS WITH(NOLOCK) ON fProgN.DateOfServiceSK = DOS.DateSK
	INNER JOIN dw.dimDate SubDate WITH(NOLOCK) ON fProgN.NotesSubmittedDateSK = SubDate.DateSK
	INNER JOIN dw.dimConsumers dJoinCon WITH(NOLOCK) ON dJoinCon.ConsumerNK = dCon.ConsumerNK
	INNER JOIN DW.factCareCoordAdmissions fCareAd WITH(NOLOCK) ON fCareAd.ConsumerSK = dJoinCon.ConsumerSK
	INNER JOIN DW.dimJunk dJunkData WITH(NOLOCK) ON fCareAd.CareDisabilityGroupSK = dJunkData.JunkSK
WHERE
	(@consumerID = dCon.ConsumerNK OR @consumerID is null)
	AND (dJunkCare.JunkNK = '1038' OR dJunkCare.JunkNK = '1037')
	AND (@careCoord = dCareCord.EmployeeNK OR @careCoord = -300)
	--1 Date of Service 2 Date of Submission
	AND ((@dateType = 1 AND DOS.DateValue BETWEEN @strDate AND @endDate) OR (@dateType = 2 AND SubDate.DateValue BETWEEN @strDate AND @endDate) )
	AND (dServ.ServicesNK = @service OR (@service = -300 AND dServ.ServicesNK IN (1386,2351)))
	AND dJunkCatch.JunkNK in (select rtrim(ltrim(element)) from dbo.cfn_split(@catchment, ','))
	AND (@disability = dJunkData.JunkNK OR @disability = '-300')
order by ConsumerNK

DROP TABLE #benPlan

