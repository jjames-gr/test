USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[DMHDiscontinuedTargetPop]    Script Date: 09/27/2013 11:03:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [REP].[DMHDiscontinuedTargetPop]
    (
		@ServiceStartDt DATETIME,
		@ServiceEndDt DATETIME
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Consumers with Discontinued DMH Target Population
-- File:	[REP].[DMHDiscontinuedTargetPop]
-- Author:	Divya Lakshmi
-- Date:	9/10/2013
-- Desc:	Report identified state funded members who have had a claim or authorization
            in the past 3 months, but have no current active Target Population assigned.
--                                          
-- CalledBy:
--          Reports: UMA032 - DMHDiscontinuedTargetPop.rdl
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		9/10/2013  Divya Lakshmi	 6331	  Created
--------------------------------------------------------------------------------
*/

--Variables 
--DECLARE
--@ServiceStartDt DATETIME,
--@ServiceEndDt DATETIME

		
--SET   @ServiceStartDt ='1/1/2012'
--SET	  @ServiceEndDt ='1/31/2012'


SELECT	DISTINCT
	c1.ConsumerNK	AS	ConsumerID,
	c1.LastName AS LastName,
	c1.FirstName AS FirstName,
	c1.DOB	AS	DOB ,
	dpg.DMHPopulationGroupCode ,
	ExpDate.DateValue AS ExpirationDt,
	srvDate.DateValue AS DOS,
	diag.DiagnosisCode,
	diag.Diagnosis AS DiagnosisDescription,
	s.ServiceCode,
	s.ServiceDescriptionShort,
	p1.ProviderNK AS ProviderID,
	p1.ProviderName

FROM 
		DW.factDMHPopulationGroups fpg   WITH(NOLOCK)
		INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fpg.ConsumerSK = c.ConsumerSK
		INNER JOIN DW.dimConsumers c1 WITH(NOLOCK) ON c.ConsumerNK = c1.ConsumerNK
        INNER JOIN DW.factClaims fc WITH(NOLOCK) ON  fc.ConsumerSK = c1.ConsumerSK
        INNER JOIN DW.dimDiagnosis diag WITH(NOLOCK) ON fc.Diagnosis1SK= diag.DiagnosisSK
		INNER JOIN DW.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK 
        INNER JOIN DW.dimProvider p1 WITH(NOLOCK) ON  p1.ProviderNK = p.ParentProviderNK 
		INNER JOIN DW.dimServices s WITH(NOLOCK) ON  fc.ServicesSK = S.ServicesSK
		INNER JOIN DW.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK= bp.BenefitPlanSK
		INNER JOIN DW.dimDMHPopulationGroups dpg WITH(NOLOCK) ON  fpg.DMHPopulationGroupSK = dpg.DMHPopulationGroupSK
		INNER JOIN DW.dimDate srvDate WITH(NOLOCK) ON fc.DateOfServiceSK = srvDate.DateSK
		INNER JOIN DW.dimDate ExpDate WITH(NOLOCK) ON fpg.ExpirationDateSK = ExpDate.DateSK

		

					
WHERE 
c1.Active=1 AND c.Active=1
AND srvDate.DateValue BETWEEN @ServiceStartDt AND @ServiceEndDt
AND fpg.ExpirationDateSK < fc.DateOfServiceSK
AND bp.InsurerID=1
AND p1.ProviderNK <> -1

ORDER BY ConsumerID














GO


