USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ListServices]    Script Date: 08/08/2013 15:29:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListServices]
	@ServiceType INT,
	@PassedID INT
AS

/*------------------------------------------------------------------------------
	Title:		List Service Definitions
	File:		rep.ListServices
	Author:		Tim Amerson
	Date:		02/20/2013
	Desc:		This listing of service definitions can be used to fill the available 
					values for a service defintion Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/18/2013		Tim Amerson     		----			Created
			2.0		08/08/2013		Justin Ward				----			Added All option to Service Summary List
	
	Usage directions:
	--Declare variable as NVARCHAR
	-- Add the following to your FROM CLAUSE:
		
		-For Services By Definition
		dw.dimServices srvc
		INNER JOIN dbo.cfn_split(@ServDefID , ',') fn ON element = srvc.ServiceDefinitionID
		
		-For Services By Code/Description
		dw.dimServices srvc
		INNER JOIN dbo.cfn_split(@ServNK , ',') fn ON element = srvc.ServicesNK
		
		-For Services By Summary
		dw.dimServices srvc
		INNER JOIN dbo.cfn_split(@ServSummID , ',') fn ON element = srvc.ServiceDefinitionID

--	-----------------------------------------------------------------------------------*/
--DECLARE
--	@ServiceType INT = 3,
--	@PassedID INT = -2

IF @ServiceType = 1
	BEGIN
		/*Services By Definition*/
		SELECT DISTINCT
			'' AS ServicesNK
			, ds.ServiceDefinitionID
			, ds.ServiceDefinition,
			2 as orderby
			
		
		FROM
			dw.dimServices ds WITH(NOLOCK)
			
		ORDER BY
			ds.ServiceDefinition
	END

ELSE IF @ServiceType = 2
	BEGIN
		/*Services By Description*/
		SELECT DISTINCT
			ds.ServicesNK
			, ds.ServiceCode AS ServiceDefinitionID
			, ds.ServiceDescription AS ServiceDefinition,
			2 as orderby
		FROM
			dw.dimServices ds WITH(NOLOCK)
		WHERE
			@PassedID = -2 OR ds.ServiceSummaryID = @PassedID
		ORDER BY
			ds.ServiceDescription
	END

ELSE IF @ServiceType = 3
	BEGIN
		/*Services By Summary*/
		SELECT DISTINCT
			'' AS ServicesNK
			, ds.ServiceSummaryID AS ServiceDefinitionID
			, ds.ServiceSummary AS ServiceDefinition,
			2 as orderby
		FROM
			dw.dimServices ds WITH(NOLOCK)
	UNION
	SELECT 
		'' as ServicesNK,
		-2 as ServiceDefinitionID,
		'All Service Summaries' as ServiceDefinition,
		1 as orderby
			
		ORDER BY
			orderby
	END
