USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[DailyClaimEDDenialsAudit]    Script Date: 07/24/2013 15:15:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[DailyClaimEDDenialsAudit]
	@StartDate DATETIME
	, @EndDate DATETIME
	, @Provider NVARCHAR(MAX)
	, @Consumer NVARCHAR(MAX)
AS

/*------------------------------------------------------------------------------
	Title:		Daily Claim ED Denials Audit
	File:		[Rep].[DailyClaimEDDenialsAudit]
	Author:		Tim Amerson
	Date:		05/29/2013
	Desc:		This report will indicate claims with any Emergency Department 
				service line that has denied. 
				We need to be able to monitor any service that may have denied due 
				to system/contract setup incomplete per Mercer. 
                                        
	Called By:
                        Reports:          CLA - Daily Claim ED Denials Audit
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/09/2013		Tim Amerson     		8796			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2012',
--	@EndDate DATETIME = '12/31/2012',
--	@Provider NVARCHAR(MAX) = '21630, 20706, 22012',
--	@Consumer NVARCHAR(MAX)
	
	
SELECT DISTINCT
	CASE
		WHEN dos.DateValue BETWEEN @StartDate AND @EndDate THEN 1
		ELSE 0
	END DOSFlag,
	
	CASE
		WHEN adj.DateValue BETWEEN @StartDate AND @EndDate THEN 2
		ELSE 0
	END ADJFlag,
	
	p.ProviderNK AS 'Provider Number',
	p.ProviderName AS 'Provider Name',
	c.ConsumerNK AS 'Client ID',
	fc.ClaimNumber AS 'Claim Number',
	adj.[DateName_en-US] AS 'Adjudicated Date',
	dos.[DateName_en-US] AS 'Date of Service',
	fc.ServiceLineRevenueCode AS 'Revenue Code',
	s.ServiceCode AS 'Service Code',
	fc.UnitsBilled AS '# of Units Billed',
	fc.UnitsClaimed AS '# of Units Approved',
	(fc.UnitsBilled - fc.UnitsClaimed) AS '# of Units Denied',
	fc.ContractRate AS 'Contract Rate',
	fc.ClaimAmount AS 'Billed Amt',
	fc.AdjudicatedAmount AS 'Approved Amt',
	fc.AdjustedAmount AS 'Denied Amt',
	rc.ReasonCodeNK AS 'Denial Reason Code',
	ben.BenefitPlan AS 'Funding Source',
	b.BillTypeCodeNK AS 'Bill Type'

FROM
	DW.factClaims fc
	INNER JOIN DW.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK
	INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK = c.ConsumerSK
	INNER JOIN DW.dimServices s WITH(NOLOCK) ON fc.ServicesSK = s.ServicesSK
	INNER JOIN DW.dimBillType b WITH(NOLOCK) ON fc.BillTypeSK = b.BillTypeSK
	INNER JOIN DW.dimBenefitPlan ben WITH(NOLOCK) ON fc.BenefitPlanSK = ben.BenefitPlanSK
	INNER JOIN DW.dimDate adj WITH(NOLOCK) ON fc.AdjudicationDateSK = adj.DateSK
	INNER JOIN DW.dimDate dos WITH(NOLOCK) ON fc.DateOfServiceSK = dos.DateSK
	INNER JOIN DW.dimReasonCodes rc WITH(NOLOCK) ON fc.ReasonCodeSK = rc.ReasonCodeSK
	INNER JOIN DW.dimJunk stat WITH(NOLOCK) ON fc.StatusSK = stat.JunkSK
	INNER JOIN dbo.cfn_split(@Provider, ',') fnProv ON fnProv.element = p.ProviderNK

WHERE 
	stat.JunkNK = '2'
	AND LTRIM(RTRIM(b.BillTypeGroup)) = 'Hospital Outpatient'
	AND s.ServiceSummary = 'Emergency Department'
	AND ( @Consumer IS NULL
		OR c.ConsumerNK = @Consumer )
	AND ( dos.DateValue BETWEEN @StartDate AND @EndDate
		OR adj.DateValue BETWEEN @StartDate AND @EndDate )

order by
	p.ProviderNK,
	c.ConsumerNK,
	fc.ClaimNumber
	
GO


