USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[OutstandingGPInvoices]    Script Date: 09/10/2013 15:39:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE ALTER procedure [REP].[OutstandingGPInvoices]
AS
/*-----------------------------------------------------------------------------
	Title:		 Outstanding GP Invoices 

	File:		[REP].[OutstandingGPInvoices]
	Author:		Kevin Hamilton	
	Date:		06/25/2013
	Desc:		Outstanding Invoices by Provider for invoices over 90 days old			
		

                                        
	Called By:
                        Reports:         FIN023-Outstanding GP Invoices 


                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/25/2013		Kevin Hamilton     		6449			Created

	-----------------------------------------------------------------------------------*/

SELECT DISTINCT
p.ProviderName,
p.ProviderNK,
fch.AdjudicatedAmount,
dd.DateValue,
ClaimAdjudicationNumber,
fac.GLBatchNumber,
fch.ClaimCheckSK 

INTO #tempAccountMaster

FROM 
	DW.FactClaimsHistorical fch with(nolock)
	INNER JOIN dw.dimProvider p with(nolock) On fch.ProviderSK = p.ProviderSK
	INNER JOIN dw.factApprovedClaims fac with(nolock)ON fac.factClaimsHistoricalSK =  fch.factClaimsHistoricalSK
	INNER JOIN dw.dimDate dd with(nolock) ON dd.DateSK = fac.ApprovedTransactionDateSK  
	
			
				
WHERE 
	fch.CapitatedSK  = 10
	AND fch.AdjudicatedAmount > 0
	AND fch.PaidAmount <= 0
	AND p.ProviderNK <> 20790
	AND DATEDIFF(day, GETDATE(),dd.DateValue) <= -90
	AND ISNULL(fac.GLBatchNumber,'0') <> '0'
	
	
	
	DELETE #tempAccountMaster 
	FROM #tempAccountMaster t,
		dw.factCreditMemo fcm
	WHERE t.ClaimAdjudicationNumber = fcm.AppliedClaimAdjudicationNumber
			AND fcm.VoidedCreditMemoSK <> 7
	
	
	DELETE #tempAccountMaster 
	FROM #tempAccountMaster t, 
		dw.factClaimCheck fcc
	WHERE t.ClaimCheckSK = fcc.ClaimCheckSK 
			AND  fcc.VoidedCheckSK <> 7
	
	
	SELECT t.*
	FROM #tempAccountMaster t
	
	
	DROP TABLE #tempAccountMaster
	
	



