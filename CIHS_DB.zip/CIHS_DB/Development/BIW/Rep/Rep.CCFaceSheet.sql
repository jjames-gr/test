USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ccFaceSheet]    Script Date: 08/28/2013 12:51:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [REP].[ccFaceSheet]
	@ConsumerID varchar(max),
  @CareCoord int 

AS
/*------------------------------------------------------------------------------
	Title:		CC FaceSheet
	File:		[REP].[ccFaceSheet]
	Author:		Kevin Hamilton	
	Date:		07/26/2013
	Desc:		Consumer specific demographic information
					
                                        
	Called By:
                        Reports:          CCO004-ccFaceSheet.rdl	

                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/03/2013		Kevin Hamilton     		8950			Created

	-----------------------------------------------------------------------------------*/
	
BEGIN

--DECLARE @ConsumerID varchar(500)
--DECLARE @CareCoord int

--SET @ConsumerID = -2
--SET @CareCoord = -2

If @ConsumerID is null or @ConsumerID = ''
	SET @ConsumerID = '-2'
	
 --create the list of diagnosis for each consumer
SELECT 
	cd.ConsumerNK, cd.DiagnosisNK, dg.Diagnosis, dg.DiagnosisCode, dd.DateSK as DiagnosisEffectiveDate
INTO #diag
FROM dw.factConsumerDiagnosis cd (nolock) 
	INNER JOIN dw.dimDiagnosis dg (nolock) on cd.diagnosisNK = dg.diagnosisNK
	INNER JOIN dw.dimDiagnosisClass dc (nolock) on dc.DiagnosisClassSK = cd.DiagnosisClassSK
	INNER JOIN dw.dimDate dd (nolock) on dd.DateSK = cd.DiagnosisEffectiveDateSK
WHERE
	 dc.ActiveDiagnosisClass = 1
	AND cd.ConsumerDiagnosisActiveFlag = 1
	AND cd.ConsumerNK <> -1
CREATE CLUSTERED INDEX idx_diagnosis ON #diag (ConsumerNK, DiagnosisEffectiveDate); 


--get current benenfit plans for consumer	
SELECT DISTINCT 
	b.BenefitPlanShort , dc.ConsumerNK, dd.DateValue
INTO #ConBenPlan
FROM dw.factEligibility fe
    INNER JOIN dw.dimConsumers dc on fe.ConsumerSK = dc.ConsumerSK
    INNER JOIN dw.dimJunk j on fe.ActionSK = j.JunkSK
    INNER JOIN dw.dimBenefitPlan b on b.BenefitPlanSK = fe.BenefitPlanSK 
    INNER JOIN dw.dimDate dd on fe.ExpirationDateSK = dd.DateSK 
WHERE
	j.JunkValue in ('Effective','Active')
	AND (dd.DateValue > GETDATE())	
CREATE CLUSTERED INDEX idx_tmpConBenPlan ON #ConBenPlan (ConsumerNK);


-- get insurance numbers
SELECT DISTINCT 
	C.ConsumerNK, InsuranceNumber
INTO #ins
FROM dw.factEligibility e
	INNER JOIN dw.dimConsumers c (nolock) on e.ConsumerSK = c.ConsumerSK
	INNER JOIN dw.dimJunk j (nolock) on e.ActionSK = j.JunkSK
WHERE j.JunkValue in ('Effective','Active')
	AND (cast(c.ConsumerNK as varchar(20)) in (select ltrim(rtrim(element)) from dbo.cfn_split(@consumerId, ',')) or @ConsumerID = '-2')
	AND c.ConsumerNK <> -1
CREATE CLUSTERED INDEX idx_insurance ON #ins (ConsumerNK, InsuranceNumber); 


      
SELECT DISTINCT
	currentc.lastName + ', ' + currentc.firstName as ConsumerName,
	currentc.ConsumerNK as ConsumerID,
	ISNULL(currentc.addressLine1, '') + ' ' + ISNULL(currentc.addressLine2, '') as ConsumerAddress1,
	ISNULL(currentc.city, '') + ', ' + ISNULL(currentc.[state], '') + ' ' + currentc.postalCode as ConsumerAddress2,
	currentc.PhoneNumber as ConsumerPhone,
	currentc.SSN,
	convert(varchar(10), currentc.DOB, 101) as DOB,
	currentc.Gender,
	currentc.Race,
	adm.DateValue as AdmissionDate,
	ldis.DateValue as DischargeDate,
	e.LastName + ', ' + e.FirstName as CareCoordinator,
	e.EmployeePhone as CareCoordinatorPhone,
	e1.LastName + ', ' + e1.FirstName as Facilitator,
	LastThreeDiagnosis = 
		   REPLACE
			  (
					REPLACE
					(
							(
								SELECT top 3
									  REPLACE(RTRIM(ISNULL(sd.DiagnosisCode, '')),' ', CHAR(127)) AS [data()]
								FROM
									  #diag sd
								WHERE
									  currentc.ConsumerNK = sd.ConsumerNK
								ORDER BY DiagnosisEffectiveDate DESC
								FOR XML PATH('') 
							),
							' ', '; '
					),
					CHAR(127), ' '
			  ),
	InsuranceNumber = 
		   REPLACE
			  (
					REPLACE
					(
							(
								SELECT distinct REPLACE(RTRIM(ISNULL(e.InsuranceNumber, '')),' ', CHAR(127)) AS [data()]
								FROM #ins e
								WHERE currentc.ConsumerNK = e.ConsumerNK
								FOR XML PATH('') 
							),
							' ', '; '
					),
					CHAR(127), ' '
			  ),
	currentc.Competency,
	ISNULL(RTRIM(LTRIM(currentc.AuthRepLastName)), '') + case when currentc.AuthRepLastName is NULL then '' else ', ' end + ISNULL(RTRIM(LTRIM(currentc.AuthRepFirstName)), '') as LegalResponsiblePerson,
	ISNULL(RTRIM(LTRIM(currentc.AuthRepAddressLine1)), '') + ' ' + ISNULL(RTRIM(LTRIM(currentc.AuthRepAddressLine2)), '') as LRPAddress1,
	ISNULL(RTRIM(LTRIM(currentc.AuthRepCity)), '') + case when currentc.AuthRepCity is NULL  then '' else ', ' end + ISNULL(RTRIM(LTRIM(currentc.AuthRepState)), '') + ' ' + ISNULL(RTRIM(LTRIM(currentc.AuthRepPostalCode)), '') as LRPAddress2,
    ISNULL(RTRIM(LTRIM(currentc.AuthRepPhone)), '') as LRPPhone,
    currentc.Guardian as Co_Guardian,
	BenefitPlan = 
                  
                  REPLACE
                  (
                        REPLACE
                        (
                              (
                              
								  SELECT DISTINCT
								  REPLACE(RTRIM(dc.BenefitPlanShort),' ', CHAR(127)) AS [data()]
								  FROM #ConBenPlan dc
								  WHERE dc.ConsumerNK = c.ConsumerNK 
                                  FOR XML PATH('') 
                              ),
                              ' ', '; '
                        ),
                        CHAR(127), ' '
                  )
 FROM
 	BIW.DW.factCareCoordAdmissions fcc
	INNER JOIN BIW.DW.dimConsumers c ON fcc.ConsumerSK = c.ConsumerSK 
	INNER JOIN BIW.DW.dimConsumers currentc ON c.ConsumerNK = currentc.ConsumerNK and currentc.ETLCurrentRow = 1
	INNER JOIN BIW.DW.dimEmployee e ON e.EmployeeSK = fcc.CareCoordinatorSK AND fcc.ActiveAdmissionFlag =1
	INNER JOIN BIW.DW.dimEmployee e1 ON e1.EmployeeSK = fcc.SupportFacilitorSK 
	INNER JOIN BIW.DW.dimDate adm (nolock) on fcc.CareCoordAdmissionsDateSK = adm.DateSK
	LEFT JOIN DW.dimDate dch (nolock) on fcc.CareCoordDischargeDateSK = dch.DateSk
	-- get the most recent discharge date for client
	LEFT JOIN ( SELECT  ROW_NUMBER() OVER (PARTITION BY  c.ConsumerNK ORDER BY cca.CareCoordDischargeDateSK DESC) as rownum,
					c.ConsumerNK,
					cca.CareCoordDischargeDateSK as LastDischargeDate
				from 
					dw.factCareCoordAdmissions cca (nolock)
					INNER JOIN  dw.dimConsumers c (nolock) on cca.ConsumerSK = c.ConsumerSK
				where 1=1
					AND (cast(c.ConsumerNK as varchar(20)) in (select ltrim(rtrim(element)) from dbo.cfn_split(@consumerId, ',')) or @ConsumerID = '-2')		
					AND c.ConsumerNK <> -1
					AND cca.CareCoordDischargeDateSK <> -1
				) dates On currentc.ConsumerNK = dates.ConsumerNK and rownum = 1
	LEFT JOIN BIW.DW.dimDate ldis (nolock) on dates.LastDischargeDate = ldis.DateSK
WHERE  (cast(c.ConsumerNK as varchar(20)) in (select ltrim(rtrim(element)) from dbo.cfn_split(@consumerId, ',')) or @ConsumerID = '-2')  
		AND (@CareCoord = -2 OR
			@CareCoord = e.EmployeeNK)    
		AND c.ConsumerNK <> -1
		AND (dch.DateValue = '1900-01-01'
			OR dch.DateValue is null)
		 
END
	DROP TABLE #ConBenPlan	
	DROP TABLE #diag
	DROP TABLE #ins
