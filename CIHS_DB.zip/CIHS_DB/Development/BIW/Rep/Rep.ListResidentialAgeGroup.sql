USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListResidentialAgeGroup] AS

/*------------------------------------------------------------------------------
	Title:		List Residential Age Group
	File:		[Rep].[ListResidentialAgeGroup]
	Author:		Doug Cox
	Date:		08/05/13
	Desc:		This listing of Residential Age Groups can be used to fill the 
					available values for Residential Age Group Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/05/2013		Doug Cox				6401			Created
	
	Usage directions:
	-- Add the following to your FROM CLAUSE:
			INNER JOIN dw.dimCustomReportGroups AS AgeGroup with(nolock) ON AgeGroup.CustomGroupName = 'CSPRChildResidentialAgeGroups'
									AND fClaims.AgeSK BETWEEN AgeGroup.BeganAttributeCodeRange AND AgeGroup.EndAttributeCodeRange
			INNER JOIN dbo.cfn_split(@Age , ',') AS fnAge ON fnAge.element = AgeGroup.CustomGroupValue
		
-----------------------------------------------------------------------------------*/

SELECT	AgeGroup.CustomGroupValue
FROM	dw.dimCustomReportGroups AS AgeGroup with(nolock) 
WHERE	AgeGroup.CustomGroupName = 'CSPRChildResidentialAgeGroups'