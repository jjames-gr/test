USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[InvalidAuths]    Script Date: 07/23/2013 17:23:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [REP].[InvalidAuths]
 
AS

/*------------------------------------------------------------------------------
	Title:		Invalid Authorizations
	File:		[REP].[InvalidAuths]
	Author:		Kevin Hamilton	
	Date:		07/29/2013
	Desc:	    Invalid Auths due to contract or service changes	
					
                                        
	Called By:
                        Reports:          UMA012-Invalid Authorizations

                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/29/2013		Kevin Hamilton     		6418			Created

	-----------------------------------------------------------------------------------*/
SELECT DISTINCT
   
      c.ConsumerNK as ClientID,
      c.LastName as ClientLastName,
      c.FirstName as ClientFirstName,
      p2.ProviderName,  
      p.ProviderName as SiteName,      
      p.AddressLine1 as ProviderAddress,
      fa.AuthorizationMasterID,
      p.ProviderNK,
      s.ServiceDefinitionID,
	  s.ServicesNK,
	  s.ServiceDescription,
	  s.ServiceDescriptionShort,
	  s.ServiceDefinition,
      s.ServiceCode,
      fa.factAuthorizationsNK as AuthID,
      fa.AuthorizationNumber,
      fa.ReferenceNumber as TarID,
      ddFrom.DateValue as EffectiveFromDate,
      ddTo.DateValue as EffectiveToDate,
      'Service Not in contract during auth period' as Reason
      
INTO #AllAuths
FROM BIW.DW.factAuthorizations fa with(nolock)
      INNER JOIN BIW.DW.dimProvider p with(nolock) ON p.ProviderSK = fa.ProviderSK 
      INNER JOIN dw.dimProvider p2 on p.ParentProviderNK = p2.ProviderNK
      INNER JOIN BIW.DW.dimServices s with(nolock) ON s.ServicesSK = fa.ServicesSK 
      INNER JOIN BIW.DW.dimConsumers c with(nolock) ON c.ConsumerSK = fa.ConsumerSK 
      INNER JOIN BIW.DW.dimDate ddFrom with(nolock) On ddFrom.DateSK = fa.EffectiveFromDateSK 
      INNER JOIN BIW.DW.dimDate ddTo with(nolock) On ddTo.DateSK = fa.EffectiveToDateSK 
 WHERE 
      ddTo.DateValue >= DATEADD(month, -6, GETDATE())
      AND ddFrom.DateValue < ddTo.DateValue
      AND s.ServiceDescriptionShort <> 'All Services'
      AND s.ServicesNK <> -1
     

      
 SELECT DISTINCT 
    fa.AuthorizationMasterID,
	s.ServiceDefinitionID,
	s.ServicesNK,
	p.ProviderNK,
	ddFrom.DateValue as EffectiveFromDate,
    ddTo.DateValue as EffectiveToDate
INTO #AllGoodAuths
FROM BIW.DW.factAuthorizations fa with(nolock)
      INNER JOIN BIW.DW.dimProvider p with(nolock) ON p.ProviderSK = fa.ProviderSK 
      INNER JOIN BIW.DW.dimServices s with(nolock) ON s.ServicesSK = fa.ServicesSK 
      INNER JOIN BIW.DW.dimConsumers c with(nolock) ON c.ConsumerSK = fa.ConsumerSK 
      INNER JOIN BIW.DW.dimDate ddFrom with(nolock) On ddFrom.DateSK = fa.EffectiveFromDateSK 
      INNER JOIN BIW.DW.dimDate ddTo with(nolock) On ddTo.DateSK = fa.EffectiveToDateSK  
      INNER JOIN (SELECT DISTINCT 
                              dp.ProviderNK,ddEff.DateValue as EffDate,ddExp.DateValue as ExpDate, ds.ServicesNK 
                         FROM BIW.DW.factProviderContract fpc with(nolock) 
                              INNER JOIN BIW.DW.dimProvider dp with(nolock)On dp.ProviderSK = fpc.ProviderSK
                              INNEr JOIN BIW.DW.dimDate ddEff with(nolock) On ddEff.DateSK = fpc.ContractEffectiveBeginDateSK 
                              INNEr JOIN BIW.DW.dimDate ddExp with(nolock) On ddExp.DateSK = fpc.ContractExpirationBeginDateSK 
                              INNER JOIN BIW.DW.dimServices ds with(nolock) ON fpc.ServicesSK = ds.ServicesSK
                        WHERE 
                              fpc.DeletedContractFlag = 0
                           
      
                        ) as factProv ON factProv.ProviderNK = p.ProviderNK 
WHERE 
      ddTo.DateValue >= DATEADD(month, -6, GETDATE())
      AND p.ProviderNK = factProv.ProviderNK
      AND  ddFrom.DateValue >= factProv.EffDate 
      AND  ddTo.DateValue <= factProv.ExpDate 
      ANd s.ServicesNK =factProv.ServicesNK 
     
     
     
 DELETE #AllAuths
 FROM #AllAuths aa,
      #AllGoodAuths ag
 WHERE aa.AuthorizationMasterID  = ag.AuthorizationMasterID  
	AND aa.ServicesNK = ag.ServicesNK 
	AND aa.ServiceDefinitionID = ag.ServiceDefinitionID 
	AND aa.EffectiveFromDate = ag.EffectiveFromDate 
	AND aa.EffectiveToDate = ag.EffectiveToDate 
	
	
	
SELECT *
FROM #AllAuths
ORDER BY ClientLastName    
      
      DROP TABLE #AllAuths 
      DROP TABLE #AllGoodAuths 