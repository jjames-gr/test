USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [Rep].[EnrollmentByProductlineDetail]

@eligibility_Start_dt datetime ,
@eligibility_end_dt datetime,
@Benefit_plan int,
@Catchment varchar(max)

AS
/*------------------------------------------------------------------------------
	Title:		Enrollment by Product Line Detail

	File:		[EnrollmentByProductlineDetail]
	Author:		Karen Roslund
	Date:		8/9/2013
	Desc:		Detail for the enrollment by Product Line			
                                        
	Called By:
                        Reports:          Coming Soon....
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		8/9/2013		Karen Roslund    			6539			Created

--	-----------------------------------------------------------------------------------*/

Begin
--declare @eligibility_Start_dt datetime = '1/1/2012',
--@eligibility_end_dt datetime = '1/31/2012',
--@Benefit_plan int = -100,
--@Catchment varchar(max) = '-300'




select distinct
fe.factEligibilitySK ,
dc.ConsumerNK as Consumer_ID,
dc.FullName as Consumer_Name,
dc.Gender,
fe.Action mem, 
delig.DateValue  dateelig,
dexp.DateValue  dexp,
dbp.BenefitPlanNK ,
dbp.BenefitPlan,
daid.CategoryNumberNK,
daid.CategoryName Medicaid_Aid_Category,
cob.COBOtherInsurance as medicare,
dc.DOB,
'' as member_count,
DATEDIFF(mm,dc.dob,@eligibility_end_dt)/12 age_value,
0 as age1,
0 as age2,
0 as ages
into #temp1

from dw.factEligibility fe with (nolock)
Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK 
inner join dw.dimMedicaidAidCategory daid with (nolock) on fe.MedicaidAidCategorySK = daid.MedicaidAidCategorySK
left join -- just getting if the consumer has any kinda medicare
 (select distinct ConsumerNK,  'yes' cobotherinsurance
     
  from dw.factCOB fcob with (nolock) 
   Inner join DW.dimConsumers dc2 with (nolock) on fcob.ConsumerSK  = dc2.ConsumersK 
 where       fcob.COBOtherInsurance like '%medicare%'
 ) cob on cob.ConsumerNK = dc.ConsumerNK 

 
 
 
 
 
 
 
 
Where
(delig.DateValue between @eligibility_Start_dt and @eligibility_end_dt 
or  dexp.DateValue  between @eligibility_Start_dt and @eligibility_end_dt )

 and (
	
					@catchment = '-300'
					OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

				)
				
and ((@Benefit_plan  = -200)--all plans
        or (@Benefit_plan  = -100 and dbp.BenefitPlanNK >=2 )
        or (dbp.BenefitPlanNK   = @Benefit_plan))
         and dc.ConsumerNK <> -1
and fe.ActionSK not in (12,14)
--and dc.ConsumerNK =21420
         

          order by Consumer_ID,dateelig,dexp 
          
          CREATE CLUSTERED INDEX idx_tmpConsumer ON #temp1 (Consumer_ID);
 
 -- Delete all the extra rows that where the dateeligibity start date is less than the Start date parameter     
 delete from #temp1 where dateelig < @eligibility_Start_dt 
          
        
 -- setting the birthday to 28 if its 29 for the month of feb         
          
          update #temp1 
        set   DOB  = DATEADD(dd,-1,dob)
      where DATEPART(mm,DOB ) = 02
      and DATEPART(dd,DOB ) = 29
          
           
          
          
SELECT * ,
					Convert(varchar,datepart(mm,dob),2) + '/' + '1'+ '/' + Convert(varchar,DATEPART(yyyy,@eligibility_end_dt ),4) as EndDateBday,  
					Convert(varchar,datepart(mm,DOB ),2) + '/' + '1' + '/' + Convert(varchar,DATEPART(yyyy,@eligibility_Start_dt ),4)  as StartDateBday,
					dob as BdayDate 
					

				INTO #memberMonthSplit
				FROM #temp1 
				
				
				--deleting those rows where the age_value is in the lower limit.
				delete from #memberMonthSplit
				WHERE age_value not IN (4,9,14,17,19,24,29,34,39,44,49,54,59,64,69,74,79,84,89)
				
				 
				-- delete those clients whose bdays are not between the start and end dates 
				delete from #memberMonthSplit 
				where EndDateBday  not between @eligibility_Start_dt and @eligibility_end_dt 
				and StartDateBday not between @eligibility_Start_dt and @eligibility_end_dt
						
				-- setting the age value for those consumers 
				update #memberMonthSplit set age1 = age_value 
				where dateelig < EndDateBday 
				
				-- setting the age value + 1 
				update #memberMonthSplit set age2 = age_value + 1
				where dateelig >= EndDateBday 
				
				-- updating the main #temp table with age1 and age2
				update t set t.age1 = m.age1 
				from #temp1 t 
				inner join #memberMonthSplit m on t.Consumer_ID = m.Consumer_ID and t.BenefitPlanNK = m.BenefitPlanNK and t.dateelig = m.dateelig 
				
				
				update t set  t.age2 = m.age2 
				from #temp1 t 
				inner join #memberMonthSplit m on t.Consumer_ID = m.Consumer_ID and t.BenefitPlanNK = m.BenefitPlanNK and t.dateelig = m.dateelig 
				
			   
			 	
				update #temp1 set age1 = age_value where Consumer_ID not in (select Consumer_ID from #memberMonthSplit )
			    update #temp1 set ages = case when age1 = 0 then age2 else age1 end
			   

				
select *, case when age1 = 0 then 0 else 1 end member_Age1, Case when age2 = 0 then 0 else 1 end Member_Age2 from #temp1 
				
	
				 
				
				
				
drop table #memberMonthSplit 
drop table #temp1 
				
End