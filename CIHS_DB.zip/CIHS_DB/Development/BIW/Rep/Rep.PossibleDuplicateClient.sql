USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[PossibleDuplicateClient]    Script Date: 04/18/2013 13:06:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [Rep].[PossibleDuplicateClient]
AS

/*------------------------------------------------------------------------------
	Title:		Possible Duplicate Client
	File:		[Rep].[PossibleDuplicateClient]
	Author:		Divya Lakshmi
	Date:		04/15/2013
	Desc:		Active Clients with the same Unique ID
				
	Called By:
                        Reports:          UMA003 PossibleDuplicateClient
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/15/2013		Divya Lakshmi    		6472			Created

	-----------------------------------------------------------------------------------*/
--CTE to capture the count of client
;With cteMain as( SELECT  CAST(c.LastName AS CHAR(3)) + CAST(c.FirstName AS CHAR(1))
            + REPLACE(CONVERT(CHAR(8), c.DOB, 10), '-', '') StateUniqueID,
            COUNT(c.ConsumerNK) c
  
    FROM    DW.dimConsumers c
    WHERE   c.active = 1
    and c.ETLCurrentRow=1
    GROUP BY CAST(c.LastName AS CHAR(3)) + CAST(c.FirstName AS CHAR(1))
            + REPLACE(CONVERT(CHAR(8), c.DOB, 10), '-', '')

    )
	
SELECT 
	
distinct	
c.ConsumerNK ConsumerID,
c.EnrollmentDate EnrollDate,
c.LastName ConsumerLastName,
c.FirstName ConsumerFirstName,
c.MiddleName ConsumerMiddleName,
c.SSN ConsumerSSN,
c.DOB ConsumerDOB,
c.GenderCode ConsumerGender,
CAST(c.LastName AS CHAR(3)) + CAST(c.FirstName AS CHAR(1))
            + REPLACE(CONVERT(CHAR(8), c.DOB, 10), '-', '') StateUniqueID	
FROM
 DW.dimConsumers c ,cteMain t
where  CAST(c.LastName AS CHAR(3)) + CAST(c.FirstName AS CHAR(1))
            + REPLACE(CONVERT(CHAR(8), c.DOB, 10), '-', '') =t.StateUniqueID
          and c.Active=1
          and c.ETLCurrentRow=1
         and c>1--Filters client where count > 1
         


order by StateUniqueID


GO


