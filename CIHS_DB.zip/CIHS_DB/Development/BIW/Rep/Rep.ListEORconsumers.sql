USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListEORconsumers] AS

	/*------------------------------------------------------------------------------e
	Title:		ListEORconsumers
	File:		Rep.ListEORconsumers.sql
	Author:		Doug Cox
	Date:		06/21/2013
	Desc:		Lists Employer of Record Consumers for use to fill Parameter values
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/29/2013		Doug Cox     			6364			Created

	-----------------------------------------------------------------------------------*/

    BEGIN
	
		SELECT	DISTINCT
				c.ConsumerNK ,
				c.LastName ,
				c.FullName 
		FROM	dw.factConsumerTags AS ct 
				INNER JOIN dw.dimJunk AS j ON ct.ConsumerTagSK = j.JunkSK 
				INNER JOIN dw.dimConsumers AS c ON ct.ConsumerSK = c.ConsumerSK
		WHERE	J.JunkNK = '558' 
				AND c.LastName <> 'Test'
		ORDER BY c.LastName

	END