USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListTARServices] AS

	/*------------------------------------------------------------------------------
	Title:		List TAR Services
	File:		rep.ListTARServices
	Author:		Doug Cox
	Date:		08/20/2013
	Desc:		This listing of TAR Registry services can be used to fill the available 
					values for a TAR registry service Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/06/2013		Doug Cox				6532			Created
	
	Usage directions:
	--Declare variable as VARCHAR(MAX)
	-- Add the following to your FROM CLAUSE:
		
	INNER JOIN dbo.cfn_split(@ServiceDefinition , ',') fnServices ON fnServices.element = dServices.ServiceDefinitionID

	-----------------------------------------------------------------------------------*/
SELECT	DISTINCT 
		dServices.ServiceDefinitionID AS ServiceDefID,
		dServices.ServiceDefinition AS ServiceDef
FROM	dw.factTARServiceToDiagnosis AS fS2D with(nolock) 
		INNER JOIN dw.dimServices AS dServices with(Nolock) ON dServices.ServicesSK = fS2D.ServicesSK
ORDER BY dServices.ServiceDefinition