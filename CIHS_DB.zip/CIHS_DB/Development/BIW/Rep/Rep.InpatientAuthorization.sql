USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[InpatientAuthorization]    Script Date: 09/05/2013 11:41:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO









CREATE PROCEDURE [REP].[InpatientAuthorization] 
	@AuthStartDate datetime,
	@AuthEndDate datetime,
	@ServiceDefinition int,
	@RequestType int,
	@DiagnosisGroup int,
	@Catchment varchar(50),
	@Insurer int
AS
/*------------------------------------------------------------------------------
-- Title:	Inpatient Authorization 
-- File:	[Rep].[InpatientAuthorization]
-- Author:	Brian Angelo
-- Date:	08/9/2013
-- Desc:	Inpatient Authorization  stored proc
--			
-- CalledBy:
-- 		Reports: "InpatientAuthorization "
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/9/2013  	Brian Angelo		6412	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/*
	/**** Test Parameters ****/
	DECLARE @AuthStartDate datetime,
			@AuthEndDate datetime,
			@ServiceDefinition int,
			@RequestType int,
			@DiagnosisGroup int,
			@Catchment varchar(50),
			@Insurer int

	SET @AuthStartDate = '1/1/13'
	SET @AuthEndDate = '1/31/13'
	SET @ServiceDefinition = -1
	SET @RequestType  = -1
	SET @DiagnosisGroup  = -300
	SET @Catchment  = -300
	SET @Insurer = -200

	--*/

	IF OBJECT_ID('tempdb..#tempResults') IS NOT NULL
		DROP TABLE #tempResults


	SELECT 
	dc.FirstName as ConsumerFirstName
	,dc.LastName as ConsumerLastName
	,dc.ConsumerNK as ConsumerID
	,dc.DOB as ConsumerDOB
	,do.County as County
	,dbp.Insurer as Insurer
	,dd.DiagnosisGroup as DiagnosisGroup
	,dp.ProviderName as ProviderName
	,dmp.ProviderName as MasterProviderName
	,ds.ServiceDefinition as ServiceDefinition
	,ds.ServiceCode as ServiceCode
	,ddEffDate.DateValue as AuthorizationEffectiveDate
	,ddExpDate.DateValue as AuthorizationExpirationDate
	,fa.AuthorizedLengthOfStay as LengthOfStay
	,dj.JunkValue as RequestType
	,fa.AuthorizationNumber
	INTO #tempResults
	FROM [BIW].[DW].[factAuthorizations] fa WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fa.ConsumerSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fa.OrganizationSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fa.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd WITH(NOLOCK) ON dd.DiagnosisSK = fa.DiagnosisSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fa.ProviderSK
	INNER JOIN [BIW].[DW].[dimProvider] dmp WITH(NOLOCK) ON dmp.ProviderSK = fa.MasterProviderSK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fa.ServicesSK
	INNER JOIN [BIW].[DW].[dimDate] ddEffDate WITH(NOLOCK) ON ddEffDate.DateSK = fa.EffectiveFromDateSK
	INNER JOIN [BIW].[DW].[dimDate] ddExpDate WITH(NOLOCK) ON ddExpDate.DateSK = fa.EffectiveToDateSK
	INNER JOIN [BIW].[DW].[factTreatmentAuthorizationRequest] ftar WITH(NOLOCK) ON ftar.TARID = fa.ReferenceNumber
	INNER JOIN [BIW].[DW].[dimJunk] dj WITH(NOLOCK) ON dj.JunkSK = ftar.RequestTypeSK AND dj.JunkEntity = 'RequestType'
	WHERE 1=1
	--/* Global filters */
	AND ds.ServiceSummaryID != 10
	AND dp.ICF = (CASE WHEN @ServiceDefinition = 46 THEN 'True' ELSE 'False' END)
	AND (dd.DiagnosisGroupID = 2 OR dd.DiagnosisGroupID = 3 OR dd.DiagnosisGroupID = 4) --Diag Group MH, SA, DD
	AND ds.ServiceDefinitionID IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WHERE CustomGroupName = 'ServiceDefsInpatientAuth')
	/* Parameters */
	AND ddEffDate.DateValue <= @AuthEndDate
	AND ddExpDate.DateValue >=  @AuthStartDate
	AND (ds.ServiceDefinitionID = @ServiceDefinition OR @ServiceDefinition = -1)
	AND (@RequestType = -1 OR dj.JunkNK = @RequestType)
	AND (dd.DiagnosisGroupID = @DiagnosisGroup OR @DiagnosisGroup = -300)
	AND (@Catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
	)
	AND ((@Insurer = dbp.BenefitPlanNK ) OR -- 1 specific Plan
		( @Insurer = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
		( @Insurer = -200 ))


	CREATE CLUSTERED INDEX ciAuthNumber ON #tempResults (AuthorizationNumber);


	SELECT 
	tr.ConsumerFirstName
	,tr.ConsumerLastName
	,tr.ConsumerID
	,tr.ConsumerDOB
	,tr.County
	,tr.Insurer
	,tr.DiagnosisGroup
	,tr.ProviderName
	,tr.MasterProviderName
	,tr.ServiceDefinition
	,tr.ServiceCode
	,tr.AuthorizationEffectiveDate
	,tr.AuthorizationExpirationDate
	,tr.LengthOfStay
	,tr.RequestType
	,tr.AuthorizationNumber
	,MIN(ddDOS.DateValue) as ClaimsStartDate
	,MAX(ddDOS.DateValue) as ClaimsEndDate 
	FROM #tempResults tr
	LEFT JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK) ON fc.AuthorizationNumber = tr.AuthorizationNumber
	LEFT JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fc.DateOfServiceSK
	GROUP BY 
	tr.ConsumerFirstName
	,tr.ConsumerLastName
	,tr.ConsumerID
	,tr.ConsumerDOB
	,tr.County
	,tr.Insurer
	,tr.DiagnosisGroup
	,tr.ProviderName
	,tr.MasterProviderName
	,tr.ServiceDefinition
	,tr.ServiceCode
	,tr.AuthorizationEffectiveDate
	,tr.AuthorizationExpirationDate
	,tr.LengthOfStay
	,tr.RequestType
	,tr.AuthorizationNumber
	order by tr.AuthorizationEffectiveDate


	DROP TABLE #tempResults

END









GO


