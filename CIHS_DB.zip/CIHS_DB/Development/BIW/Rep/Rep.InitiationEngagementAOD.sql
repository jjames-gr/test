USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[InitiationEngagementAOD]    Script Date: 09/20/2013 13:20:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[InitiationEngagementAOD]
	@BenefitPlan int,
	@StartDate datetime,
	@EndDate datetime,
	@Catchment varchar(50)
AS
/*------------------------------------------------------------------------------
-- Title:	Initiation and Engagement AOD
-- File:	[Rep].[InitiationEngagementAOD]
-- Author:	Brian Angelo
-- Date:	07/1/2013
-- Desc:	Initiation and Engagement AOD
--			
-- CalledBy:
-- 		Reports: "Initiation and Engagement AOD"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	07/1/2013   Brian Angelo		6408	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /*
	/*** Test Parameters ***/
	DECLARE @BenefitPlan int,
			@StartDate datetime,
			@EndDate datetime,
			@Catchment varchar(50)
			
	SET @BenefitPlan = -200
	SET @StartDate = '6/1/13'
	SET @EndDate = '6/30/13'
	SET @Catchment = '-2'
	--*/
	
	SET @EndDate = DATEADD(dd, 45, @EndDate)
	
	IF OBJECT_ID('tempdb..#tempEligible') IS NOT NULL
		DROP TABLE #tempEligible
	
	CREATE TABLE #tempEligible (
		ConsumerID int,
		ConsumerName varchar(50),
		ConsumerAge int,
		EncounterType varchar(50),
		FirstIncident datetime,
		ClaimAdjudicationNumber int
	)
	
	IF OBJECT_ID('tempdb..#tempPossibleRecords') IS NOT NULL
		DROP TABLE #tempPossibleRecords
	
	
	SELECT  
	dc.ConsumerNK as ConsumerID
	,dc.FullName as ConsumerName
	,da.AgeValue as ConsumerAge
	,DOS.DateValue as DateOfService
	,dd1.DiagnosisCode as DiagnosisCode1
	,dd1.Diagnosis as Diagnosis1
	,dd2.DiagnosisCode as DiagnosisCode2
	,dd2.Diagnosis as Diagnosis2
	,dd3.DiagnosisCode as DiagnosisCode3
	,dd3.Diagnosis as Diagnosis3
	,dd4.DiagnosisCode as DiagnosisCode4
	,dd4.Diagnosis as Diagnosis4
	,ds.ServiceCode as ServiceCode
	,ds.ServiceDescriptionShort
	,fc.ServiceLineRevenueCode as RevenueCode
	,dPOS.PlaceOfServiceCode as PlaceOfServiceCode
	,fc.ClaimAdjudicationNumber as ClaimAdjudicationNumber
	INTO #tempPossibleRecords
	FROM [BIW].[DW].[factClaims] fc WITH(NOLOCK) 
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd1 WITH(NOLOCK) ON dd1.DiagnosisSK = fc.Diagnosis1SK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd2 WITH(NOLOCK) ON dd2.DiagnosisSK = fc.Diagnosis2SK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd3 WITH(NOLOCK) ON dd3.DiagnosisSK = fc.Diagnosis3SK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd4 WITH(NOLOCK) ON dd4.DiagnosisSK = fc.Diagnosis4SK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
	INNER JOIN [BIW].[DW].[dimPlaceOfService] dPOS WITH(NOLOCK) ON dPOS.PlaceOfServiceSK = fc.PlaceOfServiceSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fc.OrganizationSK
	INNER JOIN [BIW].[DW].[dimDate] DOS WITH(NOLOCK) ON DOS.DateSK = fc.DateOfServiceSK
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fc.ConsumerSK
	INNER JOIN [BIW].[DW].[dimAge] da WITH(NOLOCK) ON da.AgeSK = fc.AgeSK
	WHERE 1=1
	AND DOS.DateValue BETWEEN @StartDate AND @EndDate
	AND (
			( @BenefitPlan = dbp.BenefitPlanNK ) OR -- 1 specific Plan
			( @BenefitPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
			( @BenefitPlan = -200 ) -- ALL PLANS
		)
	AND (
			@Catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
		)
		
	
	/*----------------------------------*/
	/*    Outpatient Visit	            */
	/*----------------------------------*/
	INSERT INTO #tempEligible
	SELECT  
	ConsumerID
	,ConsumerName
	,ConsumerAge
	,'Outpatient' as EncounterType
	,Min(DateOfService) as FirstIncident
	,MIN(ClaimAdjudicationNumber) as ClaimAdjudicationNumber
	FROM #tempPossibleRecords
	WHERE 
	(
		DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR
		DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR
		DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR
		DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		) --End diagnosis code check
	AND (
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTB'  OR CustomGroupName = 'HEDISAODServiceHCPCSB')
		OR
		
		RevenueCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODRevenueB')
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS1')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS1')
		) --End service codes with POS 
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS2')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS2')
		) --End service codes with POS 52,53
		
		) --End Service Code Check
		GROUP BY
		ConsumerID
		,ConsumerName
		,ConsumerAge
		
		
		/*----------------------------------*/
		/*    Detoxification Visit          */
		/*----------------------------------*/
		INSERT INTO #tempEligible
		SELECT  
		ConsumerID
		,ConsumerName
		,ConsumerAge
		,'Detox' as EncounterType
		,Min(DateOfService) as FirstIncident
		,MIN(ClaimAdjudicationNumber) as ClaimAdjudicationNumber
		FROM #tempPossibleRecords
		WHERE 
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceHCPCSC')
		OR RevenueCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODRevenueC')
		OR (
			DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisC')
			OR DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisC')
			OR DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisC')
			OR DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisC')
			) -- End diagnosis code check
		GROUP BY
		ConsumerID
		,ConsumerName
		,ConsumerAge
		
		/*----------------------------------*/
		/*    ED Visit                      */
		/*----------------------------------*/
		INSERT INTO #tempEligible
		SELECT  
		ConsumerID
		,ConsumerName
		,ConsumerAge
		,'ED' as EncounterType
		,Min(DateOfService) as FirstIncident
		,MIN(ClaimAdjudicationNumber) as ClaimAdjudicationNumber
		FROM #tempPossibleRecords
		WHERE 
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTD')
		OR RevenueCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODRevenueD')
		)
		AND (
			DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
			OR
			DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
			OR
			DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
			OR
			DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODDiagnosisA')
			) --End diagnosis code check
			
		GROUP BY
		ConsumerID
		,ConsumerName
		,ConsumerAge
		
		/*----------------------------------*/
		/*    Inpatient Visit               */
		/*----------------------------------*/
		INSERT INTO #tempEligible
		SELECT 
		dc.ConsumerNK as ConsumerID
		,dc.FullName as ConsumerName
		,da.AgeValue as ConsumerAge
		,'Inpatient' as EncounterType
		,MIN(ddDis.DateValue) as FirstIncident
		,MIN(fLOS.ClaimAdjudicationNumber) as ClaimAdjudicationNumber
		FROM [BIW].[DW].[factLengthOfStay] fLOS WITH(NOLOCK)
		INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON fLOS.ServiceSK = ds.ServicesSK
		INNER JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK) ON fc.ClaimAdjudicationNumber = fLOS.ClaimAdjudicationNumber
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd1 WITH(NOLOCK) ON dd1.DiagnosisSK = fc.Diagnosis1SK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd2 WITH(NOLOCK) ON dd2.DiagnosisSK = fc.Diagnosis2SK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd3 WITH(NOLOCK) ON dd3.DiagnosisSK = fc.Diagnosis3SK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd4 WITH(NOLOCK) ON dd4.DiagnosisSK = fc.Diagnosis4SK
		INNER JOIN [BIW].[DW].[dimDate] ddDis WITH(NOLOCK) ON ddDis.DateSK = fLOS.DateSK
		INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fLOS.BenefitPlanSK
		INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fLOS.OrganizationSK
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fLOS.ConsumerSK
		INNER JOIN [BIW].[DW].[dimAge] da WITH(NOLOCK) ON da.AgeSK = fc.AgeSK
		WHERE 1=1
		AND ds.ServiceSummaryID = 3
		AND ddDis.DateValue BETWEEN @StartDate AND @EndDate
		AND (
					( @BenefitPlan = dbp.BenefitPlanNK ) OR -- 1 specific Plan
					( @BenefitPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
					( @BenefitPlan = -200 ) -- ALL PLANS
				)
			AND (
					@Catchment = '-300'
					OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
					OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
				)
			
			--Must have one diagnosis in custom diagnosis group
			AND (
				dd1.DiagnosisCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
				OR
				dd2.DiagnosisCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
				OR
				dd3.DiagnosisCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
				OR
				dd4.DiagnosisCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
				) --End diagnosis code check
		GROUP BY 
		dc.ConsumerNK 
		,dc.FullName 
		,da.AgeValue
	
		/* Remove all eligible visits that were after the first */
		DELETE #tempEligible
		FROM #tempEligible
		WHERE FirstIncident != (SELECT MIN(FirstIncident) FROM #tempEligible te WHERE te.ConsumerID = #tempEligible.ConsumerID)
		
		/* Keep inpatient record if multiple incidents on one day */
		DELETE FROM #tempEligible
		WHERE ConsumerID IN (SELECT ConsumerID FROM #tempEligible WHERE EncounterType = 'Inpatient')
		AND EncounterType != 'Inpatient'
		
		/* Keep outpatient record if multiple incidents on one day */
		DELETE FROM #tempEligible
		WHERE ConsumerID IN (SELECT ConsumerID FROM #tempEligible WHERE EncounterType = 'Outpatient')
		AND EncounterType != 'Outpatient'
		
		/* Keep Detox record if multiple incidents on one day */
		DELETE FROM #tempEligible
		WHERE ConsumerID IN (SELECT ConsumerID FROM #tempEligible WHERE EncounterType = 'Detox')
		AND EncounterType != 'Detox'
		
		IF OBJECT_ID('tempdb..#tempInsuranceEligibility') IS NOT NULL
			DROP TABLE #tempInsuranceEligibility

	
		/* Get consumers with medicaid eligibility */
		SELECT DISTINCT
		te.*
		INTO #tempInsuranceEligibility
		FROM [BIW].[DW].[factEligibility] fe WITH(NOLOCK)
		INNER JOIN [BIW].[DW].[dimDate] ddElig WITH(NOLOCK) ON ddElig.DateSK = fe.DateSK
		INNER JOIN [BIW].[DW].[dimDate] ddExp WITH(NOLOCK) ON ddExp.DateSK = fe.ExpirationDateSK
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fe.ConsumerSK
		INNER JOIN #tempEligible te ON te.ConsumerID = dc.ConsumerNK
		WHERE DATEADD(dd, -60, te.FirstIncident) >= ddElig.DateValue
		AND DATEADD(dd, 44, te.FirstIncident) <= ddExp.DateValue	
		
		IF OBJECT_ID('tempdb..#tempPossibleClaims') IS NOT NULL
			DROP TABLE #tempPossibleClaims
		
		/* Get all claims 120 days prior to IESD and 30 days after IESD */
		SELECT DISTINCT
		tie.ConsumerID
		,fc.ClaimAdjudicationNumber
		,fc.ClaimNumber
		,DOS.DateValue as DateofService
		,ds.ServiceCode
		,ds.ServiceDescriptionShort
		,POS.PlaceOfServiceCode 
		,fc.ServiceLineRevenueCode as RevenueCode
		,dd1.DiagnosisCode as DiagnosisCode1
		,dd1.Diagnosis as Diagnosis1
		,dd2.DiagnosisCode as DiagnosisCode2
		,dd2.Diagnosis as Diagnosis2
		,dd3.DiagnosisCode as DiagnosisCode3
		,dd3.Diagnosis as Diagnosis3
		,dd4.DiagnosisCode as DiagnosisCode4
		,dd4.Diagnosis as Diagnosis4
		INTO #tempPossibleClaims
		FROM #tempInsuranceEligibility tie
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerNK = tie.ConsumerID
		INNER JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDate] DOS WITH(NOLOCK) ON DOS.DateSK = fc.DateOfServiceSK
		INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
		INNER JOIN [BIW].[DW].[dimPlaceOfService] POS WITH(NOLOCK) ON POS.PlaceOfServiceSK = fc.PlaceOfServiceSK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd1 WITH(NOLOCK) ON dd1.DiagnosisSK = fc.Diagnosis1SK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd2 WITH(NOLOCK) ON dd2.DiagnosisSK = fc.Diagnosis2SK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd3 WITH(NOLOCK) ON dd3.DiagnosisSK = fc.Diagnosis3SK
		INNER JOIN [BIW].[DW].[dimDiagnosis] dd4 WITH(NOLOCK) ON dd4.DiagnosisSK = fc.Diagnosis4SK
		WHERE DOS.DateValue BETWEEN DATEADD(dd,-120, tie.FirstIncident) AND DATEADD(DD, 30, tie.FirstIncident)
		
		IF OBJECT_ID('tempdb..#tempNegativeHistoryDate') IS NOT NULL
			DROP TABLE #tempNegativeHistoryDate
		
		/* Get negative history date or null if none exists, only null are eligible */
		SELECT 
		tie.ConsumerID
		,tie.ConsumerName
		,tie.EncounterType
		,tie.FirstIncident
		,tie.ConsumerAge
		,MAX(tpc.DateofService) as NegativeHistoryDate
		INTO #tempNegativeHistoryDate
		FROM #tempInsuranceEligibility tie
		INNER JOIN #tempPossibleClaims tpc ON tie.ConsumerID = tpc.ConsumerID
					AND tie.FirstIncident > tpc.DateofService
		WHERE
		tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		GROUP BY 
		tie.ConsumerID
		,tie.ConsumerName
		,tie.EncounterType
		,tie.FirstIncident
		,tie.ConsumerAge
		
		IF OBJECT_ID('tempdb..#tempFinalEligible') IS NOT NULL
			DROP TABLE #tempFinalEligible
		
		/* Get final list of eligible consumers having no AOD history or > 60 days */
		SELECT 
		tie.*, 
		tnd.NegativeHistoryDate, 
		DATEDIFF(DD, tnd.NegativeHistoryDate, tie.FirstIncident) as DtDiff 
		,cast('' as varchar(100)) as IESDServiceDesc
		,cast('' as varchar(100)) as IESDServiceCode
		,cast('' as varchar(100)) as IESDRevenueCode
		,cast('' as varchar(100)) as IESDDiagnosis
		INTO #tempFinalEligible
		FROM #tempInsuranceEligibility tie
		LEFT JOIN #tempNegativeHistoryDate tnd ON tie.ConsumerID = tnd.ConsumerID
		WHERE DATEDIFF(DD, tnd.NegativeHistoryDate, tie.FirstIncident) > 60 OR tnd.NegativeHistoryDate IS NULL
		
		/* Update IESD details */ 
		UPDATE #tempFinalEligible SET
		IESDServiceCode = tpr.ServiceCode
		,IESDServiceDesc = tpr.ServiceDescriptionShort
		,IESDRevenueCode = tpr.RevenueCode
		FROM #tempPossibleRecords tpr
		WHERE #tempFinalEligible.ClaimAdjudicationNumber = tpr.ClaimAdjudicationNumber
			
		IF OBJECT_ID('tempdb..#tempInitiation') IS NOT NULL
			DROP TABLE #tempInitiation
		
		/* Get initiation date and adjudication number */
		SELECT 
		tfe.ConsumerID
		,MIN(tpc.DateofService) as InitiaitonDate 
		,MIN(tpc.ClaimAdjudicationNumber) as InitiationAdjudicationNumber
		,cast('' as varchar(100)) as InitiationServiceDesc
		,cast('' as varchar(100)) as InitiationServiceCode
		,cast('' as varchar(100)) as InitiationRevenueCode
		,cast('' as varchar(100)) as InitiationDiagnosis
		INTO #tempInitiation
		FROM #tempFinalEligible tfe
		INNER JOIN #tempPossibleClaims tpc ON tpc.ConsumerID = tfe.ConsumerID
			AND tfe.FirstIncident < tpc.DateofService
			AND DATEDIFF(dd, tfe.FirstIncident, tpc.DateofService) <= 14
		WHERE 1=1
		AND tfe.EncounterType != 'Inpatient'
		AND (-- Service codes, Table IET-B
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTB'  OR CustomGroupName = 'HEDISAODServiceHCPCSB')
		OR
		
		RevenueCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODRevenueB')
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS1')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS1')
		) --End service codes with POS 
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS2')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS2')
		) --End service codes with POS 52,53
		
		) --End Service Code Check
		AND 
		(--Diagnosis Codes Table IET-A
		tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		) --End diagnosis codes
		GROUP BY
		tfe.ConsumerID


		/* Insert consumers who had inpatient IESD as inpatient stay is also initiaiton */
		INSERT #tempInitiation
		SELECT 
		tfe.ConsumerID
		,tfe.FirstIncident as InitiaitonDate 
		,tfe.ClaimAdjudicationNumber as InitiationAdjudicationNumber
		,cast('' as varchar(100)) as InitiationServiceDesc
		,cast('' as varchar(100)) as InitiationServiceCode
		,cast('' as varchar(100)) as InitiationRevenueCode
		,cast('' as varchar(100)) as InitiationDiagnosis
		FROM #tempFinalEligible tfe
		WHERE EncounterType = 'Inpatient'
		
		/* Update initiaiton details */ 
		UPDATE #tempInitiation SET
		InitiationServiceCode = tpc.ServiceCode
		,InitiationServiceDesc = tpc.ServiceDescriptionShort
		,InitiationRevenueCode = tpc.RevenueCode
		FROM #tempPossibleClaims tpc
		WHERE #tempInitiation.InitiationAdjudicationNumber = tpc.ClaimAdjudicationNumber
		
		IF OBJECT_ID('tempdb..#tempEngangement1') IS NOT NULL
			DROP TABLE #tempEngangement1
		
		/* Get first engangement date and adjudication number */
		SELECT 
		tfe.ConsumerID
		,MIN(tpc.DateofService) as Engangement1Date 
		,MIN(tpc.ClaimAdjudicationNumber) as Engangement1AdjudicationNumber
		,cast('' as varchar(100)) as Engangement1ServiceDesc
		,cast('' as varchar(100)) as Engangement1ServiceCode
		,cast('' as varchar(100)) as Engangement1Diagnosis
		,cast('' as varchar(100)) as Engangement1RevenueCode
		INTO #tempEngangement1
		FROM #tempFinalEligible tfe
		INNER JOIN #tempPossibleClaims tpc ON tpc.ConsumerID = tfe.ConsumerID
			AND tfe.FirstIncident < tpc.DateofService
			AND DATEDIFF(dd, tfe.FirstIncident, tpc.DateofService) <= 30
		INNER JOIN #tempInitiation ti ON ti.ConsumerID = tfe.ConsumerID AND ti.InitiaitonDate < tpc.DateofService
		WHERE 1=1
		AND (-- Service codes, Table IET-B
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTB'  OR CustomGroupName = 'HEDISAODServiceHCPCSB')
		OR
		
		RevenueCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODRevenueB')
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS1')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS1')
		) --End service codes with POS 
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS2')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS2')
		) --End service codes with POS 52,53
		
		) --End Service Code Check
		AND 
		(--Diagnosis Codes Table IET-A
		tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		) --End diagnosis codes
		GROUP BY
		tfe.ConsumerID
		
		
		/* Update engangement 1 details */ 
		UPDATE #tempEngangement1 SET
		Engangement1ServiceCode = tpc.ServiceCode
		,Engangement1ServiceDesc = tpc.ServiceDescriptionShort
		,Engangement1RevenueCode = tpc.RevenueCode
		FROM #tempPossibleClaims tpc
		WHERE #tempEngangement1.Engangement1AdjudicationNumber = tpc.ClaimAdjudicationNumber
		
		IF OBJECT_ID('tempdb..#tempEngangement2') IS NOT NULL
			DROP TABLE #tempEngangement2
		
		/* Get second engangement date and adjudication number */
		SELECT 
		tfe.ConsumerID
		,MIN(tpc.DateofService) as Engangement2Date 
		,MIN(tpc.ClaimAdjudicationNumber) as Engangement2AdjudicationNumber
		,cast('' as varchar(100)) as Engangement2ServiceDesc
		,cast('' as varchar(100)) as Engangement2ServiceCode
		,cast('' as varchar(100)) as Engangement2Diagnosis
		,cast('' as varchar(100)) as Engangement2RevenueCode
		INTO #tempEngangement2
		FROM #tempFinalEligible tfe
		INNER JOIN #tempPossibleClaims tpc ON tpc.ConsumerID = tfe.ConsumerID
			AND tfe.FirstIncident < tpc.DateofService
			AND DATEDIFF(dd, tfe.FirstIncident, tpc.DateofService) <= 30
		INNER JOIN #tempInitiation ti ON ti.ConsumerID = tfe.ConsumerID AND ti.InitiaitonDate < tpc.DateofService
		INNER JOIN #tempEngangement1 te1 ON te1.ConsumerID = tfe.ConsumerID AND te1.Engangement1Date < tpc.DateofService
		WHERE 1=1
		AND (-- Service codes, Table IET-B
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTB'  OR CustomGroupName = 'HEDISAODServiceHCPCSB')
		OR
		
		RevenueCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODRevenueB')
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS1')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS1')
		) --End service codes with POS 
		
		OR
		
		(
		ServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODServiceCPTBPOS2')
		AND PlaceOfServiceCode IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
								WHERE CustomGroupName = 'HEDISAODPOS2')
		) --End service codes with POS 52,53
		
		) --End Service Code Check
		AND 
		(--Diagnosis Codes Table IET-A
		tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		OR tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA')
		) --End diagnosis codes
		GROUP BY
		tfe.ConsumerID
		
		/* Update engangement 2 details */ 
		UPDATE #tempEngangement2 SET
		Engangement2ServiceCode = tpc.ServiceCode
		,Engangement2ServiceDesc = tpc.ServiceDescriptionShort
		,Engangement2RevenueCode = tpc.RevenueCode
		FROM #tempPossibleClaims tpc
		WHERE #tempEngangement2.Engangement2AdjudicationNumber = tpc.ClaimAdjudicationNumber
		
		IF OBJECT_ID('tempdb..#tempFinalResults') IS NOT NULL
			DROP TABLE #tempFinalResults
		
		SELECT 
		tfe.*
		,ti.InitiaitonDate
		,ti.InitiationAdjudicationNumber
		,ti.InitiationDiagnosis
		,ti.InitiationRevenueCode
		,ti.InitiationServiceCode
		,ti.InitiationServiceDesc
		,te1.Engangement1Date
		,te1.Engangement1AdjudicationNumber
		,te1.Engangement1Diagnosis
		,te1.Engangement1RevenueCode
		,te1.Engangement1ServiceCode
		,te1.Engangement1ServiceDesc
		,te2.Engangement2Date
		,te2.Engangement2AdjudicationNumber
		,te2.Engangement2Diagnosis
		,te2.Engangement2RevenueCode
		,te2.Engangement2ServiceCode
		,te2.Engangement2ServiceDesc
		INTO #tempFinalResults
		FROM #tempFinalEligible tfe
		LEFT JOIN #tempInitiation ti ON ti.ConsumerID = tfe.ConsumerID
		LEFT JOIN #tempEngangement1 te1 ON te1.ConsumerID = tfe.ConsumerID
		LEFT JOIN #tempEngangement2 te2 ON te2.ConsumerID = tfe.ConsumerID
		
		/* Get IESD diagnosis */
		UPDATE #tempFinalResults SET
		IESDDiagnosis = 
		CASE WHEN tpr.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpr.Diagnosis1
			 WHEN tpr.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpr.Diagnosis2
			 WHEN tpr.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpr.Diagnosis3
			 WHEN tpr.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpr.Diagnosis4
			 ELSE '' END
		FROM #tempPossibleRecords tpr 
		WHERE tpr.ClaimAdjudicationNumber = #tempFinalResults.ClaimAdjudicationNumber
		
		/* Get initation diagnosis */
		UPDATE #tempFinalResults SET
		InitiationDiagnosis = 
		CASE WHEN tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis1
			 WHEN tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis2
			 WHEN tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis3
			 WHEN tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis4
			 ELSE '' END
		FROM #tempPossibleClaims tpc 
		WHERE tpc.ClaimAdjudicationNumber = InitiationAdjudicationNumber
		
		/* Get first engangement diagnosis */
		UPDATE #tempFinalResults SET
		Engangement1Diagnosis = 
		CASE WHEN tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis1
			 WHEN tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis2
			 WHEN tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis3
			 WHEN tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis4
			 ELSE '' END
		FROM #tempPossibleClaims tpc 
		WHERE tpc.ClaimAdjudicationNumber = Engangement1AdjudicationNumber
		
		/* Get second engangement diagnosis */
		UPDATE #tempFinalResults SET
		Engangement2Diagnosis = 
		CASE WHEN tpc.DiagnosisCode1 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis1
			 WHEN tpc.DiagnosisCode2 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis2
			 WHEN tpc.DiagnosisCode3 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis3
			 WHEN tpc.DiagnosisCode4 IN (SELECT BeganAttributeCodeRange FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
										WHERE CustomGroupName = 'HEDISAODDiagnosisA') THEN tpc.Diagnosis4
			 ELSE '' END
		FROM #tempPossibleClaims tpc 
		WHERE tpc.ClaimAdjudicationNumber = Engangement2AdjudicationNumber
		
		
		
		SELECT 
		tfr.*
		,dcrg.CustomGroupValue as AgeGroup
		,cast(dcrg.BeganAttributeCodeRange as int) as AgeGroupOrder
		FROM #tempFinalResults tfr
		INNER JOIN [BIW].[DW].[dimCustomReportGroups] dcrg WITH(NOLOCK) 
			ON tfr.ConsumerAge BETWEEN BeganAttributeCodeRange AND EndAttributeCodeRange
							AND dcrg.CustomGroupName = 'HEDISAODAgeGroup'
		
		
		DROP TABLE #tempPossibleRecords
		DROP TABLE #tempEligible
		DROP TABLE #tempInsuranceEligibility
		DROP TABLE #tempPossibleClaims
		DROP TABLE #tempNegativeHistoryDate
		DROP TABLE #tempFinalEligible
		DROP TABLE #tempInitiation
		DROP TABLE #tempEngangement1
		DROP TABLE #tempEngangement2
		DROP TABLE #tempFinalResults







    
    
    
END







GO


