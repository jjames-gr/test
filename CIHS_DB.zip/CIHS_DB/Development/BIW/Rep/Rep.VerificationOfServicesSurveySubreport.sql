USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[VerificationOfServicesSurveySubreport]    Script Date: 09/26/2013 13:54:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[VerificationOfServicesSurveySubreport]
	@Strdt DATE ,			-- First Date of Service
	@Enddt DATE ,			-- Last Date of Service
	@ClientID INT ,			-- NULL = All
	@Providers INT ,		-- -2 = All
	@Catchment NVARCHAR(MAX) ,		-- -300 = All
	@Services INT ,			-- -2 = All
	@FundingSource INT		-- 3 = Medicaid B , 4 = Medicaid C
AS

/*	------------------------------------------------------------------------------
	Title:		Verification Of Services Survey
	File:		[Rep].[VerificationOfServicesSurvey]
	Author:		Doug Cox
	Date:		09/11/2013
	Desc:		This report will pull Medicaid paid claims for services received by 
				consumer to generate a mailable survey for the consumer to complete 
				and return to CIHS.
                                        
	Called By:
                Reports:	QMG009 - Verification of Services Survey.RDL
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/11/2013		Doug Cox				8953			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@Strdt DATE = '1/1/13',		-- First Date of Service
--	@Enddt DATE = '1/31/13',	-- Last Date of Service
--	@ClientID INT = 18315,		-- NULL = All, 18315,
--	@Providers INT = -2,		-- -2 = All
--	@Catchment INT = -300,		-- -300 = All
--	@Services INT = -2,			-- -2 = All
--	@FundingSource INT = -2		-- 3 = Medicaid B , 4 = Medicaid C

	;WITH cteServices AS (
		SELECT	DISTINCT
				ROW_NUMBER () OVER (PARTITION BY dConsumer.ConsumerNK ORDER BY dConsumer.ConsumerNK , dos.DateValue ) as RowNumber ,
				dos.DateValue AS DOS,
				dProvider.ProviderName,
				dServices.ServiceDescription,
				fClaims.PaidAmount,
				RTRIM(dConsumer.Language) AS ReportLanguage
		FROM	dw.factClaims AS fClaims with(nolock)
				INNER JOIN dw.dimConsumers AS dConsumer with(nolock) ON dConsumer.ConsumerSK = fClaims.ConsumerSK
				INNER JOIN dw.dimServices AS dServices with(nolock) ON dServices.ServicesSK = fClaims.ServicesSK
				INNER JOIN dw.dimProvider AS dProvider with(nolock) ON dProvider.ProviderSK = fClaims.ProviderSK
				INNER JOIN dw.dimBenefitPlan AS dBPlan with(nolock) ON dBPlan.BenefitPlanSK = fClaims.BenefitPlanSK 
				INNER JOIN dw.dimOrganization AS do with(nolock) ON do.OrganizationSK = fClaims.OrganizationSK
				INNER JOIN dw.dimDate AS DOS with(nolock) ON DOS.DateSK = fClaims.DateOfServiceSK
		WHERE	dConsumer.ConsumerNK = @ClientID
				AND fClaims.PaidAmount >= 10
				AND dServices.ServiceDefinitionID NOT IN (SELECT dcrg.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dcrg WHERE dcrg.CustomGroupName = 'ExcludeServiceDefinitionVerificationServiceSummary')
				AND dServices.ServiceCode NOT IN (SELECT dcrg.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dcrg WHERE dcrg.CustomGroupName = 'ExcludeServiceCodesVerificationServiceSummary')
				AND DOS.DateValue BETWEEN @Strdt AND @Enddt
				AND ( dBPlan.BenefitPlanNK = @FundingSource OR @FundingSource = -2 AND dBPlan.BenefitPlanNK IN (3,4) )
				AND ( dProvider.ParentProviderNK = @Providers OR @Providers = -2 )
				AND ( dServices.ServicesNK = @Services OR @Services = -2 )
				AND (
						@catchment = '-300'
						OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
						OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					)
		)
		
	SELECT * FROM cteServices WHERE RowNumber < 11