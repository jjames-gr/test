USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListProvidersforClaimReports]
AS

/*------------------------------------------------------------------------------
	Title:		List Providers for Claim reports
	File:		[Rep].[[ListProvidersforClaimReports]]
	Author:		Karen Roslund
	Date:		06/04/13
	Desc:		This listing of Providers  can be used to fill the available 
					values for the Provider Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/04/2013		Karen roslund   						Created
			1.3		07/08/2013		Doug Cox								Removed ProviderSK AND Added check for Active Providers ONLY
			1.4     07/10/2013      Karen Roslund							Removed the check for Active Providers... Because some providers may provide a service and then may become inactive later on
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
				(p.ProviderNK=@prov_Id) OR 
			( @prov_Id= -2 )
		)

	-- OR FOR Multi-select:
		1. Filter in your Parameter to eliminate ProviderNK = -2 
		2. Add the following to your FROM Clause:
			
			INNER JOIN dbo.cfn_split(@ProviderID , ',') AS prov ON prov.element = dp.ProviderNK
		
	-----------------------------------------------------------------------------------*/

	/* Get Listing of available Providers */
	SELECT distinct dp.ProviderNK,
		dp.ProviderName,
		2 as ProviderOrder 
	FROM dw.factClaims fc with (nolock)
	inner join DW.dimProvider as dp with(nolock) on fc.ProviderSK = dp.ProviderSK  and dp.ParentProviderNK = dp.ProviderNK 
	--WHERE dp.Active = 1
	UNION
	SELECT -2 AS ProviderNK ,
		'All Providers',
		1 as ProviderOrder 

	ORDER BY ProviderOrder, dp.ProviderName 
	






GO


