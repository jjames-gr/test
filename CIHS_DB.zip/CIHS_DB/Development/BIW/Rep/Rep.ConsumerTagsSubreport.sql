-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE Rep.ConsumerTagsSubreport
	@ConsumerID int,
	@StartDate datetime,
	@EndDate datetime
AS
/*------------------------------------------------------------------------------
-- Title:	Consumer Tags
-- File:	[Rep].[ConsumerTagsSubreport]
-- Author:	Brian Angelo
-- Date:	08/13/2013
-- Desc:	Consumer Tags Subreport stored proc
--			
-- CalledBy:
-- 		Reports: "Consumer Tags"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/13/2013  	Brian Angelo	6324	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /*
	/*** Test Parameters ***/
	DECLARE @ConsumerID int,
			@StartDate datetime,
			@EndDate datetime

	SET @ConsumerID = 7880
	SET @StartDate = '6/1/13'
	SET @EndDate = '6/30/13'

	--*/


	SELECT 
	fa.AuthorizationNumber as AuthorizationNumber
	,ddAuth.DateValue as AuthorizationDate
	,dp.ProviderName as ProviderName
	,ds.ServiceDescription as ServiceDescription
	,ddAuthEffFrom.DateValue as AuthStartDate
	,ddAuthEffTo.DateValue as AuthEndDate
	,fa.AuthorizedUnits as AuthorizationUnits
	,dbp.BenefitPlan as BenefitPlan
	FROM [BIW].[DW].[factAuthorizations] fa WITH(NOLOCK)
	INNEr JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fa.ConsumerSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fa.OrganizationSK
	INNER JOIN [BIW].[DW].[dimDate] ddAuth WITH(NOLOCK) ON ddAuth.DateSK = fa.CreateDateSK
	INNER JOIN [BIW].[DW].[dimDate] ddAuthEffFrom WITH(NOLOCK) ON ddAuthEffFrom.DateSK = fa.EffectiveFromDateSK
	INNER JOIN [BIW].[DW].[dimDate] ddAuthEffTo WITH(NOLOCK) ON ddAuthEffTo.DateSK = fa.EffectiveToDateSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fa.ProviderSK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fa.ServicesSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fa.BenefitPlanSK
	WHERE 1=1
	AND dc.ConsumerNK = @ConsumerID
	AND ddAuthEffFrom.DateValue BETWEEN @StartDate AND @EndDate


END
GO
