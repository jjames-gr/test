use BIW

			
USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

	  


CREATE PROCEDURE [Rep].[ClientSpecialtyDiagnosticGroupCount]
    (
		@str_dt DATETIME,
		@end_dt DATETIME,
		@catchment varchar(max), 
		@TypeOfCounty int
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Client Specialty Diagnostic Group Count
-- File:	[Rep].[ClientSpecialtyDiagnosticGroupCount]
-- Author:	Ammar Ahmed
-- Date:	9/5/2013
-- Desc:	
--			
-- CalledBy:
--          Reports: 
--          Stored Procs: 
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		9/5/2013  Ammar Ahmed		6322	  Created
--------------------------------------------------------------------------------
*/



--declare @str_dt datetime, @end_dt datetime, @catchment varchar(max), @TypeOfCounty int 
--set @str_dt			= '1/1/2013'
--set @end_dt			= '3/1/2013'
--set @catchment      = '-300' --'1021,1022,1023,1024'-- '1022' --'-300' --'1021,1022,1023,1024' --'1039,1040,1041,1042,1043' -- to use REP.ListCatchmentCounties in the report
--	--Determines if the report should generate based upon Medicaid County or County of Residence
--set @TypeOfCounty	= 1   --:1 is county of residence/consumer
--						  --:2 is Medicaid county	
 

--Query all the data
select  distinct 
		fc.SpecialDiagnosisGroup factClaimsSpecialDiagnosisGroup
		,fa.SpecialDiagnosisGroup factAuthSpecialDiagnosisGroup
		,c.AgeValue
		,c.ConsumerNK
		,c2.consumerNK consumerNK2
		,c.FullName
		,(CASE @TypeOfCounty WHEN 1 THEN c.County 
							 WHEN 2 THEN do.County 
							 END
		  )as County
		
		,AgeGroup.CustomGroupValue
		,AgeGroup.CustomReportGroupID 
		
into	#temp		
from	DW.factClaims fc
		INNER JOIN DW.factAuthorizations fa WITH(NOLOCK)on fa.AuthorizationNumber = fc.AuthorizationNumber
		INNER JOIN DW.dimConsumers c WITH(NOLOCK)on fc.ConsumerSK = c.ConsumerSK
		INNER JOIN DW.dimOrganization do WITH(NOLOCK)on fc.OrganizationSK = do.OrganizationSK
		INNER JOIN DW.dimConsumers c2 WITH(NOLOCK)on fa.ConsumerSK = c2.ConsumerSK
		INNER JOIN dw.dimCustomReportGroups AS AgeGroup  WITH(NOLOCK)ON AgeGroup.CustomGroupName = 'UtilizationRateAgeGroup'
							AND fc.AgeSK BETWEEN AgeGroup.BeganAttributeCodeRange AND AgeGroup.EndAttributeCodeRange	
		INNER JOIN dw.dimDate dateofserv WITH(NOLOCK)on dateofserv.DateSK = fc.DateOfServiceSK							
		
where	1=1  
		AND  fc.SpecialDiagnosisGroup =  fa.SpecialDiagnosisGroup 
		AND fc.SpecialDiagnosisGroup IS NOT NULL
		AND dateofserv.DateValue between @str_dt AND @end_dt
		
		
		
		AND (
				@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
	
select  * from #temp t
order by t.FullName

		
select 
	   t2.County
	   ,t2.factAuthSpecialDiagnosisGroup
	   ,(select COUNT(t.ConsumerNK)  from #temp t where t.CustomReportGroupID = 1968 
				AND t.County = t2.County AND t.factAuthSpecialDiagnosisGroup = t2.factAuthSpecialDiagnosisGroup) 'Child Age0-12' 
	   ,(select COUNT(t.ConsumerNK)  from #temp t where t.CustomReportGroupID = 1969 
				AND t.County = t2.County AND t.factAuthSpecialDiagnosisGroup = t2.factAuthSpecialDiagnosisGroup) 'Adolescent Age 13-17'
	   ,(select COUNT(t.ConsumerNK)  from #temp t where t.CustomReportGroupID = 1970 
				AND t.County = t2.County AND t.factAuthSpecialDiagnosisGroup = t2.factAuthSpecialDiagnosisGroup) 'Adult Age 18-64'
	   ,(select COUNT(t.ConsumerNK)  from #temp t where t.CustomReportGroupID = 1971 
				AND t.County = t2.County AND t.factAuthSpecialDiagnosisGroup = t2.factAuthSpecialDiagnosisGroup) 'Senior Age 65+'
	   ,count(t2.ConsumerNK)totalcount
	   
	   
from #temp t2
group by t2.County,t2.factAuthSpecialDiagnosisGroup

order by t2.County

drop table #temp