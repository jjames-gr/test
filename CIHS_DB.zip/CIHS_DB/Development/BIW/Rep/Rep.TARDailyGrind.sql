USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[TARDailyGrind]    Script Date: 09/09/2013 09:05:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO











CREATE PROCEDURE [REP].[TARDailyGrind] 
        @CareManager VARCHAR (MAX),
        @DecisionType INT
	
AS	
   
/*------------------------------------------------------------------------------
	Title:		TAR Daily Grind Report			
    File:		[REP].[TARDailyGrind] 
	Author:		Divya Lakshmi	
	Date:		06/24/2013
	Desc:		Provides list of TARs requiring review by number of days to insure review compliance
			

                                        
	Called By:
                        Reports:      UMA019 - TarDailyGrind.rdl


                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/24/2013		Divya Lakshmi     		6533			Created

--	-----------------------------------------------------------------------------------*/
--DECLARE 
--        @CareManager VARCHAR (MAX),
--        @DecisionType INT
	
-- SET    @CareManager =687---2
-- SET    @DecisionType =-2

;with cte as(SELECT DISTINCT
ftar.TARID,
sd.ServiceDefinition,
djunk1.JunkValue AS RequestType,
	CASE 
	WHEN ExpeditedFlag = 0 THEN 'Standard'
	ELSE 'Expedited'
	END as DecisionType,
djunk.JunkValue ReviewProgCode,
dCon.ConsumerNK AS ConsumerID,
dCon.LastName+', '+dCon.FirstName AS ConsumerName,
dProv.ProviderName,
dt.DateValue OriginalSubmitDate,
DATEADD(day,3,dt.DateValue)AS Day3,
DATEADD(day,14,dt.DateValue)AS Day14,
DATEADD(day,28,dt.DateValue)AS Day28,

  --DATEADD(dd, 2, ISNULL (ftar.OriginalSubmitDateSK, sd.create_dt)) Day3 ,
  --DATEADD(dd, 13, ISNULL(ftar.OriginalSubmitDateSK, sd.create_dt)) Day14 ,
  --DATEADD(dd, 27, ISNULL(ftar.OriginalSubmitDateSK, sd.create_dt)) Day28 ,
   DATEDIFF(dd, GETDATE(),
                     DATEADD(dd, 13,
                             ISNULL(dt.DateValue, convert(datetime,sd.create_dt,101)))) duedate,
dt1.DateValue AS LastDateTarReturned,
sd.ReturnHistoryComment,
dEmp.FullName AS 'Care Manager'
 
 FROM dw.factTreatmentAuthorizationRequest ftar WITH(NOLOCK) 
			INNER JOIN dw.dimConsumers AS dCon WITH(NOLOCK) ON ftar.ConsumerSK=dCon.ConsumerSK
			INNER JOIN dw.dimEmployee AS dEmp with(nolock) ON ftar.TARAssigneeSK = dEmp.EmployeeSK
			INNER JOIN dw.dimProvider dProv WITH(NOLOCK) ON ftar.ProviderSK = dProv.ProviderSK
			INNER JOIN dw.dimJunk AS djunk WITH(NOLOCK) ON ftar.ReviewProgCodeSK=djunk.junksk
												AND djunk.JunkEntity = 'ReviewProgCode'
	        INNER JOIN dw.dimJunk AS djunk1 WITH(NOLOCK) ON ftar.RequestTypeSK=djunk1.JunkSK
												AND djunk1.JunkEntity = 'RequestType'
		    INNER JOIN dw.dimDate AS dt WITH(NOLOCK) ON ftar.OriginalSubmitDateSK = dt.DateSK
		    INNER JOIN dw.dimDate AS dt1 WITH(NOLOCK) ON ftar.CreateDateSK = dt1.DateSK
            INNER JOIN  DW.factTARServiceToDiagnosis fsd1 WITH(NOLOCK) ON ftar.FactTreatmentAuthorizationRequestSK=fsd1.TreatmentAuthorizationRequestSK
			INNER JOIN cfn_split(@CareManager,',') fncare  ON  dEmp.EmployeeNK = fncare.element 
            INNER JOIN ( SELECT     
                                  MAX(fsd.TARServiceCreateDateSK) create_dt,
                                  MIN(fsd.TreatmentAuthorizationRequestSK) Requestid,
                                  dCur.ServiceDefinition,
                                  fsd.ReturnHistoryComment
                                 
                              FROM   DW.factTARServiceToDiagnosis fsd WITH(NOLOCK)
                       			     INNER JOIN dw.dimServices AS dServ WITH(NOLOCK) ON fsd.ServicesSK = dServ.ServicesSK
                       			     INNER JOIN dw.dimServices AS dCur WITH(NOLOCK) ON dServ.ServicesNK = dCur.ServicesNK
                        
                              GROUP BY  fsd.TreatmentAuthorizationRequestSK, dCur.ServiceDefinition,fsd.ReturnHistoryComment
                      ) sd ON sd.Requestid= ftar.FactTreatmentAuthorizationRequestSK 
       
       
   WHERE	djunk.JunkNK  NOT IN ( 'COMPL', 'VOID' )
                AND ftar.CreateDateSK IS NOT NULL   
              --  AND ftar.RequestTypeSK NOT IN ( -1, 0 )
                AND ftar.OriginalSubmitDateSK <> -1
            
            	AND
		(
			( 
				@DecisionType = 1--Standard
				AND ftar.ExpeditedFlag = 0 
			)
			OR 
			( 
			     @DecisionType = 2--Expedite
				 AND ftar.ExpeditedFlag = -1 
			)
			OR   @DecisionType  = -2
		)
		


  
)



SELECT *
, CASE WHEN duedate <= 1 THEN 'Due in 1 day or less'
                 WHEN duedate BETWEEN 2 AND 5 THEN 'Due in 2-5 days'
                 WHEN duedate > 5 THEN 'Due in 5 days or more'
            END datedue
FROM cte













GO


