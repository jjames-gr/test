USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[MissingProviderInformationProvider] 
AS

/*------------------------------------------------------------------------------
	Title:		Missing Provider Information (Provider)
	File:		[REP].[MissingProviderInformationProvider] 
	Author:		Karissa Martindale
	Date:		07/26/13
	Desc:		Report will flag/show identified scopes of missing information:    (i.e., lapsed licensure,
				no licensure date, no licensure demographics, no credentialing date, no re-credentialing date,   No DEA, etc.)
                                        
	Called By:
                        Reports:          UMA014 - MissingProviderInformation
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/22/2013		Karissa Martindale   	8736			Creation
-----------------------------------------------------------------------------------*/


SELECT 
ProviderSK,
COUNT(DISTINCT dServ.ServicesNK) as ServiceCount
INTO #tempServices
FROM
dw.factProviderContract fPContract WITH(NOLOCK) 
LEFT JOIN dw.dimServices dServ WITH(NOLOCK) ON fPContract.ServicesSK = dServ.ServicesSK
GROUP BY ProviderSK

select 
sub.ProviderNK,
sub.ProviderName,
sub.AddressLine1,
sub.City,
sub.[State],
sub.PostalCode,
sub.County,
sub.FederalTaxID,
MAX(CASE 
	WHEN CAST(sub.MedicaidNumber AS varchar(15)) = '' THEN 'Missing Info'
	ELSE ISNULL(CAST(sub.MedicaidNumber as varchar(15)), 'Missing Info')
END) as MedicaidNumber,
MAX(CASE 
	WHEN CAST(sub.NPI AS varchar(15)) = '' THEN 'Missing Info'
	ELSE ISNULL(CAST(sub.NPI as varchar(15)), 'Missing Info')
END) as NPI,
sub.ContactPhoneNumber,
sub.TargetPopulation,
sub.ClinicianCount,
sub.ServiceCount,
Catchment = 
ISNULL(( 
	SELECT DISTINCT
		dOrg.Catchment+';'
	FROM     
	dw.factProviderCatchmentServed fPCatch WITH(NOLOCK)
	INNER JOIN dw.dimJunk dJunk WITH(NOLOCK) ON fPCatch.CatchmentSK = dJunk.JunkSK
	INNER JOIN dw.dimOrganization dOrg WITH(NOLOCK) ON CAST(dJunk.JunkNK as varchar) = CAST(dOrg.CatchmentID as varchar)
	WHERE  sub.ProviderSK = fPCatch.ProviderSK
	FOR XML PATH('')
 ), 'Missing Info'),
[master]
INTO #tempFinal
from(
SELECT
dProv.ProviderNK,
dProvJoin.ProviderSK,
MAX(CASE 
	WHEN dProv.ProviderName = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.ProviderName, 'Missing Info')
END) as ProviderName,
MAX(CASE 
	WHEN dProv.AddressLine1 = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.AddressLine1, 'Missing Info')
END) as AddressLine1,
MAX(CASE 
	WHEN dProv.City = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.City, 'Missing Info')
END) as City,
MAX(CASE 
	WHEN dProv.[State] = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.[State], 'Missing Info')
END) as [State],
MAX(CASE 
	WHEN dProv.PostalCode = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.PostalCode, 'Missing Info')
END) as PostalCode,
MAX(CASE 
	WHEN dProv.County = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.County, 'Missing Info')
END) as County,
MAX(CASE 
	WHEN dProv.FederalTaxID = '' THEN 'Missing Info'
	ELSE ISNULL(dProv.FederalTaxID, 'Missing Info')
END) as FederalTaxID,
MAX(fPNPI.MedicaidNumber) as MedicaidNumber,
MAX(fPNPI.NPINumber) as NPI,
MAX(CASE 
	WHEN dPContact.ContactPhoneNumber = '' THEN 'Missing Info'
	ELSE ISNULL(dPContact.ContactPhoneNumber, 'Missing Info')
END) as ContactPhoneNumber,
MAX(CASE 
	WHEN fPPop.TargetPopulation = '' THEN 'Missing Info'
	ELSE ISNULL(fPPop.TargetPopulation, 'Missing Info')
END) as TargetPopulation,
COUNT(DISTINCT fClinP.ClinicianNK) as ClinicianCount,
MAX(CASE 
	WHEN CAST(ts.ServiceCount AS varchar) = '' THEN 'Missing Info'
	ELSE ISNULL(CAST(ts.ServiceCount as varchar), 'Missing Info')
END) AS ServiceCount,
CASE
WHEN dProv.ParentProviderNK = dProv.ProviderNK THEN 'TRUE'
ELSE 'FALSE'
END as [master]
FROM
dw.dimProvider dProv
LEFT JOIN dw.factProviderNPIMedicaidID fPNPI WITH(NOLOCK) ON dProv.ProviderSK = fPNPI.ProviderSK
INNER JOIN dw.dimProvider dProvJoin WITH(NOLOCK) ON dProv.ProviderNK = dProvJoin.ProviderNK
INNER JOIN dw.factProviderContact fPContact WITH(NOLOCK) ON dProvJoin.ProviderSK = fPContact.ProviderSK
INNER JOIN dw.dimProviderContacts dPContact WITH(NOLOCK) ON dPContact.ProviderContactsSK = fPContact.ProviderContactsSK
INNER JOIN dw.factProviderTargetPopulation fPPop WITH(NOLOCK) ON dProvJoin.ProviderSK = fPPop.ProviderSK
LEFT JOIN dw.factClinicianProvider fClinP WITH(NOLOCK) ON fClinP.ProviderNK = dProv.ProviderNK
LEFT JOIN #tempServices tS WITH(NOLOCK) ON dProvJoin.ProviderSK = tS.ProviderSK
WHERE dProv.Active = 1 
AND dProv.StatusID = 49 
GROUP BY
dProv.ParentProviderNK,
dProv.ProviderNK,
dProvJoin.ProviderSK
) as sub
GROUP BY
sub.ProviderNK,
sub.ProviderSK,
sub.ProviderName,
sub.AddressLine1,
sub.City,
sub.[State],
sub.PostalCode,
sub.County,
sub.FederalTaxID,
sub.NPI,
sub.ContactPhoneNumber,
sub.TargetPopulation,
sub.ClinicianCount,
sub.ServiceCount,
[master]


SELECT DISTINCT *
FROM #tempFinal
WHERE
ProviderName = 'Missing Info' OR
AddressLine1= 'Missing Info' OR
City= 'Missing Info' OR
[State]= 'Missing Info' OR
PostalCode= 'Missing Info' OR
County= 'Missing Info' OR
FederalTaxID= 'Missing Info' OR
MedicaidNumber= 'Missing Info' OR
NPI= 'Missing Info' OR
ContactPhoneNumber= 'Missing Info' OR
TargetPopulation= 'Missing Info' OR
Catchment = 'Missing Info'
ORDER BY ProviderNK

DROP TABLE #tempServices
DROP TABLE #tempFinal


