USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ContractedProvidersAndLastClaimDateSubmitted]    Script Date: 08/02/2013 09:35:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ContractedProvidersAndLastClaimDateSubmitted] 
AS
BEGIN
/*------------------------------------------------------------------------------
-- Title:	Contracted Providers and last claim date submitted
-- File:	[Rep].[[ContractedProvidersAndLastClaimDateSubmitted]]
-- Author:	Umberto Sartori
-- Date:	07/15/2013
-- Desc:	Listing of Contracted Providers and last claim date submitted
--			
-- CalledBy:
-- 		Reports: Contracted Providers - Last Claim Submit Date
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	07/15/2013  Umberto Sartori		6497	initial creation
--          07/18/2013  Umberto Sartori     6497    adjusted main address for null fields
--          07/18/2013  Umberto Sartori     6497    changed dimServices.ServiceDescriptionShort to
													dimServices.ServiceSummary
			07/24/2013  Umberto Sartori	    6497    added parent provider name
			07/24/2013  Umberto Sartori		6497	filter out all provider IDs equal to -1
--------------------------------------------------------------------------------*/

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	
--***********************************************************************************	
	
-- create temp table for catchment descriptors (by provider) to be concatenated
SELECT p.ProviderNK, c.JunkValue as Catchment 
INTO #catch
FROM 
  dw.factProviderCatchmentServed f
  inner join dw.dimProvider p on f.providerSK = p.ProviderSK
  inner join dw.dimJunk c on f.catchmentSK = c.JunkSK				
WHERE -- global filters
	p.Active = 1 
	and p.StatusID = 49


CREATE CLUSTERED INDEX idx_catchProvider ON #catch (ProviderNK);

-- create temp table for short service descriptors (by provider) to be concatenated
SELECT DISTINCT
      pr.ProviderNK
      ,ss.ServiceSummary
INTO
      #srvDesc
FROM
      dw.dimServices ss
      inner join dw.factProviderContract pc (nolock) on pc.ServicesSK= ss.ServicesSK
      inner join dw.dimProvider pr (nolock) on pr.ProviderSK = pc.ProviderSk
WHERE -- global filters
	pr.Active = 1 
	and pr.StatusID = 49      
                                                      
CREATE CLUSTERED INDEX idx_srvProvider ON #srvDesc (ProviderNK);        
      
-- get all the required fields      
SELECT  distinct
	dp.ProviderNK as ProviderID
	,dp.ParentProviderNK as ParentProviderID
	,dp.ProviderName
	,prn.ProviderName as ParentName
	,dp.EntityType
	,isnull(dp.AddressLine1 + ' ', '')  +ISNULL(dp.AddressLine2, '') as ProviderMainAddress
	,dp.City
	,dp.[State]
	,dp.PostalCode as Zip
	,dp.County
	,Catchment = 
		   REPLACE
			  (
					REPLACE
					(
							(
								SELECT DISTINCT
									  REPLACE(RTRIM(Catchment),' ', CHAR(127)) AS [data()]
								FROM
									  #catch sd
								WHERE
									  dp.ProviderNK = sd.ProviderNK
								FOR XML PATH('') 
							),
							' ', '; '
					),
					CHAR(127), ' '
			  )
	,dp.AllTargetPopulations		-- these descriptors are already concatenated
	,ServiceDescription =   
			REPLACE
				  (
						REPLACE
						(
								(
									SELECT DISTINCT
										  REPLACE(RTRIM(ServiceSummary),' ', CHAR(127)) AS [data()]
									FROM
										  #srvDesc sd
									WHERE
										  dp.ProviderNK = sd.ProviderNK
									FOR XML PATH('') 
								),
								' ', '; '
						),
						CHAR(127), ' '
				  )
	,prvClm.DateOfService
	,MIN(dc.ContractEffectiveDate) as ContractStartDate
FROM dw.dimProvider dp (nolock) 
            --inner join dw.factProviderContract pc (nolock) on pc.providerSK= dp.ProviderSK
            --inner join dw.dimProviderContract dc (nolock) on dc.ProviderContractSK = pc.ProviderContractSK
            left outer join dw.factProviderContract pc (nolock) on pc.providerSK= dp.ProviderSK
            left outer join dw.dimProviderContract dc (nolock) on dc.ProviderContractSK = pc.ProviderContractSK            
            left outer join (select MAX(dd.DateValue) as DateOfService, pv.ProviderNK
                                        from dw.factClaims clm (nolock) inner join dw.dimProvider pv (nolock) on clm.ProviderSK = pv.ProviderSK                                                                                                
                                                                                        inner join dw.dimDate dd (nolock) on dd.DateSK = clm.DateOfServiceSK
                                        where pv.Active = 1 and pv.StatusID = 49
                                        group by pv.ProviderNK) prvClm      on dp.ProviderNK = prvClm.ProviderNK   
            left outer join dw.dimProvider prn (nolock) on prn.ProviderNK = dp.ParentProviderNK   
WHERE -- global filters
      dp.Active = 1
      and dp.StatusID = 49
      and dp.ParentProviderNK <> -1
      --and prvClm.DateOfService is not null
      --and dp.ProviderNK = dp.ParentProviderNK
GROUP BY
	  dp.ProviderNK
	  ,dp.ParentProviderNK
	  ,dp.ProviderName
	  ,prn.ProviderName
	  ,dp.EntityType
	  ,isnull(dp.AddressLine1 + ' ', '')  +ISNULL(dp.AddressLine2, '')
	  ,dp.City
	  ,dp.[State]
	  ,dp.PostalCode
	  ,dp.County
	  ,dp.AllTargetPopulations
	  ,prvClm.DateOfService
  
ORDER BY
	  dp.ParentProviderNK
	  ,dp.ProviderNK


DROP TABLE #srvDesc
DROP TABLE #catch


END




















GO


