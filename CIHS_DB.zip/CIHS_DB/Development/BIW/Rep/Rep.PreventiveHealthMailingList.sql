USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[PreventiveHealthMailingList]
	@StartDate DATE,
	@EndDate DATE,
	@Diagnosis VARCHAR(50)
AS

/*	------------------------------------------------------------------------------
	Title:		Preventive Health Mailing List
	File:		[Rep].[PreventiveHealthMailingList]
	Author:		Doug Cox
	Date:		09/18/2013
	Desc:		Preventive Health Mailing List.
                                        
	Called By:
                Reports:	QMA009 - PreventiveHealthMailingList.RDL
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/18/2013		Doug Cox				6473			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATE = '1/1/13',
--	@EndDate DATE = '1/31/13',
--	@Diagnosis VARCHAR(50) = 'ADHD (DSM-IV 314.XX, 314.9)' -- 'Depression (DSM-IV-tr 296.2x-296.3x,311)'

IF object_id('tempdb..#temp') is not null
BEGIN
	DROP TABLE #temp
END

SELECT	DISTINCT
		ROW_NUMBER () OVER (PARTITION BY dCurrentConsumer.ConsumerNK ORDER BY dCurrentConsumer.ConsumerNK , dDate.DateValue ) as RowNumber ,
		dCurrentConsumer.ConsumerNK AS ConsumerID,
		dCurrentConsumer.FirstName,
		dCurrentConsumer.LastName,
		dCurrentConsumer.DOB,
		dCurrentConsumer.AgeValue,
		CASE WHEN dCurrentConsumer.AuthRepFirstName IS NOT NULL 
			THEN RTRIM(dCurrentConsumer.AuthRepFirstName) + ' ' + dCurrentConsumer.AuthRepLastName 
			ELSE CASE WHEN dCurrentConsumer.AuthRepFirstName IS NOT NULL 
				THEN RTRIM(dCurrentConsumer.AuthRepFirstName) + ' ' + dCurrentConsumer.AuthRepLastName
				ELSE RTRIM(dCurrentConsumer.FirstName) + ' ' + dCurrentConsumer.LastName
			END
		END AS AuthPerson,
		CASE WHEN dCurrentConsumer.UseMailingAddressFlag = 1 
			THEN ISNULL(dCurrentConsumer.MailingAddressLine1,'') + ' ' + ISNULL(dCurrentConsumer.MailingAddressLine2,'')
			ELSE ISNULL(dCurrentConsumer.AddressLine1,'') + ' ' + ISNULL(dCurrentConsumer.AddressLine2,'') 
		END AS StreetAddress,
		CASE WHEN dCurrentConsumer.UseMailingAddressFlag = 1 THEN dCurrentConsumer.MailingCity ELSE dCurrentConsumer.City END AS City,
		CASE WHEN dCurrentConsumer.UseMailingAddressFlag = 1 THEN dCurrentConsumer.MailingState ELSE dCurrentConsumer.[State] END AS "State",
		CASE WHEN dCurrentConsumer.UseMailingAddressFlag = 1 THEN dCurrentConsumer.MailingPostalCode ELSE dCurrentConsumer.PostalCode END AS "ZIP Code",
		CASE 
			WHEN dDiag1.DiagnosisSK IS NOT NULL THEN dDiag1.DiagnosisSK
			WHEN dDiag2.DiagnosisSK IS NOT NULL THEN dDiag2.DiagnosisSK 
			WHEN dDiag3.DiagnosisSK IS NOT NULL THEN dDiag3.DiagnosisSK 
			WHEN dDiag4.DiagnosisSK IS NOT NULL THEN dDiag4.DiagnosisSK 
		END AS DiagnosisSK,
		dDate.DateValue,
		dCurrentConsumer.County,
		dCurrentConsumer.MailingCounty
INTO	#temp
FROM	dw.factClaims AS fClaims with(nolock) 
		INNER JOIN dw.dimConsumers AS dConsumers with(nolock) ON fClaims.ConsumerSK = dConsumers.ConsumerSK
		INNER JOIN dw.dimConsumers AS dCurrentConsumer with(nolock) ON dCurrentConsumer.ConsumerNK = dConsumers.ConsumerNK AND dCurrentConsumer.ETLCurrentRow = 1
		INNER JOIN dw.dimCustomReportGroups AS dCRG with(nolock) ON dCRG.CustomGroupName = 'PreventiveHealthMailingDiagGroups' AND dCRG.CustomGroupValue = @Diagnosis
		LEFT JOIN dw.dimDiagnosis AS dDiag1 with(nolock) ON dDiag1.DiagnosisSK = fClaims.Diagnosis1SK AND dDiag1.DiagnosisNK = dCRG.BeganAttributeCodeRange
		LEFT JOIN dw.dimDiagnosis AS dDiag2 with(nolock) ON dDiag2.DiagnosisSK = fClaims.Diagnosis2SK AND dDiag2.DiagnosisNK = dCRG.BeganAttributeCodeRange
		LEFT JOIN dw.dimDiagnosis AS dDiag3 with(nolock) ON dDiag3.DiagnosisSK = fClaims.Diagnosis3SK AND dDiag3.DiagnosisNK = dCRG.BeganAttributeCodeRange
		LEFT JOIN dw.dimDiagnosis AS dDiag4 with(nolock) ON dDiag4.DiagnosisSK = fClaims.Diagnosis4SK AND dDiag4.DiagnosisNK = dCRG.BeganAttributeCodeRange
		INNER JOIN dw.dimDate AS dDate with(nolock) ON dDate.DateSK = fClaims.DateOfServiceSK
WHERE	dConsumers.ConsumerNK <> -1
		AND dDate.DateValue BETWEEN @StartDate AND @EndDate
		AND (
			( @Diagnosis = 'Depression (DSM-IV-tr 296.2x-296.3x,311)' AND dCurrentConsumer.AgeValue >= 18 )
			OR ( @Diagnosis = 'ADHD (DSM-IV 314.XX, 314.9)' AND dCurrentConsumer.AgeValue BETWEEN 5 AND 17 )
			)
		AND dCurrentConsumer.LivingArrangements NOT IN 
			( SELECT dCRG.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dCRG WHERE dCRG.CustomGroupName = 'PreventiveHealthMailingLivingArrangements' )
		AND dCurrentConsumer.DOD IS NULL
		AND CASE 
			WHEN dDiag1.DiagnosisNK IS NOT NULL THEN dDiag1.DiagnosisNK
			WHEN dDiag2.DiagnosisNK IS NOT NULL THEN dDiag2.DiagnosisNK 
			WHEN dDiag3.DiagnosisNK IS NOT NULL THEN dDiag3.DiagnosisNK 
			WHEN dDiag4.DiagnosisNK IS NOT NULL THEN dDiag4.DiagnosisNK 
		END = dCRG.BeganAttributeCodeRange

SELECT	t.ConsumerID,
		t.FirstName,
		t.LastName,
		t.DOB,
		t.AgeValue,
		t.AuthPerson,
		t.StreetAddress,
		t.City,
		t.[State],
		t.[ZIP Code],
		dDiag.DiagnosisCode,
		rtrim(dDiag.DiagnosisName) AS DiagnosisName,
		t.DateValue,
		t.County,
		t.MailingCounty
FROM	#temp AS t
		INNER JOIN dw.dimDiagnosis AS dDiag with(nolock) ON dDiag.DiagnosisSK = t.DiagnosisSK
WHERE	t.RowNumber = 1
ORDER BY t.ConsumerID