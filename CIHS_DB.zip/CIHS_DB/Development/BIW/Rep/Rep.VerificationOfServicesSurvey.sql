USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[VerificationOfServicesSurvey]    Script Date: 09/25/2013 12:49:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[VerificationOfServicesSurvey]
	@Strdt DATE ,			-- First Date of Service
	@Enddt DATE ,			-- Last Date of Service
	@ClientID INT ,			-- NULL = All
	@Providers INT ,		-- -2 = All
	@Catchment NVARCHAR(MAX) ,		-- -300 = All
	@Services INT ,			-- -2 = All
	@Method INT ,			-- 1 = By Count , 2 = By Percent
	@Value INT ,			-- Amount of Count or Percent to pull
	@FundingSource INT ,	-- 3 = Medicaid B , 4 = Medicaid C
	@GroupingMethod INT		-- 1 = By Provider , 2 = By Date of Service
AS

/*	------------------------------------------------------------------------------
	Title:		Verification Of Services Survey
	File:		[Rep].[VerificationOfServicesSurvey]
	Author:		Doug Cox
	Date:		09/11/2013
	Desc:		This report will pull Medicaid paid claims for services received by 
				consumer to generate a mailable survey for the consumer to complete 
				and return to CIHS.
                                        
	Called By:
                Reports:	QMG009 - Verification of Services Survey.RDL
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/11/2013		Doug Cox				8953			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@Strdt DATE = '1/1/13',		-- First Date of Service
--	@Enddt DATE = '1/31/13',	-- Last Date of Service
--	@ClientID INT = NULL,		-- NULL = All, 18315,
--	@Providers INT = -2,		-- -2 = All
--	@Catchment NVARCHAR(MAX) = '1021,1022,1023,1024',		-- -300 = All
--	@Services INT = -2,			-- -2 = All
--	@Method INT = 2,			-- 1 = By Count , 2 = By Percent
--	@Value INT = 1,			-- Amount of Count or Percent to pull
--	@FundingSource INT = -2,	-- 3 = Medicaid B , 4 = Medicaid C
--	@GroupingMethod INT	= 1 	-- 1 = By Provider , 2 = By Date of Service

	-- I had to use temp tables here so I could reference them more than once

	IF object_id('tempdb..#Temp1') is not null
	BEGIN
		DROP TABLE #Temp1
	END
	IF object_id('tempdb..#Temp2') is not null
	BEGIN
		DROP TABLE #Temp2
	END
	IF object_id('tempdb..#Temp3') is not null
	BEGIN
		DROP TABLE #Temp3
	END
	
	SELECT	DISTINCT
			dCurrent.ConsumerNK AS ConsumerID,
			dCurrent.FirstName + ' ' + dCurrent.LastName AS ConsumerName,
			CASE
				WHEN LEN(dCurrent.AuthRepAddressLine1) > 0 THEN dCurrent.AuthRepAddressLine1
				WHEN LEN(dCurrent.CaseHeadAddressLine1) > 0 THEN dCurrent.CaseHeadAddressLine1
				ELSE CASE WHEN dCurrent.UseMailingAddressFlag=1 THEN dCurrent.MailingAddressLine1 ELSE dCurrent.AddressLine1 END
			END AS AddressLine1,
			CASE
				WHEN LEN(dCurrent.AuthRepAddressLine1) > 0 THEN dCurrent.AuthRepAddressLine2
				WHEN LEN(dCurrent.CaseHeadAddressLine1) > 0 THEN dCurrent.CaseHeadAddressLine2
				ELSE CASE WHEN dCurrent.UseMailingAddressFlag=1 THEN dCurrent.MailingAddressLine2 ELSE dCurrent.AddressLine2 END
			END AS AddressLine2,
			CASE
				WHEN LEN(dCurrent.AuthRepAddressLine1) > 0 THEN dCurrent.AuthRepCity
				WHEN LEN(dCurrent.CaseHeadAddressLine1) > 0 THEN dCurrent.CaseHeadCity
				ELSE CASE WHEN dCurrent.UseMailingAddressFlag=1 THEN dCurrent.MailingCity ELSE dCurrent.City END
			END AS AddressCity,
			CASE
				WHEN LEN(dCurrent.AuthRepAddressLine1) > 0 THEN dCurrent.AuthRepState
				WHEN LEN(dCurrent.CaseHeadAddressLine1) > 0 THEN dCurrent.CaseHeadState
				ELSE CASE WHEN dCurrent.UseMailingAddressFlag=1 THEN dCurrent.MailingState ELSE dCurrent.State END
			END AS AddressState,
			CASE
				WHEN LEN(dCurrent.AuthRepAddressLine1) > 0 THEN dCurrent.AuthRepPostalCode
				WHEN LEN(dCurrent.CaseHeadAddressLine1) > 0 THEN dCurrent.CaseHeadPostalCode
				ELSE CASE WHEN dCurrent.UseMailingAddressFlag=1 THEN dCurrent.MailingPostalCode ELSE dCurrent.PostalCode END
			END AS AddressZIP,
			RTRIM(dCurrent.Language) AS ReportLanguage,
			CASE WHEN dCurrent.CompetencyCode = 'I' THEN 'Yes' ELSE 'No' END AS Incompetent,
			CASE WHEN dCurrent.AgeValue < 18 THEN 'Yes' ELSE 'No' END AS Minor,
			@Strdt AS StartDate,
			@Enddt AS EndDate
	INTO	#Temp1	-- Can't use CTE because I have to reference it in each of the next 2 queries
	FROM	dw.factClaims AS fClaims with(nolock)
			INNER JOIN dw.dimConsumers AS dConsumers with(nolock) ON dConsumers.ConsumerSK = fClaims.ConsumerSK
			INNER JOIN dw.dimConsumers AS dCurrent with(nolock) ON dCurrent.ConsumerNK = dConsumers.ConsumerNK AND dCurrent.ETLCurrentRow = 1
			INNER JOIN dw.dimBenefitPlan AS dBPlan with(nolock) ON dBPlan.BenefitPlanSK = fClaims.BenefitPlanSK 
			INNER JOIN dw.dimOrganization AS do with(nolock) ON do.OrganizationSK = fClaims.OrganizationSK
			INNER JOIN dw.dimProvider AS dProvider with(nolock) ON dProvider.ProviderSK = fClaims.ProviderSK
			INNER JOIN dw.dimServices AS dServices with(nolock) ON dServices.ServicesSK = fClaims.ServicesSK
			INNER JOIN dw.dimDate AS DOS with(nolock) ON DOS.DateSK = fClaims.DateOfServiceSK
	WHERE	dConsumers.ConsumerNK <> -1
			AND dCurrent.Language IN ( 'English' , 'Spanish' )
			AND fClaims.PaidAmount >= 10
			AND dCurrent.DoNotMailFlag = 0
			AND dServices.ServiceDefinitionID NOT IN (SELECT dcrg.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dcrg WHERE dcrg.CustomGroupName = 'ExcludeServiceDefinitionVerificationServiceSummary')
			AND dServices.ServiceCode NOT IN (SELECT dcrg.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dcrg WHERE dcrg.CustomGroupName = 'ExcludeServiceCodesVerificationServiceSummary')
			AND ( dCurrent.ConsumerNK = @ClientID OR @ClientID IS NULL )
			AND ( dBPlan.BenefitPlanNK = @FundingSource OR @FundingSource = -2 AND dBPlan.BenefitPlanNK IN (3,4) )
			AND (
					@catchment = '-300'
					OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				)
			AND DOS.DateValue BETWEEN @Strdt AND @Enddt
			AND ( dProvider.ParentProviderNK = @Providers OR @Providers = -2 )
			AND ( dServices.ServicesNK = @Services OR @Services = '-2' )

	CREATE TABLE #Temp2 (
		Grain varchar(25) ,
		ConsumerID int ,
		ConsumerName varchar(255) ,
		AddressLine1 varchar(255) ,
		AddressLine2 varchar(255) ,
		AddressCity varchar(255) ,
		AddressState varchar(2) ,
		AddressZIP varchar(10) ,
		ReportLanguage varchar(10) ,
		Incompetent varchar(3) ,
		Minor varchar(3) ,
		StartDate date ,
		EndDate date ,
		DOS date ,
		ProviderName varchar(255) ,
		ServiceDescription varchar(250) ,
		PaidAmount money ,
		MedicaidID varchar(50) ,
	)

	IF @Method = 1 -- By Count
		BEGIN
			INSERT INTO #Temp2 
				SELECT	TOP ( @Value )
						'Questionnaire' AS Grain ,
						t1.ConsumerID,
						t1.ConsumerName,
						t1.AddressLine1,
						t1.AddressLine2,
						t1.AddressCity,
						t1.AddressState,
						t1.AddressZIP,
						t1.ReportLanguage,
						t1.Incompetent,
						t1.Minor,
						t1.StartDate,
						t1.EndDate,
						NULL AS DOS,
						NULL AS ProviderName,
						NULL AS ServiceDescription,
						NULL AS PaidAmount,
						NULL AS MedicaidID
				FROM	( SELECT TOP ( @Value ) NEWID() AS ROWID , * FROM #Temp1 ORDER BY ROWID ) AS t1
				WHERE	( t1.AddressLine1 IS NOT NULL OR t1.AddressLine2 IS NOT NULL )
						AND t1.AddressCity IS NOT NULL
						AND t1.AddressState IS NOT NULL
						AND t1.AddressZIP IS NOT NULL
		END
	ELSE -- By Percent
		BEGIN
			INSERT INTO #Temp2 
				SELECT	'Questionnaire' AS Grain ,
						t1.ConsumerID,
						t1.ConsumerName,
						t1.AddressLine1,
						t1.AddressLine2,
						t1.AddressCity,
						t1.AddressState,
						t1.AddressZIP,
						t1.ReportLanguage,
						t1.Incompetent,
						t1.Minor,
						t1.StartDate,
						t1.EndDate,
						NULL AS DOS,
						NULL AS ProviderName,
						NULL AS ServiceDescription,
						NULL AS PaidAmount,
						NULL AS MedicaidID
				FROM	( SELECT TOP ( @Value ) PERCENT NEWID() AS ROWID , * FROM #Temp1 ORDER BY ROWID ) AS t1
				WHERE	( t1.AddressLine1 IS NOT NULL OR t1.AddressLine2 IS NOT NULL )
						AND t1.AddressCity IS NOT NULL
						AND t1.AddressState IS NOT NULL
						AND t1.AddressZIP IS NOT NULL
		END
	
	CREATE CLUSTERED INDEX idx_temp2 ON #Temp2 (ConsumerID);

--SELECT * FROM #temp2

	;WITH cteServices AS (
		SELECT	DISTINCT
				ROW_NUMBER () OVER (PARTITION BY t2.ConsumerID ORDER BY t2.ConsumerID , dos.DateValue ) as RowNumber ,
				t2.ConsumerID,
				t2.ConsumerName,
				dos.DateValue AS DOS,
				dProvider.ProviderName,
				dServices.ServiceDescription,
				fClaims.PaidAmount,
				RTRIM(t2.ReportLanguage) AS ReportLanguage,
				fClaims.BenefitPlanSK
		FROM	dw.factClaims AS fClaims with(nolock)
				INNER JOIN dw.dimConsumers AS dConsumer with(nolock) ON dConsumer.ConsumerSK = fClaims.ConsumerSK
				INNER JOIN #Temp2 AS t2 ON t2.ConsumerID = dConsumer.ConsumerNK
				INNER JOIN dw.dimServices AS dServices with(nolock) ON dServices.ServicesSK = fClaims.ServicesSK
				INNER JOIN dw.dimProvider AS dProvider with(nolock) ON dProvider.ProviderSK = fClaims.ProviderSK
				INNER JOIN dw.dimBenefitPlan AS dBPlan with(nolock) ON dBPlan.BenefitPlanSK = fClaims.BenefitPlanSK 
				INNER JOIN dw.dimOrganization AS do with(nolock) ON do.OrganizationSK = fClaims.OrganizationSK
				INNER JOIN dw.dimDate AS DOS with(nolock) ON DOS.DateSK = fClaims.DateOfServiceSK
		WHERE	fClaims.PaidAmount >= 10
				AND dServices.ServiceDefinitionID NOT IN (SELECT dcrg.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dcrg WHERE dcrg.CustomGroupName = 'ExcludeServiceDefinitionVerificationServiceSummary')
				AND dServices.ServiceCode NOT IN (SELECT dcrg.BeganAttributeCodeRange FROM dw.dimCustomReportGroups AS dcrg WHERE dcrg.CustomGroupName = 'ExcludeServiceCodesVerificationServiceSummary')
				AND DOS.DateValue BETWEEN @Strdt AND @Enddt
				AND ( dBPlan.BenefitPlanNK = @FundingSource OR @FundingSource = -2 AND dBPlan.BenefitPlanNK IN (3,4) )
				AND ( dProvider.ParentProviderNK = @Providers OR @Providers = -2 )
				AND ( dServices.ServicesNK = @Services OR @Services = -2 )
				AND (
						@catchment = '-300'
						OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
						OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					)
		)

	INSERT INTO #Temp2
		SELECT	DISTINCT
    			'Service Summary' AS Grain ,
				cte.ConsumerID,
				cte.ConsumerName,
				NULL AS AddressLine1,
				NULL AS AddressLine2,
				NULL AS AddressCity,
				NULL AS AddressState,
				NULL AS AddressZIP,
				cte.ReportLanguage,
				NULL AS Incompetent,
				NULL AS Minor,
				@Strdt AS StartDate,
				@Enddt AS EndDate,
				cte.DOS,
				cte.ProviderName,
				cte.ServiceDescription,
				cte.PaidAmount,
				fElig.InsuranceNumber AS MedicaidID
		FROM	cteServices AS cte				
				INNER JOIN dw.dimConsumers AS dConsumers with(nolock) ON dConsumers.ConsumerNK = cte.ConsumerID
				INNER JOIN dw.factEligibility AS fElig with(nolock) ON fElig.ConsumerSK = dConsumers.ConsumerSK AND fElig.BenefitPlanSK = cte.BenefitPlanSK
				INNER JOIN dw.dimDate AS EligBeginDate with(nolock) ON EligBeginDate.DateSK = fElig.DateSK
				INNER JOIN dw.dimDate AS EligEndDate with(nolock) ON EligEndDate.DateSK = fElig.ExpirationDateSK
		WHERE	cte.RowNumber < 11
				AND cte.DOS BETWEEN EligBeginDate.DateValue AND EligEndDate.DateValue
				
SELECT * FROM #Temp2