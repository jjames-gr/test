USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[CCAge18Within120Days] ( @Disability VARCHAR(50), @Catchment VARCHAR(50) ) AS

/*------------------------------------------------------------------------------
	Title:		CCAge18Within120Days
	File:		[Rep].[CCAge18Within120Days]
	Author:		Doug Cox
	Date:		07/18/13
	Desc:		Displays Consumers who will be the age 18 within the next 120 days

	Called By:
                        Reports:          CCO001 - CC Age 18 Within 120 Days
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/18/2013		Doug Cox				8947			Created
			1.1		08/15/2013		Doug Cox				8947			Changed to make Catchment Multiselect
																			and show all diagnosis codes, not just
																			the top 3
	
-----------------------------------------------------------------------------------*/

--DECLARE
--	@Disability VARCHAR(50) = '-2',
--	@Catchment VARCHAR(50) = '1039,1040,1041,1042,1043'

	-- I Had to use a temp table to use an Order By

	IF object_id('tempdb..#temp') is not null
		BEGIN
			DROP TABLE #temp
		END

	SELECT	DISTINCT
			dCon.ConsumerNK,
			dD.DiagnosisCode,
			fCD.DiagnosisEffectiveDateSK 
	INTO	#temp
	FROM	DW.dimConsumers AS dCon with(nolock)
			INNER JOIN DW.factConsumerDiagnosis AS fCD WITH(NOLOCK) ON dCon.ConsumerSK = fCD.ConsumerSK
			INNER JOIN DW.dimDiagnosis AS dD ON fCD.DiagnosisSK = dD.DiagnosisSK
			INNER JOIN DW.dimDate AS dDate ON dDate.DateSK =  fCD.DiagnosisExpirationDateSK
	WHERE	DATEDIFF(day, GETDATE(), dateadd(year, 18, dCon.DOB)) BETWEEN 1 AND 120
	ORDER BY dcon.ConsumerNK ASC , fCD.DiagnosisEffectiveDateSK DESC
	
	--SELECT * FROM #temp WHERE ConsumerNK = 255872
	
	SELECT	DISTINCT 
			dDisability.JunkValue AS DisabilityGroup,
			dcon.LastName + ', ' + dCon.FirstName AS ConsumerName,
			dCon.ConsumerNK AS ConsumerID,
			dCon.DOB AS ConsumerDOB,
			ISNULL((SELECT DISTINCT RTRIM(t.DiagnosisCode) + ', ' FROM #temp AS t WHERE t.ConsumerNK = dCon.ConsumerNK FOR XML PATH('') ),'  ')  AS DiagnosisCodes ,  
			dEmp.LastName + ', ' + dEmp.FirstName AS CareCoordinator,
			dCatch.JunkValue AS Catchment,
			dCon.Competency AS CompetencyLevel
	FROM	DW.dimConsumers AS dCon with(nolock)
			INNER JOIN DW.factCareCoordAdmissions AS fCareCoordAdmin with(nolock) on fCareCoordAdmin.ConsumerSK = dCon.ConsumerSK
			INNER JOIN DW.dimEmployee AS dEmp with(nolock) ON fCareCoordAdmin.CareCoordinatorSK = dEmp.EmployeeSK
			INNER JOIN DW.dimJunk AS dDisability with(nolock) ON fCareCoordAdmin.CareDisabilityGroupSK = dDisability.JunkSK AND dDisability.JunkEntity = 'CareDisabilityGroup'
			INNER JOIN DW.dimJunk AS dCatch with(nolock) ON dCatch.JunkSK = fCareCoordAdmin.CatchmentSK AND dCatch.JunkEntity = 'AreaCatchments'
			INNER JOIN dbo.cfn_split(@Catchment , ',') fnc ON fnc.element = dCatch.JunkNK
	WHERE	DATEDIFF(day, GETDATE(), dateadd(year, 18, dCon.DOB)) BETWEEN 1 AND 120
			AND fCareCoordAdmin.CareCoordDischargeDateSK = -1
			AND fCareCoordAdmin.ActiveAdmissionFlag = 1
			--AND ( @Catchment = '-2' OR dCatch.JunkNK = @Catchment )
			AND ( @Disability = '-2' OR dDisability.JunkNK = @Disability )