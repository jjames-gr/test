USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ClaimsByClientProvider]    Script Date: 09/25/2013 13:15:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ClaimsByClientProvider] 
(
      --@showHeader internal param
      @basis INT, -- 1(Claims by Client DOS) 2(Claims by Provider DOS) 3(Claims by Provider Processed Date) 4(Claims by Prodiver Re-Processed Date) 5(Claims by Provider Receieved Date)
      @str_date DATETIME,
      @end_date DATETIME,
      @service VARCHAR(MAX),
      @clientID INT,
      @insurance VARCHAR(MAX),
      @reverts INT, --1 Approved 2 Denied 3 Pending 4 Reverted/Readjudicated -1 All
      @catchment VARCHAR(MAX),
      @provider VARCHAR(MAX)
)
AS

/*------------------------------------------------------------------------------
      Title:            Claims by Client/Provider
      File:       [Rep].[ClaimsByClientProvider]
      Author:           Karissa Martindale
      Date:       05/16/13
      Desc:       Claim detail listed by Client, Provider, Dt Processed, Dt Received or Dt re-processed.
                                        
      Called By:
                        Reports:          CML333 - Claims by Client/Provider
                        Stored Procs:     None
                       
      -----------------------------------------------------------------------------------
      Version History:
      
                  Ver         Date              Author                              TixNo             Description
                  ---         ----------        ---------------               -----             -----------
                  1.0         05/15/2013        Karissa Martindale      6303                         Created
                  1.1         7/8/13                  Doug Cox                      6303              Changed from Provider SK to Provider NK
      
-----------------------------------------------------------------------------------*/


--DECLARE 
--    @basis INT =1, -- 1(Claims by Client DOS) 2(Claims by Provider DOS) 3(Claims by Provider Processed Date) 4(Claims by Prodiver Re-Processed Date) 5(Claims by Provider Receieved Date)
--    @str_date DATETIME ='6/1/13',
--    @end_date DATETIME ='6/5/13',
--    @service VARCHAR(MAX) = '1',
--    @clientID INT = 12171,
--    @insurance VARCHAR(MAX) = '1, 2, 3, 4, 5, 6',
--    @reverts INT = -100, --1 Approved 2 Denied 3 Pending 4 Reverted/Readjudicated -100 All
--    @catchment INT = '1021',
--    @provider VARCHAR(MAX) = '21097'--'21631'
      

SELECT DISTINCT
      mainprov.ProviderNK as masternk,
      mainprov.ProviderName as mastername,
      dCon.ConsumerNK,
      dCon.LastName,
      dProv.ProviderNK as siteNK,
      dProv.ProviderName as siteName,
      dOrg.Catchment,
      fClaim.ClaimAdjudicationNumber,
      fClaim.ClaimNumber,
      fClaim.ReferenceNumber,
      fclaim.DateofServiceSK,
      dServ.ServiceCode,
      fClaim.UnitsClaimed,
      fClaim.UnitsBilled, --Approved Units? Additional notes on RRD to look at 
      fClaim.ClaimAmount / NULLIF(fClaim.UnitsClaimed, 0) as calcRate,
      fClaim.ContractRate,
      fclaim.ReceivedDateValue,
      MIN(fclaim.DateValue) as adjDate,
      MAX(fClaim.DateValue) as reAdjDate,
      fClaim.ClaimAmount as billedAmount,
      CASE fClaim.StatusSK
      WHEN 1 THEN fClaim.AdjudicatedAmount
      ELSE ''
      END as approvedAmount,
      fClaim.PaidAmount,
      fClaim.CapitatedAmount,
      fClaim.AdjustedAmount,
      fClaim.COBAmount,
      dReas.ReasonCodeNK,
      dBen.BenefitPlanShort,
      dOrg.County,
      dProv.ProviderNK,
      dProv.ProviderName,
      fClaim.StatusSK,
      dJunk.JunkEntity,
      Case dJunk.JunkNK
      WHEN 1 THEN 'Approved'
      WHEN 2 THEN 'Denied'
      WHEN 3 THEN 'Pending'
      WHEN 4 THEN 'Reverted/Readjudicated'
      END as JunkNK,
      dServ.ServicesNK
INTO #tempFinal
FROM (SELECT      ClaimNumber,
                        ClaimAdjudicationNumber,
                        ReferenceNumber,
                        UnitsClaimed,
                        UnitsBilled,
                        ClaimAmount,
                        ContractRate,
                        StatusSK,
                        AdjudicatedAmount,
                        PaidAmount,
                        CapitatedAmount,
                        AdjustedAmount,
                        COBAmount,
                        ConsumerSK,
                        OrganizationSK,
                        ServicesSK,
                        BenefitPlanSK,
                        ProviderSK,
                        ReasonCodeSK,
                        dDOS.DateValue as DateofServiceSK,
                        dRec.DateValue as ReceivedDateValue,
                        dAdj.DateValue
                        from Dw.factClaims fc
                        --Date Joins
                        INNER JOIN BIW.DW.dimDate dDOS WITH(NOLOCK) ON fc.DateOfServiceSK = dDOS.DateSK 
                         INNER JOIN BIW.DW.dimDate dAdj WITH(NOLOCK) ON fc.AdjudicationDateSK = dAdj.DateSK
                        INNER JOIN BIW.DW.dimDate dRec WITH(NOLOCK) ON fc.ReceivedDateSK = dRec.DateSK
                        WHERE
                              ((
                                    -- 1(Claims by Client DOS) 
                                    -- 2(Claims by Provider DOS) 
                                    (@basis = 1 OR @basis = 2)
                                    --AND dCreate.DateValue BETWEEN @str_date AND @end_date
                                    AND dDOS.DateValue BETWEEN @str_date AND @end_date
                              )
                              OR
                              (
                                    -- 3(Claims by Provider Processed Date) 
                                    @basis = 3 
                                    AND dAdj.DateValue BETWEEN @str_date AND @end_date
                              )
                              OR
                              (
                                    -- 4(Claims by Provider Re-Processed Date) 
                                    @basis = 4 
                                    AND (
                                                dAdj.DateValue BETWEEN @str_date AND @end_date 
                                                AND (fc.ReSubReferenceNumber is not null OR fc.ReSubReferenceNumber = '')
                                          ) 
                              )
                              OR
                              (
                                    -- 5(Claims by Provider Receieved Date)
                                    @basis = 5 
                                    AND dRec.DateValue BETWEEN @str_date AND @end_date
                              )))fClaim
      INNER JOIN BIW.DW.dimConsumers dCon WITH(NOLOCK) ON fClaim.ConsumerSK = dCon.ConsumerSK
      INNER JOIN BIW.DW.dimOrganization dOrg WITH(NOLOCK) ON fClaim.OrganizationSK = dOrg.OrganizationSK
      INNER JOIN BIW.DW.dimServices dServ WITH(NOLOCK) ON fClaim.ServicesSK = dServ.ServicesSK
            INNER JOIN dbo.cfn_split(@service , ',') fn ON element = dServ.ServicesNK
      INNER JOIN BIW.DW.dimBenefitPlan dBen WITH(NOLOCK) ON fClaim.BenefitPlanSK = dBen.BenefitPlanSK
            INNER JOIN dbo.cfn_split(@insurance , ',') fnb ON fnb.element = dBen.BenefitPlanNK
      INNER JOIN BIW.DW.dimProvider dProv WITH(NOLOCK) ON fClaim.ProviderSK = dProv.ProviderSK
            INNER JOIN dbo.cfn_split(@provider , ',') fnp ON fnp.element = dProv.ProviderNK
     --added master prov joins
      INNER JOIN DW.dimProvider MainProv WITH(NOLOCK) ON dProv.ParentProviderNK = MainProv.ProviderNK
      INNER JOIN BIW.DW.dimJunk dJunk WITH(NOLOCK) ON fClaim.StatusSK = dJunk.JunkSK
      INNER JOIN BIW.DW.dimReasonCodes dReas WITH(NOLOCK) ON fClaim.ReasonCodeSK = dReas.ReasonCodeSK
      

      --AND (dBen.BenefitPlanNK IN (2,3,4,5,6) --Medicaid
      --    OR dReas.ReasonCodeNK IN (1060, 1061, 1062, 1063,1064, 1065, 1066, 1067,1068, 1069, 1070, 1071, 1072, 1084, 1085, 1087, 1089, 1094, 1095, 1096,1107, 1111, 1114, 1115,1122, 1123, 1141, 1143)
      --    )
      WHERE
      (@catchment = '-300' --All Catchments
      OR CONVERT(nvarchar, dOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') ) --Specific Catchment
      OR CONVERT(nvarchar, dOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') ) --Specific County
      )
      AND (dCon.ConsumerNK = @clientID OR @clientID is null)
GROUP BY mainprov.ProviderNK, mainprov.ProviderName, dProv.ProviderNK, dProv.ProviderName, dCon.ConsumerNK, dCon.LastName, --fClaim.ProviderSK,
            dOrg.Catchment, fClaim.ClaimAdjudicationNumber,
            fClaim.ClaimNumber, fClaim.ReferenceNumber, DateofServiceSK, dServ.ServiceCode, fClaim.UnitsClaimed, fClaim.UnitsBilled, fClaim.ClaimAmount,
            fClaim.ContractRate, fclaim.DateValue, ReceivedDateValue, fClaim.PaidAmount, fClaim.AdjudicatedAmount, fClaim.CapitatedAmount, fClaim.AdjustedAmount, fClaim.COBAmount,
            fClaim.ReasonCodeSK, dBen.BenefitPlanShort, dOrg.County, fClaim.StatusSK, dJunk.JunkEntity, dJunk.JunkNK,
            dReas.ReasonCodeNK, dServ.ServicesNK
--Order by handled in RDL

UPDATE #tempFinal 
SET UnitsBilled = 0, COBAmount = 0.00
WHERE JunkNK = 'Denied'

--Reverted Claims
IF @reverts = 4
BEGIN
      SELECT * 
      FROM #tempFinal
      WHERE
      StatusSK = 4 AND JunkEntity = 'ClaimAdjudicatedStatus'
END

IF @reverts <> 4
BEGIN 
      --All Claims
      IF @reverts = -100
      BEGIN
            SELECT * 
            FROM #tempFinal
            WHERE
            StatusSK IN (1,2,3,4,5) AND JunkEntity = 'ClaimAdjudicatedStatus' 
      END
      
      --Non-Reverted Claims
      IF @reverts <> -100
      BEGIN
            SELECT * 
            FROM #tempFinal
            WHERE
            StatusSK <> 4 AND JunkEntity = 'ClaimAdjudicatedStatus'
      END
END

DROP TABLE #tempFinal
