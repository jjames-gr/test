USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[DMA_ICF_MH_DD_PaidDays] ( @StartDate DATE, @EndDate DATE , @PlanID INT, @Age VARCHAR(MAX) ) AS

/*------------------------------------------------------------------------------
	Title:		DMA_ICF_MH_DD_PaidDays
	File:		Rep.DMA_ICF_MH_DD_PaidDays.sql
	Author:		Doug Cox
	Date:		08/02/2013
	Desc:		DMA ICF MH_DD Paid Days
                                        
	Called By:
                        Reports:          STP009 - DMA ICF MH DD Paid Days.rdl
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/02/2013		Doug Cox     			6371			Created

	-----------------------------------------------------------------------------------*/

	/*	TESTING	*/
	--DECLARE 
	--@StartDate DATE = '1/1/13',
	--@EndDate DATE = '1/31/13',
	--@PlanID INT = -100,
	--@Age VARCHAR(MAX) = '1,2,-1'
	/*	END TESTING	*/

	;WITH cteMedicaidNumber AS (
		SELECT	ROW_NUMBER () OVER (PARTITION BY fMedicaidID.ProviderSK ORDER BY fMedicaidID.ProviderSK, fMedicaidID.ETLModifiedDate DESC) as RowNumber,
				fMedicaidID.ProviderSK,
				fMedicaidID.MedicaidNumber
		FROM	dw.factProviderNPIMedicaidID AS fMedicaidID with(nolock) 
				INNER JOIN dw.dimProvider AS dProv with(nolock) ON dProv.ProviderSK = fMedicaidID.ProviderSK AND dProv.ICF = 'TRUE'
		WHERE	fMedicaidID.ActiveFlag = 1
				AND fMedicaidID.MedicaidNumber NOT LIKE 'PD%'
		)

	SELECT	CONVERT(CHAR(6),dDOS.DateValue,112) AS ServiceMonth,
			cte.MedicaidNumber AS MedicaidNumber,
			dProv.ProviderNK AS ProviderID,
			dProv.ProviderName,
			dProv.AddressLine1 + ' ' + ISNULL(dProv.AddressLine2,'') + ' ' + dProv.City + ' ' + dProv.State + ' ' + dProv.PostalCode AS SiteAddress,
			dOrg.CountyNumber,
			COUNT(*) AS 'Days',
			SUM(fClaims.PaidAmount) AS PaidAmount,
			SUM(fClaims.AdjudicatedAmount) AS AdjudicatedAmount,
			dPlan.BenefitPlanShort AS BenefitPlan,
			dDiag.DiagnosisGroup,
			dAge.StateGroup AS AgeGroup
	FROM	dw.factClaims AS fClaims with(nolock)
			INNER JOIN dw.dimProvider AS dProv with(nolock) ON dProv.ProviderSK = fClaims.ProviderSK AND dProv.ICF = 'TRUE'
			LEFT OUTER JOIN cteMedicaidNumber AS cte ON fClaims.ProviderSK = cte.ProviderSK AND cte.RowNumber = 1
			INNER JOIN dw.dimOrganization AS dOrg with(nolock) ON dOrg.OrganizationSK = fClaims.OrganizationSK
			INNER JOIN dw.dimBenefitPlan AS dPlan with(nolock) ON dPlan.BenefitPlanSK = fclaims.BenefitPlanSK
			INNER JOIN dw.dimDiagnosis AS dDiag with(nolock) ON dDiag.DiagnosisSK = fClaims.Diagnosis1SK
			INNER JOIN dw.dimConsumers AS dConsumer with(nolock) ON dConsumer.ConsumerSK = fClaims.ConsumerSK
			INNER JOIN dw.dimServices AS dServ with(nolock) ON fClaims.ServicesSK = dServ.ServicesSK AND dServ.ServicesNK IN (1,2)
			INNER JOIN dw.dimDate AS dDOS with(nolock) ON dDOS.DateSK = fClaims.DateOfServiceSK
			INNER JOIN dw.dimJunk AS dApprovedClaims with(nolock) ON dApprovedClaims.JunkSK = fClaims.StatusSK 
												AND dApprovedClaims.JunkEntity = 'ClaimAdjudicatedStatus'
												AND dApprovedClaims.JunkValue = 'Approved'
			INNER JOIN dw.dimAge AS dAge with(nolock) ON dAge.AgeSK = fClaims.AgeSK
			INNER JOIN dbo.cfn_split(@Age , ',') AS fnAge ON fnAge.element = dAge.StateGroupID
	WHERE	dDOS.DateValue BETWEEN @StartDate AND @EndDate
			AND (
				( @PlanID = dPlan.BenefitPlanNK ) OR -- 1 specific Plan
				( @PlanID = -100 AND dPlan.InsurerID = 2 ) -- ALL Medicaid
				)
			AND fClaims.AdjudicatedAmount > 0
	GROUP BY CONVERT(CHAR(6),dDOS.DateValue,112) ,
			cte.MedicaidNumber,
			dProv.ProviderNK,
			dProv.ProviderName,
			dProv.AddressLine1 + ' ' + ISNULL(dProv.AddressLine2,'') + ' ' + dProv.City + ' ' + dProv.State + ' ' + dProv.PostalCode,
			dOrg.CountyNumber,
			dPlan.BenefitPlanShort,
			dDiag.DiagnosisGroup,
			dAge.StateGroup
	ORDER BY CONVERT(CHAR(6),dDOS.DateValue,112),
			dProv.ProviderNK