USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[SpecialNeedsPopulations]    Script Date: 09/24/2013 13:37:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [REP].[B3ServicesReport]
(
	@StartDate DATETIME,
	@EndDate DATETIME,
	@COA NVARCHAR(MAX),
	@Serv NVARCHAR(MAX),
	@Catchment NVARCHAR(MAX)
)
AS

/*------------------------------------------------------------------------------
	Title:		B3 Services Report
	File:		[REP].[B3ServicesReport] 
	Author:		Tim Amerson
	Date:		09/24/13
	Desc:		Report B3 Expenditures(Payments) reported by DATE OF SERVICE.
                                        
	Called By:
                        Reports:          FIN025 - B3 Services Report 
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/24/2013		Tim Amerson			   	6452			Created
-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2010',
--	@EndDate DATETIME = '7/31/2013',
--	@Catchment NVARCHAR(MAX) = '1021,1022,1023,1024',---300,
--	@COA NVARCHAR(MAX) = -300,
--	@Serv NVARCHAR(MAX) = -300
	
SELECT
	*
FROM
(
	SELECT
		PlaceHolder = 1
		,ConsumerID = dc.ConsumerNK
		,dName = dd.[DateName_en-US]
		,dVal = dd.DateValue
		,ServCode = ds.ServiceCode
		,sMod = ds.Modifier1
		,County = do.County
		,MthYr = dd.[MonthAndYear_en-US]
		,MthName = dd.[MonthName_en-US]
		,MthNumber = dd.MonthInYear
		,Yr = dd.YearValue
		,BenPlan = bp.BenefitPlanNK
		,COA = coa.CustomGroupValue
		,Serv =
			CASE
				WHEN srv.CustomGroupValue IS NOT NULL THEN srv.CustomGroupValue
				WHEN bp.BenefitPlanNK = 5 THEN 'Innovations'
				ELSE ' Service Code:' + ds.ServiceCode + ' Modification: ' + ds.Modifier1
			END
		,DOS = dos.DateValue
		,ClaimNbr = fc.ClaimNumber
		,CheckDt = dd.DateValue
		,Amt = SubQ.CreditMemoApplyAmount
		
	FROM
		(
			SELECT
				cm.AppliedClaimAdjudicationNumber
				,CreditDateSK = CASE WHEN cc.ClaimCheckDateSK = -1 THEN cm.CreditMemoDateSK ELSE cc.ClaimCheckDateSK END --cmDate.DateValue ELSE ccDate.DateValue END
				,cm.CreditMemoApplyAmount
				
			FROM
				dw.factClaimCheck cc
				LEFT JOIN dw.factCreditMemo cm on cc.ClaimCheckSK = cm.ClaimCheckSK
				INNER JOIN dw.dimDate ccDate on cc.ClaimCheckDateSK = ccDate.DateSK
				INNER JOIN dw.dimDate cmDate on cm.CreditMemoDateSK = cmDate.DateSK
			WHERE 1=1
				AND cm.VoidedCreditMemoSK <> 7
				AND CASE WHEN cc.ClaimCheckDateSK = -1 THEN cmDate.DateValue ELSE ccDate.DateValue END BETWEEN @StartDate AND @EndDate
				
		) SubQ
		
		INNER JOIN dw.dimDate dd on SubQ.CreditDateSK = dd.DateSK
		INNER JOIN dw.factClaims fc on fc.ClaimAdjudicationNumber = SubQ.AppliedClaimAdjudicationNumber
		INNER JOIN dw.dimDate dos on fc.DateOfServiceSK = dos.DateSK
		INNER JOIN dw.dimOrganization do on fc.OrganizationSK = do.OrganizationSK
		INNER JOIN dw.dimBenefitPlan bp on fc.BenefitPlanSK = bp.BenefitPlanSK
		INNER JOIN dw.dimServices ds on fc.ServicesSK = ds.ServicesSK
		INNER JOIN dw.dimMedicaidAidCategory mac on fc.MedicaidAidCategorySK = mac.MedicaidAidCategorySK
		INNER JOIN dw.dimCustomReportGroups coa on mac.CategoryNumberNK = coa.AttributeID AND coa.CustomGroupName = 'MOAOrderGrouping'
		INNER JOIN dw.dimConsumers dc on fc.ConsumerSK = dc.ConsumerSK
		left JOIN dw.dimCustomReportGroups srv on ds.ServicesNK = srv.AttributeID AND srv.CustomGroupName = 'B3ExpendituresServiceCodes'

	WHERE 1=1
		AND fc.StatusSK = 1
		AND ( bp.BenefitPlanNK IN ( 5 , 6 ) )
		AND ds.Active = 1
		AND
		(
			@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		) 

	UNION ALL

	SELECT
		PlaceHolder = 1
		,ConsumerID = dc.ConsumerNK
		,dName = dd.[DateName_en-US]
		,dVal = dd.DateValue
		,ServCode = ds.ServiceCode
		,sMod = ds.Modifier1
		,County = do.County
		,MthYr = dd.[MonthAndYear_en-US]
		,MthName = dd.[MonthName_en-US]
		,MthNumber = dd.MonthInYear
		,Yr = dd.YearValue
		,BenPlan = bp.BenefitPlanNK
		,COA = coa.CustomGroupValue
		,Serv =
			CASE
				WHEN srv.CustomGroupValue IS NOT NULL THEN srv.CustomGroupValue
				WHEN bp.BenefitPlanNK = 5 THEN 'Innovations'
				ELSE ' Service Code:' + ds.ServiceCode + ' Modification: ' + ds.Modifier1
			END
		,DOS = dos.DateValue
		,ClaimNbr = fc.ClaimNumber
		,CheckDt = dd.DateValue
		,Amt = ccd.ClaimCheckDetailAmount
		
	FROM
		dw.factClaimCheck cc
		INNER JOIN dw.factClaimCheckDetail ccd WITH(NOLOCK) ON cc.ClaimCheckSK = ccd.ClaimCheckSK
		INNER JOIN dw.dimDate dd on cc.ClaimCheckDateSK = dd.DateSK
		INNER JOIN dw.factClaims fc on fc.ClaimAdjudicationNumber = ccd.ClaimCheckAdjudicationNumber
		INNER JOIN dw.dimDate dos on fc.DateOfServiceSK = dos.DateSK
		INNER JOIN dw.dimOrganization do on fc.OrganizationSK = do.OrganizationSK
		INNER JOIN dw.dimBenefitPlan bp on fc.BenefitPlanSK = bp.BenefitPlanSK
		INNER JOIN dw.dimServices ds on fc.ServicesSK = ds.ServicesSK
		INNER JOIN dw.dimMedicaidAidCategory mac on fc.MedicaidAidCategorySK = mac.MedicaidAidCategorySK
		INNER JOIN dw.dimCustomReportGroups coa on mac.CategoryNumberNK = coa.AttributeID AND coa.CustomGroupName = 'MOAOrderGrouping'
		INNER JOIN dw.dimConsumers dc on fc.ConsumerSK = dc.ConsumerSK
		left JOIN dw.dimCustomReportGroups srv on ds.ServicesNK = srv.AttributeID AND srv.CustomGroupName = 'B3ExpendituresServiceCodes'

	WHERE 1=1
		AND fc.StatusSK = 1
		AND ( bp.BenefitPlanNK IN ( 5 , 6 ) )
		AND dd.DateValue  BETWEEN @StartDate AND @EndDate
		AND ds.Active = 1
		AND
		(
			@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		) 
) SubQ

WHERE 1=1	
	AND ( @COA = '-300' OR SubQ.COA = @COA )
	AND ( @Serv = '-300' OR SubQ.Serv = @Serv )