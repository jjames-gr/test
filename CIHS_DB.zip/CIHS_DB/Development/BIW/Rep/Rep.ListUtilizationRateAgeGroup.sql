USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListUtilizationRateAgeGroup] AS

/*------------------------------------------------------------------------------
	Title:		List Utilization Rate Age Group
	File:		[Rep].[ListUtilizationRateAgeGroup]
	Author:		Doug Cox
	Date:		07/31/13
	Desc:		This listing of Utilization Rate Age Groups can be used to fill the 
					available values for Utilization Rate Age Group Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/19/2013		Doug Cox				8947			Created
	
	Usage directions:
	-- Add the following to your FROM CLAUSE:
			INNER JOIN dw.dimCustomReportGroups AS AgeGroup with(nolock) ON AgeGroup.CustomGroupName = 'UtilizationRateAgeGroup'
									AND fClaims.AgeSK BETWEEN AgeGroup.BeganAttributeCodeRange AND AgeGroup.EndAttributeCodeRange

	-- Add the following to your WHERE CLAUSE:
			AND ( @AgeGroup = '-1' OR  @AgeGroup = AgeGroup.CustomGroupValue )
		
-----------------------------------------------------------------------------------*/

SELECT	'<ALL>' AS CustomGroupValue
UNION
SELECT	AgeGroup.CustomGroupValue
FROM	dw.dimCustomReportGroups AS AgeGroup with(nolock) 
WHERE	AgeGroup.CustomGroupName = 'UtilizationRateAgeGroup'

GO


