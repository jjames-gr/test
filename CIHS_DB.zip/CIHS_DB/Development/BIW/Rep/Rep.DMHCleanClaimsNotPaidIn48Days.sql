USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[DMHCleanClaimsNotPaidIn48Days]    Script Date: 06/06/2013 09:23:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [Rep].[DMHCleanClaimsNotPaidIn48Days]
	@StartDate DATETIME = '1/1/2013',
	@EndDate DATETIME = '1/31/2013',
	@BenPlan INT = -200,
	@Catchment NVARCHAR(MAX) = -1
AS

/*
	------------------------------------------------------------------------------
	Title:		DMH Clean Claims Not Paid In 48 Days
	File:		[Rep].[DMHCleanClaimsNotPaidIn48Days]
	Author:		Tim Amerson
	Date:		06/11/2013
	Desc:		This report is ran to identify any claims that were not paid promptly
				(within 48 days) for a given date range.  Clean claims are included
				when they are greater than 48 days old whether they are paid or not paid.
				This is a penalty report to determine what extra needs to be paid on.  
                                        
	Called By:
                        Reports:	CLM015 - DMH Clean Claims Not Paid In 48 Days
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/11/2013		Tim Amerson     		6381			Created

	-----------------------------------------------------------------------------------
*/

--DECLARE
--	@StartDate DATETIME = '1/1/2013',
--	@EndDate DATETIME = '3/31/2013',
--	@BenPlan INT = -200,
--	@Catchment NVARCHAR(MAX) = -300;
	
WITH cteNotPaidIn48Days AS
(
	SELECT
		dp.ProviderNK
		, dp.ProviderName
		, fc.ClaimDetailNumber
		, RecDate = rd.DateValue
		, fc.ClaimAdjudicationNumber
		, DOS = ds.DateValue
		, CheckDate = fccd.DateValue
		, dc.ConsumerNK
		, fc.ClaimNumber
		, fc.AdjudicatedAmount
		, DaysLate = DATEDIFF(day, ISNULL(rd.DateValue, cd.DateValue ),ISNULL(pd.DateValue, GETDATE())) - 48
		--, ccj.*

	FROM
		dw.factClaims fc WITH(NOLOCK)
		INNER JOIN dw.dimDate rd WITH(NOLOCK) ON fc.ReceivedDateSK = rd.DateSK
		INNER JOIN dw.dimDate cd WITH(NOLOCK) ON fc.CreateDateSK = cd.DateSK
		INNER JOIN dw.dimDate pd WITH(NOLOCK) ON fc.PaidDateSK = pd.DateSK
		INNER JOIN dw.dimDate ds WITH(NOLOCK) ON fc.DateOfServiceSK = ds.DateSK
		INNER JOIN dw.dimProvider dp WITH(NOLOCK) ON fc.ProviderSK = dp.ProviderSK
		INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
		INNER JOIN dw.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK = bp.BenefitPlanSK
		INNER JOIN dw.dimOrganization do WITH(NOLOCK) ON fc.OrganizationSK = do.OrganizationSK
		INNER JOIN dw.dimJunk ccj WITH(NOLOCK) ON fc.CleanClaimSK = ccj.JunkSK
		LEFT JOIN dw.factClaimCheck fcc WITH(NOLOCK) ON fc.ClaimCheckSK = fcc.ClaimCheckSK
		LEFT JOIN dw.dimDate fccd WITH(NOLOCK) ON fcc.ClaimCheckDateSK = fccd.DateSK

	WHERE
		ccj.JunkNK = '1'
		AND DATEDIFF(day, ISNULL(rd.DateValue, cd.DateValue ),ISNULL(pd.DateValue, GETDATE())) > 48
		AND rd.DateValue BETWEEN @StartDate AND @EndDate
		AND
		(
			( @BenPlan = bp.BenefitPlanNK ) OR -- 1 specific Plan
			( @BenPlan = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
			( @BenPlan = -200 ) -- ALL PLANS
		)
		AND
		(
	
			@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

		)
)

SELECT
	cNP.*
	, Interest = ROUND(CAST(CAST(cNP.AdjudicatedAmount AS FLOAT) * CAST(POWER(( CAST(( 1 + ( .00021902 ) ) AS FLOAT) ), cNP.DaysLate) AS FLOAT) - cNP.AdjudicatedAmount AS MONEY), 2)
	
FROM
	cteNotPaidIn48Days cNP

GO