USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[SubcapitatedServices]    Script Date: 07/23/2013 12:46:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [REP].[SubcapitatedServices]
    @contractStatus INT,
    @provider NVARCHAR(MAX) 
AS 
 
 /*------------------------------------------------------------------------------
	Title:		Subcapitated Services Report
	File:		[REP].[SubcapitatedServices]
	Author:		Divya Lakshmi
	Date:		7/19/2013
	Desc:		Displays Subcapitated Services			
                                        
	Called By:
                        Reports:          CLM021 - SubcapitatedServices.rdl
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		7/19/2013		Divya Lakshmi    		6528			Created

--	-----------------------------------------------------------------------------------*/


--DECLARE @contractStatus INT, @provider NVARCHAR(MAX) 
--set  @contractStatus =0
--set  @provider =-2



IF @contractStatus = 1 
            BEGIN
            SELECT  distinct
                    p1.ProviderNK AS MainProviderID,
                    p1.ProviderName AS MainProvider,
                    p.ProviderNK AS ContractProviderID,
                    p.ProviderName AS ContractProvider,
                    dpc.ProviderContractNK,
                    ins.Insurer,
                    s.ServicesNK,
                    s.ServiceCode,
                    s.ServiceDescriptionShort,
                    eff.DateValue As EffectiveDate,
                    ex.DateValue As ExpiredDate

FROM DW.factProviderContract fpc

	INNER JOIN DW.dimProviderContract dpc with(nolock) ON dpc.ProviderContractSK = fpc.ProviderContractSK  
	INNER JOIN DW.dimProvider p on fpc.ProviderSK = p.ProviderSK 
	INNER JOIN dw.dimProvider p1 on p.ParentProviderNK = p1.ProviderNK	
	INNER JOIN DW.dimServices s with(nolock)ON fpc.ServicesSK = s.ServicesSK 
	INNER JOIN DW.dimDate eff with(nolock)ON eff.DateSK = fpc.ContractEffectiveBeginDateSK   
	INNER JOIN DW.dimDate ex with(nolock)ON ex.DateSK = fpc.ContractExpirationBeginDateSK
	INNER JOIN DWV.diminsurers ins with(nolock) ON ins.InsurerSK = fpc.InsurerSK  

WHERE 
          ex.DateValue > GETDATE()
          AND fpc.DeletedContractFlag = 0
          AND fpc.SubCapitatedFlag = 1
          AND (
			  (p1.ProviderNK=@provider) OR 
			  ( @provider= -2 )
			  )
END 


ELSE 
BEGIN

            SELECT  distinct
                    p1.ProviderNK AS MainProviderID,
                    p1.ProviderName AS MainProvider,
                    p.ProviderNK AS ContractProviderID,
                    p.ProviderName AS ContractProvider,
                    dpc.ProviderContractNK,
                    ins.Insurer,
                    s.ServicesNK,
                    s.ServiceCode,
                    s.ServiceDescriptionShort,
                    eff.DateValue As EffectiveDate,
                    ex.DateValue As ExpiredDate
                    

FROM DW.factProviderContract fpc

	INNER JOIN DW.dimProviderContract dpc with(nolock) ON dpc.ProviderContractSK = fpc.ProviderContractSK  
	INNER JOIN DW.dimProvider p on fpc.ProviderSK = p.ProviderSK 
	INNER JOIN dw.dimProvider p1 on p.ParentProviderNK = p1.ProviderNK	
	INNER JOIN DW.dimServices s with(nolock)ON fpc.ServicesSK = s.ServicesSK 
	INNER JOIN DW.dimDate eff with(nolock)ON eff.DateSK = fpc.ContractEffectiveBeginDateSK   
	INNER JOIN DW.dimDate ex with(nolock)ON ex.DateSK = fpc.ContractExpirationBeginDateSK
	INNER JOIN DWV.diminsurers ins with(nolock) ON ins.InsurerSK = fpc.InsurerSK  
	
WHERE  
         ex.DateValue < GETDATE()
         AND fpc.DeletedContractFlag = 0
         AND fpc.SubCapitatedFlag = 1
         AND (
			 (p1.ProviderNK=@provider) OR 
			 ( @provider= -2 )
			 )
			 order by p.ProviderNK
END 



GO


