USE [BIW]
GO
/****** Object:  StoredProcedure [Rep].[ConsumerMedicaidandUninsuredPopulationByCounty]    Script Date: 05/06/2013 16:28:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create procedure [Rep].[ClaimsReceivedbutnotprocessed]
@recd_str_dt datetime,
@recd_end_dt datetime
as
/*------------------------------------------------------------------------------
	Title:		Claims Received by Not Processed
	File:		ClaimsReceivedbutnotprocessed
	Author:		Karen Roslund
	Date:		05/06/2013
	Desc:		This report shows claims that are not processed
                                        
	Called By:
                        Reports:          Claims Received but not processed
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/06/2013		Karen Roslund 			6315			Created

	-----------------------------------------------------------------------------------*/
	
	select 
fc.ClaimDetailNumber,
fc.ReceivedDateSK,
recddt.[DateName_en-US] as recd_date,
fc.AdjudicationDateSK,
fc.ClaimAdjudicationNumber,
fc.ClaimNumber, 
fc.StatusSK,
fc.DateOfServiceSK,
dos.[DateName_en-US] as dos,
fc.CreateDateSK,
creatdt.[DateName_en-US] create_dt,
fcc.ClaimCheckDateSK,
 datefactclaimcheck.[DateName_en-US] check_date, 
p.ProviderName,
c.ConsumerNK,
fc.AdjudicatedAmount  

 
From dw.factClaims fc with (nolock)
inner join dw.dimDate Recddt with (nolock) on fc.ReceivedDateSK = Recddt.DateSK 
inner join DW.dimDate dos with (nolock) on fc.DateOfServiceSK = dos.DateSK 
inner join dw.dimDate creatdt with (nolock) on fc.CreateDateSK = creatdt.DateSK 
left outer  join dw.dimProvider p with (nolock) on fc.ProviderSK = p.ProviderSK 
inner join dw.dimConsumers c with (nolock) on fc.ConsumerSK = c.ConsumerSK
left outer join dw.factClaimCheck  fcc with (nolock) on fc.ClaimCheckSK = fcc.ClaimCheckSK and fcc.VoidedCheckSK = 6
left outer join dw.dimDate datefactclaimcheck with (nolock) on fcc.ClaimCheckDateSK = datefactclaimcheck.DateSK 
where 
Recddt.DateValue   between @recd_str_dt  and @recd_end_dt  
and fc.Deleted = 0
and fc.StatusSK =-1
order by p.ProviderName