USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListAreaCatchments] AS

/*------------------------------------------------------------------------------
	Title:		List Area Catchments
	File:		[Rep].[ListAreaCatchments]
	Author:		Doug Cox
	Date:		07/19/13
	Desc:		This listing of Area Catchments can be used to fill the 
					available values for Area Catchments Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/19/2013		Doug Cox				8947			Created
					07/22/2013      Umberto Sartori			8947			Changed JunkSK reference to JunkNK
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
	-- ( @Catchment = -2 OR fCareCoordAdmin.CatchmentSK = @Catchment )
		
-----------------------------------------------------------------------------------*/

SELECT	dJunk.JunkNK ,
		dJunk.JunkValue
FROM	DW.dimJunk AS dJunk with(nolock) 
WHERE	dJunk.JunkEntity = 'AreaCatchments'
UNION	
SELECT	'-2' AS JunkNK ,
		'All' AS JunkValue


GO
