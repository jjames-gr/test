USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [REP].[ActiveClinicianswithExpiringLicense] 
	@Lin_expire_st_dt datetime,
	@lin_expire_end_dt datetime,
	@cred_expire_st_dt datetime ,
	@cred_expire_end_dt datetime
AS
/*------------------------------------------------------------------------------
	Title:		Active Clinician with Expiring License
	File:		REP.[ActiveClinicianswithExpiringLicense]
	Author:		Karen Roslund
	Date:		7/26/2013
	Desc:		This report allows the staff to see which clinicians have a license that is going to expire within the seleted date range.			
                                        
	Called By:
                        Reports:          Coming Soon....
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		7/25/2013		Karen Roslund    			6267			Created

--	-----------------------------------------------------------------------------------*/





--Declare @Lin_expire_st_dt datetime = '1/1/2012',
--@lin_expire_end_dt datetime ='12/31/2012',
--@cred_expire_st_dt datetime ,
--@cred_expire_end_dt datetime 



select 
dc.ClinicianNK as Clinician_ID,
dc.FirstName as Clinician_First_Name,
dc.MiddleName as Clinician_Middle_Name,
dc.LastName as Clinician_Last_Name,
dc.Phone as Clinician_Phone,
dc.ClinicianEmail as Clinician_Email,
dc.NPI as NPI_ID,
dl.Licensecode as License,
fcl.LicenseNumber as License_No, 
dlic_exp.[DateName_en-US]  Expire_Date,
dcred_iss.[DateName_en-US] Credential_Date,
dcred_exp.[DateName_en-US] Credential_Expire






From
dw.dimclinician dc
Inner join dw.dimclinician dc1 with (nolock) on dc.ClinicianNK = dc1.ClinicianNK 
--inner join dw.dimServices ds2 with (nolock) on ds.ServicesNK = ds2.ServicesNK 
 left outer Join dw.factClinicianLicense fcl with (nolock) on dc1.ClinicianSK = fcl.ClinicianSK
Inner Join dw.dimClinician dc2 with (nolock) on dc.ClinicianNK   = dc2.ClinicianNK  
left outer join dw.factClinicianCredentials fcc with (nolock) on dc2.ClinicianSK = fcc.ClinicianSK 
left outer Join dw.dimLicense  dl with (nolock) on fcl.LicenseSK = dl.LicenseSK 
Inner join dw.dimDate dlic_str with (nolock) on fcl.LicenseIssueDateSK = dlic_str.DateSK 
Inner Join dw.dimDate dlic_exp with (nolock) on fcl.LicenseExpireDateSK = dlic_exp.DateSK 
Inner Join dw.dimDate dcred_iss with (nolock) on fcc.CredentialIssueDateSK = dcred_iss.DateSK 
Inner Join dw.dimDate dcred_exp with (nolock) on fcc.CredentialExpireDateSK = dcred_exp.DateSK 

Where 
   dc.Active = 1
   and dc.ETLCurrentRow =1 
   and ((dlic_exp.DateValue  between @Lin_expire_st_dt and @lin_expire_end_dt )
         or (dcred_exp.DateValue between @cred_expire_st_dt and @cred_expire_end_dt) )
         
Order by Clinician_ID  
   