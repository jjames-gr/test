USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[UtilDataByBenefitSrvcLevelAndSrvcDesc]    Script Date: 06/06/2013 09:23:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [Rep].[UtilDataByBenefitSrvcLevelAndSrvcDesc]
	@StartDate DATETIME
	, @EndDate DATETIME
	, @DiagCategory NVARCHAR(MAX)
	, @BenPlan INT
	, @Age NVARCHAR(MAX)
	, @CapFlag NVARCHAR(MAX)
AS

/*------------------------------------------------------------------------------
	Title:		Util Data by Benefit Srvc Level and Srvc Desc
	File:		[Rep].[UtilDataByBenefitSrvcLevelAndSrvcDesc]
	Author:		Tim Amerson
	Date:		05/29/2013
	Desc:		Distinct count of client utilization by Benefit Service Level 
				(Basic, Basic Augmented, Enhanced) and by service description / service code.
                                        
	Called By:
                        Reports:          MGM001 - Util Data by Benefit Srvc Level and Srvc Desc
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/29/2013		Tim Amerson     		6544			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2013',
--	@EndDate DATETIME = '1/31/2013',
--	@DiagCategory NVARCHAR(MAX) = '1,2,3,4,-1,-2',
--	@BenPlan INT = -200,
--	@Age NVARCHAR(MAX) = '1,2,-1',
--	@CapFlag NVARCHAR(MAX) = '10,11'
	
	
SELECT
	gs.JunkValue AS GroupedService
	, ds.ServiceSummary
	, ds.ServiceDescriptionShort
	, fc.ConsumerSK AS ClientCount
	, fc.UnitsBilled AS Units
	, fc.adjudicatedAmount AS AdjAmt
	, dd.DiagnosisCode
	, bp.BenefitPlan
	, da.StateGroup
	, cap.JunkValue AS CapitatedValue
FROM
	dw.factClaims fc WITH(NOLOCK)
	INNER JOIN dw.dimDate dos WITH(NOLOCK) ON fc.DateOfServiceSK = dos.DateSK
	INNER JOIN dw.dimServices ds WITH(NOLOCK) ON fc.ServicesSK = ds.ServicesSK
	INNER JOIN dw.dimJunk gs WITH(NOLOCK) ON fc.GroupedServicesSK = gs.JunkSK
	INNER JOIN dw.dimDiagnosis dd WITH(NOLOCK) ON fc.Diagnosis1SK = dd.DiagnosisSK
	INNER JOIN dw.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK = bp.BenefitPlanSK
	INNER JOIN dw.dimAge da WITH(NOLOCK) ON fc.AgeSK = da.AgeSK
	INNER JOIN dw.dimJunk cap WITH(NOLOCK) ON fc.CapitatedSK = cap.JunkSK
	INNER JOIN dbo.cfn_split(@Age , ',') fnAge ON fnAge.element = da.StateGroupID
	INNER JOIN dbo.cfn_split(@DiagCategory , ',') fnDiag ON fnDiag.element = dd.DiagnosisGroupID
	INNER JOIN dbo.cfn_split(@CapFlag , ',') fnCap ON fnCap.element = fc.CapitatedSK
	
WHERE
	dos.DateValue BETWEEN @StartDate AND @EndDate
	AND
	(
		( @BenPlan = bp.BenefitPlanNK ) OR -- 1 specific Plan
		( @BenPlan = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
		( @BenPlan = -200 ) -- ALL PLANS
	)
	

GO


