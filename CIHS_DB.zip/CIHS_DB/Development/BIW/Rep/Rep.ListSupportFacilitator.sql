USE [BIW]
GO
/****** Object:  StoredProcedure [Rep].[ListAreaCatchments]    Script Date: 07/22/2013 10:56:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListSupportFacilitator] AS

/*------------------------------------------------------------------------------
	Title:		List Area Catchments Multi Select
	File:		[Rep].[ListSupportFacilitator] 
	Author:		Kevin Hamilton
	Date:		07/19/13
	Desc:		This listing of Support Facilitator can be used to fill the 
					available values for Support Facilitaor Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/19/2013		Kevin Hamilton			8951			Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
	Single Select
	-- e.EmployeeNK = @SupportFacilitator 
	Optional Parameter
	--(Case when (e.EmployeeNK = @SupportFacilitator) THEN 1
				    when (@SupportFacilitator IS NULL OR @SupportFacilitator = '') THEN 1
				 end)=1
		
-----------------------------------------------------------------------------------*/
SELECT  null as EmployeeNK, ' ' as CCName
UNION ALL
SELECT DISTINCT 	
	dEmp.EmployeeNK as CCID,
	dEmp.LastName  +', '+ dEmp.FirstName AS CCName
FROM 
	DW.factCareCoordAdmissions fcc
	INNER JOIN DW.dimEmployee dEmp with(nolock) ON  dEmp.EmployeeSK = fcc.SupportFacilitorSK  
WHERE	--dEmp.Active  = 1
	EmployeeNK <> -1
 ORDER BY CCName 