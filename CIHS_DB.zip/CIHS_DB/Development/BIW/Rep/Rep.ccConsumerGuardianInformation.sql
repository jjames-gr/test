USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ccConsumerGuardianInformation]    Script Date: 09/26/2013 08:48:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [REP].[ccConsumerGuardianInformation]
@disch_str_dt datetime ,
@disch_end_dt datetime,
@Catchment varchar(max),
@Age int ,
@Benefit_Plan varchar(max),
@Consumer_Status int

AS

/*-------------------------------------------------------------------------------------------
-- Title:  Consumer Guardian Information
-- File:   ccConsumerGuardianInformation
-- Author: Divya Lakshmi
-- Date:   7/25/2013
-- Desc:   Used to identify legal guardians of consumers 
--                                          
Called By:
                        Reports:         CCO005 - ConsumerGuardianInformation
                        Stored Procs:     None
---------------------------------------------------------------------------------------------
-- Change Hisory
-- Ver                   Date                  Author              TixNo         Description
-- ---                 --------            ---------------         -----        --------------
-- 1.0                 07/25/2013            Divya Lakshmi          6320         Creation
-----------------------------------------------------------------------------------------------
*/
--declare 
--@disch_str_dt datetime = '1/1/2012',
--@disch_end_dt datetime = '1/31/2012',
--@Catchment varchar(max) = '1039',
--@Age int = -1,
--@Benefit_Plan varchar(max) = '1',
--@Consumer_Id int=19045,--187854--19330--19045
--@Consumer_Status int=2  -- 1 - Discharge  2- Admission


            
            
SELECT DISTINCT C.ConsumerNK, DateSK, BenefitPlanNK
 INTO #temp
     FROM dw.factEligibility e WITH(NOLOCK) 
            INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON e.ConsumerSK = c.ConsumerSK
            INNER JOIN dw.dimJunk j WITH(NOLOCK) ON e.ActionSK = j.JunkSK
            INNER JOIN DW.dimBenefitPlan dbp WITH(NOLOCK) ON e.BenefitPlanSK = dbp.BenefitPlanSK 
            INNER JOIN cfn_split(@Benefit_Plan,',') fnben  ON  dbp.BenefitPlanNK = fnben.element 
      WHERE j.JunkValue IN ('Effective','Active')
      

 CREATE CLUSTERED INDEX idx_date ON #temp (datesk);

SELECT DISTINCT
c1.ConsumerNK AS ConsumerID,
c1.LastName +' '+ c1.FirstName AS ConsumerName,
isnull(c1.AddressLine1,'') +' '+ isnull(c1.AddressLine2,'') AS ConsumerAddress,
c1.City,
c1.State,
c1.PostalCode,
c1.Language,
--c.Phone,
max(dAdd.DateValue)  AS CareCoordAdmissionsDate,
CASE WHEN a.AgeValue >= '18' THEN 'Adult'
	ELSE 'Child'
END as Age,
--CASE WHEN fcc.ActiveAdmissionFlag = '1' THEN 'Yes'
--	ELSE 'No'
--END as ActiveAdmissionFlag,
dcare.JunkValue CareDisability,
c1.AuthRepFirstName +' '+ c1.AuthRepLastName AS LRPName,
isnull(c1.AuthRepAddressLine1,'')+' '+ isnull(c1.AuthRepAddressLine2,'') AS LRPAddress,
c1.AuthRepCity,
c1.AuthRepState,
c1.AuthRepPostalCode,
CASE
	WHEN dcarecod.FullName like '%Unknown%' 
	THEN  ''
	ELSE dcarecod.FullName
END as CareCordinator,
CASE 
	WHEN dsup.FullName like '%Unknown%'
	THEN ''
	ELSE dsup.FullName
END as SupportFacilitor

FROM 
BIW.DW.factCareCoordAdmissions fcc WITH(NOLOCK) 
INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fcc.ConsumerSK = c.ConsumerSK 
INNER JOIN DW.dimConsumers c1 WITH(NOLOCK) ON c.ConsumerNK = c1.ConsumerNK and c1.ETLCurrentRow=1
INNER JOIN DW.dimDate dAdd WITH(NOLOCK) ON dAdd.DateSK = fcc.CareCoordAdmissionsDateSK
INNER JOIN DW.dimDate dDis WITH(NOLOCK) ON dDis.DateSK = fcc.CareCoordDischargeDateSK
INNER JOIN DW.dimAge a WITH(NOLOCK)  ON a.AgeValue = c1.AgeValue 
INNER JOIN #temp tmp ON --convert(int, LEFT(CareCoordAdmissionsDateSK,6) + '01') = tmp.DateSK and
 tmp.ConsumerNK=c.ConsumerNK
INNER JOIN DW.dimJunk dCatch WITH(NOLOCK) ON fcc.CatchmentSK = dCatch.junksk AND dCatch.JunkEntity = 'AreaCatchments'
INNER JOIN cfn_split(@Catchment,',') fnCatch ON dCatch.JunkNK = fnCatch.element
INNER JOIN DW.dimCustomReportGroups AS AgeGroups WITH(NOLOCK) ON CustomGroupName = 'ConsumerGuardianAgeGroup'
										AND a.AgeSK BETWEEN cast(AgeGroups.BeganAttributeCodeRange as int) AND cast(AgeGroups.EndAttributeCodeRange as int)
INNER JOIN DW.dimJunk dcare WITH(NOLOCK) ON fcc.CareDisabilityGroupSK = dcare.JunkSK 
INNER JOIN DW.dimEmployee dcarecod WITH(NOLOCK) ON fcc.CareCoordinatorSK = dcarecod.EmployeeSK 
INNER JOIN DW.dimEmployee dsup WITH(NOLOCK) ON fcc.SupportFacilitorSK = dsup.EmployeeSK
WHERE 

	(
		 (@age = 1 AND AgeGroups.CustomGroupValue = 'Child')
		OR (@age = 2 AND AgeGroups.CustomGroupValue = 'Adult')
		OR (@age = -1)
	)
AND ((@Consumer_Status = 1 AND dDis.DateValue BETWEEN @disch_str_dt AND @disch_end_dt )
 OR  (@Consumer_Status = 2 AND fcc.CareCoordDischargeDateSK=-1 AND ActiveAdmissionFlag=1))--AND dAdd.DateValue BETWEEN @disch_str_dt AND @disch_end_dt )  )

group by

c1.ConsumerNK,
c1.LastName +' '+ c1.FirstName,
isnull(c1.AddressLine1,'') +' '+ isnull(c1.AddressLine2,''),
c1.City,
c1.State,
c1.PostalCode,
c1.Language,
a.AgeValue,
dcare.JunkValue,
c1.AuthRepFirstName +' '+ c1.AuthRepLastName ,
isnull(c1.AuthRepAddressLine1,'')+' '+ isnull(c1.AuthRepAddressLine2,''),
c1.AuthRepCity,
c1.AuthRepState,
c1.AuthRepPostalCode,
dcarecod.FullName,
dsup.FullName


DROP table #temp
















GO


