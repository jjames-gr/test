USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ListCareManagerMulti]    Script Date: 09/06/2013 16:07:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListCareManagerMulti] AS

/*------------------------------------------------------------------------------
	Title:		List Care Manager Multi
	File:		[Rep].[ListCareManagerMulti] 
	Author:		Divya Lakshmi
	Date:		09/6/2013
	Desc:		This listing of Care Managers can be used to fill the 
					available values for Care Manager Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/6/2013		Divya Lakshmi			6533       		Created
	Usage directions:
	-- Add the following to your FROM CLAUSE:
		INNER JOIN cfn_split(@CareManager,',') fncare  ON  dEmp.EmployeeNK = fncare.element 

-------------------------------------------------------------------------------------*/

SELECT  -1 AS EmpID,
		150 AS ccOrder,
		'Unknown' AS ccName
UNION
SELECT	DISTINCT 	
		dEmp.EmployeeNK AS EmpID,
		200 AS ccOrder,
		dEmp.LastName + ', ' +  dEmp.FirstName AS ccName
FROM	DW.factTreatmentAuthorizationRequest AS fTAR with(nolock) 
		INNER JOIN DW.dimEmployee AS dEmp with(nolock) ON  dEmp.EmployeeSK = fTAR.TARAssigneeSK
ORDER BY ccOrder, ccName
GO


