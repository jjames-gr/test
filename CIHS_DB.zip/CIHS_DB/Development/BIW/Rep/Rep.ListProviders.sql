USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListProviders]
AS

/*------------------------------------------------------------------------------
	Title:		List Providers
	File:		[Rep].[ListProviders]
	Author:		Divya Lakshmi
	Date:		02/25/13
	Desc:		This listing of Providers  can be used to fill the available 
					values for the Provider Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/19/2013		Divya Lakshmi   						Created
			1.1		05/15/2013		Brian Angelo							Added column to set All Providers on top of list
			1.2		05/23/2013		Doug Cox								Added ProviderSK and notes for multi-select use
			1.3		07/08/2013		Doug Cox								Removed ProviderSK
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
				(p.ProviderNK=@prov_Id) OR 
			( @prov_Id= -2 )
		)

	-- OR FOR Multi-select:
		1. Filter in your Parameter to eliminate ProviderNK = -2 
		2. Add the following to your FROM Clause:
			
			INNER JOIN dbo.cfn_split(@ProviderID , ',') AS prov ON prov.element = dp.ProviderNK
		
	-----------------------------------------------------------------------------------*/

	/* Get Listing of available Providers */
	SELECT dp.ProviderNK,
		dp.ProviderName,
		2 as ProviderOrder 
	FROM DW.dimProvider as dp with(nolock)
	WHERE dp.ProviderNK <> 1
		and dp.ProviderNK=dp.ParentProviderNK
		and Active=1
	UNION
	SELECT -2 AS ProviderNK ,
		'All Providers',
		1 as ProviderOrder 

	ORDER BY ProviderOrder, dp.ProviderName 
	






GO


