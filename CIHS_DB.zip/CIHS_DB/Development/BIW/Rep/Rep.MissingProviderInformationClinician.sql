USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[MissingProviderInformationClinician] 
AS

/*------------------------------------------------------------------------------
	Title:		Missing Provider Information (Clinician)
	File:		[REP].[MissingProviderInformationClinician] 
	Author:		Karissa Martindale
	Date:		07/26/13
	Desc:		Report will flag/show identified scopes of missing information:    (i.e., lapsed licensure,
				no licensure date, no licensure demographics, no credentialing date, no re-credentialing date,   No DEA, etc.)
                                        
	Called By:
                        Reports:          UMA014 - MissingProviderInformation
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/22/2013		Karissa Martindale   	8736			Creation
-----------------------------------------------------------------------------------*/


SELECT DISTINCT	
	dClin.FirstName + ' ' +	dClin.MiddleName + ' ' + dClin.LastName as FullName,
	MAX(CASE 
		WHEN CAST(CAST(dClin.DOB AS DATE) AS varchar) = '' THEN 'Missing Info'
		ELSE ISNULL(NULLIF(CAST(CAST(dClin.DOB as Date) as varchar), '1900-01-01'), 'Missing Info')
	END) as DOB,
	MAX(CASE
		WHEN dClin.AddressLine1 = '' THEN 'Missing Info'
		WHEN dClin.AddressLine1 = '-' THEN 'Missing Info'
		ELSE ISNULL(dClin.AddressLine1, 'Missing Info') 
	END) as AddressLine1,
	MAX(CASE 
		WHEN dClin.City = '' THEN 'Missing Info'
		WHEN dClin.City = '-' THEN 'Missing Info'
		ELSE ISNULL(dClin.City, 'Missing Info') 
	END) as City,
	MAX(CASE
		WHEN dClin.State = '' THEN 'Missing Info'
		WHEN dClin.State = '-' THEN 'Missing Info'
		ELSE ISNULL(dClin.State, 'Missing Info') 
	END) as State,
	MAX(CASE 
		WHEN dClin.PostalCode = '' THEN 'Missing Info'
		WHEN dClin.PostalCode = '-' THEN 'Missing Info'
		ELSE ISNULL(dClin.PostalCode, 'Missing Info')
	END) as PostalCode,
	MAX(CASE
		WHEN dClin.County = '' THEN 'Missing Info'
		WHEN dClin.County = '-' THEN 'Missing Info'
		ELSE ISNULL(dClin.County, 'Missing Info')
	END) as County,
	MAX(CASE
		WHEN dClin.SSN = '' THEN 'Missing Info'
		ELSE ISNULL(dClin.SSN, 'Missing Info')
	END) as SSN,
	MAX(CASE 
		WHEN dClin.ClinicianEmail = '' THEN 'Missing Info'
		ELSE ISNULL(dClin.ClinicianEmail, 'Missing Info')
	END) as ClinicianEmail,
	MAX(CASE 
		WHEN dClin.NPI = '' THEN 'Missing Info'
		ELSE ISNULL(dClin.NPI, 'Missing Info')
	END) as NPI,
	MAX(CASE 
		WHEN dClin.Phone = '' THEN 'Missing Info'
		ELSE ISNULL(dClin.Phone, 'Missing Info')
	END) as Phone,
	CASE 
		WHEN dDateCredIssue.DateValue = '' THEN 'Missing Info'
		ELSE ISNULL(NULLIF(CAST(dDateCredIssue.DateValue as varchar), '1900-01-01'), 'Missing Info')
	END as CredentialIssueDate,
	CASE
		WHEN dDateCredExp.DateValue = '' THEN 'Missing Info'
		ELSE ISNULL(NULLIF(CAST(dDateCredExp.DateValue as varchar), '2999-12-31'), 'Missing Info')
	END as CredentialExpireDate,
	CASE
		WHEN fClinLic.LicenseNumber = '' THEN 'Missing Info'
		ELSE ISNULL(fClinLic.LicenseNumber, 'Missing Info')
	END as LicenseNumber,
	CASE
		WHEN dDateLicIssue.DateValue = '' THEN 'Missing Info'
		ELSE ISNULL(NULLIF(CAST(dDateLicIssue.DateValue as varchar), '1900-01-01'), 'Missing Info')
	END as LicenseIssueDate,
	CASE
		WHEN dDateLicExp.DateValue = '' THEN 'Missing Info'
		ELSE ISNULL(NULLIF(CAST(dDateLicExp.DateValue as varchar), '2999-12-31'), 'Missing Info')
	END as LicenseExpDate
INTO #tempFinal
FROM
	BIW.DW.dimClinician dClin WITH(NOLOCK)
	LEFT JOIN dw.factClinicianCredentials fClinCre WITH(NOLOCK) ON fClinCre.ClinicianSK = dClin.ClinicianSK
	INNER JOIN BIW.DW.dimClinician dJoinClin WITH(NOLOCK) ON dClin.ClinicianNK = dJoinClin.ClinicianNK
	LEFT JOIN dw.factClinicianLicense fClinLic WITH(NOLOCK) ON dJoinClin.ClinicianSK = fClinLic.ClinicianSK
	LEFT JOIN dw.dimLicense dLicense WITH(NOLOCK) ON fClinLic.LicenseSK = dLicense.LicenseSK
	LEFT JOIN dw.dimDate dDateCredExp WITH(NOLOCK) ON fClinCre.CredentialExpireDateSK = dDateCredExp.DateSK
	LEFT JOIN dw.dimDate dDateCredIssue WITH(NOLOCK) ON fClinCre.CredentialIssueDateSK = dDateCredIssue.DateSK
	LEFT JOIN dw.dimDate dDateLicExp WITH(NOLOCK) ON fClinLic.LicenseExpireDateSK = dDateLicExp.DateSK
	LEFT JOIN dw.dimDate dDateLicIssue WITH(NOLOCK) ON fClinLic.LicenseIssueDateSK = dDateLicIssue.DateSK
WHERE
	dClin.Active = 1 and dClin.ETLCurrentRow = 1
GROUP BY
	dClin.FirstName,
	dClin.MiddleName,
	dClin.LastName,
	fClinLic.LicenseNumber,
	dDateCredIssue.DateValue,
	dDateCredExp.DateValue,
	dDateLicIssue.DateValue,
	dDateLicExp.DateValue
order by fullName, LicenseNumber

SELECT DISTINCT * 
FROM #tempFinal
WHERE
	DOB = 'Missing Info' OR
	AddressLine1 = 'Missing Info' OR
	City = 'Missing Info' OR
	State = 'Missing Info' OR
	PostalCode = 'Missing Info' OR
	County = 'Missing Info' OR
	SSN = 'Missing Info' OR
	ClinicianEmail = 'Missing Info' OR
	NPI = 'Missing Info' OR
	Phone = 'Missing Info' OR
	CredentialIssueDate = 'Missing Info' OR
	CredentialExpireDate = 'Missing Info' OR
	LicenseNumber = 'Missing Info' OR
	LicenseIssueDate = 'Missing Info' OR
	LicenseExpDate = 'Missing Info'

DROP TABLE #tempFinal
