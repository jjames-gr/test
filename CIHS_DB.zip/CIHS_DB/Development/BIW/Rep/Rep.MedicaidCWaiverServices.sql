USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[MedicaidCWaiverServices]    Script Date: 09/24/2013 13:48:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [REP].[MedicaidCWaiverServices]
	@StartDate datetime,
	@EndDate datetime,
	@Catchment int,
	@BenefitPlan int
AS
/*------------------------------------------------------------------------------
-- Title:	Medicaid C Waiver Services
-- File:	[Rep].[MedicaidCWaiverServices]
-- Author:	Brian Angelo
-- Date:	08/6/2013
-- Desc:	Medicaid C Waiver Services proc
--			
-- CalledBy:
-- 		Reports: "Medicaid C Waiver Services"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/6/2013  	Brian Angelo		6432	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
    /*
	/** Test Parameters **/
	DECLARE @StartDate datetime,
			@EndDate datetime,
			@Catchment int,
			@BenefitPlan int
			
	SET @StartDate  = '3/1/13'
	SET @EndDate = '3/31/13'
	SET @Catchment = -2
	SET @BenefitPlan = -200
	--*/

	IF OBJECT_ID('tempdb..#tempEligibleConsumers') IS NOT NULL
			DROP TABLE #tempEligibleConsumers

	SELECT DISTINCT
	ConsumerNK 
	INTO #tempEligibleConsumers
	FROM
	[BIW].[DW].[dimConsumers] dcFE WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[factEligibility] fe WITH(NOLOCK) ON dcFE.ConsumerSK = fe.ConsumerSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] AS dbp WITH(NOLOCK) ON fe.BenefitPlanSK = dbp.BenefitPlanSK
	WHERE dbp.BenefitPlanNK = 4 --Medicaid C consumers only

	CREATE CLUSTERED INDEX idx_tmpConsumer ON #tempEligibleConsumers (ConsumerNK);

	IF OBJECT_ID('tempdb..#tempAllResults') IS NOT NULL
			DROP TABLE #tempAllResults

	;WITH cteServiceCodes as (
		SELECT DISTINCT Comments, BeganAttributeCodeRange 
		FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
		WHERE CustomGroupName = 'CWaiverClientServiceCodes'
	)
			
	SELECT
	CASE WHEN csc.Comments = 'Unknown' THEN 'Inpatient' ELSE csc.Comments END as ServiceDefinition
	,ds.ServiceDescription
	,ds.ServiceCode+Isnull(ds.Modifier1, '') as ServiceCode
	,catchment.Catchment
	,dbp.BenefitPlanShort
	,dc.ConsumerNK
	,SUM(fc.UnitsClaimed) as Units
	,SUM(fc.AdjudicatedAmount) as TotalCost
	INTO #tempAllResults
	FROM [BIW].[DW].[factClaims] fc WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimJunk] dj WITH(NOLOCK) ON dj.JunkSK = fc.StatusSK AND dj.JunkEntity = 'ClaimAdjudicatedStatus'
	INNER JOIN [BIW].[DW].[dimBenefitPlan] AS dbp WITH(NOLOCK) ON fc.BenefitPlanSK = dbp.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
	INNER JOIN [BIW].[DW].[dimOrganization] catchment WITH(NOLOCK) ON catchment.OrganizationSK = fc.OrganizationSK
	INNER JOIN [BIW].[DW].[dimDate] ddDOS WITH(NOLOCK) ON ddDOS.DateSK = fc.DateOfServiceSK
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fc.ConsumerSK
	INNER JOIN #tempEligibleConsumers tec ON tec.ConsumerNK = dc.ConsumerNK
	INNER JOIN cteServiceCodes csc ON csc.BeganAttributeCodeRange = ds.ServiceCode
	WHERE 
	dj.JunkNK = 1 --Approved claims only 
	AND (( @BenefitPlan = dbp.BenefitPlanNK ) OR -- Specific Plan
		( @BenefitPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
		( @BenefitPlan = -200 )) -- ALL PLANS
	AND ddDOS.DateValue BETWEEN @StartDate AND @EndDate
	AND (catchment.CatchmentID = @Catchment OR @Catchment = -2)
	GROUP BY
	csc.Comments
	,ds.ServiceDescription
	,ds.ServiceCode+Isnull(ds.Modifier1, '')
	,catchment.Catchment
	,dbp.BenefitPlanShort
	,dc.ConsumerNK



	--Count of distinct consumers grouped by service, catchment, insurance
	;WITH cteServiceCatchmentInsuranceCount as 
	(
	SELECT
	Catchment
	,BenefitPlanShort
	,ServiceDefinition
	,ServiceCode
	,COUNT(distinct ConsumerNK) as countDistinctServiceCatchmentInsurance
	FROM
	#tempAllResults
	GROUP BY 
	Catchment
	,BenefitPlanShort
	,ServiceDefinition
	,ServiceCode
	)
	
	--Count of distinct consumers grouped by service, insurance
	,cteServiceInsuranceCount as 
	(
	SELECT
	BenefitPlanShort
	,ServiceDefinition
	,COUNT(distinct ConsumerNK) as countDistinctServiceInsurance
	FROM
	#tempAllResults
	GROUP BY 
	BenefitPlanShort
	,ServiceDefinition
	)

	--Count of distinct consumers grouped by catchment, insurance
	,cteCatchmentInsuranceCount as
	(
	SELECT 
	Catchment
	,BenefitPlanShort
	,COUNT(distinct ConsumerNK) as countDistinctCatchmentInsurance
	FROM
	#tempAllResults
	GROUP BY 
	Catchment
	,BenefitPlanShort
	)

	--Count of distinct consumers grouped by insurance
	,cteInsuranceCount as
	(
	SELECT 
	BenefitPlanShort
	,COUNT(distinct ConsumerNK) as countDistinctInsurance
	FROM
	#tempAllResults
	GROUP BY 
	BenefitPlanShort
	)

	--Count of distinct consumers grouped by catchment
	,cteCatchmentCount as
	(
	SELECT 
	Catchment
	,COUNT(distinct ConsumerNK) as countDistinctCatchment
	FROM
	#tempAllResults
	GROUP BY 
	Catchment
	)

	--Count of distinct consumers 
	,cteDistinctCount as
	(
	SELECT 
	COUNT(distinct ConsumerNK) as countDistinctConsumer
	FROM
	#tempAllResults
	)

	SELECT DISTINCT
	tar.ServiceDefinition
	,tar.ServiceDescription
	,tar.ServiceCode
	,tar.Catchment
	,tar.BenefitPlanShort
	,SUM(tar.Units) as Units
	,SUM(tar.TotalCost) as TotalCost
	,cscic.countDistinctServiceCatchmentInsurance
	,csic.countDistinctServiceInsurance
	,ccic.countDistinctCatchmentInsurance
	,cic.countDistinctInsurance
	,ccc.countDistinctCatchment
	,cdc.countDistinctConsumer
	FROM #tempAllResults tar
	INNER JOIN cteServiceCatchmentInsuranceCount cscic ON cscic.BenefitPlanShort = tar.BenefitPlanShort
													AND cscic.Catchment = tar.Catchment
													AND cscic.ServiceDefinition = tar.ServiceDefinition
													AND cscic.ServiceCode = tar.ServiceCode
	INNER JOIN cteServiceInsuranceCount csic ON csic.BenefitPlanShort = tar.BenefitPlanShort
													AND csic.ServiceDefinition = tar.ServiceDefinition
	INNER JOIN cteCatchmentInsuranceCount ccic ON ccic.BenefitPlanShort = tar.BenefitPlanShort
													AND ccic.Catchment = tar.Catchment
	INNER JOIN cteInsuranceCount cic ON cic.BenefitPlanShort = tar.BenefitPlanShort
	INNER JOIN cteCatchmentCount ccc ON ccc.Catchment = tar.Catchment
	INNER JOIN cteDistinctCount cdc ON 1=1
	GROUP BY 
	tar.ServiceDefinition
	,tar.ServiceDescription
	,tar.ServiceCode
	,tar.Catchment
	,tar.BenefitPlanShort
	,cscic.countDistinctServiceCatchmentInsurance
	,csic.countDistinctServiceInsurance
	,ccic.countDistinctCatchmentInsurance
	,cic.countDistinctInsurance
	,ccc.countDistinctCatchment
	,cdc.countDistinctConsumer

	DROP TABLE #tempEligibleConsumers
	DROP TABLE #tempAllResults
    
END










GO


