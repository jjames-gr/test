Use BIW 

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



create PROCEDURE [REP].[ListDiagnosisGroup]
AS

/*------------------------------------------------------------------------------
	Title:		[Rep].[ListDiagnosisGroup]
	File:		[Rep].[ListDiagnosisGroup]
	Author:		Karen Roslund
	Date:		07/19/2013
	Desc:		
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/19/2013		Karen Roslund				----			Drop Down for Diag Group Codes
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		INNER JOIN dbo.cfn_split(@DiagCategory , ',') fnDiag ON fnDiag.element = dd.DiagnosisGroupID
		

	-----------------------------------------------------------------------------------*/

SELECT DISTINCT 
	1 as DiagOrder,
	dd.DiagnosisGroupID
	, dd.DiagnosisGroup
FROM DW.dimDiagnosis as dd with(nolock)

union 
select 
2 as DiagOrder,
-300 as diagnosisGroupID,
'ALL' as DiagnosisGroup

ORDER BY Diagorder,dd.DiagnosisGroup


