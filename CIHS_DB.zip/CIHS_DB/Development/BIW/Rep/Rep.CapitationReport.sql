USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[CapitationReport]    Script Date: 08/27/2013 09:40:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[CapitationReport] 
(
	@catchment INT
)
AS
BEGIN
/*------------------------------------------------------------------------------
-- Title:	Capitation Report
-- File:	[Rep].[CapitationReport]
-- Author:	Umberto Sartori
-- Date:	07/18/2013
-- Desc:	Identify and report on State associated Capitated claims
--			
-- CalledBy:
-- 		Reports: Capitation Report
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	07/18/2013  Umberto Sartori		6192	initial creation
--------------------------------------------------------------------------------*/

--declare 
--	@catchment varchar(MAX) = '1021, 1022'


select prv.ProviderNK as ProviderID
	,prv.ProviderName
	,MAX(convert(date, ad.DateValue)) as LastServiceDate
	,SUM(isnull(clm.AdjudicatedAmount, 0)) as AdjudicatedAmount
	,org.CatchmentID as Catchment
	,org.Catchment as CatchmentName
from dw.factClaims clm (nolock) LEFT OUTER JOIN dw.dimProvider prv (nolock) on clm.ProviderSK = prv.ProviderSK
								LEFT OUTER JOIN dw.dimDate ad (nolock) on ad.DateSK = clm.DateOfServiceSK
								LEFT OUTER JOIN dw.dimOrganization org (nolock) on org.organizationSK = clm.OrganizationSK
		INNER JOIN cfn_split(@catchment,',') fnCatch on org.CatchmentID = fnCatch.element
where 1=1
	and clm.ClaimNumber <> 0
	and clm.StatusSK = 1
	and clm.BenefitPlanSK = 0
	--and clm.CapitatedSK = 11
	and clm.AdjudicatedAmount is not null
	and prv.ProviderNK <> -1
group by
prv.ProviderNK
,prv.ProviderName
,org.CatchmentID
,org.Catchment
order by
	prv.providerNK

End
