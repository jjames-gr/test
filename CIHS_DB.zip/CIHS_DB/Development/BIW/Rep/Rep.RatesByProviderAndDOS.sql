USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[RatesByProviderAndDOS]    Script Date: 08/20/2013 10:37:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [REP].[RatesByProviderAndDOS]
    @dos datetime,
    @provider int
AS 
 
 /*------------------------------------------------------------------------------
	Title:		Rates by Provider and DOS
	File:		[REP].[RatesByProviderAndDOS]
	Author:		Divya Lakshmi
	Date:		7/10/2013
	Desc:		Shows rates for a given provider on a specific date of service
	Called By:
                        Reports:          FIN016- RatesByProviderAndDos.rdl
                        Stored Procs:     [REP].[RatesByProviderAndDOS]
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		7/10/2013		Divya Lakshmi    		6505			Created

--	-----------------------------------------------------------------------------------*/


--DECLARE @dos datetime,@provider int
--set @dos ='1/1/2013'
--set @provider =23120




SELECT  distinct
@dos DOS
,CAST(eff.DateValue as varchar(100)) + '  -  ' + CAST (ex.DateValue as varchar(100)) AS EffectiveDates
,s.ServiceCode
,s.Modifier1
,s.Modifier2
,s.ServicesNK
,fpcr.ContractRate
,p.StatusName
,p.AvailableStatus
,i.Insurer
,p.ProviderNK
,p.ProviderName


 FROM DW.factProviderContractRates fpcr with(nolock)

	INNER JOIN DW.dimProviderContract dpc with(nolock) on dpc.ProviderContractSK = fpcr.ProviderContractSK   
	INNER JOIN DW.dimProvider p with(nolock) on fpcr.ProviderSK = p.ProviderSK 
	INNER JOIN dw.dimProvider p1 with(nolock) on p.ParentProviderNK = p1.ProviderNK	
	INNER JOIN DW.dimServices s with(nolock) on fpcr.ServicesSK = s.ServicesSK 
	INNER JOIN DW.dimProviderContract dpc1 with(nolock) on dpc.ProviderContractNK = dpc1.ProviderContractNK  
	INNER JOIN DW.factProviderContract fpc with(nolock) on fpc.ProviderContractSK= dpc1.ProviderContractSK
	INNER JOIN DWV.dimInsurers i with(nolock)on fpc.InsurerSK = i.InsurerSK 
	INNER JOIN DW.dimDate eff with(nolock)on eff.DateSK = fpcr.ContractRateEffectiveDateSK   
	INNER JOIN DW.dimDate ex with(nolock)on ex.DateSK = fpcr.ContractRateExpirationDateSK
	
	
WHERE  

    @dos BETWEEN eff.DateValue AND ex.DateValue
AND @dos BETWEEN dpc.ContractEffectiveDate AND dpc.ContractExpirationDate
--AND (@dos < dpc.ContractTerminationDate or dpc.ContractTerminationDate='1900-01-01 00:00:00.000')
AND @dos < ISNULL(dpc.ContractTerminationDate, '9999-12-31 00:00:00.000')

AND (
			(p1.ProviderNK=@provider) OR 
			( @provider= -2 ) 
			
		)


ORDER BY ProviderNK













GO


