USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ListDisabilityGroup]    Script Date: 07/22/2013 15:28:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [REP].[ListDisabilityGroup] AS

/*------------------------------------------------------------------------------
	Title:		List Disability Group
	File:		[Rep].[ListDisabilityGroup]
	Author:		Doug Cox
	Date:		07/19/13
	Desc:		This listing of Disability Groups can be used to fill the 
					available values for Disability Group Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/19/2013		Doug Cox				8947			Created
					07/22/2013		Umberto Sartori			8947			Changed JunkSK reference to JunkNK
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
	-- ( @Disability = '-2' OR dj.JunkNK = @Disability )
		
-----------------------------------------------------------------------------------*/

SELECT	dJunk.JunkNK ,
		dJunk.JunkValue
FROM	DW.dimJunk AS dJunk with(nolock) 
WHERE	dJunk.JunkEntity = 'CareDisabilityGroup'
UNION	
SELECT	'-2' AS JunkNK ,
		'Both' AS JunkValue


GO


