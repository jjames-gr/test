USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[cspReportInvalidClientAddressList]    Script Date: 07/10/2013 14:55:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [REP].[cspReportInvalidClientAddressList]
	@str_dt datetime,
	@end_dt datetime
AS
/*------------------------------------------------------------------------------
-- Title:	Invalid Client Address List
-- File:	Rep.cspReportInvalidClientAddressList
-- Author:	Brian Angelo
-- Date:	05/21/2013
-- Desc:	Invalid Client Address List stored proc
--			
-- CalledBy:
-- 		Reports: "Invalid Client Address List"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	05/21/2013  Brian Angelo		6419	initial creation
--------------------------------------------------------------------------------*/
BEGIN

	SET NOCOUNT ON;
	/* Test Parameters */
	/*
    DECLARE @str_dt datetime,
		@end_dt datetime
		
	SET @str_dt = '1/1/13'
	SET @end_dt = '1/31/13'
	--*/

	SELECT DISTINCT
	dp.ProviderName
	,dc.ConsumerNK
	,dc.LastName
	,dc.FirstName 
	,dc.MiddleName
	,dc.DOB
	,dc.SSN
	,dc.AddressLine1
	,dc.AddressLine2
	,dc.City
	,dc.[State]
	,dc.PostalCode
	,dc.County
	,dc.LivingArrangements
	FROM [BIW].[DW].[factClaims] fc
	INNER JOIN [BIW].[DW].[dimProvider] dp ON dp.ProviderSK = fc.ProviderSK
	INNER JOIN [BIW].[DW].[dimClinician] dcl ON dcl.ClinicianSK = fc.ClinicianSK
	INNER JOIN [BIW].[DW].[dimConsumers] dc ON dc.ConsumerSK = fc.ConsumerSK
	INNER JOIN [BIW].[DW].[dimDate] ddDoS ON ddDoS.DateSK = fc.DateofServiceSK
	WHERE dc.Active = 1
	AND dc.livingarrangements IN ('Private Residence (house,apartment,mobile home,child living with family)', 'Homeless (street, vehicle, shelter)', 'Other')			
	AND ddDoS.DateValue between @str_dt and @end_dt
	AND 
	(
		dc.AddressLine1 IN ('Incarcerated', 'Homeless', 'Unknown', 'Jail')
		OR dc.AddressLine1 like '%Homeless%'
		OR rtrim(ltrim(Isnull(dc.AddressLine1,''))) = ''
		OR rtrim(ltrim(Isnull(dc.City,''))) = ''
		OR rtrim(ltrim(Isnull(dc.State,''))) = ''
		OR rtrim(ltrim(Isnull(dc.PostalCode,''))) = ''
	)			

	

	ORDER BY dp.ProviderName, dc.LastName

    
END




GO


