USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ListCustomCatchment]    Script Date: 09/06/2013 13:08:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ListCustomCatchment]
AS

/*------------------------------------------------------------------------------
	Title:		List Custom Catchment
	File:		[REP].[ListCustomCatchment]
	Author:		Divya Lakshmi
	Date:		09/16/2013
	Desc:		This listing of 15 Counties and Catchments can be used to fill the
					available values for County/Catchment Parameters
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/16/2013		Divya Lakshmi    		6504			Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
	
			@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

		)

	-----------------------------------------------------------------------------------*/



-- <ALL Cardinal Innovations> option for drop down
SELECT
	ccID =
		REPLACE
		(
			  (
				SELECT DISTINCT
					 do.CatchmentID AS [data()]
				FROM dw.dimOrganization as do with(nolock)
				WHERE do.CatchmentID > 0
				FOR XML PATH('') 
			  ),
			  ' ', ','
		)
	, -200 as ccOrder
	, '<ALL Cardinal Innovations>' as ccName
UNION

-- Get catchments for drop down
SELECT DISTINCT
	CONVERT(NVARCHAR(MAX), do.CatchmentID) AS ccID,
	-100 AS ccOrder,
	do.Catchment AS ccName
FROM dw.dimOrganization as do with(nolock)
WHERE do.CatchmentID > 0
UNION

-- Get counties for drop down
SELECT
	CONVERT(NVARCHAR(MAX), do.OrganizationNK) AS ccID,
	100 AS ccOrder,
	do.County AS ccName
FROM dw.dimOrganization as do with(nolock)
WHERE do.CatchmentID > 0

ORDER BY ccOrder, ccName

GO


