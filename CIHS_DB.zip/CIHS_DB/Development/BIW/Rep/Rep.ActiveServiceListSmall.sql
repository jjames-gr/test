USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ActiveServiceListSmall]    Script Date: 08/28/2013 08:26:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [REP].[ActiveServiceListSmall]
	@ActiveDate DATETIME
	,@Sort INT
AS

/*------------------------------------------------------------------------------
	Title:		Active Service List Small
	File:		[Rep].[ActiveServiceListSmall]
	Author:		Divya Lakshmi
	Date:		05/20/2013
	Desc:		To view the list of active service codes by Service Category or Service Code.
                                        
	Called By:
                        Reports:          CDS002 - ActiveServiceListSmall
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/20/2013		Divya Lakshmi    		6269			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@ActiveDate DATETIME = '1/1/2013',
--	@Sort Int = 2
	

BEGIN	
SELECT DISTINCT
cur.ServiceSummary,
--s.ServiceSummary,
cur.ServiceDefinition,
RTRIM(ISNULL(cur.Modifier1, '')) as Mod1,
RTRIM(ISNULL(cur.Modifier2,'')) AS Mod2 ,
cur.ServiceCode,
cur.ServiceDescription,
bdt.datevalue as 'Service Effective Date',
dt.datevalue as 'Service End Date',
bp.DailyMaxServices,
bp.WeeklyMaxServices,
bp.MonthlyMaxServices,
bp.YearlyMaxServices,
bp.LifetimeMaxServices,
bp.BasicServiceFlag,
case when bp.BasicUnitMultiple=0 then 'False'
else 'True' end as BasicMax,
cur.ServicesNK

	
	
FROM
	DW.dimServices s WITH(NOLOCK)
	left outer JOIN DW.factServicesBenefitPlan bp WITH(NOLOCK) ON s.ServicesSK = bp.ServicesSK
	left outer JOIN DW.dimServices cur WITH(NOLOCK) ON s.ServicesNK = cur.ServicesNK --AND cur.ETLCurrentRow =1
    left outer JOIN DW.dimDate dt WITH(NOLOCK) ON bp.ExpirationDateSK = dt.DateSK
    left outer JOIN DW.dimDate bdt WITH(NOLOCK) ON bp.EffectiveDateSK = bdt.DateSK

WHERE
	cur.Active= 1
	AND cur.ServiceDefinitionID<>-1
	AND cur.ServiceCode not like '%All%'
	AND (@ActiveDate <=dt.DateValue)
	--AND @ActiveDate <= ISNULL(dt.DateValue, '1/1/9999')
    AND (@Sort= 1 or @Sort=2)
    AND @ActiveDate BETWEEN cur.ETLEffectiveFrom AND cur.ETLEffectiveTo



END






GO


