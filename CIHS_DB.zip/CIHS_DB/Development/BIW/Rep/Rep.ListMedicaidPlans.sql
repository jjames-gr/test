USE BIW
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListMedicaidPlans]
AS

/*------------------------------------------------------------------------------
	Title:		List Medicaid Plans
	File:		rep.ListMedicaidPlans
	Author:		Doug Cox
	Date:		08/2/2013
	Desc:		This listing of Medicaid plans can be used to fill the available 
					values for a Medicaid plan Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/02/2013		Doug Cox     			6371			Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
			( @PlanID = dbp.MedicaidPlanSK ) OR -- 1 specific Plan
			( @PlanID = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
		)

	-----------------------------------------------------------------------------------*/

/* Get Listing of all Medicaid Plans */
SELECT dbp.BenefitPlanNK,
	dbp.BenefitPlanShort
FROM DW.dimBenefitPlan as dbp with(nolock)
WHERE dbp.InsurerID = 2
/* Add item for All Medicaid Plans */
UNION
SELECT -100 AS BenefitPlanNK,
	'All Medicaid Plans'
