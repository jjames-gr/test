USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[CreditMemo]    Script Date: 03/21/2013 11:54:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








CREATE PROCEDURE [Rep].[CreditMemo] 
    @str_dt DATETIME ,
    @end_dt DATETIME ,
    @prov_Id NVARCHAR(MAX)
   
AS
/*------------------------------------------------------------------------------
	Title:		Credit Memo Report
	File:		CreditMemo
	Author:		Divya Lakshmi
	Date:		2/25/2013
	Desc:		To track reverted and adjusted claims to compare what is coming over from Great Plains.			
                                        
	Called By:
                        Reports:         FIN001 - Credit Memo Report.rdl
                        Stored Procs:     [Rep].[CreditMemo] 
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/25/2013		Divya Lakshmi   	    6350			Created

	-----------------------------------------------------------------------------------*/
--DECLARE @str_dt DATETIME , @end_dt DATETIME ,@prov_Id int
--set @str_dt ='11/01/2012'
--set @end_dt ='12/01/2012'
--set @prov_Id =21631


BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--select * from dw.dimProvider order by providernk

--select * from dw.factClaimshistorical
SELECT DISTINCT
 
fc.ClaimNumber ClaimID,
fch.ClaimAdjudicationNumber OldClaimAdjNumber,
fc.ClaimAdjudicationNumber ClaimAdjNumber,
c.ConsumerNK ConsumerID,
s.ServicesNK ServiceCode,
fc.ClaimAmount ClaimAmount,
fc.AdjustedAmount AdjustedAmount,
fc.CreditAmount CreditAmount,
fc.PaidAmount PaidAmount,
fc.DateofServiceSK DateofService,
fc.AdjudicationDateSK AdjudicationDate,
rc.ReasonCodeNK ReasonCode,
emp.FullName UpdatedBy,
p.ProviderName Provider,
p.ProviderNK ProviderID
    
  FROM
    
    DW.factClaims fc WITH(NOLOCK) 
	INNER JOIN DW.dimDate procdate WITH(NOLOCK) ON fc.AdjudicationDateSK = procdate.DateSK
	INNER JOIN DW.dimServices s WITH(NOLOCK) ON fc.ServicesSK = s.ServicesSK
	INNER JOIN DW.dimReasonCodes rc WITH(NOLOCK) ON fc.ReasonCodeSK = rc.ReasonCodeSK
	INNER JOIN DW.dimEmployee emp WITH(NOLOCK) ON fc.EmployeeSK = emp.EmployeeSK
	INNER JOIN dw.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK
	INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK = c.ConsumerSK
	INNER JOIN DW.factClaimsHistorical fch WITH(NOLOCK) ON fch.ClaimAdjudicationNumber = fc.ClaimAdjudicationNumber
	INNER JOIN dw.dimJunk dj WITH(NOLOCK) ON fc.CapitatedSK = dj.JunkSK
	                                 --and fc.StatusSK=dj.JunkSK
	INNER JOIN dw.dimJunk junk WITH(NOLOCK) ON fc.StatusSK=junk.JunkSK
    INNER JOIN dbo.cfn_split(@prov_Id , ',') fn ON element = p.ProviderNK

	--select * from dw.dimjunk
	WHERE 
	 
	procdate.DateValue between @str_dt and @end_dt
AND fc.StatusSK in(1,4,5)
and dj.JunkEntity='ClaimCapitatedFlag' and dj.JunkNK=0
--and junk.JunkSK in(1,4,5)


	--AND (
	--		(@prov_Id=p.ProviderNK) OR 
	--		( @prov_Id= -2 ) 
	--	)
 GROUP BY 
 fc.ClaimNumber,
 fch.ClaimAdjudicationNumber ,
 fc.ClaimAdjudicationNumber,
 c.ConsumerNK,
 s.ServicesNK,
 fc.ClaimAmount,
fc.AdjustedAmount,
fc.CreditAmount,
fc.PaidAmount ,
 fc.DateofServiceSK ,
fc.AdjudicationDateSK,
rc.ReasonCodeNK ,
emp.FullName ,
p.ProviderName,
p.ProviderNK 
	ORDER BY  p.ProviderName
	
-----------------------------------------	


	
	

	
	
	
		
END







GO


