USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ConsumersMultiDMHPop]    Script Date: 09/25/2013 13:52:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ConsumersMultiDMHPop] (
	@EffectiveDate datetime
)
AS
/*------------------------------------------------------------------------------
-- Title:	Consumers with Multiple DMH Target Populations
-- File:	[Rep].[ConsumersMultiDMHPop]
-- Author:	Brian Angelo
-- Date:	09/23/2013
-- Desc:	Consumers with Multiple DMH Target Populations stored proc
--			
-- CalledBy:
-- 		Reports: "Consumers with Multiple DMH Target Populations"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	09/23/2013  	Brian Angelo	6332	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--DECLARE @EffectiveDAte datetime = '6/1/13'

    IF OBJECT_ID('tempdb..#tempMultPop') IS NOT NULL
	DROP TABLE #tempMultPop

	/* Get consumers with multiple population groups */
	SELECT DISTINCT
	ConsumerNK,
	pop.DMHPopulationGroupCode,
	pop.DMHPopulationGroupDescription,
	effD.DateValue as EffectiveDate,
	expD.DateValue as ExpirationDate,
	dc.FirstName,					
	dc.LastName,								
	dc.MiddleName,									
	dc.DOB,							
	dc.County,
	IsNull(dc.ClinicalHomeProviderName, 'No Clinical Home') as ClinicalHomeProviderName,	
	dc.CreateDate
	INTO #tempMultPop
	FROM [BIW].[DW].[factDMHPopulationGroups] DMH WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimDMHPopulationGroups] pop WITH(NOLOCK) on pop.DMHPopulationGroupSK = DMH.DMHPopulationGroupSK 
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) on DMH.ConsumerSK = dc.ConsumerSK 
	INNER JOIN [BIW].[DW].[dimDate] effD WITH(NOLOCK) ON effD.DateSK = DMH.EffectiveDateSK
	INNER JOIN [BIW].[DW].[dimDate] expD WITH(NOLOCK) ON expD.DateSK = DMH.ExpirationDateSK
	WHERE 1=1
	AND pop.DMHPopulationGroupCode not in ('ADMRI','AMDEF','AMPAT','AMSMI','AMSPM','ASDHH','ASDWI','ASHMT','ASHOM','CMDEF','CMMED','CMPAT','CSCJO','CSDWI','CSIP','CSSP','CSWOM')
	AND dc.Active = 1
	AND DMH.ActiveFlag = 1
	AND expD.DateValue >= @EffectiveDate

	;WITH cteMultPop as
	(
		SELECT 
		ConsumerNK,
		COUNT(DISTINCT DMHPopulationGroupDescription) as cntPop
		FROM #tempMultPop
		GROUP BY ConsumerNK
		HAVING COUNT(DISTINCT DMHPopulationGroupDescription) > 1
	)

	DELETE FROM #tempMultPop
	WHERE #tempMultPop.ConsumerNK NOT IN (SELECT ConsumerNK FROM cteMultPop)
	
	--SELECT * FROM #tempMultPop
	
	/* Get eligibility information */
	;WITH cteEligible as (
		SELECT 
		pop.ConsumerNK,
		'Yes' as MedicaidEligible
		FROM #tempMultPop pop
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) on dc.ConsumerNK = pop.ConsumerNK
		INNER JOIN [BIW].[DW].[factEligibility] fe WITH(NOLOCK) on dc.ConsumerSK = fe.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDate] effDfe WITH(NOLOCK) ON effDfe.DateSK = fe.DateSK
		INNER JOIN [BIW].[DW].[dimDate] expDfe WITH(NOLOCK) ON expDfe.DateSK = fe.ExpirationDateSK
		INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) on dbp.BenefitPlanSK = fe.BenefitPlanSK
		WHERE 1=1
		AND ISNULL(expDfe.DateValue, '1/1/2099')  >= @EffectiveDate 
		AND ISNULL(effDfe.DateValue, '1/1/2099')  <= @EffectiveDate
		AND dbp.InsurerID = 2
		AND dc.Active = 1
	)
	
	/* Get clients with recent claims */
	, cteClaim as 
	(
		SELECT DISTINCT dc.ConsumerNK
		FROM #tempMultPop pop
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) on dc.ConsumerNK = pop.ConsumerNK
		INNER JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK)  on fc.ConsumerSK = dc.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDate] DOS WITH(NOLOCK) ON DOS.DateSK = fc.DateOfServiceSK
		WHERE 1=1
		AND DOS.DateValue >= DATEADD(yy, -1, @EffectiveDate)
		AND dc.Active = 1
	)
	
	/* Get clients with recent authorizations */
	, cteAuth as 
	(
		SELECT DISTINCT dc.ConsumerNK
		FROM #tempMultPop pop
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) on dc.ConsumerNK = pop.ConsumerNK
		INNER JOIN [BIW].[DW].[factAuthorizations] fa WITH(NOLOCK) on fa.ConsumerSK = dc.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDate] faEff WITH(NOLOCK) ON faEff.DateSK = fa.EffectiveFromDateSK
		WHERE 1=1
		AND faEff.DateValue >= DATEADD(yy, -1, @EffectiveDate)
		AND dc.Active = 1
	)
	
	/* Get consumers that were created 90 days after parameter */
	, cte90Days as
	(
		SELECT ConsumerNK
		FROM #tempMultPop
		WHERE CreateDate >= DATEADD(day, 90, @EffectiveDate)
	)
	
	/* Get consumers with multiple population groups having a recent claim and authorization  */
	/* Determine if they are medicaid eligible or ineligible, do not have to be eligible to be on report  */
	SELECT DISTINCT
	pop.DMHPopulationGroupCode,
	pop.ConsumerNK as ConsumerID,
	ISNULL(elig.MedicaidEligible, 'No') as MedicaidEligible,
	pop.DMHPopulationGroupDescription as AssignedTargetPop,
	pop.EffectiveDate,
	pop.ExpirationDate as DMHPopulationEndDate,
	pop.FirstName,
	pop.LastName,
	pop.MiddleName,
	pop.DOB,
	pop.County,
	pop.ClinicalHomeProviderName	
	FROM #tempMultPop pop
	LEFT JOIN cteEligible elig ON elig.ConsumerNK = pop.ConsumerNK
	LEFT JOIN cteClaim claim ON claim.ConsumerNK = pop.ConsumerNK
	LEFT JOIN cteAuth auth ON auth.ConsumerNK = pop.ConsumerNK
	LEFT JOIN cte90Days ndays ON ndays.ConsumerNK = pop.ConsumerNK
	WHERE 1=1
	AND (
		claim.ConsumerNK IS NOT NULL
		OR
		auth.ConsumerNK IS NOT NULL
		OR
		ndays.ConsumerNK IS NOT NULL
		)
	ORDER BY pop.ConsumerNK
	
END

