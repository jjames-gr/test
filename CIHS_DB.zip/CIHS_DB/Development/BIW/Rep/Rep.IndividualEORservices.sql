USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[IndividualEORservices] ( @StartDate Date, @EndDate Date, @Consumers VARCHAR(MAX) , @GroupBy VARCHAR(15)) AS

	/*------------------------------------------------------------------------------
	Title:		IndividualEORservices
	File:		Rep.IndividualEORservices.sql
	Author:		Doug Cox
	Date:		07/02/2013
	Desc:		Report to send out to ER families for services.
                                        
	Called By:
                        Reports:          IndividualEORservices
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/02/2013		Doug Cox     			6364			Created

	-----------------------------------------------------------------------------------*/
	
/*	TESTING	*/
--DECLARE @StartDate AS Date = '1/29/13'
--DECLARE @EndDate AS Date = '2/5/13'
--DECLARE @Consumers AS VARCHAR(MAX) = '12649,86073,100964,113626,10490,384236,12475,12289,112805,12416,9868,350700,12290,158815,164741,390283,7228,7231,9853,67567'
--DECLARE @GroupBy AS VARCHAR(15) = 'Service Code'
/*	END TESTING	*/

    BEGIN
		SELECT	DISTINCT
				dConsumers.LastName + ', #' + CONVERT(varchar(10),dConsumers.ConsumerNK) AS Consumer,
				dProvider.ProviderName ,
				dProvider.ProviderNK ,
				fClaims.ClaimNumber ,
				DOS.DateValue AS DOS ,
				dServices.ServiceCode ,
				dServices.ServiceDescription ,
				ReceivedDate.DateValue AS ReceivedDate ,
				fClaims.UnitsBilled ,
				fClaims.AdjudicatedAmount ,
				fClaims.PaidAmount ,
				dBenePlan.BenefitPlanShort
		FROM	DW.factClaims AS fClaims
				INNER JOIN dw.dimJunk AS dJunk ON fClaims.StatusSK = dJunk.JunkSK 
				INNER JOIN dw.dimConsumers AS dConsumers ON fClaims.ConsumerSK = dConsumers.ConsumerSK
				INNER JOIN dw.dimProvider AS dProvider ON fClaims.ProviderSK = dProvider.ProviderSK
				INNER JOIN dw.dimServices AS dServices ON fClaims.ServicesSK = dServices.ServicesSK 
				INNER JOIN dw.dimBenefitPlan AS dBenePlan ON fClaims.BenefitPlanSK = dBenePlan.BenefitPlanSK 
				INNER JOIN dw.dimDate AS DOS ON fClaims.DateOfServiceSK = DOS.DateSK
				INNER JOIN dw.dimDate AS ReceivedDate ON fClaims.ReceivedDateSK = ReceivedDate.DateSK
				INNER JOIN (SELECT * FROM dbo.cfn_split(@Consumers,',')) AS c1 ON c1.element = dConsumers.ConsumerNK
		WHERE	dJunk.JunkEntity = 'ClaimAdjudicatedStatus' 
				AND dJunk.JunkValue = 'Approved'
				AND dos.DateValue BETWEEN @StartDate AND @EndDate

	END