USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ReferralCallsByProvider]    Script Date: 08/28/2013 10:54:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ReferralCallsByProvider]
	@StartDate datetime,
	@EndDate datetime,
	@Service varchar(max)
AS
/*------------------------------------------------------------------------------
-- Title:	Referral Calls By Provider
-- File:	[Rep].[ReferralCallsByProvider]
-- Author:	Brian Angelo
-- Date:	08/26/2013
-- Desc:	Referral Calls By Provider stored proc
--			
-- CalledBy:
-- 		Reports: "Referral Calls By Provider"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/26/2013  Brian Angelo		6507	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /*
	/*** Test Parameters ***/
	DECLARE @StartDate datetime = '6/1/13',
			@EndDate datetime = '6/30/13',
			@Service int = -2

	--*/

	IF OBJECT_ID('tempdb..#tempRawData') IS NOT NULL
		DROP TABLE #tempRawData

	/* Get raw data */
	SELECT DISTINCT
	dp.ProviderName
	,ds.ServiceDescription
	,dc.County as CountyofResidence
	,do.County as MedicaidCounty
	,fstrpd.ScreeningTriageReferralProvDetSK as TimesOffered
	,fa.AppointmentID as TimesSelected
	,fstr.ScreeningTriageReferralID as NumberSTR
	,fa.AppointmentID as NumberOffered
	INTO #tempRawData
	FROM [BIW].[DW].[factScreeningTriageReferral] fstr WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimDate] screenDate WITH(NOLOCK) ON screenDate.DateSK = fstr.ScreenDateSK
	INNER JOIN [BIW].[DW].[factScreeningTriageReferralProvDet] fstrpd WITH(NOLOCK) ON fstrpd.ScreeningTriageReferralSK = fstr.ScreeningTriageReferralSK
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fstrpd.ServicesSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fstrpd.ProviderSK
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fstr.ConsumerSK
	INNER JOIN [BIW].[DW].[factAppointments] fa WITH(NOLOCK) ON fa.ScreeningTriageReferralSK = fstr.ScreeningTriageReferralSK
	INNER JOIN [BIW].[DW].[dimServices] dsa WITH(NOLOCK) ON dsa.ServicesSK = fa.ServicesSK
	INNER JOIN [BIW].[DW].[dimConsumers] dcElig WITH(NOLOCK) ON dcElig.ConsumerNK = dc.ConsumerNK
	INNER JOIN [BIW].[DW].[factEligibility] fe WITH(NOLOCK) ON fe.ConsumerSK = dcElig.ConsumerSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fe.BenefitPlanSK AND dbp.InsurerID = 2
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fe.OrganizationSK
	INNER JOIN dbo.cfn_split(@Service , ',') fn ON element = ds.ServicesNK OR element  = dsa.ServicesNK --Services filter
	WHERE 1=1
	AND screenDate.DateValue BETWEEN @StartDate AND @EndDate



	/* Get distinct counts by service */
	;WITH cteServiceCount as (
	SELECT
	ServiceDescription
	,COUNT(DISTINCT NumberSTR) as NumberSTR
	,COUNT(DISTINCT NumberOffered) as NumberOffered
	FROM #tempRawData
	GROUP BY ServiceDescription
	)

	/* Get distinct counts by service, provider, county and join services count */
	SELECT 
	trd.ProviderName 
	,trd.ServiceDescription
	,trd.CountyofResidence
	,trd.MedicaidCounty
	,COUNT(DISTINCT TimesOffered) as TimesOffered
	,COUNT(DISTINCT TimesSelected) as TimesSelected
	,csc.NumberOffered
	,csc.NumberSTR
	FROM #tempRawData trd
	INNER JOIN cteServiceCount csc ON csc.ServiceDescription = trd.ServiceDescription
	GROUP BY 
	trd.ProviderName 
	,trd.ServiceDescription
	,trd.CountyofResidence
	,trd.MedicaidCounty
	,csc.NumberOffered
	,csc.NumberSTR
    
    
END



GO


