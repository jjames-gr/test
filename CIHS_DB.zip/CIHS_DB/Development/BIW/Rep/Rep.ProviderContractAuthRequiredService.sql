USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ProviderContractAuthRequiredService]    Script Date: 08/05/2013 08:43:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [REP].[ProviderContractAuthRequiredService]
    @provider VARCHAR(100) ,
    @services INT
AS 
 
 /*------------------------------------------------------------------------------
	Title:		Authorization Required for Service by Provider Contract
	File:		ProviderContractAuthRequiredService
	Author:		Divya Lakshmi
	Date:		7/10/2013
	Desc:		Displays provider contract information that has been flagged as 
	            authorization required withint a certain date range.			
                                        
	Called By:
                        Reports:      FIN013 - Provider Contract Auth Required Service.rdl
                        Stored Procs:   [REP].[ProviderContractAuthRequiredService]
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		7/10/2013		Divya Lakshmi    		6283			Created

--	-----------------------------------------------------------------------------------*/


--DECLARE @provider INT,@services INT
--set @provider =-2
--set @services =0--1311



SELECT  distinct
p1.ProviderName AS Provider,
fpc.Providersk,
p.ProviderNK,
P.AddressLine1,
fpc.ProviderContractSK As ProviderContract,
ins.Insurer,
s.ServicesNK,
s.ServiceCode,
s.ServiceDescription,
p.ProviderName As ProviderLocation,
eff.DateValue As EffectiveDate,
ex.DateValue As ExpiredDate,
p.ParentProviderNK

 FROM DW.factProviderContract fpc WITH(NOLOCK) 

	INNER JOIN DW.dimProviderContract dpc WITH(NOLOCK) ON dpc.ProviderContractSK = fpc.ProviderContractSK  
	INNER JOIN DW.dimProvider p WITH(NOLOCK) ON  fpc.ProviderSK = p.ProviderSK 
	INNER JOIN dw.dimProvider p1 WITH(NOLOCK) ON  p.ParentProviderNK = p1.ProviderNK	
	INNER JOIN DW.dimServices s WITH(NOLOCK) ON  fpc.ServicesSK = s.ServicesSK 
	INNER JOIN DW.dimDate eff WITH(NOLOCK) ON  eff.DateSK = fpc.ContractEffectiveBeginDateSK   
	INNER JOIN DW.dimDate ex WITH(NOLOCK) ON  ex.DateSK = fpc.ContractExpirationBeginDateSK
	INNER JOIN DW.dimBenefitPlan ins WITH(NOLOCK) ON ins.InsurerID = fpc.InsurerSK  
	--INNER JOIN #prov dprov on p.ProviderSK = dprov.providersk
	--INNER JOIN #serv dserv on s.ServicesSK = dserv.ServicesSK
	
WHERE fpc.AuthorizationRequestedFlag = 1
AND p1.ProviderName NOT LIKE '%test%'
AND fpc.DeletedContractFlag = 0
AND fpc.ActiveContractFlag = 1
AND (
			(p.ProviderNK=@provider) OR 
			( @provider= -2 ) OR
			 @provider=0
		)

AND ( s.ServicesNK = @services
   OR @services=-2
   OR @services=0
   )
AND ex.DateValue > GETDATE()

ORDER BY ProviderNK






GO


