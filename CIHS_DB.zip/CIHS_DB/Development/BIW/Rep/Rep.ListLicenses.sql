USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListLicenses] AS

/*------------------------------------------------------------------------------
	Title:		List Licenses
	File:		rep.ListLicenses
	Author:		Doug Cox
	Date:		07/15/2013
	Desc:		This listing of Licenses can be used to fill the available values for License Parameters
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/15/2013		Doug Cox     			Many			Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		

	-----------------------------------------------------------------------------------*/

-- Get Licenses for drop down
SELECT
		dLic.LicenseID AS LicID,
		dLic.License AS LicName
FROM	dw.dimLicense AS dLic with(nolock) 
WHERE	dLic.Active = 1
		AND dLic.LicenseID > 0