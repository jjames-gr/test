USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ccCaseload]    Script Date: 09/23/2013 08:31:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [REP].[ccCaseload]
        @Catchment VARCHAR (MAX),
		@Disability INT,
		@CareCoordinator VARCHAR (MAX),
		@SupportFacilitator VARCHAR (MAX)

AS
/*------------------------------------------------------------------------------
	Title:		CC Caseload
	File:		[REP].[ccCaseload]
	Author:		Kevin Hamilton	
	Date:		07/26/2013
	Desc:		Staff current assigned consumer list
					
                                        
	Called By:
                        Reports:          CCO004-Caseload.rdl	

                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/25/2013		Kevin Hamilton     		8951			Created

	-----------------------------------------------------------------------------------*/
--Declare 
--@Catchment INT,
--@Disability INT,
--@CareCoordinator INT,
--@SupportFacilitator INT


--SET @Catchment = -2
--SET @Disability = -2
--SET @CareCoordinator = '-2'
--SET @SupportFacilitator = '-2'

 Select distinct b.BenefitPlanShort , dc.ConsumerNK 
		INTO #ConBenPlan
      from dw.factEligibility fe
            inner join dw.dimConsumers dc on fe.ConsumerSK = dc.ConsumerSK
            inner join dw.dimJunk j on fe.ActionSK = j.JunkSK
            inner join dw.dimBenefitPlan b on b.BenefitPlanSK = fe.BenefitPlanSK 
      where j.JunkValue in ('Effective','Active')
      
   CREATE CLUSTERED INDEX idx_tmpConBenPlan ON #ConBenPlan (ConsumerNK);
      
SELECT DISTINCT
 
      benefit_plan = 
                  
                  REPLACE
                  (
                        REPLACE
                        (
                              (
                              
      SELECT DISTINCT
	  REPLACE(RTRIM(dc.BenefitPlanShort),' ', CHAR(127)) AS [data()]
      FROM #ConBenPlan dc
      WHERE dc.ConsumerNK = c.ConsumerNK 
      
      
     
    
                                                         
                                    FOR XML PATH('') 
                              ),
                              ' ', '; '
                        ),
                        CHAR(127), ' '
                  ),
           

dCatch.JunkValue as Catchment,
currentc.LastName + ', ' + c.FirstName as ConsumerName,
currentc.ConsumerNK,
currentc.DOB,
currentc.AddressLine1,
currentc.AddressLine2,
currentc.City,
currentc.State,
currentc.PostalCode,
currentc.PhoneNumber,
dAdd.DateValue as CareCoordAdmissionsDate,
dDis.DateValue as CareCoordDischargeDate,
currentc.Competency,
CASE WHEN (e.FirstName + ' ' + e.LastName) = 'Unknown Unknown' THEN null
ELSE (e.FirstName + ' ' + e.LastName)
END AS CareCoordinator,
CASE WHEN (e1.FirstName + ' ' + e1.LastName) = 'Unknown Unknown' THEN null
ELSE (e1.FirstName + ' ' + e1.LastName)
END AS SupportFacilitator,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepLastName)) 
ELSE ''
END  as 'AuthLastName' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepFirstName))
ELSE ''
END  as 'AuthFirstName' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepAddressLine1))
ELSE ''
END  as 'AuthRepAddressLine1' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepAddressLine2))
ELSE ''
END  as 'AuthRepAddressLine2' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepCity))
ELSE ''
END  as 'AuthRepCity' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepState))
ELSE ''
END  as 'AuthRepState' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepPostalCode))
ELSE ''
END  as 'AuthRepPostalCode' ,
CASE WHEN currentc.AuthRepEndDate IS null OR currentc.AuthRepEndDate = '1900-01-01' THEN 
LTRIM(RTRIM(currentc.AuthRepPhone))
ELSE ''
END  as 'AuthRepPhone' ,

CASE WHEN a.AgeValue >= '18' THEN 'Adult'
	ELSE 'Child'
END as Age,
jCDG.JunkValue as DiagGroup
,fcc.ActiveAdmissionFlag
,currentC.AuthRepEndDate

FROM 
BIW.DW.factCareCoordAdmissions fcc
INNER JOIN BIW.DW.dimConsumers c ON fcc.ConsumerSK = c.ConsumerSK 
INNER JOIN BIW.DW.dimConsumers currentc ON c.ConsumerNK = currentc.ConsumerNK and currentc.ETLCurrentRow = 1
INNER JOIN BIW.DW.dimEmployee e ON e.EmployeeSK = fcc.CareCoordinatorSK 
INNER JOIN BIW.DW.dimEmployee e1 ON e1.EmployeeSK = fcc.SupportFacilitorSK 
INNER JOIN BIW.DW.dimEmployee e2 ON e2.EmployeeSK = fcc.SecondaryCareCoordinatorSK 
INNER JOIN BIW.DW.dimJunk jCDG ON jCDG.JunkSK = fcc.CareDisabilityGroupSK 
INNER JOIN BIW.DW.dimDate dAdd ON dAdd.DateSK = fcc.CareCoordAdmissionsDateSK
LEFT  JOIN BIW.DW.dimDate dDis ON dDis.DateSK = fcc.CareCoordDischargeDateSK
INNER JOIN BIW.DW.dimAge a ON a.AgeValue = c.AgeValue 
INNER JOIN DW.dimJunk AS dJunk with(nolock) ON fcc.CareDisabilityGroupSK = dJunk.JunkSK AND dJunk.JunkEntity = 'CareDisabilityGroup'
INNER JOIN DW.dimJunk AS dCatch with(nolock) ON dCatch.JunkSK = fcc.CatchmentSK AND dCatch.JunkEntity = 'AreaCatchments'
INNER JOIN dbo.cfn_split(@Catchment,',') org1 ON org1.element = dCatch.JunkNK  

  
                    
WHERE 
	dDis.DateValue = '1900-01-01'
	
	AND c.ConsumerNK <> -1
	AND fcc.ActiveAdmissionFlag =1
	AND ( @Disability = -2 OR dJunk.JunkNK = @Disability )
	AND (@CareCoordinator = -2 OR
		 @CareCoordinator = e.EmployeeNK)
	AND (@SupportFacilitator = -2 OR
		 @SupportFacilitator = e1.EmployeeNK )




  ORDER BY ConsumerName 
			
	DROP TABLE #ConBenPlan		