Use BIW 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ListRegistryServiceTypes] AS

/*------------------------------------------------------------------------------
	Title:		[Rep].[ListRegistryServiceTypes]
	File:		[Rep].[ListRegistryServiceTypes]
	Author:		Doug Cox
	Date:		08/20/2013
	Desc:		Use to fill the drop-down box for Registry Service Types
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/20/2013		Doug Cox				6509			Drop Down for Registry Service Types
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		AND ( @Diagnosis = -300 OR dJ.JunkNK = @Diagnosis )
		

	-----------------------------------------------------------------------------------*/

SELECT	DISTINCT 
		1 as SortOrder,
		dj.JunkNK AS ServiceTypeID,
		dj.JunkValue AS ServiceType
FROM	DW.dimJunk AS dj with(nolock)
WHERE	dj.JunkEntity = 'ServiceType'
UNION 
SELECT 
		2 AS SortOrder,
		-300 AS ServiceTypeID,
		'ALL' AS ServiceType
ORDER BY SortOrder


