USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListTARActionsTaken] AS

/*------------------------------------------------------------------------------
	Title:		[Rep].[ListTARActionsTaken]
	File:		[Rep].[ListTARActionsTaken]
	Author:		Doug Cox
	Date:		08/22/2013
	Desc:		
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/22/2013		Doug Cox				----			Drop Down for TAR Actions Taken
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		INNER JOIN dbo.cfn_split(@DiagCategory , ',') fnDiag ON fnDiag.element = dd.DiagnosisGroupID

	-----------------------------------------------------------------------------------*/

SELECT	DISTINCT
		dcrg.JunkNK,
		dcrg.JunkValue
FROM	dw.dimJunk AS dCRG
WHERE	dCRG.JunkEntity = 'ActionTaken'