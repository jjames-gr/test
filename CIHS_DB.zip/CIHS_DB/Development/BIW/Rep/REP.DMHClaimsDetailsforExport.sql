USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[DMHClaimsDetailsforExport] 
(
	@stdate datetime
	,@enddate datetime 
	,@DMHStatus varchar(MAX) 
    ,@ProviderNK int
	,@ServiceCodes varchar(max) 
)
AS

/*------------------------------------------------------------------------------
	Title:		DMH Claims Details for Export	
	File:		
	Author:		Ammar Ahmed
	Date:		09/13/2013
	Desc:		To analyze denials and approvals			 
		
                                        
	Called By:
                        Reports:          
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		9/13/2013		Ammar Ahmed				6422			started
	-----------------------------------------------------------------------------------*/

--DECLARE
--@stdate datetime = '06/01/2012'
--	,@enddate datetime = '12/01/2012'
--	,@DMHStatus varchar(MAX) = 'D'
--	,@ProviderNK int = -2
--	,@ServiceCodes varchar(max) = -2

--My code
select  distinct
		fc.ClaimNumber  
		,fc.ClaimAdjudicationNumber 
		,AdjClaimDate.DateValue AS AdjClaimDate
		,con.ConsumerNK 
		,con.LastName+', '+con.FirstName AS ConsumerName
		,con.DOB 
		,fc.BillingNPINumber 
		,s.ServiceCode 
		,s.Modifier1 
		,s.Modifier2 
		,s.DMHStateServiceCode	
		,s.MedicareEligibleCodeFlag
		,s.DMHStateServiceModifier1 
		,s.DMHStateServiceModifier2 
		,d.DiagnosisName	
		,pos.PlaceOfServiceCode	
		,fc.UnitsClaimed	
		,tax.TaxonomyCode	
		,fc.AdjudicatedAmount	
		,fc.RenderingNPINumber	
		,DMHSentDate.DateValue AS DMHSentDate
		,dmhReason.DMHReasonCode 
		,fc.DMHSentStatusCode	
		,cl.LastName+', '+cl.FirstName	AS ClinicianName
		,p.ProviderName	
		,p.ProviderNK	

from	DW.factclaimshistorical fc with(nolock)
		INNER JOIN DW.dimConsumers con with(nolock)on fc.ConsumerSK = con.ConsumerSK
		INNER JOIN DW.dimServices s with(nolock)on fc.ServicesSK = s.ServicesSK
									and (s.ServiceCode=@ServiceCodes or @ServiceCodes='-2')
		INNER JOIN DW.dimDiagnosis d with(nolock)on d.DiagnosisSK = fc.DMHDiagnosisSK --? 
		INNER JOIN DW.dimDate AdjClaimDate with(nolock)on AdjClaimDate.DateSK = fc.DateOfServiceSK 
									and AdjClaimDate.DateValue between @stdate and @enddate
		INNER JOIN DW.dimDate DMHSentDate with(nolock)on DMHSentDate.DateSK = fc.DMHSentDateSK 
		INNER JOIN DW.dimPlaceOfService pos with(nolock)on pos.PlaceOfServiceSK = fc.PlaceOfServiceSK
		INNER JOIN DW.dimTaxonomyCodes tax with(nolock)on tax.TaxonomyCodeSK = fc.TaxonomyCodeSK
		INNER JOIN DW.dimClinician cl with(nolock)on cl.ClinicianSK = fc.ClinicianSK
		INNER JOIN DW.dimProvider p with(nolock)on p.ProviderSK = fc.ProviderSK 	
		INNER JOIN DW.dimReasonCodes reason with(nolock)on reason.ReasonCodeSK = fc.ReasonCodeSK
		INNER JOIN DW.dimJunk j with(nolock)on j.JunkSK = fc.DMHCrossoverMedicaidClaimSK 
									and j.JunkNK <> '1'
									and j.JunkEntity = 'DMHCrossoverMedicaidClaim'	
										
		INNER JOIN DW.dimDMHReason dmhReason with(nolock)on fc.DMHReasonSK = dmhreason.DMHReasonSK  	
WHERE	1=1
		and (fc.DMHSentStatusCode=@DMHStatus or @DMHStatus='-200')
		and (p.ProviderNK=@ProviderNK or @ProviderNK=-2)