USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ConsumersByDisability]    Script Date: 10/01/2013 10:52:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO









CREATE PROCEDURE [REP].[ConsumersByDisability]
  (
      @Noc INT ,
      @StartDt DATETIME ,
      @EndDt DATETIME ,
      @Diag NVARCHAR(MAX) ,
      @Age INT ,
      @Plan_Id INT  ,
      @Living_Arrangement INT,
      @Catchment NVARCHAR(MAX)
	)

AS

/*-------------------------------------------------------------------------------------------
-- Title:  Random Sample of Consumers by Disability
-- File:   ConsumersByDisability
-- Author: Divya Lakshmi
-- Date:   8/2/2013
-- Desc:   To pull a random sample of consumers for the National Core Indicators (NCI) Survey
--                                             
	Called By:
                        Reports:        QMG005 - RandomSampleOfConsumerByDisability.rdl		                                 

---------------------------------------------------------------------------------------------
-- Change Hisory
-- Ver                   Date                  Author              TixNo         Description
-- ---                 --------            ---------------         -----        --------------
-- 1.0                 08/2/2013            Divya Lakshmi          6504          Creation
-- 1.1				   09/20/2013			Brian Angelo		   6504			 Added active check for provider, 
--																				 Changed consumer county to pull county from claim
--																				 Ordered by authorization number to pull current most authorization
-----------------------------------------------------------------------------------------------
*/
--DECLARE
--	  @Noc INT = 50000
--	, @StartDt DATETIME = '7/1/2013'
--	, @EndDt DATETIME = '7/31/2013'
--	, @Diag NVARCHAR(MAX) = 2---1
--	, @Age INT =2-- 3
--	, @Plan_Id NVARCHAR(MAX) = 4---200
--	, @Living_Arrangement INT =1-- -1
--	, @Catchment INT = -300;

;with cte as
(
SELECT DISTINCT
c1.FirstName,
c1.LastName,
c1.DOB,
a.AgeValue,
srvc.DateValue as DateOfService,
c1.ConsumerNK,
c1.AddressLine1,
c1.AddressLine2,
c1.City,
c1.State,
c1.PostalCode,
o.County AS Consumer_county, --BA 09/20/2013
c1.PhoneNumber,
d.DiagnosisGroup,
--fc.AuthorizationNumber,
prov.ProviderName,
prov.MailingAddressLine1,
prov.MailingAddressLine2,
prov.MailingCity,
prov.MailingState,
prov.MailingZip,
prov.County,
prov.ContactName,
prov.ContactPhoneNumber,
s.ServiceDescription,
c1.LivingArrangements,
isnull(c1.AuthRepFirstName,'') +' '+ isnull(c1.AuthRepLastName,'') AS LegalGuardianName,
c1.AuthRepAddressLine1,
c1.AuthRepAddressLine2,
c1.AuthRepCity,
c1.AuthRepState,
c1.AuthRepPostalCode,
CASE
WHEN care.Care_contact IS NULL THEN care.Support_facilitator
ELSE care.Care_contact
END AS CareContact,
auth.AuthNo as AuthorizationNumber,
CASE WHEN prov.ContactTypeID = 1 THEN 'Main'   
			ELSE 'Secondary'
		  END ContactType


FROM
BIW.DW.factClaims fc WITH(NOLOCK) 
    INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fc.ConsumerSK = c.ConsumerSK 
    INNER JOIN DW.dimConsumers c1 WITH(NOLOCK) ON c.ConsumerNK = c1.ConsumerNK and c1.ETLCurrentRow=1
    INNER JOIN DW.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK 
	INNER JOIN DW.dimDiagnosis d WITH(NOLOCK) ON fc.Diagnosis1SK=d.DiagnosisSK
	INNER JOIN DW.dimServices s WITH(NOLOCK) ON fc.ServicesSK = s.ServicesSK
    INNER JOIN DW.dimbenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK=bp.BenefitPlanSK
	INNER JOIN DW.dimOrganization o WITH(NOLOCK) ON fc.OrganizationSK = o.OrganizationSK
	INNER JOIN DW.dimAge a WITH(NOLOCK)  ON a.AgeValue = c.AgeValue 
    INNER JOIN DW.dimJunk j WITH(NOLOCK) ON fc.StatusSK= j.JunkSK
    INNER JOIN DW.dimDate srvc WITH(NOLOCK) ON fc.DateOfServiceSK = srvc.DateSK
  --  INNER JOIN cfn_split(@plan_Id,',') fnben  ON  bp.BenefitPlanNK = fnben.element 
    INNER JOIN cfn_split(@diag,',') fndiag  ON  d.DiagnosisGroupID = fndiag.element 
	--INNER JOIN DW.dimCustomReportGroups AS la WITH(NOLOCK) ON la.CustomGroupName = 'LivingATAwayHome'
    INNER JOIN DW.dimCustomReportGroups AS Age WITH(NOLOCK) ON Age.CustomGroupName = 'ConsumersByDisabilityAgeGroup'
										AND a.AgeSK BETWEEN cast(Age.BeganAttributeCodeRange as int) AND cast(Age.EndAttributeCodeRange as int)
     LEFT OUTER JOIN (
          SELECT max(fa.AuthorizationNumber) as AuthNo,c.ConsumerNK from
                 DW.factAuthorizations fa WITH(NOLOCK)INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fa.ConsumerSK=c.ConsumerSK
          GROUP BY c.ConsumerNK
     )as auth ON auth.ConsumerNK = c1.ConsumerNK AND fc.AuthorizationNumber = auth.AuthNo --KM Is this needed? 10/1
     LEFT OUTER JOIN 
		(
			SELECT
				  c.ConsumerNK
				, fcc.ConsumerSK
				, fcc.CareCoordAdmissionsDateSK
				, fcc.CareCoordDischargeDateSK
				--, fcc.CareCoordinatorSK AS Care_contact
				--, fcc.SupportFacilitorSK AS Support_facilitator
				,CASE WHEN (e.FirstName + ' ' + e.LastName) = 'Unknown Unknown' THEN null
ELSE (e.FirstName + ' ' + e.LastName)
END AS  Care_contact
				,CASE WHEN (e1.FirstName + ' ' + e1.LastName) = 'Unknown Unknown' THEN null
ELSE (e1.FirstName + ' ' + e1.LastName)
END  AS Support_facilitator
			FROM
			
			BIW.DW.factCareCoordAdmissions fcc WITH(NOLOCK) 
            INNER JOIN DW.dimConsumers c WITH(NOLOCK) ON fcc.ConsumerSK = c.ConsumerSK 
			INNER JOIN BIW.DW.dimEmployee e WITH(NOLOCK)ON e.EmployeeSK = fcc.CareCoordinatorSK 
			INNER JOIN BIW.DW.dimEmployee e1 WITH(NOLOCK)ON e1.EmployeeSK = fcc.SupportFacilitorSK 
		) AS care ON c.ConsumerNK = care.ConsumerNK
			AND ((fc.DateOfServiceSK BETWEEN care.CareCoordAdmissionsDateSK AND care.CareCoordDischargeDateSK)
			or (fc.DateOfServiceSK> =care.CareCoordAdmissionsDateSK and care.CareCoordDischargeDateSK=-1))
		
		INNER JOIN
		(
			SELECT
				  prv.ProviderNK
				, prv.ProviderName
				, prv.MailingAddressLine1 
				, prv.MailingAddressLine2 
				, prv.MailingCity 
				, prv.MailingState
				, prv.MailingZip
				, prv.County 
				, pc.ContactName
				, pc.ContactPhoneNumber
				,pc.ContactTypeID
			
				
		     FROM
				dw.dimProvider prv WITH(NOLOCK)
			    LEFT OUTER JOIN dw.factProviderContact fpc WITH(NOLOCK) ON fpc.ProviderSK=prv.ProviderSK
				LEFT OUTER JOIN dw.dimProviderContacts pc WITH(NOLOCK) ON pc.ProviderContactsSK=fpc.ProviderContactsSK  AND pc.ContactTypeID = 1
				       AND pc.ActiveProviderContactFlag=1  
				LEFT OUTER JOIN DW.dimCustomReportGroups AS lip WITH(NOLOCK) ON lip.CustomGroupName = 'StateLIPHospitals'
				       AND prv.Active=1
				       AND prv.EntityTypeID  = lip.AttributeID
		) AS prov ON p.ProviderNK = prov.ProviderNK
WHERE
	c.active = 1
	AND p.Active = 1 --BA 09/20/2013
	AND srvc.DateValue BETWEEN @StartDt AND @EndDt
	AND fc.StatusSK = 1
	
	AND(
			( @plan_Id = bp.BenefitPlanNK ) OR -- 1 Specific Plan
			( @Plan_ID = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
			( @Plan_ID = -200 ) -- ALL PLANS
		)
		

    AND	(
		   (@Age = 1 AND Age.CustomGroupValue = 'Child (0-17)')
		OR (@Age = 2 AND Age.CustomGroupValue = 'Adult (18+)')
		OR (@Age = 3 AND Age.CustomGroupValue = 'ALL')
	    )
	AND c.DOD IS NULL
	AND
		(
				( 
				@living_arrangement = 1
				AND c.LivingArrangementsID in(select AttributeID from dw.dimCustomReportGroups
				where  CustomGroupValue='Living At Home')
			)
			OR 
			( 
				@living_arrangement = 2
				AND c.LivingArrangementsID in(select AttributeID from dw.dimCustomReportGroups
				where CustomGroupValue='Living Away From Home')
			)
			OR  @living_arrangement = -1
		)
		
	AND
		( 
			   c.AddressLine1 NOT LIKE '%Homeless%'
			OR c.AddressLine1 NOT LIKE '%Incar%'
			OR c.AddressLine1 NOT LIKE '%Unknown%'
			OR c.AddressLine1 NOT LIKE '%Jail%'
		)
		
	--AND
	--	(
	--		d.DiagnosisGroupID = @diag
	--		OR @diag = -1
	--		OR @diag = -2
	--	)

	AND (
			@Catchment = '-300'
			OR CONVERT(nvarchar, o.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
			OR CONVERT(nvarchar, o.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@Catchment, ',') )
		)
	)
	

SELECT TOP ( @noc )
	NEWID() AS ROWID
	, ts.*
FROM
	( select 
		*
		, ROW_NUMBER = ROW_NUMBER() OVER ( PARTITION BY t.consumernk ORDER BY t.consumernk DESC, t.AuthorizationNumber DESC ) --BA 09/20/2013
	from
		cte t
	) as ts
where
	ts.ROW_NUMBER = 1
ORDER BY
	ROWID





















