USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ClientSpecificRates]    Script Date: 06/27/2013 08:38:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [REP].[ClientSpecificRates]
 @provider INT
   
AS

/*------------------------------------------------------------------------------
	Title:		Client Specific Rates
	File:		[Rep].[ClientSpecificRates]
	Author:		Kevin Hamilton
	Date:		05/21/2013
	Desc:		To monitor client specific rates since they are temporary. 
				Clients are re-evaluated and rates need to be updated.
				Monitor the effective rates and rate history.


                                        
	Called By:
                        Reports:         CLM019-Client Specific Rates.rdl
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/21/2013		Kevin Hamilton     		6323			Created

	-----------------------------------------------------------------------------------*/
--DECLARE @provider int
           
    
            
--SET @provider = -2

SELECT DISTINCT
      p.ProviderNK,
      p.ProviderName,
      dbp.Insurer,
      s.ServiceDescriptionShort,
      c.ConsumerNK,
      fc.ConsumerSK,
      ddeff.DateValue as 'Eff_Date', 
      ddExp.DateValue as 'Exp_Date', 
      fc.ConsumerContractRate,
      s.ServicesNK,
      fpc.ActiveContractFlag
FROM
      [BIW].[DW].factConsumerContractRate fc with(nolock)
      INNER JOIN [BIW].[DW].dimProvider p with(nolock) ON fc.ProviderSK = p.ProviderSK 
      INNER JOIN [BIW].[DW].dimConsumers c with(nolock)  ON fc.ConsumerSK = c.ConsumerSK
      INNER JOIN [BIW].[DW].dimServices s with(nolock) ON fc.ServicesSK = s.ServicesSK
      INNER JOIN [BIW].[DW].[dimDate] ddEff with(nolock) ON ddEff.DateSK = fc.ConsumerContractEffectiveDateSK 
      INNER JOIN [BIW].[DW].[dimDate] ddExp with(nolock) ON ddExp.DateSK = fc.ConsumerContractExpirationDateSK 
      
      INNER JOIN [BIW].[DW].dimProvider pCon with(nolock) ON p.ProviderNK = pCon.ProviderNK
      INNER JOIN [BIW].[DW].factProviderContract fpc with(nolock) ON pCon.ProviderSK = fpc.ProviderSK
      INNER JOIN [BIW].[DW].dimProviderContract dpc on fpc.ProviderContractSK = dpc.ProviderContractSK and fc.ConsumerContractRateNK = dpc.ProviderContractNK
      INNER JOIN [BIW].[DW].dimBenefitPlan dbp with(nolock) ON fpc.InsurerSK = dbp.InsurerID
      
         
       
WHERE 
	(
      fpc.ActiveContractFlag = 1
      OR
      fc.ConsumerContractExpirationDateSK is not null
	)   
   
 AND (@provider = p.ProviderNK OR 
    @provider = -2 )
   
 
ORDER BY p.ProviderNK, c.ConsumerNK


