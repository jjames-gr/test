USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[CheckWriteDetailStateAudit]
	@strDate DATE,
	@endDate DATE,
	@provID INT
AS

/*
	------------------------------------------------------------------------------
	Title:		Check Write Detail for State Audit
	File:		[Rep].[CheckWriteDetailStateAudit]
	Author:		Karissa Martindale
	Date:		08/07/13
	Desc:		
                                        
	Called By:  State audit report listing cliams counts along with check information by Provider and Catchment
	
                        Reports: FIN017 - CheckWriteDetailStateAudit	
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/07/13		Karissa Martindale     	8941			Created

	-----------------------------------------------------------------------------------
*/

--DECLARE
--	@strDate DATE = '1/1/13',
--	@endDate DATE = '9/7/13',
--	@provID INT = -2--22961

SELECT DISTINCT 
	dProv.ProviderNK,
	dProv.ProviderName,
	fCheck.ClaimCheckNumber,
	dCheckDate.DateValue as CheckDate,
	fClaims.ClaimAdjudicationNumber,
	fClaims.ClaimNumber,
	dServ.ServiceCode,
	dServ.ServiceDescription,
	dBenPlan.BenefitPlanShort,
	dBenPlan.InsurerShort,
	dBenPlan.InsurerID,
	dDOS.DateValue as DateofService,
	dCon.ConsumerNK,
	dCon.FullName,
	dOrg.Catchment,
	dOrg.County,
	fCheckDet.ClaimCheckDetailAmount,
	fClaims.AdjustedAmount,
	fClaims.PaidAmount,
	fClaims.ClaimAmount,
	fCheck.ClaimCheckAmount,
	fClaims.AdjudicatedAmount,
	CASE
		WHEN (fClaims.PaidAmount + fClaims.AdjudicatedAmount = 0) THEN fMemo.CreditMemoApplyAmount
		ELSE fClaims.PaidAmount
	END as CalcdPaidAmount,
	fClaims.ClaimDetailNumber,
	fMemo.CreditMemoApplyAmount,
	fClaims.ContractRate,
	dGLA.CostCenterCode,
	dGLA.GLAccount,
	dCheckDate.[MonthAndYearAbbr_en-US] as accountingperiod,
	fClaims.dmhsentstatuscode
FROM
	dw.factClaimCheck fCheck WITH(NOLOCK)
	INNER JOIN dw.factClaimCheckDetail fCheckDet WITH(NOLOCK) ON fCheckDet.ClaimCheckSK = fCheck.ClaimCheckSK
	INNER JOIN dw.dimProvider dProv WITH(NOLOCK) ON fCheck.ProviderSK = dProv.ProviderSK
	INNER JOIN dw.dimDate dCheckDate WITH(NOLOCK) ON fCheck.ClaimCheckDateSK = dCheckDate.DateSK
	INNER JOIN dw.factClaims fClaims WITH(NOLOCK) ON fClaims.ClaimAdjudicationNumber = fCheckDet.ClaimCheckAdjudicationNumber
	INNER JOIN dw.dimServices dServ WITH(NOLOCK) ON fClaims.ServicesSK = dServ.ServicesSK
	INNER JOIN dw.dimDate dDOS WITH(NOLOCK) ON fClaims.DateOfServiceSK = dDOS.DateSK
	INNER JOIN dw.dimBenefitPlan dBenPlan WITH(NOLOCK) ON fClaims.BenefitPlanSK = dBenPlan.BenefitPlanSK
	INNER JOIN dw.dimConsumers dCon WITH(NOLOCK) ON fClaims.ConsumerSK = dCon.ConsumerSK
	INNER JOIN dw.dimOrganization dOrg WITH(NOLOCK) ON fClaims.OrganizationSK = dOrg.OrganizationSK
	LEFT JOIN dw.factCreditMemo fMemo WITH(NOLOCK) ON fMemo.ClaimCheckSK = fCheck.ClaimCheckSK AND fClaims.ClaimAdjudicationNumber = fMemo.AppliedClaimAdjudicationNumber--and fMemo.SourceClaimAdjudicationNumber = fClaims.ClaimAdjudicationNumber
	INNER JOIN dw.dimGLAccount dGLA WITH(NOLOCK) ON fClaims.GLAccountSK = dGLA.GLAccountSK
WHERE 
	fClaims.AdjudicatedAmount > 0
	AND (@provID = dProv.ProviderNK OR @provID = -2)
	AND dCheckDate.DateValue BETWEEN @strDate AND @endDate
	--and fClaims.ClaimAdjudicationNumber = 12389468
ORDER BY claimadjudicationnumber



--select distinct GLAccountSK, COUNT(*) as c from dw.FactClaims group by GLAccountSK order by c DESC--where ClaimAdjudicationNumber = 14933878


--select * from qm..tbl_claims_adj where claim_adj_id = 12760405
