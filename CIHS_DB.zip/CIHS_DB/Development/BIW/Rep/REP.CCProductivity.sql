USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[CCProductivity]    Script Date: 09/11/2013 16:28:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[CCProductivity]
    (		
		@str_dt datetime, 
		@end_dt datetime, 
		@catchment nvarchar(max),
		@CareDisability nvarchar(max)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Provider Active Utilization
-- File:	[Rep].[CCProductivity]
-- Author:	Ammar Ahmed
-- Date:	07/12/2013
-- Desc:	This report allows the staff to see all Care Coordinators and the total hours 
--			they have spent during a time period with their Consumers
--
--                                          
-- CalledBy:
--          Reports: 
--          Stored Procs: 
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
--	1.0		07/22/2013  Ammar Ahmed		8949	  Created
--	1.1		07/31/2013  Ammar Ahmed     8949      Added support for multi disability group
--	1.2		08/27/2013	Ammar Ahmed		8949	  Showing users with 0 hours of travel		 
--------------------------------------------------------------------------------
--*/

--Date of Service Start Date
--Date of Service End Date
--Care Disability
----Catchment
--declare @str_dt datetime, @end_dt datetime, @catchment nvarchar(max),@CareDisability nvarchar(max)
--set @str_dt			= '1/1/2012'
--set @end_dt			= '2/1/2012'
--set @catchment      = '1039' --'1039,1040,1041,1042,1043'
--set @CareDisability = '1036' --'1036,1036' --'1035' --services 72	73


---------------------------------------------
--# Hours of Care Coordination for Time Period
--------------------------------------------
select distinct EmployeeNK
				,E.FirstName
				,E.LastName
				,cast(sum(fpn.TotalMinutesWithClient/60.0) as decimal(18,2)) AS HoursOfCareC
into #tempCare
from DW.factProgressNotes FPN WITH(NOLOCK) 
	  INNER JOIN DW.dimEmployee E WITH(NOLOCK)ON  E.EmployeeSK = FPN.CaseManagerSK
	  INNER JOIN DW.dimJunk j WITH(NOLOCK)ON FPN.ProgressStatusSK = j.JunkSK
								 and j.JunkEntity = 'ProgressStatus' and j.JunkNK in ('APPROVED','SUBMITTED')
	  INNER JOIN DW.dimJunk Catchment WITH(NOLOCK)ON FPN.CatchmentSK = Catchment.JunkSK
	  INNER JOIN DW.dimServices s WITH(NOLOCK)ON s.ServicesSK = FPN.ServicesSK
	  INNER JOIN DW.dimDate d WITH(NOLOCK)on FPN.DateOfServiceSK = d.DateSK
	  INNER JOIN DW.dimCustomReportGroups CRG WITH(NOLOCK)ON s.ServicesNK = CRG.AttributeID AND CRG.CustomGroupName = 'CareCoordinationService'
	  INNER JOIN cfn_split(@Catchment,',') fnCatch on Catchment.JunkNK = fnCatch.element

WHERE 1=1 
	  and d.DateValue between @str_dt and @end_dt
		
group by EmployeeNK 
		 ,E.LastName
		 ,E.FirstName
		 ,Catchment.JunkValue				
order by EmployeeNK

---------------------------------------------
--# Hours of Travel for Time Period
---------------------------------------------
select distinct EmployeeNK
		,cast(sum(fpn.TotalMinutesWithClient/60.0)as decimal(18,2)) AS HoursOfTravel 
into #tempTravel
from DW.factProgressNotes FPN with(nolock) 
	  INNER JOIN DW.dimEmployee E with(nolock)ON  E.EmployeeSK = FPN.CaseManagerSK
	  INNER JOIN DW.dimJunk j WITH(NOLOCK)ON FPN.ProgressStatusSK = j.JunkSK
								 and j.JunkEntity = 'ProgressStatus' and j.JunkNK in ('APPROVED','SUBMITTED')
	  INNER JOIN DW.dimJunk Catchment WITH(NOLOCK)ON FPN.CatchmentSK = Catchment.JunkSK
	  INNER JOIN DW.dimServices s WITH(NOLOCK)ON s.ServicesSK = FPN.ServicesSK
	  INNER JOIN DW.dimDate d WITH(NOLOCK)on FPN.DateOfServiceSK = d.DateSK  
	  INNER JOIN DW.dimCustomReportGroups g  WITH(NOLOCK)ON  s.ServicesNK = g.AttributeID AND g.CustomGroupName='CareCoordinationServiceTravel'	
	  INNER JOIN cfn_split(@Catchment,',') fnCatch on Catchment.JunkNK = fnCatch.element	
WHERE 
		d.DateValue between @str_dt and @end_dt		
		
group by EmployeeNK 
		 ,E.LastName
		 ,E.FirstName
		 ,Catchment.JunkValue				
order by EmployeeNK

	

---------------
--Get the Employee infos
---------------
select distinct 
		E.EmployeeNK
		,E.LastName
		,E.FirstName 
		,catchment.JunkValue as catchment
		,CareDisability.JunkValue as CareDisabilityJV
		,CareDisability.JunkNK as CareDisabilityNK
		 
INTO #TempEmp
from DW.factProgressNotes FPN with(nolock) 
	  INNER JOIN DW.dimEmployee E with(nolock)ON  E.EmployeeSK = FPN.CaseManagerSK
	  INNER JOIN DW.dimJunk j WITH(NOLOCK)ON FPN.ProgressStatusSK = j.JunkSK
								 and j.JunkEntity = 'ProgressStatus' and j.JunkNK in ('APPROVED','SUBMITTED')
	  INNER JOIN DW.dimJunk Catchment WITH(NOLOCK)ON FPN.CatchmentSK = Catchment.JunkSK
	  INNER JOIN DW.dimServices s WITH(NOLOCK)ON s.ServicesSK = FPN.ServicesSK
	  INNER JOIN DW.dimDate d WITH(NOLOCK)on FPN.DateOfServiceSK = d.DateSK
	  
	  INNER JOIN DW.dimEmployee E2 with(nolock)ON E2.EmployeeNK = E.EmployeeNK
	  INNER JOIN DW.factCareCoordAdmissions FCCA WITH(NOLOCK)ON FCCA.CareCoordinatorSK = E2.EmployeeSK 
	  
	  INNER JOIN DW.dimJunk CareDisability WITH(NOLOCK)ON FCCA.CareDisabilityGroupSK = CareDisability.JunkSK
	  INNER JOIN DW.dimCustomReportGroups g  WITH(NOLOCK)ON  s.ServicesNK = g.AttributeID AND g.CustomGroupName='CareCoordinationService'	
	  
	  INNER JOIN cfn_split(@Catchment,',') fnCatch on Catchment.JunkNK = fnCatch.element 
	  INNER JOIN cfn_split(@CareDisability,',') fnCare on CareDisability.JunkNK  = fnCare.element 
	  WHERE 
		d.DateValue between @str_dt and @end_dt
			
group by E.EmployeeNK 
		 ,E.LastName
		 ,E.FirstName
		 ,Catchment.JunkValue
		 ,CareDisability.JunkValue
		 ,CareDisability.JunkNK

order by E.EmployeeNK	




---------------------
--Combine the columns
---------------------
select distinct
		--catchment =
		--	( SELECT DISTINCT
		--			emp.catchment
		--		FROM
		--			#TempEmp emp
		--		WHERE
		--			emp.EmployeeNK = tc.EmployeeNK
		--	)
	   emp.catchment
	   ,tc.FirstName
	   ,tc.LastName
	   ,ISNULL(tc.HoursOfCareC,0) AS HoursOfCareC
	   ,ISNULL(tt.HoursOfTravel,0) AS HoursOfTravel
	   ,ISNULL(tc.HoursOfCareC,0) + ISNULL(tt.HoursOfTravel,0) as TotalHours
	   ,tc.EmployeeNK

	   
from #TempEmp emp
left JOIN 
#tempCare tc on tc.EmployeeNK = emp.EmployeeNK
left Join #tempTravel tt on tt.EmployeeNK = tc.EmployeeNK


--Where CareDisabilityNK is not null	

order by LastName

				
drop table  #tempCare
drop table  #tempTravel
drop table  #TempEmp

