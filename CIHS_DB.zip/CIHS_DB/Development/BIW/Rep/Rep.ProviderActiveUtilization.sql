USE [BIW]
GO
/****** Object:  StoredProcedure [Rep].[ProviderActiveUtilization]    Script Date: 08/07/2013 11:15:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [Rep].[ProviderActiveUtilization]
    (
		@str_dt datetime, 
		@end_dt datetime,
		@catchment nvarchar(max), 
		@planfund int, 
		@ServiceDefinitionID nvarchar(max)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	Provider Active Utilization
-- File:	[Rep].[Provider Active Utilization]
-- Author:	Ammar Ahmed
-- Date:	07/12/2013
-- Desc:	Provides a grouped listing of service definitions, benefit plans and providers along with a distinct client count of 
--			claims processed within a provided date range.	
--                                          
-- CalledBy:
--          Reports: 
--          Stored Procs: 
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
-- 1.0		07/12/2013  Ammar Ahmed		6477	  Created
--------------------------------------------------------------------------------
--*/		

--declare @str_dt datetime, @end_dt datetime, @catchment nvarchar(max), @planfund int, @ServiceDefinitionID int
--set @str_dt = '1/1/2012'
--set @end_dt ='1/1/2013'
--set @planfund = -200 --Benefit Plan
--set @catchment = -300 --'1024' --
--set @ServiceDefinitionID = -1 --services



select distinct
	p.ProviderNK
	,s.ServiceDefinition
	,bp.BenefitPlan
	,p.ProviderName
	,c.ConsumerNK
	,COUNT(c.ConsumerNK) as 'client count'
	,CAST(CAST(COUNT(c.ConsumerNK)*100/cnt.concount as Decimal(6,2)) as VARCHAR) + '%' as 'PercentOfServiceDefinition'
	,s.ServiceDescription
	,s.ServiceSummary
	,s.ServiceDefinitionID
	,org.CatchmentID
	,org.Catchment

into #tempActiveUtilization
from		   
			   DW.factClaims fc WITH(NOLOCK)
	INNER JOIN DW.dimServices s WITH(NOLOCK)on fc.ServicesSK = s.ServicesSK
	INNER JOIN dbo.cfn_split(@ServiceDefinitionID , ',') fn ON element = s.ServiceDefinitionID
	
	INNER JOIN DW.dimBenefitPlan bp WITH(NOLOCK)on fc.BenefitPlanSK = bp.BenefitPlanSK
	INNER JOIN DW.dimProvider p WITH(NOLOCK)on fc.ProviderSK = p.ProviderSK
	INNER JOIN DW.dimDate d WITH(NOLOCK)on fc.DateOfServiceSK = d.DateSK
	INNER JOIN DW.dimConsumers c WITH(NOLOCK)on fc.ConsumerSK = c.ConsumerSK
	INNER JOIN DW.dimOrganization org WITH(NOLOCK)on org.OrganizationSK = fc.OrganizationSK

	INNER JOIN (
		select distinct 
				s.ServiceDefinitionID, 
				CAST(COUNT(c.ConsumerNK) as Decimal(12,4)) as concount
		from DW.factClaims fc
			,DW.dimDate d
			,DW.dimServices s
			,dw.dimConsumers c
		where d.DateSK = fc.DateOfServiceSK 
				and fc.ConsumerSK = c.ConsumerSK
				and fc.ServicesSK = s.ServicesSK
				and d.DateValue between @str_dt and @end_dt
		group by s.ServiceDefinitionID
	) as cnt on s.ServiceDefinitionID = cnt.ServiceDefinitionID

Where d.DateValue between @str_dt and @end_dt
		and fc.StatusSK = 1
		
		--Catchment
		AND(
				@Catchment = '-300'
				OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
		--Benefit Plan	
		AND(
				( @planfund = bp.BenefitPlanNK ) OR -- 1 specific Plan
				( @planfund = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
				( @planfund = -200 ) -- ALL PLANS
		)
		
		
	group by p.ProviderNK
			,p.ProviderName
			,bp.BenefitPlan
			,c.ConsumerNK
			,s.ServiceDescription
			,s.ServiceSummary
			,s.ServiceDefinitionID
			,cnt.concount
			,org.CatchmentID
			,fc.ServicesSK
			,s.ServicesNK
			,org.CatchmentID
			,org.Catchment
			,s.ServiceDefinitionID
			
			,s.ServiceDefinition
	
order by ConsumerNK



select BenefitPlan as BenefitPlan2 
		,ServiceDefinition as ServiceDefinition2
		,count(*) as BenefitPlanCount 
Into #tempBenefitPlan
from #tempActiveUtilization
group by BenefitPlan
		,ServiceDefinition
order by ServiceDefinition


select * 
from #tempBenefitPlan B
	INNER JOIN #tempActiveUtilization U on U.BenefitPlan = B.BenefitPlan2 
										AND U.ServiceDefinition = B.ServiceDefinition2
	Order by U.ServiceDefinition 


drop table #tempActiveUtilization
drop table #tempBenefitPlan
