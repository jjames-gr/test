USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[ListDiagnosisCode]    Script Date: 06/06/2013 09:22:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [Rep].[ListDiagnosisCode]
AS

/*------------------------------------------------------------------------------
	Title:		[Rep].[ListDiagnosisCode]
	File:		[Rep].[ListDiagnosisCode]
	Author:		Tim Amerson
	Date:		05/30/2013
	Desc:		
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/31/2013		Tim Amerson				----			Drop Down for Diag Group Codes
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		INNER JOIN dbo.cfn_split(@DiagCategory , ',') fnDiag ON fnDiag.element = dd.DiagnosisGroupID
		

	-----------------------------------------------------------------------------------*/

SELECT DISTINCT 
	dd.DiagnosisGroupID
	, dd.DiagnosisGroup
FROM DW.dimDiagnosis as dd with(nolock)
ORDER BY dd.DiagnosisGroup


GO


