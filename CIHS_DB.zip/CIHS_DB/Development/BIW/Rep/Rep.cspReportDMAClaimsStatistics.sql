USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[cspReportDMAClaimsStatistics]    Script Date: 06/18/2013 13:35:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[cspReportDMAClaimsStatistics]
	@str_dt datetime,
	@end_dt datetime
AS
/*------------------------------------------------------------------------------
-- Title:	DMA Claims Statistics
-- File:	[Rep].[cspReportDMAClaimsStatistics]
-- Author:	Brian Angelo
-- Date:	06/17/2013
-- Desc:	DMA Claims Statistics stored proc
--			
-- CalledBy:
-- 		Reports: "DMA Claims Statistics"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	06/17/2013  Brian Angelo		8056	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--Test Parameters
	/*
	DECLARE @str_dt datetime,
			@end_dt datetime
			
	SET @str_dt = '1/1/13'
	SET @end_dt = '7/31/13'
	--*/
	
	;WITH cteAvgDays as (
	SELECT  IsNull(AVG(DATEDIFF(dd, ddRD.DateValue, ddPD.DateValue)),0) as AvgNumDaysProcessing, ddPD.[MonthName_en-US] as [Month]
							FROM [BIW].[DW].[factClaims] fc
							INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH (NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
							AND dbp.InsurerID = 2
							INNER JOIN [BIW].[DW].[dimDate] ddPD WITH (NOLOCK) ON ddPD.DateSK = fc.PaidDateSK
							INNER JOIN [BIW].[DW].[dimDate] ddRD WITH (NOLOCK) ON ddRD.DateSK = fc.ReceivedDateSK
							WHERE ddPD.DateValue between @str_dt and @end_dt
							GROUP BY ddPD.[MonthName_en-US]
	)
	
    SELECT 
    SUM(CASE WHEN ddAD.DateValue between @str_dt and @end_dt THEN 1 ELSE 0 END) as ClaimsReceived
    ,SUM(CASE WHEN ddAD.DateValue between @str_dt and @end_dt and fc.StatusSK = 2 THEN 1 ELSE 0 END) as ClaimsDenied
    ,SUM(CASE WHEN ddPD.DateValue between @str_dt and @end_dt AND DATEDIFF(dd, ddPD.DateValue, ddRD.DateValue) <= 30 THEN 1 ELSE 0 END) as ClaimsReceivedIn30
    ,IsNull(cteAvgDays.AvgNumDaysProcessing, 0) as AvgNumDaysProcessing
    ,ddAD.[MonthName_en-US] as [Month]
    ,ddAD.QuarterInYear as [Quarter]
    ,ddAD.MonthInYear as MonthOrder
    --INTO #Results
    FROM [BIW].[DW].[factClaims] fc
    INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH (NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
		AND dbp.InsurerID = 2
    INNER JOIN [BIW].[DW].[dimDate] ddPD WITH (NOLOCK) ON ddPD.DateSK = fc.PaidDateSK
    INNER JOIN [BIW].[DW].[dimDate] ddAD WITH (NOLOCK) ON ddAD.DateSK = fc.AdjudicationDateSK
    INNER JOIN [BIW].[DW].[dimDate] ddRD WITH (NOLOCK) ON ddRD.DateSK = fc.ReceivedDateSK
    LEFT JOIN cteAvgDays WITH (NOLOCK) ON cteAvgDays.[Month] = ddAD.[MonthName_en-US]
    GROUP BY ddAD.[MonthName_en-US], ddAD.MonthInYear, ddAD.QuarterInYear, cteAvgDays.AvgNumDaysProcessing
    ORDER BY ddAD.MonthInYear

    
END




GO


