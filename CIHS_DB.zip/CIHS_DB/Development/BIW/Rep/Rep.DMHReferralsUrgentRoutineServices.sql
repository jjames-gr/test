USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[DMHReferralsUrgentRoutineServices]    Script Date: 09/05/2013 09:07:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[DMHReferralsUrgentRoutineServices]
	@StartDate datetime,
	@EndDate datetime,
	@SeverityType int,
	@Catchment varchar(50),
	@BenefitPlan int
AS
/*------------------------------------------------------------------------------
-- Title:	DMH Referrals for Urgent and Routine Services
-- File:	[REP].[DMHReferralsUrgentRoutineServices]
-- Author:	Brian Angelo
-- Date:	08/22/2013
-- Desc:	DMH Referrals for Urgent and Routine Services stored proc
--			
-- CalledBy:
-- 		Reports: "DMH Referrals for Urgent and Routine Services"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/22/2013  Brian Angelo		6383	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /* 
	/*** Test Parameters ***/
	DECLARE @StartDate datetime = '1/1/13',
			@EndDate datetime = '1/31/13',
			@SeverityType int = -1,
			@Catchment varchar(50) = '-300',
			@BenefitPlan int = -1
			
	--*/
	
	IF OBJECT_ID('tempdb..#TempAllRecords') IS NOT NULL
		DROP TABLE #TempAllRecords
	
	SELECT DISTINCT
	referraltype.JunkValue as ReferralType
	,referraltype.JunkNK as NeedSeverityID
	,referraltype.JunkValue as NeedSeverity
	,strType.JunkValue as STRType
	,CASE	WHEN dp.ProviderNK = 21491 THEN 'PBH' 
			WHEN dp.ProviderNK = 22945 THEN 'TRIUMPH'
			ELSE dp.ProviderName END AS ProviderName
	,screenDate.DateValue as ScreenDate
	,aptDate.DateValue as AppointmentDate
	,aptStatus.JunkValue as AppointmentStatus
	,fstr.ScreeningTriageReferralID as STRID
	,dcScreening.FullName as ConsumerName
	,dcScreening.ConsumerNK as ConsumerID
	,dcScreening.DOB as DOB
	,dcScreening.County as County
	,IsNull(dpParent.ProviderName,'') + IsNull(dp.ProviderName,'') as [Provider/Site]
	,dac.AppointmentComments as Comments
	,de.FullName as CallCenterRepresentative
	/* Fields needed for logic later on */
	,CAST('1/1/1900' as datetime) as ClaimDate
	,fa.AppointmentID
	INTO #tempAllRecords
	FROM [BIW].[DW].[factAppointments] fa WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[factScreeningTriageReferral] fstr WITH(NOLOCK) ON fa.ScreeningTriageReferralSK = fstr.ScreeningTriageReferralSK
	INNER JOIN [BIW].[DW].[factCalls] fc WITH(NOLOCK) ON fc.CallID = fstr.CallID
	INNER JOIN [BIW].[DW].[dimEmployee] de WITH(NOLOCK) ON de.EmployeeSK = fc.EmployeeSK
	INNER JOIN [BIW].[DW].[dimConsumers] dcScreening WITH(NOLOCK) ON dcScreening.ConsumerSK = fstr.ConsumerSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fa.ProviderSK
	INNER JOIN [BIW].[DW].[dimProvider] dpParent WITH(NOLOCK) ON dp.ParentProviderNK = dpParent.ProviderNK
	INNER JOIN [BIW].[DW].[dimJunk] referraltype WITH(NOLOCK) ON referraltype.JunkSK = fstr.NeedSeveritySK and referraltype.JunkEntity = 'NeedSeverity'
	INNER JOIN [BIW].[DW].[dimJunk] strType WITH(NOLOCK) ON strType.JunkSK = fstr.STREntryType AND strType.JunkEntity = 'EntryType'
	INNER JOIN [BIW].[DW].[dimDate] screenDate WITH(NOLOCK) ON screenDate.DateSK = fstr.ScreenDateSK
	INNER JOIN [BIW].[DW].[dimDate] aptDate WITH(NOLOCK) ON aptDate.DateSK = fa.AppointmentDateSK
	INNER JOIN [BIW].[DW].[dimJunk] aptStatus WITH(NOLOCK) ON aptStatus.JunkSK = fa.AppointmentStatusSK and aptStatus.JunkEntity = 'AppointmentStatus'
	INNER JOIN [BIW].[DW].[dimAppointmentComments] dac WITH(NOLOCK) ON dac.AppointmentCommentsSK = fa.AppointmentCommentsSK
	INNER JOIN [BIW].[DW].[dimJunk] strStatus WITH(NOLOCK) ON strStatus.JunkSK = fstr.CurrentSTRStatusSK AND strStatus.JunkEntity = 'STRStatus'
	INNER JOIN [BIW].[DW].[dimJunk] submitted WITH(NOLOCK) ON submitted.JunkSK = fstr.SubmittedFlagSK AND submitted.JunkEntity = 'Boolean'
	WHERE 1=1
	/* Global Filers */
	AND strStatus.JunkNK in (1,3)
	AND submitted.JunkNK = 1
	AND dcScreening.ConsumerNK > 0
	AND strType.JunkNK in (1,2)
	AND dcScreening.Active = 1
	/* Parameters */
	AND screenDate.DateValue BETWEEN @StartDate AND @EndDate

	
	/* Get newly enrolled consumers */
	IF OBJECT_ID('tempdb..#tempEnrollment') IS NOT NULL
		DROP TABLE #tempEnrollment

	SELECT DISTINCT tar.*
	INTO #tempEnrollment
	FROM #tempAllRecords tar
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerNK = tar.ConsumerID
	WHERE 1=1
	AND dc.CreateDate BETWEEN @StartDate AND @EndDate


	/* Looks for consumers without a claims for the last 60 days whose target pop is not AMSRE */
	IF OBJECT_ID('tempdb..#tempAMSRE') IS NOT NULL
		DROP TABLE #tempAMSRE
	
	SELECT DISTINCT
	tar.ConsumerID
	,DOS.DateValue as ClaimDate
	,fc.ClaimNumber
	INTO #tempAMSRE
	FROM #tempAllRecords tar
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerNK = tar.ConsumerID
	INNER JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
	INNER JOIN [BIW].[DW].[dimDate] DOS WITH(NOLOCK) ON DOS.DateSK = fc.DateOfServiceSK
	WHERE DOS.DateValue BETWEEN DATEADD(dd, -60, tar.ScreenDate) AND DATEADD(dd,1,tar.ScreenDate)
	
	
	/* Selects consumers without claims into new temp table */
	IF OBJECT_ID('tempdb..#tempWithoutClaims') IS NOT NULL
		DROP TABLE #tempWithoutClaims
	
	SELECT tar.*
	INTO #tempWithoutClaims
	FROM #tempAllRecords tar
	WHERE tar.ConsumerID NOT IN (SELECT ConsumerID FROM #tempAMSRE)
	
	/* Selects consumers without claims and enrollment into new temp table */
	IF OBJECT_ID('tempdb..#tempEnrollmentAndWithoutClaims') IS NOT NULL
		DROP TABLE #tempEnrollmentAndWithoutClaims
	
	SELECT * 
	INTO #tempEnrollmentAndWithoutClaims
	FROM #tempWithoutClaims
	UNION ALL
	SELECT * FROM #tempEnrollment
	
	/* Remove AMSRE target pop */
	;With cte_targetpop as
	(
		SELECT ConsumerID
		FROM #tempAllRecords tar
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerNK = tar.ConsumerID
		INNER JOIN [BIW].[DW].[factDMHPopulationGroups] fipg WITH(NOLOCK) ON fipg.ConsumerSK = dc.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDMHPopulationGroups] dipg WITH(NOLOCK) ON fipg.DMHPopulationGroupSK = dipg.DMHPopulationGroupSK
		WHERE 1=1
		AND fipg.ActiveFlag = 1
		AND dipg.DMHPopulationGroupNK = 14
	)
	
	DELETE t
	FROM #tempEnrollmentAndWithoutClaims t, cte_targetpop cte
	WHERE t.ConsumerID = cte.ConsumerID
	
	IF @SeverityType <> -1
		DELETE #tempEnrollmentAndWithoutClaims
		WHERE NeedSeverityID <> @SeverityType
	
	/* Get the minimum claim date */
	;With cte_claims as (
		SELECT ConsumerID,
				MIN(DOS.DateValue) as ClaimDate
		FROM #tempEnrollmentAndWithoutClaims t
		INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerNK = t.ConsumerID
		INNER JOIN [BIW].[DW].[factClaims] fc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
		INNER JOIN [BIW].[DW].[dimDate] DOS WITH(NOLOCK) ON DOS.DateSK = fc.DateOfServiceSK
		WHERE DOS.DateValue >= t.ScreenDate
		GROUP BY ConsumerID
	)
	
	UPDATE t SET
	t.ClaimDate = cte.ClaimDate
	FROM #tempEnrollmentAndWithoutClaims t
	INNER JOIN cte_claims cte ON cte.ConsumerID = t.ConsumerID
	
	
	IF OBJECT_ID('tempdb..#tempMinAptDate') IS NOT NULL
		DROP TABLE #tempMinAptDate
	
	SELECT 
	MIN(AppointmentDate) as AppointmentDate
	,MIN(AppointmentID) as AppointmentID
	,MIN(STRID) as STRID
	,CAST('' as varchar(50)) as AppointmentStatus
	,CAST('' as varchar(max)) as Comments
	,CAST('' as varchar(50)) as STRType
	,t.ClaimDate
	,t.ReferralType
	,t.NeedSeverity
	,t.NeedSeverityID
	,t.ScreenDate
	,t.ConsumerName
	,t.ConsumerID
	,t.County
	,t.DOB
	,t.[Provider/Site]
	,t.ProviderName
	,t.CallCenterRepresentative
	INTO #tempMinAptDate
	FROM #tempEnrollmentAndWithoutClaims t
	GROUP BY 
	t.ClaimDate
	,t.ReferralType
	,t.NeedSeverity
	,t.NeedSeverityID
	,t.ScreenDate
	,t.ConsumerName
	,t.ConsumerID
	,t.County
	,t.DOB
	,t.[Provider/Site]
	,t.ProviderName
	,t.CallCenterRepresentative
	
	
	UPDATE t SET
	t.AppointmentStatus = t1.AppointmentStatus,
	t.Comments = t1.Comments
	FROM #tempMinAptDate t
	INNER JOIN #tempEnrollmentAndWithoutClaims t1 ON t.AppointmentID = t1.AppointmentID
	
	UPDATE t SET
	t.STRType = t1.STRType
	FROM #tempMinAptDate t
	INNER JOIN #tempEnrollmentAndWithoutClaims t1 ON t.STRID = t1.STRID
	
	IF OBJECT_ID('tempdb..#tempServiceDescription') IS NOT NULL
		DROP TABLE #tempServiceDescription
	
	/* Add service to records */
	SELECT t.*
	,ds.ServiceDescription
	,ds.MedicareEligibleCodeFlag as MedicaidEligible
	INTO #tempServiceDescription
	FROM #tempMinAptDate t
	INNER JOIN [BIW].[DW].[factAppointments] fa WITH(NOLOCK) ON fa.AppointmentID = t.AppointmentID
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fa.ServicesSK

	
	/* Eliminate services based on plan and catchment selected */
	SELECT t.*, do.Catchment
	,CASE   WHEN cast(t.MedicaidEligible as bit) = 0 THEN 'State'
			WHEN cast(t.MedicaidEligible as bit) = 1 THEN 'Medicaid'
			ELSE '' END as PlanID
	FROM #tempServiceDescription t
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.County = t.County
	WHERE 1=1
	AND (cast(cast(t.MedicaidEligible as bit) as int) = @BenefitPlan OR @BenefitPlan = -1)
	AND (@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		)
	ORDER BY ConsumerID

	DROP TABLE #tempAllRecords
	DROP TABLE #tempEnrollment
	DROP TABLE #tempAMSRE
	DROP TABLE #tempWithoutClaims
	DROP TABLE #tempEnrollmentAndWithoutClaims
	DROP TABLE #tempMinAptDate
	DROP TABLE #tempServiceDescription
	
END


GO


