USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[cspReportClaimsByServiceDefinition]    Script Date: 03/21/2013 08:36:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [Rep].[cspReportClaimsByServiceDefinition]
	@StartDate DATETIME
	,@EndDate DATETIME
	,@ServDefID NVARCHAR(MAX)
AS

/*------------------------------------------------------------------------------
	Title:		Claims By Service Definition]
	File:		[Rep].[cspReportClaimsByServiceDefinition]
	Author:		Tim Amerson
	Date:		02/20/2013
	Desc:		Claim detail listed by ClientID and Service Delivered.
				Provides claims detail by service definition.  Used to 
					list claim detail by service, client/consumer, date,
					county, insurance and provider.
                                        
	Called By:
                        Reports:          CL369ClaimsByServiceDefinition
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/18/2013		Tim Amerson     		6311			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '10/1/2012',
--	@EndDate DATETIME = '12/31/2012',
--	@ServDefID NVARCHAR(MAX) = '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30'
	
SELECT --DISTINCT
	cons.ConsumerNK
	,cons.FirstName
	,cons.LastName
	,cons.MiddleName
	,claims.ClaimNumber
	,srvc.ServiceDefinitionID
	,srvc.ServiceDefinition
	,claims.AdjudicatedAmount
	,ben.BenefitPlanShort
	,cons.DOB
	,org.County
	,cons.Gender
	,diag.DiagnosisGroup
	,srvc.Modifier1 + ' ' + srvc.Modifier2 AS Modifier
	,srvc.ServiceDescriptionShort
	,srvc.ServiceDescription
	,prov.ProviderNK
	
FROM
	DW.factClaims claims
	INNER JOIN DW.dimDate dttm ON claims.DateOfServiceSK = dttm.DateSK
	INNER JOIN DW.dimConsumers cons ON claims.ConsumerSK = cons.ConsumerSK
	INNER JOIN DW.dimServices srvc ON claims.ServicesSK = srvc.ServicesSK
	INNER JOIN DW.dimBenefitPlan ben ON claims.BenefitPlanSK = ben.BenefitPlanSK
	INNER JOIN DW.dimOrganization org ON claims.OrganizationSK = org.OrganizationSK
	INNER JOIN DW.dimDiagnosis diag ON claims.Diagnosis1SK = diag.DiagnosisSK
	INNER JOIN DW.dimProvider prov ON claims.ProviderSK = prov.ProviderSK
	INNER JOIN dbo.cfn_split(@ServDefID , ',') fn ON element = srvc.ServiceDefinitionID
	
WHERE
	claims.StatusSK = 1
	AND claims.AdjudicatedAmount > 0
	AND dttm.DateValue BETWEEN @StartDate AND @EndDate
	
ORDER BY
	cons.LastName
	,cons.FirstName
GO


