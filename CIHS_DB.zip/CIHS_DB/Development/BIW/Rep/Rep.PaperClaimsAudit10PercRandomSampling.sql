USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create procedure [Rep].[PaperClaimsAudit10PercRandomSampling]
@adj_str_dt datetime, @adj_end_dt datetime, @bill_type int

as
/*------------------------------------------------------------------------------
	Title:		Paper Claims Audit - 10% Random Sampling
	File:		[PaperClaimsAudit10PercRandomSampling]
	Author:		Karen Roslund
	Date:		05/24/2013
	Desc:		To audit a random sampling of manual claims to verify correct data entered and processed.
                                        
	Called By:
                        Reports:          PaperClaimsAudit10PercRandomSampling
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/24/2013		Karen Roslund 			6450			Created

	-----------------------------------------------------------------------------------*/



--declare @adj_str_dt datetime, @adj_end_dt datetime, @bill_type int

--set @adj_str_dt = '5/1/2013'
--set @adj_end_dt = '5/30/2013'
--set @bill_type  = 28


/*
26	IP	ClaimType	Institution Paper ub
27	PF	ClaimType	Provider File
28	PP	ClaimType	Provider Paper cms1500
*/

create table #temp
(
prov_name varchar(500),
Provider_direct_claim int,
Consumer_name varchar(1000),
Consumer_DOB date,
Diagnosis_code varchar(20),
DOS_start_date date,
DOS_end_date date,
Place_Of_service varchar(5000),
Service_code varchar(20),
service_description varchar(5000),
Modifier1 varchar(10),
Modifier2 Varchar(10),
Diagnosis_group_id int,
Claim_amount money,
Units_billed int,
Provider_NPI varchar(200),
COB_Amount money,
COB_Reason varchar(5000),
Type_Of_bill varchar(200),
Revenue_Code varchar(200),
Date_Of_service datetime,
Primary_Payer varchar(200),
Secondary_Payer varchar(200),
Health_plan_id  int,
Secondary_health_plan_id int,
Diagnosis_codes2 varchar(200),
clinician_name varchar(200),
Clinician_license_no varchar(200),
Clinician_NPI varchar(200)

)

IF @bill_type = 28
begin
---CMS 1500
select 
p.ProviderName,
fc.ReferenceNumber,
fc.claimnumber,
fc.ClaimDetailNumber,
c.FullName,
c.DOB,
d.DiagnosisCode,
d.DiagnosisGroupID,
(  (dos.DateValue  )) start_dt,    
((dos.DateValue))  End_dt,
pos.PlaceOfService,
ds.ServiceCode,
ds.Modifier1,
ds.Modifier2,
fc.ClaimAmount,
fc.UnitsBilled,
p.NPI,
fc.COBAmount,
rc.Description

into #temp2

from
	DW.factClaims fc with (nolock)
	Inner Join Dw.dimProvider p with (nolock) on fc.ProviderSK = p.ProviderSK 
	inner join dw.dimConsumers c with (nolock) on fc.ConsumerSK = c.ConsumerSK 
	Inner Join dw.dimDiagnosis d with (nolock)on fc.Diagnosis1SK = d.DiagnosisSK 
	Inner join dw.dimDate dd with (nolock) on fc.adjudicationdatesk = dd.DateSK 
	Inner join DW.dimDate dos with (nolock) on fc.DateOfServiceSK = dos.DateSK 
	Inner join dw.dimServices ds with (nolock) on fc.ServicesSK = ds.ServicesSK
	Inner Join dw.dimReasonCodes rc with (nolock) on fc.ReasonCodeSK = rc.ReasonCodeSK 
	Inner Join dw.dimPlaceOfService pos with (nolock) on fc.PlaceOfServiceSK = pos.PlaceOfServiceSK 
	 
where
		dd.DateValue between @adj_str_dt and @adj_end_dt 
	AND
		fc.PaperClaimSK =18
	and fc.ClaimTypeSK = 28
	AND p.ProviderNK <> 20790
	--and ClaimNumber  = 6006083 

	--select * from #temp2 order by start_dt 
	;with Cte_Min_max as 
	(
	select distinct cast(MIN(start_dt) as date) dos_str,cast(MAX(end_dt) as date) dos_end, ClaimNumber
	from #temp2 
    group by ClaimNumber)
    
    Insert into #temp
    (prov_name,Provider_direct_claim,Consumer_name,Consumer_DOB,Diagnosis_code,DOS_start_date,DOS_end_date,Place_Of_service,service_code,Modifier1,Modifier2,Diagnosis_group_id,Claim_amount,Units_billed,Provider_NPI,COB_Amount,COB_Reason)
    select ProviderName,ReferenceNumber,FullName,DOB,DiagnosisCode,dt.dos_str,dt.dos_end,PlaceOfService,ServiceCode,Modifier1,Modifier2,DiagnosisGroupID,ClaimAmount,UnitsBilled,NPI,COBAmount,Description   from #temp2 t inner join Cte_Min_max  dt on t.ClaimNumber =  dt.ClaimNumber  
    
    drop table #temp2 
    
   End
    
    --select * from cte_min_max order by ClaimNumber 
    
    
---UB04
IF @bill_type = 26
Begin
select 
p.ProviderName ,
--p.ProviderSK,
fc.ReferenceNumber,
fc.ClaimNumber,
fc.ClaimDetailNumber,
bt.BillTypeName,
(dos.[DateValue] )  start_dt,    
(dos.DateValue )  End_dt,
c.FullName cons_full_name,
c.DOB,
fc.ServiceLineRevenueCode,
ds.ServiceCode,
ds.ServiceDescription,
dos.DateValue  claim_dt,
fc.UnitsBilled,
fc.ClaimAmount,
bp.BenefitPlan,
fc.cobplan,
bp.BenefitPlanNK,
fc.COBAmount,
diag1.DiagnosisCode diag_code1,
diag2.DiagnosisCode diag_code2, 
clin.FullName clin_full_name,
fclinlic.LicenseNumber,
fclinlic.ClinicianLicenseNK,
npi.NPINumber 

into #temp1

from
	DW.factClaims fc with (nolock)
	Inner Join Dw.dimProvider p with (nolock) on fc.ProviderSK = p.ProviderSK 
	inner join dw.dimConsumers c with (nolock) on fc.ConsumerSK = c.ConsumerSK 
	Inner Join dw.dimDiagnosis diag1 with (nolock)on fc.Diagnosis1SK = diag1.DiagnosisSK 
	Inner Join dw.dimDiagnosis diag2 with (nolock)on fc.Diagnosis2SK = diag2.DiagnosisSK 
	Inner join dw.dimDate dd with (nolock) on fc.AdjudicationDateSK  = dd.DateSK 
	Inner join dw.dimDate dos with (nolock) on fc.DateOfServiceSK   = dos.DateSK 
	Inner join dw.dimServices ds with (nolock) on fc.ServicesSK = ds.ServicesSK
	Inner join dw.dimBillType bt with (nolock) on fc.BillTypeSK = bt.BillTypeSK 
	Inner join dw.dimBenefitPlan bp with (nolock) on fc.BenefitPlanSK = bp.BenefitPlanSK 
	Inner join dw.dimClinician clin with (nolock) on fc.ClinicianSK = clin.ClinicianSK 
	left outer  join dw.factClinicianLicense fclinlic with (nolock) on clin.ClinicianSK = fclinlic.ClinicianSK 
	left outer Join dw.factProviderNPIMedicaidID npi with (nolock) on fc.ProviderSK = npi.ProviderSK and npi.ActiveFlag = 1
where
		dd.DateValue between @adj_str_dt and @adj_end_dt 
	AND
		fc.PaperClaimSK =18
	and fc.ClaimTypeSK = 26
	AND p.ProviderNK <> 20790
	--and fc.ReferenceNumber = 1287323
	--and dos.DateValue = '3/15/2013'
	
	;with Cte_Min_max as 
	(
	select distinct cast(MIN(start_dt) as date) dos_str,cast(MAX(end_dt) as DATE) dos_end, ClaimNumber
	from #temp1 
    group by ClaimNumber)
    
    Insert into #temp
    (prov_name,Provider_direct_claim,Type_Of_bill,DOS_start_date,DOS_end_date,Consumer_name,Consumer_DOB,Revenue_Code,Service_code,service_description,Date_Of_service,Units_billed,Claim_amount,Primary_Payer,Secondary_Payer,Health_plan_id, COB_Amount,Diagnosis_code,Diagnosis_codes2,clinician_name,Clinician_license_no,Clinician_NPI)
    select ProviderName,ReferenceNumber,BillTypeName,dt.dos_str,dt.dos_end,cons_full_name,DOB,ServiceLineRevenueCode,ServiceCode,ServiceDescription,claim_dt,UnitsBilled,ClaimAmount,BenefitPlan,COBPlan,BenefitPlanNK,COBAmount,diag_code1,diag_code2,clin_full_name,ClinicianLicenseNK,NPINumber    
     from #temp1 t inner join Cte_Min_max  dt on t.ClaimNumber =  dt.ClaimNumber  
	drop table #temp1 
	
	End
	
	
	DECLARE @cnt INT
        DECLARE @cntpercent INT
        DECLARE @cntline INT
        SELECT  @cnt = COUNT(*)
        FROM    #temp   
        SELECT  @cntpercent = ROUND(@cnt * .10, 0)
/*--select top (@cntpercent) * from #audit order by newId() */
        SET ROWCOUNT  @cntpercent
        SELECT  *
        FROM    #temp 
        ORDER BY NEWID()
        SET ROWCOUNT 0
	
	
	
	drop table #temp 


	
	--select top 1 * from  dw.factClinicianLicense 