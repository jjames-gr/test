USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ConsumerURSelectionReport]    Script Date: 08/08/2013 15:22:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [REP].[ConsumerURSelectionReport]
	@StartDate DATETIME,
	@EndDate DATETIME,
	@DiagCategory NVARCHAR(MAX),
	@BenPlan INT,
	@Catchment NVARCHAR(MAX),
	@ServiceDescription NVARCHAR(MAX),
	@SortColumn NVARCHAR(MAX),
	@ReportOutput INT
AS

/*
	------------------------------------------------------------------------------
	Title:		Consumer UR Selection Report
	File:		[Rep].[ConsumerURSelectionReport]
	Author:		Tim Amerson
	Date:		06/06/2013
	Desc:		Tool used to select and track random 5 client for UR.
				Clinical Operations is responsible for completing Utilization Review
				(both routine and focused) on all providers. This report provides a
				sample of charts to be reviewed for the UR process.
                                        
	Called By:
                        Reports:	UMA008 - Consumer UR Selection Report
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/06/2013		Tim Amerson     		6326			Created
			2.0		08/08/2013		Justin Ward				6326			Changed ClaimAmount to AdjudicationAmount

	-----------------------------------------------------------------------------------
*/

--DECLARE
--	@StartDate DATETIME = '1/1/2013',
--	@EndDate DATETIME = '1/31/2013',
--	@DiagCategory NVARCHAR(MAX) = '1,2,3,4,-1,-2',
--	@BenPlan INT = -200,
--	@Catchment NVARCHAR(MAX) = -300,
--	--@ServiceSummary NVARCHAR(MAX) = '',
--	@ServiceDescription NVARCHAR(MAX) = '1,2,3,4,5,6,100,101,102,103',
--	@SortColumn NVARCHAR(MAX) = 'TotalClaimsAmount',
--	@ReportOutput INT = 3
	
DECLARE
	@sortOrder NVARCHAR(MAX),
	@percent NVARCHAR(MAX)

IF @ReportOutput IN ( 1, 3 )
	BEGIN
		SET @sortOrder = 'ASC'
	END
	
ELSE IF @ReportOutput = 2
	BEGIN
		SET @sortOrder = 'DESC'
	END
	
IF @ReportOutput = 1
	BEGIN
		SET @percent = 100
	END
	
ELSE IF @ReportOutput <> 1
	BEGIN
		SET @percent = 10
	END

/*Parameter definitions for dynamic SQL*/
DECLARE
	@ParameterDefinition NVARCHAR(MAX) = '@StartDate DATETIME,
		@EndDate DATETIME,
		@DiagCategory NVARCHAR(MAX),
		@BenPlan INT,
		@Catchment NVARCHAR(MAX),
		@ServiceDescription NVARCHAR(MAX)'

/*Dynamic SQL Declaration*/
DECLARE 
	@SQL NVARCHAR(MAX) = '
		SELECT TOP ' + @percent + ' PERCENT
			dc.ConsumerNK
			, dc.LastName
			, dc.FirstName
			, dc.DOB
			, ds.ServiceCode
			, ds.ServiceDescription
			, dp.ProviderName
			, do.Catchment
			, dd.DiagnosisCode
			, dd.DiagnosisName
			, SUM(fc.UnitsClaimed) AS UnitsClaimed
			, SUM(fc.AdjudicatedAmount) AS TotalClaimsAmount
		
		FROM
			dw.factClaims fc WITH(NOLOCK)
			INNER JOIN dw.dimDate dos WITH(NOLOCK) ON fc.DateOfServiceSK = dos.DateSK
			INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
			INNER JOIN dw.dimProvider dp WITH(NOLOCK) ON fc.ProviderSK = dp.ProviderSK
			INNER JOIN dw.dimServices ds WITH(NOLOCK) ON fc.ServicesSK = ds.ServicesSK
			INNER JOIN dw.dimDiagnosis dd WITH(NOLOCK) ON fc.Diagnosis1SK = dd.DiagnosisSK
			INNER JOIN dw.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK = bp.BenefitPlanSK
			INNER JOIN dw.dimOrganization do WITH(NOLOCK) ON fc.OrganizationSK = do.OrganizationSK
			INNER JOIN dbo.cfn_split(@DiagCategory, '','') fnDiag ON fnDiag.element = dd.DiagnosisGroupID
			INNER JOIN dbo.cfn_split(@ServiceDescription, '','') fnSrvDesc ON fnSrvDesc.element = ds.ServicesNK
			
		WHERE
			dos.DateValue BETWEEN @StartDate AND @EndDate
			AND fc.StatusSK = 1
			AND
			(
				( @BenPlan = bp.BenefitPlanNK ) OR -- 1 specific Plan
				( @BenPlan = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
				( @BenPlan = -200 ) -- ALL PLANS
			)
			
			AND
			(
	
				@catchment = ''-300''
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, '','') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, '','') )

			)
			
		GROUP BY
			dc.ConsumerNK
			, dc.LastName
			, dc.FirstName
			, dc.DOB
			, ds.ServiceCode
			, ds.ServiceDescription
			, dp.ProviderName
			, do.Catchment
			, dd.DiagnosisCode
			, dd.DiagnosisName
		
		ORDER BY ' +
			@SortColumn + ' ' + @sortOrder
			
/*
	Execute dynamic SQL with SQL Query, Parameter Definitions,
	and Individual Parameters passed in execute command
*/
EXECUTE
	sp_executesql
		@SQL, 
		@ParameterDefinition,
		@StartDate,
		@EndDate,
		@DiagCategory,
		@BenPlan,
		@Catchment,
		@ServiceDescription


