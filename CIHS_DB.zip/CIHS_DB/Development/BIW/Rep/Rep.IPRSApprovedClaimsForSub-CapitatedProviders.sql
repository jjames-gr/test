USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[IPRSApprovedClaimsForSub-CapitatedProviders]    Script Date: 09/09/2013 13:05:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO










CREATE PROCEDURE [REP].[IPRSApprovedClaimsForSub-CapitatedProviders]
	@StartDate DATETIME
	,@EndDate DATETIME
	,@Catchment NVARCHAR(MAX)
AS

/*------------------------------------------------------------------------------
	Title:		IPRS Approved Claims for Sub-Capitated Providers
	File:		[Rep].[IPRSApprovedClaimsForSub-CapitatedProviders]
	Author:		Divya Lakshmi
	Date:		04/25/2013
	Desc:		Total cost of services on claims approved by IPRS are needed to 
	            complete UCR and Non-UCR reporting for sub-capitated providers which 
	            is required by the State. 
                                        
	Called By:
                        Reports:          FIN022 - IPRSApprovedClaimsForSub-CapitatedProviders
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/25/2013		Divya Lakshmi    		6421			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2012',
--	@EndDate DATETIME = '1/31/2012',
--	@Catchment NVARCHAR(MAX) = -2

;with cte as(SELECT DISTINCT
fc.claimadjudicationnumber,
p.ProviderNK ProviderID,
p.ProviderName,
fc.AdjudicatedAmount ,
cons.consumernk,
CASE  WHEN S.ServicesNK = 1  AND P.ICF = 'True' THEN 'ICF'
      WHEN S.ServicesNK = 1 AND P.ICF = 'False' then 'Inpatient'  
      ELSE S.ServiceSummary
      END AS ServiceSummary,
CASE  WHEN org.Catchment= '' or org.Catchment IS null THEN 'OOC'
ELSE org.Catchment
END AS Catchment
	
FROM
	DW.factClaims fc WITH(NOLOCK) 
	INNER JOIN DW.dimDate dt WITH(NOLOCK) ON fc.DateOfServiceSK = dt.DateSK
	INNER JOIN DW.dimProvider p WITH(NOLOCK) ON fc.ProviderSK = p.ProviderSK
	INNER JOIN DW.dimConsumers cons WITH(NOLOCK) ON fc.ConsumerSK = cons.ConsumerSK
	INNER JOIN DW.dimServices s WITH(NOLOCK) ON fc.ServicesSK = s.ServicesSK
	INNER JOIN DW.dimOrganization org WITH(NOLOCK) ON fc.OrganizationSK = org.OrganizationSK
	INNER JOIN DW.dimJunk jcap WITH(NOLOCK) ON jcap.JunkSK = fc.CapitatedSK  and jcap.JunkEntity='ClaimCapitatedFlag'


WHERE
    jcap.JunkNK='1'
	AND fc.DMHSentStatusCode = 'A'
	AND dt.DateValue BETWEEN @StartDate AND @EndDate
	AND (@catchment = '-2'
				OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				)
)
	
SELECT ProviderID,
       ProviderName,
       sum(AdjudicatedAmount) Amt,
       ServiceSummary,
       Catchment 
FROM cte
GROUP BY ProviderID,
         ProviderName,
         ServiceSummary,
         Catchment
ORDER BY ProviderName










GO


