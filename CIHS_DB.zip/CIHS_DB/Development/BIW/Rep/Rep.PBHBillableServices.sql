USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[PBHBillableServices]    Script Date: 09/18/2013 10:13:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [REP].[PBHBillableServices]
@str_dt DATETIME ,
@end_dt DATETIME
AS

/*------------------------------------------------------------------------------
	Title:		Billable Service Codes			
	File:		[Rep].[PBHBillableServices]
	Author:		Kevin Hamilton	
	Date:		08/14/2013
	Desc:		Active Billable Services with Payer by Date range. 			
	
			

                                        
	Called By:
                        Reports:        CDS001-BillableServices.rdl
			


                       
	-----------------------------------------------------------------------------------
	Version History:()
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/14/2013		Kevin Hamilton     		6453			Created

--------------------------------------------------------------------------------------*/
--DECLARE
--@str_dt DATETIME ,
--@end_dt DATETIME

--SET @str_dt = '1/1/2013'
--SET @end_dt = '3/1/2013'
 





 SELECT DISTINCT
 s.ServicesNK,
 s.ServiceCode,
 s.Modifier1,
 s.Modifier2,
 s.ServiceDescription,
 MAX(CASE WHEN MedTP.COBInsurance like '%Medicare%' AND  s.MedicareEligibleCodeFlag = 'True'
		THEN 'X' 
		ELSE ''
	END)  as Medicare,
 MAX(CASE WHEN MedTP.COBInsurance not like '%Medicare%' AND s.MedicareEligibleCodeFlag = 'False' 
		THEN 'X' 
		ELSE ''
	END)  as [ThirdParty],
 MAX(CASE WHEN ben.BenefitPlanNK = 7 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS HealthChoiceNC,
 MAX(CASE WHEN ben.BenefitPlanNK = 8 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS IAFT,
 MAX(CASE WHEN ben.BenefitPlanNK = 3 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS MedicaidB,
 MAX(CASE WHEN ben.BenefitPlanNK = 6 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS MedicaidB3,
 MAX(CASE WHEN ben.BenefitPlanNK = 4 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS MedicaidC,
 MAX(CASE WHEN ben.BenefitPlanNK = 5 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS MedicaidDI,
 MAX(CASE WHEN ben.BenefitPlanNK = 2 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS MedicaidFFS,
 MAX(CASE WHEN ben.BenefitPlanNK = 1 AND fsb.BillableFlag =1
		THEN 'X'
		ELSE ''
	END) AS [State]
	
		

 FROM 
 DW.factServicesBenefitPlan fsb
 INNER JOIN  DW.dimServices s with(nolock) ON fsb.ServicesSK = s.ServicesSK 
 INNER JOIN  DW.dimBenefitPlan ben with(nolock) ON ben.BenefitPlanSK = fsb.BenefitPlanSK
 
 LEFT JOIN (SELECT DISTINCT fc.COBInsurance, ds.ServicesNK 
			 FROM dw.factClaims fc with(nolock)
			 INNER JOIN dw.dimServices ds with(nolock) ON fc.ServicesSK = ds.ServicesSK 
				 AND ds.ServiceDefinitionID  <> -1
			 ) as MedTP ON  MedTP.ServicesNK = s.ServicesNK  
			 
 INNER JOIN dw.dimDate ddeff with(nolock) ON fsb.EffectiveDateSK  = ddeff.DateSK
 LEFT JOIN dw.dimDate ddend with(nolock) ON fsb.ExpirationDateSK  = ddend.DateSK
 	
			


 
WHERE
s.Active = 1
 AND s.ServiceDefinitionID  <> -1
AND s.ServicesNK <> -1
AND BenefitPlanNK NOT IN(-1,99)
AND ddeff.DateValue <= @end_dt
AND ISNULL(ddend.DateValue, '1/1/2099') >=@str_dt 

	
 
 GROUP BY s.ServicesNK, s.ServiceCode, s.Modifier1, s.Modifier2, s.ServiceDescription 
 ORDER BY s.ServicesNK
 
 

