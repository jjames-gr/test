USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[ListCapitatedFlag]    Script Date: 06/06/2013 09:22:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [Rep].[ListCapitatedFlag]
AS

/*------------------------------------------------------------------------------
	Title:		[Rep].[ListCapitatedFlag]
	File:		[Rep].[ListCapitatedFlag]
	Author:		Tim Amerson
	Date:		05/30/2013
	Desc:		
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/31/2013		Tim Amerson				----			Drop Down for Capitated Flags
	
	Usage directions:
	-- Add the following to your FROM CLAUSE:
		INNER JOIN dbo.cfn_split(@DiagCategory , ',') fnDiag ON fnDiag.element = dd.DiagnosisGroupID
		

	-----------------------------------------------------------------------------------*/

SELECT DISTINCT 
	cap.JunkSK
	, cap.JunkNK
	, cap.JunkValue
FROM DW.dimJunk cap with(nolock)
WHERE cap.JunkEntity = 'ClaimCapitatedFlag'
ORDER BY cap.JunkValue


GO


