USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[DMALanguageDiversity]    Script Date: 06/07/2013 10:27:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[DMALanguageDiversity] 
(
	@strDate DATETIME,
	@endDate DATETIME,
	@insPlan INT,
	@catchment INT 
)AS
/*------------------------------------------------------------------------------
	Title:		DMA Language Diversity of Membership
	File:		[Rep].[DMALanguageDiversity]
	Author:		Karissa Martindale
	Date:		05/22/13
	Desc:		Unduplicated count of Consumers enrolled any time during the measurement year by language.
                                        
	Called By:
                        Reports:          STA003 - DMALanguageDiversity
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/22/2013		Karissa Martindale   	6732			Created
	
-----------------------------------------------------------------------------------*/
--DECLARE
--	@strDate DATETIME = '1/1/12',
--	@endDate DATETIME = '1/3/12',
--	@insPlan INT = -200,
--	@catchment INT = 1021

SELECT DISTINCT
	dCon.ConsumerNK,
	dCon.FullName,
	CASE 
	WHEN dCon.[Language] = '--Unknown--' THEN 'Unknown'
	WHEN  dCon.[Language] is null THEN 'Unknown'
	ELSE dCon.[Language]
	END as [Language],
	ISNULL(NULLIF(dCon.GenderCode, '--'), 'U') as GenderCode,
	COUNT(DISTINCT ConsumerNK) as number,
	dOrg.Catchment
FROM BIW.DW.factEligibility fElig WITH(NOLOCK) 
	 INNER JOIN BIW.DW.dimConsumers dCon WITH(NOLOCK) ON fElig.ConsumerSK = dCon.ConsumerSK
	 INNER JOIN BIW.DW.dimOrganization dOrg WITH(NOLOCK) ON fElig.OrganizationSK = dOrg.OrganizationSK
	 INNER JOIN BIW.DW.dimBenefitPlan dimBenP WITH(NOLOCK) ON fElig.BenefitPlanSK = dimBenP.BenefitPlanSK
	 INNER JOIN BIW.DW.dimDate dDate WITH(NOLOCK) ON fElig.DateSK = dDate.DateSK
	 INNER JOIN BIW.DW.dimDate dExp WITH(NOLOCK) ON ISNULL(NULLIF(fElig.ExpirationDateSK, -1), 29990101) = dExp.DateSK
WHERE
	dDate.DateValue <= @strDate 
	AND dExp.DateValue >= @endDate
	AND ( 
		@catchment = -2 OR -- All Catchments
		dOrg.OrganizationNK = @catchment OR -- Specific County
		dOrg.CatchmentID = @catchment -- Specific Catchment
	)
	AND(
		( @insPlan = dimBenP.BenefitPlanSK ) OR -- 1 specific Plan
		( @insPlan = -100 AND dimBenP.InsurerID = 2 ) OR -- ALL Medicaid
		( @insPlan = -200 ) -- ALL PLANS
	)
GROUP BY
	dOrg.Catchment, dCon.ConsumerNK, dCon.FullName, dCon.Language, dCon.GenderCode
ORDER BY
	dCon.ConsumerNK