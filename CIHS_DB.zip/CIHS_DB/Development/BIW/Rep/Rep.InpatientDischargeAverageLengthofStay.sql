USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[InpatientDischargeAverageLengthofStay]    Script Date: 09/12/2013 09:45:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[InpatientDischargeAverageLengthofStay] 
(
	@strDate DATETIME,
	@endDate DATETIME,
	@srcDef INT,
	@insurance INT,
	@diagCat INT,
	@catchment NVARCHAR(MAX)
)
AS 

/*------------------------------------------------------------------------------
	Title:		Inpatient Discharge and Average Length of Stay	
	File:	    [REP].[InpatientDischargeAverageLengthofStay] 
	Author:		Karissa Martindale
	Date:		6/24/2013
	Desc:		Identifies Inpatient Discharges and Length of Stay for consumers. 
				The detail report will display additional information about the services received and diagnosis assigned.						
                                        
	Called By:
                        Reports:          STP006 - InpatientDischargeAverageLengthofStay
                        Stored Procs:     [REP].[InpatientDischargeAverageLengthofStay] 
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		6/24/2013		Karissa Martindale    	6414    		Created
			2.0		8/19/2013		Justin Ward				6414			Added Provider ID

--	-----------------------------------------------------------------------------------*/


--DECLARE
--	@strDate DATETIME ='1/1/13',
--	@endDate DATETIME = '3/31/13',
--	@srcDef INT = -300,
--	@insurance INT = -2,
--	@diagCat INT = 4,
--	@catchment NVARCHAR(MAX) = '1021,1022,1023,1024'
--	--@reportType

/*
	
	--Member Months Eligibility Logic--
	
	Consumers can only have a max of 12 months eligibility in a given year
	Pulled based on Medicaid first and State second
	State pulled where consumers DO NOT have Medicaid
	Age calculated based on the first day of any given month
	
*/
select distinct
	dc.ConsumerNK as Consumer_ID,
	dc.FullName as Consumer_Name,
	Gender =
		CASE
			WHEN dc.Gender = 'Unspecified' THEN 'Unknown'
			ELSE dc.Gender
		END,
	delig.DateValue  dateelig,
	dc.DOB,
	1 as member_count,
	AgeValue =
		CASE
			WHEN datepart(mm,dc.DOB) <> datepart(mm,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
			WHEN datepart(dd,dc.DOB) = datepart(dd,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
			ELSE DATEDIFF(mm,dc.dob,delig.datevalue)/12 - 1
		END
	
into
	#tmpMemberMonths

from
	dw.factEligibility fe with (nolock)
	Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
	Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
	Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
	inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
	inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK
	inner join dw.dimAge da with(nolock) on fe.AgeSK = da.AgeSK 
	inner join dw.dimJunk dj with (nolock) on fe.ActionSK = dj.JunkSK

Where 1=1
	
	AND delig.DateValue between @strDate and @endDate
	and
	(
		@catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)
	and dbp.InsurerID = 2
		
	and dc.ConsumerNK <> -1
	and dj.JunkValue = 'Active'

IF @insurance IN (1,-2)
	BEGIN

		insert into #tmpMemberMonths

		select distinct
			dc.ConsumerNK as Consumer_ID,
			dc.FullName as Consumer_Name,
			Gender =
				CASE
					WHEN dc.Gender = 'Unspecified' THEN 'Unknown'
					ELSE dc.Gender
				END,
			delig.DateValue  dateelig,
			dc.DOB,
			1 as member_count,
			AgeValue =
				CASE
					WHEN datepart(mm,dc.DOB) <> datepart(mm,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
					WHEN datepart(dd,dc.DOB) = datepart(dd,delig.datevalue) THEN DATEDIFF(mm,dc.dob,delig.datevalue)/12
					ELSE DATEDIFF(mm,dc.dob,delig.datevalue)/12 - 1
				END

		from
			dw.factEligibility fe with (nolock)
			Inner Join dw.dimDate delig with (nolock) on fe.DateSK = delig.DateSK 
			Inner join dw.dimDate dexp with (nolock) on fe.ExpirationDateSK = dexp.DateSK 
			Inner join DW.dimBenefitPlan dbp with (nolock) on fe.BenefitPlanSK = dbp.BenefitPlanSK 
			inner join dw.dimOrganization do with (nolock) on fe.OrganizationSK = do.OrganizationSK 
			inner join DW.dimConsumers dc with (nolock) on fe.ConsumerSK = dc.ConsumerSK
			inner join dw.dimAge da with(nolock) on fe.AgeSK = da.AgeSK 
			inner join dw.dimJunk dj with (nolock) on fe.ActionSK = dj.JunkSK

		Where 1=1

			AND dc.ConsumerNK NOT IN ( SELECT t.Consumer_ID FROM #tmpMemberMonths t )
			
			AND delig.DateValue between @strDate and @endDate
			and
			(
				@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
			and dbp.InsurerID = 1
				
			and dc.ConsumerNK <> -1
			and dj.JunkValue = 'Active'
	END
          
CREATE CLUSTERED INDEX idx_tmpConsumer ON #tmpMemberMonths (Consumer_ID);

		    
CREATE TABLE #tmpInpDischALOS
        (
		  rptOrder INT,
          age CHAR(20) ,
          gender varCHAR(500) ,
          cnt float,
          eligible_month FLOAT ,
          DischPerThou FLOAT,
          [Days] float,
          ALOS float,
          Report_type varchar(500),
          
          Client_Name varchar(MAX),
          Client_ID int,
          Client_DOB datetime,
          Client_Age int,
          Claim_Number int,
          Admit_Dt datetime,
          Disch_Dt datetime,
          Service_code varchar(500),
          Bill_Code varchar(500),
          Client_DX  varchar(500),
          Client_DX_Group varchar(500),
          Provider_Name varchar(max),
          Provider_ID int,
          LengthOfStay int,
          MemberMonths int,
        )


--Insert blank values that ensure every group shows on report even if no data exists
    INSERT  INTO #tmpInpDischALOS (rptOrder,age,gender,cnt,eligible_month,DischPerThou,[Days],ALOS,Report_type)
    
    SELECT 100, 'Age ' + crg.CustomGroupValue, 'Male', 0, 0, 0, 0 , 0, 'MemberMonths'
	FROM biw.dw.dimCustomReportGroups crg where crg.CustomGroupName = 'InpatientDischargeAverageLengthofStayCustomAgeGroup'
	
	UNION ALL
	
	SELECT 200, 'Age ' + crg.CustomGroupValue, 'Female', 0, 0, 0, 0 , 0, 'MemberMonths'
	FROM biw.dw.dimCustomReportGroups crg where crg.CustomGroupName = 'InpatientDischargeAverageLengthofStayCustomAgeGroup'
	
	UNION ALL
	
	SELECT 300, 'Age ' + crg.CustomGroupValue, 'Unknown', 0, 0, 0, 0 , 0, 'MemberMonths'
	FROM biw.dw.dimCustomReportGroups crg where crg.CustomGroupName = 'InpatientDischargeAverageLengthofStayCustomAgeGroup'

;WITH cteEligAgg AS
(
	SELECT
		elig.Consumer_ID
		,SUM(elig.member_count) as MemberMonths
	FROM
		#tmpMemberMonths elig
	GROUP BY
		elig.Consumer_ID
)


insert into #tmpInpDischALOS


SELECT DISTINCT
	rptOrder =
		CASE
			WHEN dcon.Gender = 'MALE' THEN 100
			WHEN dCon.Gender = 'FEMALE' THEN 200
			ELSE 300
		END,
	AgeGroup = 'Age ' + crgA.CustomGroupValue,
	Gender =
		CASE
			WHEN dCon.Gender = 'Unspecified' THEN 'Unknown'
			ELSE dCon.Gender
		END,
	0,
	0,
	0,
	0,
	0,
	'Detail',

	dCon.FullName,
	dCon.ConsumerNK,
	dCon.DOB,
	dAge.AgeValue,
	fLength.ClaimNumber,
	dDOS.DateValue as admittedDate,
	dDis.DateValue as dischargeDate,
	dServ.ServiceCode,
	dBill.BillTypeCodeNK,
	dDiag1.Diagnosis,
	dDiag1.DiagnosisCode,
	dProv.ProviderName,
	dProv.ProviderNK as ProviderID,
	fLength.LengthOfStay,
	MemberMonths = ISNULL(tElig.MemberMonths,0)
	
FROM
	BIW.DW.factLengthOfStay fLength WITH(NOLOCK)
	INNER JOIN BIW.DW.factClaims fClaims WITH(NOLOCK)ON fLength.ClaimAdjudicationNumber = fClaims.ClaimAdjudicationNumber
	INNER JOIN BIW.DW.dimConsumers dCon WITH(NOLOCK) ON fLength.ConsumerSK = dCon.ConsumerSK
	INNER JOIN BIW.DW.dimDiagnosis dDiag1 WITH(NOLOCK) ON fClaims.Diagnosis1SK = dDiag1.DiagnosisSK
	INNER JOIN BIW.DW.dimDiagnosis dDiag2 WITH(NOLOCK) ON fClaims.Diagnosis2SK = dDiag2.DiagnosisSK
	INNER JOIN BIW.DW.dimDate dDOS WITH(NOLOCK) ON fClaims.DateofServiceSK = dDOS.DateSK
	INNER JOIN BIW.DW.dimDate dDis WITH(NOLOCK) ON fLength.DateSK = dDis.DateSK
	INNER JOIN BIW.DW.dimServices dServ WITH(NOLOCK) ON fLength.ServiceSK = dServ.ServicesSK
	INNER JOIN BIW.DW.dimBillType dBill WITH(NOLOCK) ON fClaims.BillTypeSK = dBill.BillTypeSK
	INNER JOIN BIW.DW.dimOrganization dOrg WITH(NOLOCK) ON fLength.OrganizationSK = dOrg.OrganizationSK
	INNER JOIN BIW.DW.dimBenefitPlan dBenPlan WITH(NOLOCK) ON fLength.BenefitPlanSK = dBenPlan.BenefitPlanSK
	INNER JOIN BIW.DW.dimProvider dProv WITH(NOLOCK) ON fLength.ProviderSK = dProv.ProviderSK
	INNER JOIN BIW.DW.dimAge dAge WITH(NOLOCK) ON fLength.AgeSK = dAge.AgeSK
	
	LEFT JOIN cteEligAgg tElig WITH(NOLOCK) ON dCon.ConsumerNK = tElig.Consumer_ID
	LEFT JOIN biw.dw.dimCustomReportGroups crgA ON dAge.AgeValue BETWEEN crgA.BeganAttributeCodeRange AND crgA.EndAttributeCodeRange AND crgA.CustomGroupName = 'InpatientDischargeAverageLengthofStayCustomAgeGroup'
	
WHERE
	fClaims.StatusSK = 1
	AND dDis.DateValue BETWEEN @strDate AND @endDate
	AND 
	(
		(
			@diagCat = 3 --MH
			AND dDiag1.DiagnosisCode IN ( SELECT crgMH.BeganAttributeCodeRange FROM biw.dw.dimCustomReportGroups crgMH WHERE crgMH.CustomGroupName = 'HedisUntilizationDiagnosisGroupMH' )
		)
		OR
		(
			@diagCat = 4 --SA
			AND dDiag1.DiagnosisCode IN ( SELECT crgSA.BeganAttributeCodeRange FROM biw.dw.dimCustomReportGroups crgSA WHERE crgSA.CustomGroupName IN ( 'HedisUntilizationDiagnosisGroup' , 'DeniedPendedClaimsServiceCodes' ) )
		)
	)
	AND
	(@catchment = '-300'
			OR CONVERT(nvarchar, dOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, dOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)
	AND
	(
		( dBenPlan.InsurerID = @insurance ) OR -- 1 specific Plan
		( @insurance = -2 ) -- ALL PLANS
	)
	AND (@srcDef = dServ.ServiceDefinitionID OR (@srcDef = -300 AND dServ.ServiceDefinitionID IN ( SELECT crgMH.BeganAttributeCodeRange FROM biw.dw.dimCustomReportGroups crgMH WHERE crgMH.CustomGroupName = 'InpatientDischargeAverageLengthofStayServiceDefinitionsGroup' ) ) )


;WITH cteMemberMonthsByAge AS
(
	SELECT
		AgeGroup = 'Age ' + crgA.CustomGroupValue
		,elig.Gender
		,SUM(elig.member_count) as MemberMonths
	FROM
		#tmpMemberMonths elig
		LEFT JOIN biw.dw.dimCustomReportGroups crgA ON elig.AgeValue BETWEEN crgA.BeganAttributeCodeRange AND crgA.EndAttributeCodeRange AND crgA.CustomGroupName = 'InpatientDischargeAverageLengthofStayCustomAgeGroup'
	GROUP BY
		crgA.CustomGroupValue
		,elig.Gender
)

UPDATE #tmpInpDischALOS
SET eligible_month = cte.MemberMonths
FROM cteMemberMonthsByAge cte
WHERE age = cte.AgeGroup
	AND #tmpInpDischALOS.gender = cte.Gender
	
INSERT  INTO #tmpInpDischALOS (rptOrder,age,gender,cnt,eligible_month,DischPerThou,[Days],ALOS,Report_type)
SELECT 
	t9.rptOrder
	,t9.age
	,t9.gender
	,Discharges = isnull( COUNT(t9.Claim_Number), 0 )
	,isnull( t9.eligible_month, 0 )
	,DischPerThou =  isnull( ( ( COUNT(t9.Claim_Number) / nullif(t9.eligible_month,0) ) * 1000 ), 0 )
	,[Days] = isnull( SUM(t9.LengthOfStay), 0 )
	,ALOS = isnull( CAST( ( CAST( SUM(t9.LengthOfStay) AS FLOAT ) / CAST( COUNT(t9.Claim_Number) AS FLOAT ) ) AS FLOAT ), 0 )
	,'Summary'
	
FROM
	#tmpInpDischALOS t9

GROUP BY
	t9.rptOrder
	,
	t9.age
	,t9.gender
	,t9.eligible_month

UNION ALL

SELECT
	500
	,subQ.age
	,subQ.gender
	,Discharges = isnull( sum(subQ.Discharges), 0 )
	,eligible_month = isnull( sum(subQ.eligible_month), 0 )
	,DischPerThou =  isnull( ( ( sum(subQ.Discharges) / nullif(sum(subQ.eligible_month),0) ) * 1000 ), 0 )
	,[Days] = isnull( sum(subQ.Days), 0 )
	,ALOS = isnull( CAST( ( CAST( sum(subQ.Days) AS FLOAT ) / CAST( sum(subQ.Discharges) AS FLOAT ) ) AS FLOAT ), 0 )
	,subQ.Report_Type	

FROM
(
	SELECT 
		age = 'Total'
		,t9.gender
		,Discharges = COUNT(t9.Claim_Number)
		,t9.eligible_month
		,[Days] = SUM(t9.LengthOfStay)
		,ALOS = CAST( ( CAST( SUM(t9.LengthOfStay) AS FLOAT ) / CAST( COUNT(t9.Claim_Number) AS FLOAT ) ) AS FLOAT )
		, Report_Type = 'Summary'
		
	FROM
		#tmpInpDischALOS t9

	GROUP BY
		t9.gender
		,t9.eligible_month
) AS subQ

GROUP BY
	subQ.age
	,subQ.gender
	,subQ.Report_Type
	
	
INSERT  INTO #tmpInpDischALOS (rptOrder,age,gender,cnt,eligible_month,DischPerThou,[Days],ALOS,Report_type)
SELECT 
	600
	,t9.age
	,gender = 'Total'
	,Discharges = isnull( SUM(t9.cnt), 0 )
	,eligible_month = isnull( sum(t9.eligible_month), 0 )
	,DischPerThou =  isnull( ( ( SUM(t9.cnt) / nullif(sum(t9.eligible_month),0) ) * 1000 ), 0 )
	,[Days] = isnull( SUM(t9.Days), 0 )
	,ALOS = isnull( CAST( ( CAST( SUM(t9.Days) AS FLOAT ) / nullif( CAST( SUM(t9.cnt) AS FLOAT ), 0) ) AS FLOAT ), 0 )
	,Report_type = 'Summary'
	
FROM
	#tmpInpDischALOS t9

WHERE
	t9.Report_type = 'Summary'

GROUP BY
	t9.age
	
		
	
select * from #tmpInpDischALOS
	
DROP TABLE #tmpMemberMonths
DROP TABLE #tmpInpDischALOS