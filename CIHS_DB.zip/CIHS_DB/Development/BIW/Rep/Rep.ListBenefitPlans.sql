USE BIW
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListBenefitPlans]
AS

/*------------------------------------------------------------------------------
	Title:		List Benefit Plans
	File:		rep.ListBenefitPlans
	Author:		Doug Cox
	Date:		02/13/2013
	Desc:		This listing of benefit plans can be used to fill the available 
					values for a benefit plan Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/13/2013		Doug Cox     			7062			Created
			1.1		05/30/2013		Brian Angelo			fix				Edited to have SK and NK
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
			( @PlanID = dbp.BenefitPlanSK ) OR -- 1 specific Plan
			( @PlanID = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
			( @PlanID = -200 ) -- ALL PLANS
		)

	-----------------------------------------------------------------------------------*/

/* Get Listing of available Benefit Plans */
SELECT dbp.BenefitPlanNK,
	dbp.BenefitPlanSK,
	dbp.BenefitPlanShort
FROM DW.dimBenefitPlan as dbp with(nolock)
/* Add item for All Medicaid Plans */
UNION
SELECT -100 AS BenefitPlanNK,
	-100 AS BenefitPlanSK,
	'All Medicaid Plans'
/* Add item for All Plans */
UNION
SELECT -200 AS BenefitPlanNK,
	-200 AS BenefitPlanSK,
	'All Plans'
