USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[OutstandingAuthsbyDiagService]    Script Date: 08/12/2013 11:09:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[OutstandingAuthsbyDiagService] 
	@OpenDate datetime,
	@provider int,
	@Fund int,
	@catchment varchar(max), 
	@UseOpenDate bit
AS
/*------------------------------------------------------------------------------
	Title:		Outstanding Authorizations by Diag and Service
	File:		Outstanding Authorizations by Diag and Service
	Author:		Justin Ward
	Date:		6/14/2013
	Desc:		Report that shows open authorizations on a given date by diagnosis group and service category.			
                                        
	Called By:
                        Reports:          Coming Soon....
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		6/14/2013		Justin Ward    			6448			Created

--	-----------------------------------------------------------------------------------*/
--DECLARE
--	@OpenDate datetime = '7/31/2013',
--	@provider int = -2,
--	@Fund int = -200,
--	@catchment varchar(max) = '-300',
--	@UseOpenDate bit = 1

Declare 
@dateUsed as datetime =

(Select 
	CASE WHEN @UseOpenDate = 1
	THEN @OpenDate
	Else GETDATE()
END)

BEGIN
;WITH cteAuths as (
SELECT
	Diag.DiagnosisGroup,
	Diag.DiagnosisGroupID,
	Serv.ServiceSummary,
	Serv.ServicesNK,
	Prov.ProviderNK,
	Clients.ConsumerNK as ConsumerID,
	Auths.AuthorizationNumber,
	Auths.AuthorizedUnits as AuthorizedUnits,
	Auths.UsedUnits as ApprovedUnits
FROM 
	DW.factAuthorizations Auths WITH(NOLOCK)
	INNER JOIN DW.dimServices Serv WITH(NOLOCK) ON Auths.ServicesSK = Serv.ServicesSK
	INNER JOIN DW.dimConsumers Clients WITH(NOLOCK) ON  Auths.ConsumerSK = Clients.ConsumerSK
	INNER JOIN DW.dimDate EffFrom WITH(NOLOCK) ON Auths.EffectiveFromDateSK = EffFrom.DateSK
	INNER JOIN DW.dimDate EffTo WITH(NOLOCK) ON Auths.EffectiveToDateSK = EffTo.DateSK
	INNER JOIN DW.dimDiagnosis Diag WITH(NOLOCK) ON Auths.DiagnosisSK = Diag.DiagnosisSK	
	INNER JOIN DW.dimBenefitPlan Insurer WITH(NOLOCK) ON Auths.BenefitPlanSK = Insurer.BenefitPlanSK
	INNER JOIN DW.dimProvider Prov WITH(NOLOCK) ON Auths.ProviderSK = Prov.ProviderSK
	INNER JOIN DW.dimOrganization Org WITH(NOLOCK) ON Auths.OrganizationSK = Org.OrganizationSK

	
	
WHERE
		EffFrom.DateValue <= @dateUsed
		AND EffTo.DateValue > @dateUsed
		AND (
				@Fund = Insurer.BenefitPlanNK OR
				(@Fund = -100 and Insurer.InsurerID = 2) OR
				@Fund = -200
			)
		AND EffTo.DateValue <> EffFrom.DateValue
		AND 
		(
			(Prov.ProviderNK = @provider) OR 
			( @provider= -2 )
		)
		AND
		(     
                  @catchment = '-300'
                  OR CONVERT(nvarchar, Org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
                  OR CONVERT(nvarchar, Org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
            )


	)
	--select * from cteAuths 
	--where AuthorizationNumber = '1303756825'
	

	
	SELECT 
		Auths.DiagnosisGroup,
		Auths.ServiceSummary,
		Auths.ServicesNK,
		Auths.ProviderNK,
		Auths.AuthorizationNumber,
		Auths.AuthorizedUnits,
		Auths.ApprovedUnits,
		AVG(Claims.ContractRate) as ConRate,
		SUM(ISNULL(Claims.AdjudicatedAmount,0)) as AdjAmt
	INTO #getClaims
	FROM 
		cteAuths Auths
		INNER JOIN DW.dimConsumers Consumers WITH(NOLOCK) ON Auths.ConsumerID = Consumers.ConsumerNK
		INNER JOIN DW.dimServices Serv WITH(NOLOCK) ON Serv.ServicesNK = Auths.ServicesNK
		LEFT OUTER JOIN DW.factClaims Claims WITH(NOLOCK) ON Claims.ConsumerSK = Consumers.ConsumerSK
		AND Claims.AuthorizationNumber = Auths.AuthorizationNumber
		AND Claims.ServicesSK = Serv.ServicesSK
		LEFT OUTER JOIN DW.dimDate AdjDt WITH(NOLOCK) ON Claims.AdjudicationDateSK = AdjDt.DateSK
	WHERE 
		ISNULL(AdjDt.DateValue,@dateUsed) <= @dateUsed 
	GROUP BY
		Auths.DiagnosisGroup,
		Auths.ServiceSummary,
		Auths.ServicesNK,
		Auths.ProviderNK,
		Auths.AuthorizationNumber,
		Auths.AuthorizedUnits,
		Auths.ApprovedUnits
		
		--select * 
		--from #getClaims 
		--where AuthorizationNumber = '1105667922'
	
		UPDATE #getClaims
		SET ConRate = conRates.ContractRate
		FROM #getClaims gC
			inner join dw.dimProvider prov on gC.ProviderNK = prov.ProviderNK
			inner join dw.dimServices serv on gC.ServicesNK = serv.ServicesNK
			inner join dw.factProviderContractRates conRates on conRates.ProviderSK = prov.ProviderSK
			AND conRates.ServicesSK = serv.ServicesSK
		WHERE gC.ConRate IS NULL
		
		--delete from #getClaims where ConRate = 0
;WITH cteCombine as (		
select 
	DiagnosisGroup,
	ServiceSummary,
	AuthorizationNumber,
	SUM(AuthorizedUnits) as AuthorizedUnits,
	SUM(ApprovedUnits) as ApprovedUnits,
	AVG(ConRate) as ConRate,
	AdjAmt
from #getClaims 
group by
	DiagnosisGroup,
	ServiceSummary,
	AuthorizationNumber,
	AdjAmt
--order by AuthorizationNumber
)


	SELECT 
		DiagnosisGroup,
		ServiceSummary,
		AuthorizationNumber,
		AuthorizedUnits,
		ConRate,
		(AuthorizedUnits * ConRate) as AuthorizedAmount,
		ApprovedUnits,
		AdjAmt as ApprovedAmt,
		(AuthorizedUnits - ApprovedUnits) as OutstandingUnits,
		(AuthorizedUnits * ConRate) - AdjAmt as OutstandingAmount
	FROM cteCombine                                   -- 
	WHERE ((AuthorizedUnits * ConRate) - AdjAmt) >= 0 
	Group by 
		DiagnosisGroup,
		ServiceSummary,
		AuthorizationNumber,
		AuthorizedUnits,
		ConRate,
		ApprovedUnits,
		AdjAmt

	ORDER BY AuthorizationNumber
	
	
drop table #getClaims
END	





