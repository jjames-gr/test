USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[FinancialFundingCapitation]    Script Date: 07/23/2013 12:37:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [REP].[FinancialFundingCapitation]
          @StartDate DateTime,
          @EndDate DateTime,
          @Catchment VarChar(Max)
AS

/*------------------------------------------------------------------------------
      Title:            Financial Funding Capitation  
      File:       [Rep].[FinancialFundingCapitation]
      Author:           Kevin Hamilton    
      Date:       06/19/2013
      Desc:       Detailed listing of providers that have capitated amounts.                
                                        
      Called By:
                        Reports:         Financial Funding Capitation   
                  


                       
      -----------------------------------------------------------------------------------
      Version History:
      
                  Ver         Date              Author                              TixNo             Description
                  ---         ----------        ---------------               -----             -----------
                  1.0         06/19/2013        Kevin Hamilton                6392              Created

--    -----------------------------------------------------------------------------------*/

--DECLARE @StartDate DateTime,
--            @EndDate DateTime,
--            @Catchment INT
            
--      SET @StartDate = '1/1/2011'
--      SET @EndDate = '12/31/2013'
--      SET @Catchment = -300
      




SELECT DISTINCT 
	 
     
     ddst.DateValue as StartDate,
     ddend.DateValue as EndDate,
     fpfc.CapitationAmount,
     CASE WHEN fpfc.UsedAmount IS Null THEN 0 
		Else fpfc.UsedAmount
	 END as Used2Amount,
     CASE WHEN (NULLIF(fpfc.UsedAmount,0) / (NULLIF(fpfc.CapitationAmount,0))) is null Then 0
		ELSE (NULLIF(fpfc.UsedAmount,0) /(NULLIF(fpfc.CapitationAmount,0)))
      End as Percent2OfEarning,
     CASE WHEN fpfc.AllCapitatedServiceCodes = '-1' THEN 'All Services'
		ELSE fpfc.AllCapitatedServiceCodes 
      End service_codes,
      j.JunkValue as Catchment,
      dp.ProviderName
    
FROM  DW.factProviderFundingCapitation fpfc 
	  INNER JOIN DW.dimProvider dp with(nolock) ON dp.ProviderSK = fpfc.ProviderSK
	  INNER JOIN DW.dimDate ddst with(nolock) ON ddst.DateSK = fpfc.CapitationStartDateSK 
      INNER JOIN DW.dimDate ddend with(nolock) ON ddend.DateSK = fpfc.CapitationEndDateSK
      INNER JOIN DW.dimJunk j with(nolock) ON ClientCatchmentSK  = j.JunkSK
      INNER JOIN dbo.cfn_split(@Catchment,',') org1 ON org1.element = j.JunkNK  
WHERE 
  (ddst.DateValue >=  @StartDate 
   AND ddend.DateValue <= @EndDate)

      
GROUP BY 
 ddst.DateValue, dp.ProviderName, fpfc.CapitationAmount,fpfc.UsedAmount
 ,fpfc.AllCapitatedServiceCodes, ddst.DateValue, ddend.DateValue, j.JunkValue

ORDER BY ProviderName 
