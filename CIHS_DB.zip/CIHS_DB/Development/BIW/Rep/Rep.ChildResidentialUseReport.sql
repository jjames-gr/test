USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ProviderListingDataDump]    Script Date: 09/17/2013 13:53:37 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ChildResidentialUseReport] 
(
	@strDate DATE,
	@endDate DATE,
	@insurer INT,
	@lvlService NVARCHAR(MAX),
	@catchment NVARCHAR(MAX)
)
AS



/*------------------------------------------------------------------------------
	Title:		Child Residential Use Report
	File:		[REP].[ChildResidentialUseReport] 
	Author:		Karissa Martindale
	Date:		09/17/13
	Desc:		Identifies children who have received inpatient services and claim statistics in the same time frame of these inpatient stays.
                                        
	Called By:
                        Reports:          
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/17/2013		Karissa Martindale   	6294			Created
-----------------------------------------------------------------------------------*/


--DECLARE
--	@strDate DATE = '1/1/13',
--	@endDate DATE = '1/31/13',
--	@insurer INT = '-300',
--	@lvlService NVARCHAR(MAX) = '1328',--'1328, 75, 87, 52, 189, 190, 191, 35',
--	@catchment NVARCHAR(MAX) = '-300'
	
SELECT DISTINCT
	dCust.CustomGroupValue,
	dServ.ServicesNK,
	dServ.ServiceDescription,
	dCon.FullName,
	dCon.ConsumerNK,
	dCon.DOB,
	CASE
	WHEN dBenPlan.InsurerID = 2 THEN dEligOrg.County
	ELSE 'State'
	END as dConCatchment,
	fClaims.SpecialDiagnosisGroup,
	dDiag.DiagnosisCode as Diagnosis1SK,
	dOrgCon.Catchment,
	fScreen.CalocusResultSK,
	--CASE
	--WHEN dScore.ScoreResultsNK = 7 THEN 'Level I'
	--WHEN dScore.ScoreResultsNK = 8 THEN 'Level II'
	--WHEN dScore.ScoreResultsNK = 9 THEN 'Level III'
	--WHEN dScore.ScoreResultsNK = 10 THEN 'Level IV'
	--WHEN dScore.ScoreResultsNK = 11 THEN 'Level V'
	--WHEN dScore.ScoreResultsNK = 12 THEN 'Level VI'
	--END as calocusscore,
	dScore.ResultLevelOfCare as calocusscore,
	fLength.LengthOfStay,
	dInpatientBegin.DateValue as inpatientDate,
	fClaims.ClaimNumber
INTO #mainTemp
FROM
	dw.factClaims fClaims WITH(NOLOCK)
	inner join dw.dimDiagnosis dDiag with(nolock) on fClaims.Diagnosis1SK =  dDiag.DiagnosisSK
	INNER JOIN dw.dimConsumers dCon WITH(NOLOCK) ON fClaims.ConsumerSK = dCon.ConsumerSK
	INNER JOIN dw.dimConsumers dConJoin WITH(NOLOCK) ON dCon.ConsumerNK = dConJoin.ConsumerNK
	INNER JOIN dw.dimConsumers dconjoin2 with(nolock) on dCon.ConsumerNK = dconjoin2.ConsumerNK
	INNER JOIN dw.dimServices dServ WITH(NOLOCK) ON fClaims.ServicesSK = dServ.ServicesSK
	INNER JOIN dw.dimOrganization dOrgCon WITH(NOLOCK) ON fClaims.OrganizationSK = dOrgCon.OrganizationSK
	INNER JOIN dw.dimBenefitPlan dBenPlan WITH(NOLOCK) ON fClaims.BenefitPlanSK = dBenPlan.BenefitPlanSK
	INNER JOIN dw.dimBenefitPlan dBenPlanJoin WITH(NOLOCK) ON dBenPlan.BenefitPlanNK = dBenPlanJoin.BenefitPlanNK
	INNER JOIN dw.dimProvider dProv WITH(NOLOCK) ON fClaims.ProviderSK = dProv.ProviderSK
	INNER JOIN dw.dimProvider dProvJoin WITH(NOLOCK) ON dProv.ProviderNK = dProvJoin.ProviderNK
	INNER JOIN dw.factScreeningTriageReferral fScreen WITH(NOLOCK) ON dconjoin2.ConsumerSK = fScreen.ConsumerSK
	INNER JOIN dw.dimScoreResults dScore WITH(NOLOCK) ON dScore.ScoreResultsSK = fScreen.CalocusResultSK
	Left JOIN dw.factLengthOfStay fLength WITH(NOLOCK) ON fLength.ClaimNumber = fClaims.ClaimNumber
	Left JOIN dw.dimDate dInpatientBegin WITH(NOLOCK) ON fLength.DateSK = dInpatientBegin.DateSK
	INNER JOIN dw.factEligibility fElig WITH(NOLOCK) ON fElig.ConsumerSK = dConJoin.ConsumerSK AND fElig.BenefitPlanSK = dBenPlanJoin.BenefitPlanSK
	INNER JOIN dw.dimOrganization dEligOrg WITH(NOLOCK) ON dEligOrg.OrganizationSK = fElig.OrganizationSK
	INNER JOIN dw.dimCustomReportGroups dCust WITH(NOLOCK) ON dServ.ServicesNK = dCust.AttributeID AND CustomGroupName = 'ChildResidentialUse'
	inner join dw.dimDate ddos on fClaims.DateOfServiceSK = ddos.DateSK
WHERE
	ddos.DateValue between @strDate and @endDate
    AND fElig.DateSK <= convert(int, convert(varchar, @endDate, 112))
    AND fElig.ExpirationDateSK >= convert(int, convert(varchar, @strDate, 112))
	AND (dBenPlan.InsurerID = @insurer OR @insurer = -300)
	AND 
	(
		@catchment = '-300'
		OR CONVERT(nvarchar, dOrgCon.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, dOrgCon.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)
	--Have a group for Services called ChildResidentialUse
	AND dServ.ServicesNK IN ( SELECT element FROM dbo.cfn_split(@lvlService, ',') )
	AND fClaims.AgeSK BETWEEN 4 AND 20


;WITH cteSmallCount AS (

select 
COUNT(distinct ConsumerNK) as SmallConsumerCount
FROM
	dw.dimConsumers dCon
	INNER JOIN dw.factClaims on dCon.ConsumerSK = factClaims.ConsumerSK
	inner join dw.dimDate dDOS ON dDOS.DateSK = factClaims.DateOfServiceSK
where
	factClaims.AgeSK BETWEEN 4 AND 20
	and dDOS.DateValue BETWEEN @strDate AND @endDate
)	

SELECT DISTINCT
	mTemp.CustomGroupValue,
	mTemp.ServicesNK,
	mTemp.ServiceDescription,
	mTemp.FullName,
	mTemp.ConsumerNK,
	mTemp.DOB,
	mTemp.dConCatchment,
	mTemp.SpecialDiagnosisGroup,
	mTemp.Diagnosis1SK,
	mTemp.Catchment,
	MAX(CASE
	WHEN dScore.ScoreResultsNK = 7 THEN 'Level I'
	WHEN dScore.ScoreResultsNK = 8 THEN 'Level II'
	WHEN dScore.ScoreResultsNK = 9 THEN 'Level III'
	WHEN dScore.ScoreResultsNK = 10 THEN 'Level IV'
	WHEN dScore.ScoreResultsNK = 11 THEN 'Level V'
	WHEN dScore.ScoreResultsNK = 12 THEN 'Level VI'
	ELSE mTemp.calocusscore
	END) as calocusauth,
	mTemp.LengthOfStay,
	mTemp.inpatientDate,
	DATEADD(DAY, -(LengthofStay), mTemp.inpatientDate) as startLOS,
	SmallConsumerCount
FROM
cteSmallCount,
#mainTemp mTemp	
inner join dw.dimConsumers c on mTemp.ConsumerNK = c.ConsumerNK
LEFT JOIN dw.factTreatmentAuthorizationRequest fTreatAuth WITH(NOLOCK) ON c.ConsumerSK = fTreatAuth.ConsumerSK -- fTAR.TreatmentAuthorizationRequestSK = fTreatAuth.FactTreatmentAuthorizationRequestSK --fTreatAuth.TARID = fAuth.ReferenceNumber  c.ConsumerSK = fTreatAuth.ConsumerSK and
LEFT JOIN dw.factTarServiceToDiagnosis fTAR WITH(NOLOCK) ON convert(int, convert(varchar,DATEADD(DAY, -(LengthofStay), mTemp.inpatientDate), 112)) = fTAR.ServiceStartDateSK and fTAR.TreatmentAuthorizationRequestSK = fTreatAuth.FactTreatmentAuthorizationRequestSK
LEFT JOIN dw.dimScoreResults dScore WITH(NOLOCK) ON dScore.ScoreResultsSK = fTreatAuth.CalocusResultSK
GROUP BY 
	mTemp.CustomGroupValue,
	mTemp.ServicesNK,
	mTemp.ServiceDescription,
	mTemp.FullName,
	mTemp.ConsumerNK,
	mTemp.DOB,
	mTemp.dConCatchment,
	mTemp.SpecialDiagnosisGroup,
	mTemp.Diagnosis1SK,
	mTemp.Catchment,
	mTemp.LengthOfStay,
	mTemp.ClaimNumber,
	mTemp.inpatientDate,
	DATEADD(DAY, -(LengthofStay), mTemp.inpatientDate),
	SmallConsumerCount


Drop Table #mainTemp

