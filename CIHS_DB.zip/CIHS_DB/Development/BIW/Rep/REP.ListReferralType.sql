USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ListReferralType]    Script Date: 08/20/2013 11:32:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [REP].[ListReferralType]

AS

/*------------------------------------------------------------------------------
	Title:		List Referral Type
	File:		[Rep].[ListReferralType] 
	Author:		Tim Amerson
	Date:		08/20/2013
	Desc:		Listing of Call Center Reps can be used to fill the 
					available values for Call Center Reps Parameters
					and cascading by date of call on factCalls table.

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/20/2013		Tim Amerson				----       		Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
	Single Select
	-- dj.JunkNK = @ReferralType OR @ReferralType = -2
	
		
-----------------------------------------------------------------------------------*/


SELECT  '-2' as ReferralID,  100 as ReferralOrder,'All Referral Types' as ReferralName
UNION ALL
SELECT DISTINCT 	
	dj.JunkNK as ReferralID,
	200 as ReferralOrder,
	dj.JunkValue AS ReferralName
FROM 
	biw.dw.dimjunk dj
WHERE	
	dj.JunkEntity = 'ReferralType'
	
 ORDER BY ReferralOrder, ReferralName


