USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[MissingOrFalseSSN]    Script Date: 08/19/2013 14:34:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROCEDURE [REP].[MissingOrFalseSSN]
	 @StartDate DATETIME
	,@EndDate DATETIME
AS


/*------------------------------------------------------------------------------
	Title:		Missing or False SSN
	File:		[Rep].[MissingOrFalseSSN]
	Author:		Divya Lakshmi
	Date:		04/08/2013
	Desc:		Missing or False SSN by claim date Range.
                                        
	Called By:
                        Reports:        UMA009 -  MissingOrFalseSSN
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/08/2013		Divya Lakshmi     		6445			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2013',
--	@EndDate DATETIME = '1/31/2013'
	
SELECT DISTINCT
	c.ConsumerNK ConsumerID,
	c.ConsumerSK,
    c.LastName ConsumerLastName,
    c.FirstName ConsumerFirstName ,
    c.MiddleName ConsumerMiddleName,
    c.SSN,
    CASE WHEN (c.MissingSSNFlag =  1)
    THEN 'True' 
    Else 'False'
    End as NoSSN,
    c.MissingSSNFlag,
    MAX(fc.ClaimNumber) ClaimNumber ,
    p.ProviderNK as claim_by,
    p.providername as claim_prov,
    0 AS auth_by ,
    CAST('' AS CHAR(200)) AS auth_prov ,
   -- 0 AS enroll_by,
    c.EnrollmentProviderName AS enroll_prov ,
    c.CreateDate,
    c.ETLCurrentRow

into #temp
FROM

	DW.factClaims fc with(nolock)
	INNER JOIN DW.dimDate dt with(nolock) on fc.DateOfServiceSK = dt.DateSK
	INNER JOIN DW.dimConsumers c with(nolock)  on fc.ConsumerSK = c.ConsumerSK
	INNER JOIN DW.dimProvider p with(nolock) on fc.ProviderSK = p.ProviderSK
	--INNER JOIN DW.factAuthorizations fa ON fa.ProviderSK = p.ProviderSK
	INNER JOIN (
				SELECT DISTINCT fc1.ConsumerSK, MAX(ClaimNumber) as claim_no
				FROM DW.factClaims fc1 with(nolock)
					INNER JOIN DW.dimDate dt with(nolock) on fc1.DateOfServiceSK = dt.DateSK

				where  dt.Datevalue BETWEEN @StartDate AND @EndDate
				group by fc1.ConsumerSK

			) as a1 on a1.claim_no=fc.ClaimNumber and a1.ConsumerSK=c.ConsumerSK
			
WHERE
c.active=1 
AND (( MissingSSNFlag= 1 ) 
                  OR (ISNULL(REPLACE(c.SSN, '-', ''), '000000000') LIKE '%0000' )
                  OR ( ISNULL(REPLACE (c.SSN, '-', ''), '000000000') = '078051120' )
                  OR ( ISNULL(REPLACE(c.SSN, '-', ''), '000000000') = '111111111' )
                  OR ( ISNULL(REPLACE(c.SSN, '-', ''), '000000000') LIKE '999999999' )
                  OR ( ISNULL(REPLACE(c.SSN, '-', ''), '000000000') BETWEEN '987654320'  AND   '987654329' )
                  OR ( LEN(ISNULL(REPLACE(c.SSN, '-', ''), '000000000')) < 9 )
                  )

            AND dt.Datevalue BETWEEN @StartDate AND @EndDate
            AND c.FirstName <> 'Piedmont'
  
	GROUP BY
c.ConsumerNK,
c.ConsumerSK,
c.LastName,
c.FirstName,
c.MiddleName,
c.SSN,
c.MissingSSNFlag,
c.CreateDate,
c.ETLCurrentRow,
c.EnrollmentProviderName, 
p.ProviderNK,
p.ProviderName
	

	
            

	;with cte as (SELECT  m.ConsumerSK ,
            MAX(AuthorizationNumber) auth_id
    FROM    DW.factAuthorizations m with(nolock)
           INNER JOIN  #temp s on m.ConsumerSK = s.ConsumerSK
    WHERE     s.ETLCurrentRow=1
    GROUP BY m.ConsumerSK)
	
    UPDATE  #temp
    SET     auth_by = p1.ProviderNK ,
            auth_prov = p1.providername
    FROM    #temp s INNER JOIN cte t on  s.ConsumerSK=t.ConsumerSK
            INNER JOIN dw.factAuthorizations fa with(nolock) on t.auth_id=fa.AuthorizationNumber
            INNER JOIN DW.dimProvider p with(nolock) on fa.ProviderSK=p.ProviderSK
            INNER JOIN DW.dimProvider p1 with(nolock) on p.ParentProviderNK = p1.ProviderNK
            
 
DELETE FROM #temp
WHERE claimnumber not in (SELECT Max(claimnumber) as Id FROM #temp GROUP BY ConsumerID) 

   
SELECT * FROM #temp
DROP TABLE #temp












GO


