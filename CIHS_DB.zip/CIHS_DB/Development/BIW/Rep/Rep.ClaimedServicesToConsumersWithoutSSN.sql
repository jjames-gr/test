USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ClaimedServicesToConsumersWithoutSSN]    Script Date: 07/29/2013 11:12:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO










CREATE PROCEDURE [REP].[ClaimedServicesToConsumersWithoutSSN]
	@StartDate DATETIME
	,@EndDate  DATETIME
	,@plan_Id  int

AS


/*------------------------------------------------------------------------------
	Title:		Claimed Services to Consumers without a SSN
	File:		[Rep].[ClaimedServicesToConsumersWithoutSSN]
	Author:		Divya Lakshmi
	Date:		04/12/2013
	Desc:		Displays claims data for consumers that do not have a valid SSN.
                                        
	Called By:
                        Reports:        CLM012 - ClaimedServicesToClientsWithoutSSN.rdl
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		04/18/2013		Divya Lakshmi     		6299			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2012',
--	@EndDate DATETIME = '1/31/2012',
--	@plan_Id varchar(100)='-200'

select distinct 
c.ConsumerNK,
c.LastName,
c.FirstName,
c.SSN,
dt.DateValue EffDate,
expdt.DateValue ExpirationDate,
fc.claimnumber ClaimNumber,
srvc.DateValue DOS,
p.providernk ProviderID,
p.providername Provider,
bp.benefitplanshort FundingSource,
s.servicecode ServiceCode,
s.ServiceDescriptionShort ServiceDescription,
fc.AdjudicatedAmount AdjudicatedAmount,
o.Catchment,
o.county,
fc.PaidAmount,
paid.DateValue PaidDate,
recd.DateValue as ReceivedDate,
CASE WHEN fc.CapitatedSK = '11' THEN 'Yes'
	ELSE 'No'
END as CapitatedSK,
bp.BenefitPlanSK,
bp.InsurerID,
TotApprovedClaim=(select 
                  sum(fc.AdjudicatedAmount) AdjudicatedAmount
                  FROM

	              DW.factClaims fc with(nolock)
	              INNER JOIN DW.dimDate dt with(nolock) ON fc.DateOfServiceSK = dt.DateSK
	              INNER JOIN DW.dimConsumers c with(nolock)  ON fc.ConsumerSK = c.ConsumerSK
	              INNER JOIN DW.dimServices s with(nolock) ON fc.ServicesSK = s.ServicesSK
                  INNER JOIN DW.dimbenefitPlan bp with(nolock) ON fc.BenefitPlanSK=bp.BenefitPlanSK
                  INNER JOIN DW.dimJunk j with(nolock) ON fc.StatusSK= j.JunkSK	
                  WHERE 

                  dt.datevalue BETWEEN @StartDate AND @EndDate
                  AND j.JunkEntity= 'ClaimAdjudicatedStatus' 
                  AND j.JunkSK = 1
                  )
FROM


	DW.factClaims fc with(nolock)
	INNER JOIN DW.dimDate srvc with(nolock) ON fc.DateOfServiceSK = srvc.DateSK
	INNER JOIN DW.dimDate recd with(nolock) ON fc.ReceivedDateSK = recd.DateSK
	INNER JOIN DW.dimDate paid with(nolock) ON fc.PaidDateSK = paid.DateSK
	INNER JOIN DW.dimConsumers c with(nolock)  ON fc.ConsumerSK = c.ConsumerSK
	INNER JOIN DW.dimProvider p with(nolock) ON fc.ProviderSK = p.ProviderSK
	INNER JOIN DW.dimServices s with(nolock) ON fc.ServicesSK = s.ServicesSK
    INNER JOIN DW.dimbenefitPlan bp with(nolock) ON fc.BenefitPlanSK=bp.BenefitPlanSK
	INNER JOIN DW.dimOrganization o with(nolock) ON fc.OrganizationSK = o.OrganizationSK
    INNER JOIN DW.dimJunk j with(nolock) ON fc.StatusSK= j.JunkSK

	INNER JOIN DW.dimbenefitPlan bp2 with(nolock) ON bp.BenefitPlanNK=bp2.BenefitPlanNK
    INNER JOIN DW.dimConsumers c2 with(nolock)  ON c.ConsumerNK = c2.ConsumerNK
	INNER JOIN DW.factEligibility fe with(nolock) ON fe.ConsumerSK = c2.ConsumerSK and fe.BenefitPlanSK=bp2.BenefitPlanSK
	INNER JOIN DW.dimDate dt with(nolock) ON fe.DateSK = dt.DateSK
	INNER JOIN DW.dimDate expdt with(nolock) ON fe.ExpirationDateSK = expdt.DateSK

WHERE 
fe.ActionSK=12 
AND p.active=1 
AND (( c.MissingSSNFlag= 1 ) 
OR (ISNULL(REPLACE(c.SSN, '-', ''), '000000000') LIKE '%0000' )
                  OR ( ISNULL(REPLACE (c.SSN, '-', ''), '000000000') = '078051120' )
                  OR ( ISNULL(REPLACE(c.SSN, '-', ''), '000000000') = '111111111' )
                  OR ( ISNULL(REPLACE(c.SSN, '-', ''), '000000000') LIKE '999999999' )
                  OR ( ISNULL(REPLACE(c.SSN, '-', ''), '000000000') BETWEEN '987654320'  AND   '987654329' )
                  OR ( LEN(ISNULL(REPLACE(c.SSN, '-', ''), '000000000')) < 9 )
                  )

         AND srvc.datevalue BETWEEN @StartDate AND @EndDate
         AND dt.DateValue<=DATEADD(dd,1,@EndDate)
         AND expdt.DateValue >=@StartDate

	AND(
			( @plan_Id = bp.BenefitPlanNK ) OR -- 1 specific Plan
			( @Plan_ID = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
			( @Plan_ID = -200 ) -- ALL PLANS
		)

AND j.JunkEntity= 'ClaimAdjudicatedStatus' 
AND j.JunkNK = 1
order by c.ConsumerNK











GO


