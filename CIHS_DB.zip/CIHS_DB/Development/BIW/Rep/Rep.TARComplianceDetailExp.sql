USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[TARComplianceDetailExp]
	@StartDate DATE,
	@EndDate DATE,
	@DateType INT, -- 1 = 'Processed Date', 2 = 'Received Date'
	@Catchment VARCHAR(MAX), -- = -300,
	@Provider INT, -- = -2,
	@BenefitPlan VARCHAR(MAX), -- = '-1,1,2,3,4,5,6,7,99,8',
	@UserLogin VARCHAR(MAX), -- = 'Brian.Angelo',
	@CareManager VARCHAR(MAX), -- '977,139,602,809,110,636,641,657,561,1143,852,1117,839,834,563,619,727,887,1175,87,613,605,1191,776,84,1177,738,1003,1258,1178,805,892,569,731,158,1026,101,687,788,100,838,633,851,932,739,651,658,1,740,1285,65,1092,845,1176,1025,638,774,138,604,732,248,631,1002,555,688,735,830,1150,814,637,680,854,608,877,741,862,843,1195,37,17,119,661,939,1126,618,1135,1254,1284,649,42,773,1252,123,-1,85,133,763,787,1173',
	@DisabilityType VARCHAR(MAX), -- = 'DD,MH,SA',
	@ActionTaken VARCHAR(MAX), -- = 'ADMDENY,APPR,DENY,DENYPT,DISCHRG,NR,PEND,REQPSYCH,UNPROC',
	@ServiceDefinition VARCHAR(MAX), -- = '123,1,2,3,4,96,5,142,6,117,7,145,8,9,10,11,97,100,12,13,110,14,15,93,16,134,105,124,17,18,136,135,137,138,139,140,141,125,19,20,21,22,23,24,108,126,114,132,25,26,27,121,28,29,30,31,32,33,34,35,119,37,40,41,120,42,43,39,44,38,45,127,107,133,102,46,95,112,47,98,103,94,128,48,49,148,129,116,50,51,52,53,54,144,55,131,56,57,58,122,59,109,60,61,62,63,64,65,118,104,66,67,113,68,69,70,71,72,73,74,130,75,-1,143,76',
	@SelectFields VARCHAR(MAX)
AS

/*	------------------------------------------------------------------------------
	Title:		TAR Compliance Detail Export
	File:		[Rep].[TARComplianceDetailExp]
	Author:		Doug Cox
	Date:		08/22/2013
	Desc:		Data dump of processed TAR information.

	Called By:
                        Reports:	UMA025 - TARComplianceDetailExp.RDL
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/22/2013		Doug Cox				6532			Created

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATE = '1/1/13',
--	@EndDate DATE = '1/31/13',
--	@DateType INT = 1, -- 1 = 'Processed Date', 2 = 'Received Date'
--	@Catchment VARCHAR(MAX) = -300,
--	@Provider INT = -2,--22415,--23402,--21351,-- -2,
--	@BenefitPlan VARCHAR(MAX) = '-1,1,2,3,4,5,6,7,99,8',
--	@UserLogin VARCHAR(MAX) = 'Brian.Angelo',--NULL,
--	@CareManager VARCHAR(MAX) = '977,139,602,809,110,636,641,657,561,1143,852,1117,839,834,563,619,727,887,1175,87,613,605,1191,776,84,1177,738,1003,1258,1178,805,892,569,731,158,1026,101,687,788,100,838,633,851,932,739,651,658,1,740,1285,65,1092,845,1176,1025,638,774,138,604,732,248,631,1002,555,688,735,830,1150,814,637,680,854,608,877,741,862,843,1195,37,17,119,661,939,1126,618,1135,1254,1284,649,42,773,1252,123,-1,85,133,763,787,1173',
--	@DisabilityType VARCHAR(MAX) = 'DD,MH,SA',
--	@ActionTaken VARCHAR(MAX) = 'ADMDENY,APPR,DENY,DENYPT,DISCHRG,NR,PEND,REQPSYCH,UNPROC',
--	@ServiceDefinition VARCHAR(MAX) = '123,1,3,4,5,142,6,117,7,8,9,97,100,12,13,110,14,15,93,16,134,105,124,18,19,20,23,24,108,132,25,26,27,121,28,29,30,31,32,33,34,35,119,37,40,120,42,43,39,38,45,127,133,102,46,95,112,47,98,103,94,128,48,49,148,129,116,50,51,52,53,54,144,55,131,56,57,58,59,109,60,61,62,63,64,65,104,66,67,113,68,69,71,130,-1,143',
--	@SelectFields VARCHAR(MAX)

DECLARE @filenm  AS VARCHAR(2000),
        @FilePath AS VARCHAR(75),
        @UserPath AS VARCHAR(75),
        @ProcName AS VARCHAR(100) = 'Rep.TARComplianceDetailExp', --OBJECT_NAME(@@ProcID),
        @raiseErrorMsg VARCHAR(255)
        
IF @UserLogin IS NULL AND @Provider = -2
   BEGIN
      SET @raiseErrorMsg = 'User Login cannot be null when running for all Providers. Aborting procedure.'
      RAISERROR (@raiseErrorMsg, 16, 1)
      RETURN
   END

IF @UserLogin IS NOT NULL AND NOT EXISTS ( SELECT  1
                FROM    BIW.DW.dimEmployee
                WHERE   AccountName like '%' + @UserLogin )
   BEGIN
      SET @raiseErrorMsg = 'User Login of ' +  @UserLogin + ' is not a valid user. Aborting procedure.'
      RAISERROR (@raiseErrorMsg, 16, 1)
      RETURN
   END
   
IF object_id('tempdb..#temp') is not null
BEGIN
	DROP TABLE #temp
END

SELECT	DISTINCT 
		dCurrentConsumer.ConsumerNK AS ConsumerID,
		dCurrentConsumer.LastName,
		dCurrentConsumer.FirstName,
		dCurrentConsumer.DOB,
		dCurrentConsumer.County AS CountyOfResidenceMedicaid,
		dBPlan.BenefitPlanShort,
		fTAR.TARID AS TAR_ID,
		TarType.JunkValue AS TAR_Type,
		CASE WHEN fTAR.ExpeditedFlag = 1 THEN 'Yes' ELSE 'No' END AS Expedited,
		SubmitDate.DateValue AS ServiceRequestDate,
		dServices.ServiceDefinition AS ServiceRequested,
		dServices.ServiceCode,
		ActionTaken.JunkValue AS ActionTaken,
		UpdateDate.DateValue AS ActionDate,
		CASE WHEN SubmitDate.DateValue > UpdateDate.DateValue THEN 0 ELSE DATEDIFF(DAY,SubmitDate.DateValue,UpdateDate.DateValue) END AS NumberOfDaysToAct,
		dDiag.DiagnosisCode,
		SpecialtyCode.JunkValue AS DisabilityType,
		dProvider.ProviderNK AS ProviderID,
		dProvider.ProviderName AS SubmittingProvider,
		dEmp.FullName AS CareManager,
		fS2D.TarServiceID
INTO	#temp
FROM	dw.factTreatmentAuthorizationRequest AS fTAR with(nolock) 
		INNER JOIN dw.factTARServiceToDiagnosis AS fS2D with(nolock) ON fS2D.TreatmentAuthorizationRequestSK = fTAR.FactTreatmentAuthorizationRequestSK
		INNER JOIN dw.dimBenefitPlan AS dBPlan with(nolock) ON dBPlan.BenefitPlanSK = fS2D.BenefitPlanSK
		INNER JOIN dw.dimServices AS dServices with(Nolock) ON dServices.ServicesSK = fS2D.ServicesSK
		INNER JOIN dw.dimConsumers AS dConsumers with(nolock) ON fTAR.ConsumerSK = dConsumers.ConsumerSK
		INNER JOIN dw.dimConsumers AS dCurrentConsumer with(nolock) ON dCurrentConsumer.ConsumerNK = dConsumers.ConsumerNK AND dCurrentConsumer.ETLCurrentRow = 1
		INNER JOIN dw.dimOrganization AS do with(nolock) ON do.County = dCurrentConsumer.County
		INNER JOIN dw.dimProvider AS dProvider with(nolock) ON fTAR.ProviderSK = dProvider.ProviderSK
		INNER JOIN dw.dimDiagnosis AS dDiag with(nolock) ON dDiag.DiagnosisSK = fS2D.DiagnosisSK
		INNER JOIN dw.dimEmployee AS dEmp with(nolock) ON dEmp.EmployeeSK = fTAR.TARAssigneeSK
		INNER JOIN dw.dimJunk AS TarType with(nolock) ON TarType.JunkSK = fTAR.RequestTypeSK AND TarType.JunkEntity = 'RequestType'
		INNER JOIN dw.dimJunk AS ActionTaken with(nolock) ON ActionTaken.JunkSK = fS2D.ActionTakenSK AND ActionTaken.JunkEntity = 'ActionTaken'
		INNER JOIN dw.dimJunk AS ReviewProgCode with(nolock) ON ReviewProgCode.JunkSK = fTAR.ReviewProgCodeSK AND ReviewProgCode.JunkEntity = 'ReviewProgCode'
		INNER JOIN dw.dimJunk AS SpecialtyCode with(nolock) ON SpecialtyCode.JunkSK = fTAR.SpecialtyCodeSK AND SpecialtyCode.JunkEntity = 'SpecialtyCode'
		INNER JOIN dw.dimDate AS SubmitDate with(nolock) ON SubmitDate.DateSK = fTAR.OriginalSubmitDateSK
		INNER JOIN dw.dimDate AS UpdateDate with(nolock) ON UpdateDate.DateSK = fS2D.TARServiceUpdateDateSK
		INNER JOIN dbo.cfn_split(@DisabilityType , ',') fnDisability ON fnDisability.element = SpecialtyCode.JunkValue
		INNER JOIN dbo.cfn_split(@ActionTaken , ',') fnAction ON fnAction.element = ActionTaken.JunkValue
		INNER JOIN dbo.cfn_split(@ServiceDefinition , ',') fnServices ON fnServices.element = dServices.ServiceDefinitionID
		INNER JOIN dbo.cfn_split(@BenefitPlan , ',') fnBenePlan ON fnBenePlan.element = dBPlan.BenefitPlanNK
		INNER JOIN dbo.cfn_split(@CareManager , ',') fnCareMan ON fnCareMan.element = dEmp.EmployeeNK
WHERE	dConsumers.ConsumerNK <> -1
		AND ReviewProgCode.JunkValue <> 'VOID'
		AND ActionTaken.JunkValue <> 'NR'
		AND fTAR.OriginalSubmitDateSK <> -1
		AND ( 
				( @DateType = 1 AND UpdateDate.DateValue BETWEEN @StartDate AND @EndDate ) -- By Processed Date
				OR
				( @DateType = 2 AND SubmitDate.DateValue BETWEEN @StartDate AND @EndDate ) -- By Received Date
			)
		AND (
				@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
		AND ( @Provider = -2 OR dProvider.ProviderNK = @Provider )
ORDER BY dCurrentConsumer.LastName, dCurrentConsumer.FirstName		

IF @Provider <> -2
	BEGIN
		SELECT * FROM #temp
	END
ELSE
	BEGIN
		SELECT  @FilePath = EmployeeBulkReportPath
		FROM    dw.dimEmployee
		WHERE   AccountName like '%' + @UserLogin
		      
		SET		@filenm = @FilePath + '\' + 'TAR_Compliance_Detail_data_dump' + CONVERT(VARCHAR(8),GETDATE(), 112) +
					  REPLACE(CONVERT(VARCHAR(20),GETDATE(), 114), ':', '') + '.csv' 

		DELETE FROM ODS.DataExports WHERE StoredProcedure = @ProcName;
		INSERT INTO ODS.DataExports ( StoredProcedure, DataValues )
			SELECT	@ProcName,
						' Consumer ID,' +
						'Last Name,' +
						'First Name,' +
						'DOB,' +
						'County of Residence Medicaid,' +
						'Insurance,' +
						'TAR#,' +
						'TAR Type,' +
						'Expedited,' +
						'Service Request Date,' +
						'Service Requested,' +
						'Service Code,' +
						'Action Taken,' +
						'Action Date,' +
						'Number of Days to Act,' +
						'Diagnosis Code,' +
						'Disability Type,' +
						'Provider ID,' +
						'Submitting Provider,' +
						'Care Manager,' +
						'TAR Service ID' AS LastName
			UNION ALL
			SELECT		DISTINCT
                        @ProcName,
                        CAST(t.ConsumerID AS VARCHAR(20)) + ',' +
                        + '"' + ISNULL(t.LastName,'') + '"' + ',' +
                        ISNULL(t.FirstName,'') + ',' +
                        CAST(t.DOB AS VARCHAR(20)) + ',' +
                        ISNULL(t.CountyOfResidenceMedicaid,'') + ',' +
                        ISNULL(RTRIM(t.BenefitPlanShort),'') + ',' +
                        CAST(t.TAR_ID AS VARCHAR(20)) + ',' +
                        ISNULL(t.TAR_Type,'') + ',' +
                        ISNULL(t.Expedited,'') + ',' +
                        CAST(t.ServiceRequestDate AS VARCHAR(20)) + ',' +
                        + '"' + ISNULL(t.ServiceRequested,'') + '"' + ',' +
                        ISNULL(t.ServiceCode,'') + ',' +
                        ISNULL(t.ActionTaken,'') + ',' +
                        CAST(t.ActionDate AS VARCHAR(20)) + ',' +
                        CAST(t.NumberOfDaysToAct AS VARCHAR(20)) + ',' +
                        ISNULL(t.DiagnosisCode,'') + ',' +
                        ISNULL(t.DisabilityType,'') + ',' +
                        CAST(t.ProviderID AS VARCHAR(20)) + ',' +
                        + '"' + ISNULL(t.SubmittingProvider,'') + '"' + ',' +
                        ISNULL(t.CareManager,'') + ',' +
                        CAST(t.TarServiceID AS VARCHAR(20)) AS txt
			FROM		#temp AS t
			ORDER BY	LastName	
	
--SELECT * FROM ODS.DataExports WHERE StoredProcedure = @ProcName ORDER BY RowID

		DECLARE	@cmd VARCHAR(1000) ,
				@rc INT = 0                    
                 
		SET		@cmd = 'bcp.exe "SELECT DataValues FROM BIW.ODS.DataExports WITH (NOLOCK)' + 
						' WHERE StoredProcedure = ' + '''' + @ProcName + '''' + ' ORDER BY RowID" QUERYOUT "c:\Temp\'
						+ RTRIM(@@SERVICENAME) + '\output.csv" -q -c -t "," -S "'
						+ RTRIM(@@SERVERNAME) + '" -T'
                                               				                            
		EXECUTE master..xp_cmdshell @cmd, NO_OUTPUT
             
		IF @@error <> 0 OR @rc <> 0 
			BEGIN
				RAISERROR('xp_cmdshell bcp failed !!!',16,1)
				RETURN
			END

		SET @cmd = 'move c:\Temp\' + RTRIM(@@SERVICENAME) + '\output.csv "' + RTRIM(@filenm) + '"'
		EXECUTE master..xp_cmdshell @cmd, no_output
         
		IF @@error <> 0 OR @rc <> 0 
		BEGIN
			RAISERROR('xp_cmdshell move failed !!!',16,1)
			RETURN
		END    
         
		SELECT	'EXPORT' AS ConsumerID,
				@filenm AS LastName,
				NULL AS FirstName,
				NULL AS DOB,
				NULL AS CountyOfResidenceMedicaid,
				NULL AS BenefitPlanShort,
				NULL AS TAR_ID,
				NULL AS TAR_Type,
				NULL AS Expedited,
				NULL AS ServiceRequestDate,
				NULL AS ServiceRequested,
				NULL AS ServiceCode,
				NULL AS ActionTaken,
				NULL AS ActionDate,
				NULL AS NumberOfDaysToAct,
				NULL AS DiagnosisCode,
				NULL AS DisabilityType,
				NULL AS ProviderID,
				NULL AS SubmittingProvider,
				NULL AS CareManager,
				NULL AS TarServiceID

	END
