USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ListCareManager] AS

/*------------------------------------------------------------------------------
	Title:		List Care Manager
	File:		[Rep].[ListCareManager] 
	Author:		Divya Lakshmi
	Date:		08/14/2013
	Desc:		This listing of Care Managers can be used to fill the 
					available values for Care Manager Parameters

	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/14/2013		Divya Lakshmi			6533       		Created
			1.1		08/27/2013		Doug Cox				6532			Changed to use factTAR.TARAssigneeSK
																			And added Unknown
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		AND ( @CareManager = -2 OR dEmp.EmployeeNK = @CareManager )

-----------------------------------------------------------------------------------*/

SELECT  -2 AS EmpID,
		100 AS ccOrder,
		'All Care Managers' AS ccName
UNION
SELECT  -1 AS EmpID,
		150 AS ccOrder,
		'Unknown' AS ccName
UNION
SELECT	DISTINCT 	
		dEmp.EmployeeNK AS EmpID,
		200 AS ccOrder,
		dEmp.LastName + ', ' +  dEmp.FirstName AS ccName
FROM	DW.factTreatmentAuthorizationRequest AS fTAR with(nolock) 
		INNER JOIN DW.dimEmployee AS dEmp with(nolock) ON  dEmp.EmployeeSK = fTAR.TARAssigneeSK
ORDER BY ccOrder, ccName