USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[MedicaidCapitatedPaymentsReceivedAfterDecesaedDate]    Script Date: 08/29/2013 09:14:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[MedicaidCapitatedPaymentsReceivedAfterDecesaedDate]
	@StartDate DATE,
	@EndDate DATE,
	@Catchment VARCHAR(50)
AS

/*
	------------------------------------------------------------------------------
	Title:		Medicaid Capitated Payments Received After Decesaed Date
	File:		[Rep].[MedicaidCapitatedPaymentsReceivedAfterDecesaedDate]
	Author:		Tim Amerson
	Date:		08/29/2013
	Desc:		To monitor and check for payments received after a client's deceased date.
                                        
	Called By:
                        Reports:	FIN021 - Medicaid Capitated Payments Received After Decesaed Date
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/29/2013		Tim Amerson     		6434			Created

	-----------------------------------------------------------------------------------
*/

--DECLARE
--	@StartDate DATE = '1/1/2013'
--	, @EndDate DATE = '6/30/2013'
--	, @Catchment VARCHAR(50)

SELECT DISTINCT
	dcel.ConsumerNK
	, dcel.FirstName
	, dcel.LastName
	, dcel.DOD
	, fe.InsuranceNumber
	, dbpel.BenefitPlanNK
	, fc.PaidAmount
	, fc.AdjudicatedAmount
	, fc.ClaimAmount
	, fc.AdjustedAmount
	, fc.CreditAmount
	, dPaid.[MonthName_en-US] PaidMonth
	, dPaid.[YearName_en-US] PaidYear
	, dPaid.[DateName_en-US] PaidDate
	, dRec.[DateName_en-US] ReceivedDate
	, jCap.JunkValue
	, emp.FullName
	, do.Catchment
	, dcel.DeceasedUpdatedByEmployee
	, dcel.DeceasedUpdateDate
	
FROM
	dw.factEligibility fe WITH(NOLOCK)
	INNER JOIN dw.dimConsumers dcel WITH(NOLOCK) ON fe.ConsumerSK = dcel.ConsumerSK
	INNER JOIN dw.dimBenefitPlan dbpel WITH(NOLOCK) ON fe.BenefitPlanSK = dbpel.BenefitPlanSK
	INNER JOIN dw.dimDate dEff WITH(NOLOCK) ON fe.DateSK = dEff.DateSK
	
	INNER JOIN dw.dimConsumers dccl WITH(NOLOCK) ON dcel.ConsumerNK = dccl.ConsumerNK
	INNER JOIN dw.dimBenefitPlan dbpcl WITH(NOLOCK) ON dbpel.BenefitPlanNK = dbpcl.BenefitPlanNK
	INNER JOIN dw.factClaims fc WITH(NOLOCK) ON fc.ConsumerSK = dccl.ConsumerSK AND fc.BenefitPlanSK = dbpcl.BenefitPlanSK
	INNER JOIN dw.dimDate dPaid WITH(NOLOCK) ON fc.PaidDateSK = dPaid.DateSK
	INNER JOIN dw.dimDate dRec WITH(NOLOCK) ON fc.ReceivedDateSK = dRec.DateSK
	INNER JOIN dw.dimJunk jCap WITH(NOLOCK) ON fc.CapitatedSK = jCap.JunkSK
	INNER JOIN dw.dimEmployee emp WITH(NOLOCK) ON fc.EmployeeSK = emp.EmployeeSK
	INNER JOIN dw.dimOrganization do WITH(NOLOCK) ON fc.OrganizationSK = do.OrganizationSK
	INNER JOIN dbo.cfn_split(@catchment, ',') cc ON do.CatchmentID = cc.element
	
WHERE 1=1
	AND dbpcl.InsurerID = 2
	AND jCap.JunkNK = '1'
	AND dEff.DateValue > dcel.DOD
	AND dccl.DOD BETWEEN @StartDate AND @EndDate