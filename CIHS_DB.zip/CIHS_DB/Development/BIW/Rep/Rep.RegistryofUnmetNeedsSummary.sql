USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[RegistryofUnmetNeedsSummary]
	@StartDate DATE ,
	@EndDate DATE,
	@Diagnosis INT, 
	@RegistryService VARCHAR(MAX),
	@Catchment VARCHAR(MAX)
AS

/*	------------------------------------------------------------------------------
	Title:		Registry of Unmet Needs Summary	
	File:		[Rep].[RegistryofUnmetNeedsSummary]
	Author:		Doug Cox
	Date:		08/20/2013
	Desc:		Individuals regardless of insurance waiting on DD, MH or SA services.
                                        
	Called By:
                        Reports:	UMA023 - RegistryofUnmetNeedsSummary.RDL
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/20/2013		Doug Cox				6509			Created
			1.1		09/17/2013		Doug Cox				6509			Added 'Awaiting Innovations'

	-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATE = '1/1/13',
--	@EndDate DATE = '1/31/13',
--	@Diagnosis INT = '-300',
--	@RegistryService VARCHAR(MAX) = '-400,-272,-269,-223,-21,-1,1,68,74,158,159,160,165,171,177,178,182,183,184,1183,1184,1187,1191,1202,1489',
--	@Catchment VARCHAR(MAX) = '-300'--'1021'

IF object_id('tempdb..#temp') is not null
BEGIN
	DROP TABLE #temp
END

SELECT	DISTINCT 
		dO.Catchment,
		dC.County,
		fRWL.AwaitingInnovationsFlag,
		CASE WHEN fRWL.AwaitingInnovationsFlag = 1 THEN 'Awaiting Innovations' ELSE dS.ServiceDescription END AS ServiceDescription,
		dC.ConsumerNK, 
		fRWL.RegistryClientStatusSK,
		dStatus.JunkValue AS RegStatus,
		dS.ServicesNK
INTO	#temp
FROM	DW.factRegistryWaitingList AS fRWL with(nolock)
		INNER JOIN dw.dimServices AS dS WITH(NOLOCK) ON dS.ServicesSK = fRWL.ServicesSK
		INNER JOIN dw.dimConsumers AS dC with(nolock) ON dC.ConsumerSK = fRWL.ConsumerSK
		INNER JOIN dw.dimOrganization AS dO with(nolock) ON dO.County = dC.County
		INNER JOIN dw.dimDate AS dD with(nolock) ON dD.DateSK = fRWL.DateWaitingSK
		INNER JOIN dw.dimJunk AS dStatus with(nolock) ON dStatus.JunkSK = fRWL.RegistryClientStatusSK AND dStatus.JunkEntity = 'RegistryClientStatus'
WHERE	1=1
		AND dD.DateValue BETWEEN @StartDate AND @EndDate
		AND (
			@Diagnosis = -300 
			OR @Diagnosis IN ( SELECT dJ.JunkNK FROM dw.dimJunk AS dJ with(nolock) WHERE dJ.JunkSK = fRWL.ServiceTypeSK AND dJ.JunkEntity = 'ServiceType' )
			OR fRWL.AwaitingInnovationsFlag = 1 
			)
		AND	(
			@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			)
		AND ( 
			( fRWL.AwaitingInnovationsFlag = 0 AND dS.ServicesNK IN ( SELECT fn.element FROM dbo.cfn_split(@RegistryService , ',') AS fn ) )
			OR ( fRWL.AwaitingInnovationsFlag = 1 AND -400 IN ( SELECT fn.element FROM dbo.cfn_split(@RegistryService , ',') AS fn ) )
			)

--SELECT	* FROM #temp WHERE AwaitingInnovationsFlag = 1
		
SELECT	DISTINCT
		t1.Catchment,
		t1.County,
		t1.ServiceDescription,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Available' ) AS Available,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Pend' ) AS Pend,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Placed' ) AS Placed,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Removed' ) AS Removed,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Under Review' ) AS UnderReview,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Referral Closed' ) AS ReferralClosed,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t 
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County AND t.RegStatus = 'Not Eligible' ) AS NotEligible,
		( SELECT COUNT(distinct t.ConsumerNK) FROM #temp t  
			WHERE t.ServiceDescription = t1.ServiceDescription AND t.County = t1.County ) AS Total
FROM	#temp AS t1