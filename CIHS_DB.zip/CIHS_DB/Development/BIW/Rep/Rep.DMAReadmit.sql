USE [BIW]
GO
/****** Object:  StoredProcedure [Rep].[CSPRCommunityHospitalReadmissionsSummaryCount]    Script Date: 07/18/2013 13:57:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [Rep].[DMAReadmit] 
	@disch_dos_str_dt datetime,
	@disch_dos_end_dt datetime,
	@insurer int , 
	@srvc_def int = 1 , --1 = inpatient, 2 = detox, 3 = Facility based crisis, 4 = PRTF
	@diagnosis int,
	@catchment varchar(max) 
	,@days int,@report_Type int 
AS
/*------------------------------------------------------------------------------
	Title:		DMA Readmit
	File:		DMA Readmit
	Author:		Karen Roslund
	Date:		7/5/2013
	Desc:		Identify discharge, readmit and length of stay for inpatient claims.			
                                        
	Called By:
                        Reports:          Coming Soon....
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		7/19/2013		Karen Roslund    			6378			Created
			1.1		7/29/2013		Karen Roslund    			6378			Added logic to use custom group instead of service codes
			1.2		9/19/2013		Karen Roslund				6378			Added logic to remove the same the discharged claims showing up as a readmit
--	-----------------------------------------------------------------------------------*/


BEGIN

--declare @disch_dos_str_dt datetime = '1/1/2013', @disch_dos_end_dt datetime = '3/31/2013',@insurer int = -200, 
--@srvc_def int = 2 , --1 = inpatient, 2 = detox, 3 = Facility based crisis, 4 = PRTF
--@diagnosis int =-300, @catchment nvarchar(max) = '-300',@days int = 100,@report_Type int =1


select 
dc.ConsumerNK,
dc.FullName consumer_name,
da.AgeValue, 
dc.DOB,
dbp.BenefitPlanShort as insurance,
do.County,
dd.DiagnosisGroupID,
dd.DiagnosisGroup,
d.[DateName_en-US] date_of_discharge,
dp.ProviderName,
flos.ClaimNumber,
fc.ClaimDetailNumber,
ds.ServiceCode,
dateadd(dd,-(flos.lengthofstay -1),d.DateValue) discharge_claim_start_date,
d.[DateName_en-US] discharge_claim_end_dt,
do.Catchment, 
flos.LengthOfStay -1 as LengthOfStay,
ROW_NUMBER() OVER (Partition by flos.claimnumber ORDER BY fc.claimdetailnumber ASC) as firstVisit  

into #discharges

From dw.factLengthOfStay flos with (nolock)
Inner join dw.dimDate d with (nolock) on  flos.DateSK = d.DateSK 
Inner join DW.factClaims fc with (nolock) on flos.ClaimNumber = fc.ClaimNumber and flos.ClaimAdjudicationNumber = fc.ClaimAdjudicationNumber 
inner join dw.dimConsumers dc with (nolock) on flos.ConsumerSK = dc.ConsumerSK 
inner join dw.dimOrganization do with (nolock) on fc.OrganizationSK = do.OrganizationSK
Inner join dw.dimDiagnosis dd with (nolock) on fc.Diagnosis1SK = dd.DiagnosisSK 
Inner join DW.dimBenefitPlan dbp with (nolock) on fc.BenefitPlanSK = dbp.BenefitPlanSK 
inner join dw.dimAge da with (nolock) on fc.AgeSK = da.AgeSK 
inner join DW.dimProvider dp with (nolock) on flos.ProviderSK = dp.ProviderSK 
inner join DW.dimServices ds with (nolock) on flos.ServiceSK = ds.ServicesSK 
Inner join DW.dimCustomReportGroups ServCode WITH(NOLOCK) ON ds.servicesnk  = ServCode.AttributeID 
 
 
 where 
 fc.StatusSK = 1
 and d.DateValue between @disch_dos_str_dt and @disch_dos_end_dt 
 and  (
	
					@catchment = '-300'
					OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

				)
 and ((@srvc_def = 1 and  (ds.ServiceDefinitionID <> 46 AND ds.ServiceCode <> '100') and
       servcode.CustomGroupName =  'ReadmissionInpatientCodes')
       or ( @srvc_def = 2 and servcode.CustomGroupName = 'DMAReadmitGroups' and servcode.CustomGroupValue = 'Detox')
       or ( @srvc_Def = 3 and servcode.CustomGroupName = 'DMAReadmitGroups' and servcode.CustomGroupValue = 'Facility Based Crisis')
       or ( @srvc_def = 4 and servcode.CustomGroupName = 'DMAReadmitGroups' and servcode.CustomGroupValue = 'PRTF')
       or ( @srvc_def = -1 and ServCode.CustomGroupName in ('ReadmissionInpatientCodes','DMAReadmitGroups')))
     
       
  and ((@diagnosis = -300 )
        or (dd.DiagnosisGroupID  = @diagnosis ))
  and ((@insurer = -200)--all plans
        or (@insurer = -100 and dbp.BenefitPlanNK >=2 )
        or (dbp.BenefitPlanNK   = @insurer ))
          
          
          
          
order by dc.ConsumerNK 

delete from #discharges where firstVisit <> 1

select 
dc.ConsumerNK,
dc.FullName consumer_name,
da.AgeValue, 
dc.DOB,
dbp.BenefitPlanShort as insurance,
do.County,
dd.DiagnosisGroupID,
dd.DiagnosisGroup,
d.[DateName_en-US] date_of_discharge,
dp.ProviderName,
flos.ClaimNumber,
fc.ClaimDetailNumber,
flos.ClaimAdjudicationNumber,
ds.ServiceCode,
dateadd(dd,-(flos.lengthofstay -1),d.DateValue) discharge_claim_start_date,
d.[DateName_en-US] discharge_claim_end_dt,
do.Catchment 
--ROW_NUMBER() OVER (Partition by dc.consumernk ORDER BY dateadd(dd,-(flos.lengthofstay -1),d.DateValue) ASC) as firstVisit  

into #readmits

From dw.factLengthOfStay flos with (nolock)
Inner join dw.dimDate d with (nolock) on  flos.DateSK = d.DateSK 
Inner join DW.factClaims fc with (nolock) on flos.ClaimNumber = fc.ClaimNumber and flos.ClaimAdjudicationNumber = fc.ClaimAdjudicationNumber 
inner join dw.dimConsumers dc with (nolock) on flos.ConsumerSK = dc.ConsumerSK 
inner join dw.dimOrganization do with (nolock) on fc.OrganizationSK = do.OrganizationSK
Inner join dw.dimDiagnosis dd with (nolock) on fc.Diagnosis1SK = dd.DiagnosisSK 
Inner join DW.dimBenefitPlan dbp with (nolock) on fc.BenefitPlanSK = dbp.BenefitPlanSK 
inner join dw.dimAge da with (nolock) on fc.AgeSK = da.AgeSK 
inner join DW.dimProvider dp with (nolock) on flos.ProviderSK = dp.ProviderSK 
inner join DW.dimServices ds with (nolock) on flos.ServiceSK = ds.ServicesSK 
Inner join #discharges dish on dc.ConsumerNK = dish.ConsumerNK 
Inner join DW.dimCustomReportGroups ServCode WITH(NOLOCK) ON ds.ServiceCode  = ServCode.BeganAttributeCodeRange 
 
 where 
 fc.StatusSK = 1
 and DATEADD(dd, @days, d.DateValue) > dish.discharge_claim_start_date
                            AND DATEDIFF(dd, dish.discharge_claim_start_date, d.DateValue) BETWEEN 2 AND @days
 --and dish.ClaimNumber <> flos.ClaimNumber 
 --and dish.ClaimDetailNumber  <> fc.ClaimDetailNumber 
 and flos.ClaimNumber not in (select ClaimNumber from #discharges)
 and  (
	
					@catchment = '-300'
					OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
					OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

				)
 and ((@srvc_def = 1 and  (ds.ServiceDefinitionID <> 46 AND ds.ServiceCode <> '100') and
 servcode.CustomGroupName =  'ReadmissionInpatientCodes')
       or ( @srvc_def = 2 and servcode.CustomGroupName = 'DMAReadmitGroups' and servcode.CustomGroupValue = 'Detox')
       or ( @srvc_Def = 3 and servcode.CustomGroupName = 'DMAReadmitGroups' and servcode.CustomGroupValue = 'Facility Based Crisis')
       or ( @srvc_def = 4 and servcode.CustomGroupName = 'DMAReadmitGroups' and servcode.CustomGroupValue = 'PRTF')
       or ( @srvc_def = -1 and ServCode.CustomGroupName in ('ReadmissionInpatientCodes','DMAReadmitGroups')))
       
  and ((@diagnosis = -300 )
        or (dd.DiagnosisGroupID  = @diagnosis ))
  and ((@insurer = -200)--all plans
        or (@insurer = -100 and dbp.BenefitPlanNK >=2 )
        or (dbp.BenefitPlanNK   = @insurer ))
        
order by dc.ConsumerNK  

--select * from #discharges 
--select * from #readmits 



--select * from dw.dimdiagnosis where ServiceSK = -1

create table #temp_final
(
Client_Name varchar(200),
Client_ID int,
Client_AGE int,
Client_DOB datetime,
Insurance varchar(200),
Client_County varchar(200),
discharge_diag_group int,
Discharge_Diagnosis varchar(200),
Discharge_Date datetime,
Discharge_Provider_Name varchar(2000),
Discharge_Claim_Master_ID int,
Discharge_Claim_Detail_ID int,
Discharge_Service_Code varchar(20),
Discharge_Claim_Start_Date datetime,
Discharge_Claim_End_Date datetime,
readmit_client_Id int,
Readmit_Claim_Master_ID int,
Readmit_Claim_Detail_ID int,
Readmit_Diagnosis varchar(20),
Readmit_Claim_Service_Code varchar(20),
Readmit_Date datetime,
Readmit_Provider_Name varchar(2000),
Client_Catchment varchar(2000),
Length_of_Stay int,
no_Readmits float,
Perc_length_of_Stay float,
Average_Length_of_Stay float,
Distinct_Total_Readmits int,
Total_No_of_Discharges int,
age_group varchar(200)
)
if @report_Type = 0
begin
insert into #temp_final
(Client_ID,Client_Name,Client_AGE,Client_DOB,Insurance,Client_County,discharge_diag_group,Discharge_Diagnosis,
Discharge_Date,Discharge_Provider_Name,Discharge_Service_Code,Discharge_Claim_Master_ID,Discharge_Claim_Detail_ID,
Discharge_Claim_Start_Date,Discharge_Claim_End_Date,readmit_client_id,Readmit_Claim_Master_ID,Readmit_Claim_Detail_ID,Readmit_Diagnosis,
Readmit_Claim_Service_Code,Readmit_Provider_Name,Readmit_Date,Client_Catchment,Length_of_Stay)
(
select distinct
t.ConsumerNK,
t.consumer_name,
t.AgeValue,
t.DOB,
t.insurance,
t.County,
t.DiagnosisGroupID,
t.DiagnosisGroup,
t.date_of_discharge,
t.ProviderName, 
t.ServiceCode,
t.ClaimNumber,
t.ClaimDetailNumber,
t.discharge_claim_start_date,
t.discharge_claim_end_dt,
t1.ConsumerNK as readmit_client_id,
t1.ClaimNumber as readmit_claimnumber,
t1.ClaimDetailNumber as readmit_claimdetail,
t1.DiagnosisGroup as readmit_diagnosis,
t1.ServiceCode as readmit_service,
t1.ProviderName as readmit_provider,
t1.discharge_claim_start_date readmit_dt,
t.Catchment,
t.LengthOfStay 
 

From 
#discharges t
left outer join #readmits t1 on t.ConsumerNK = t1.consumernk 
)
select * from #temp_final 
end 


if @report_Type = 1
begin

select distinct
t.ConsumerNK,
t.consumer_name,
t.AgeValue,
t.DOB,
t.insurance,
t.County,
t.DiagnosisGroupID,
t.DiagnosisGroup,
t.date_of_discharge,
t.ProviderName, 
t.ServiceCode,
t.ClaimNumber,
t.ClaimDetailNumber,
t.discharge_claim_start_date,
t.discharge_claim_end_dt,
t1.ConsumerNK as readmit_client_id,
t1.ClaimNumber as readmit_claimnumber,
t1.ClaimDetailNumber as readmit_claimdetail,
t1.DiagnosisGroup as readmit_diagnosis,
t1.ServiceCode as readmit_service,
t1.ProviderName as readmit_provider,
t1.discharge_claim_start_date readmit_dt,
t.Catchment,
t.LengthOfStay 
into #temp 

From 
#discharges t
left outer join #readmits t1 on t.ConsumerNK = t1.consumernk 

insert into #temp_final
(discharge_diag_group ,discharge_diagnosis,age_group )
select 3,'MH' ,'0-12'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 3,'MH' ,'13-17'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 3,'MH' ,'18-20'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 3,'MH' ,'21-34'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 3,'MH' ,'35-64'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 3,'MH' ,'65+'

insert into #temp_final
(discharge_diag_group ,Discharge_Diagnosis,age_group )
select 2,'DD' ,'0-12'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 2,'DD' ,'13-17'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 2,'DD' ,'18-20'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 2,'DD' ,'21-34'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 2,'DD' ,'35-64'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 2,'DD' ,'65+'

insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'0-12'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'13-17'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'18-20'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'21-34'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'35-64'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'65+'

insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 2,'DD' ,'Total'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 3,'MH' ,'Total'
insert into #temp_final
(discharge_diag_group,discharge_diagnosis,age_group )
select 4,'SA' ,'Total'


--select * from  #temp_final 

;with cte as(
select 
DiagnosisGroup ,
DiagnosisGroupID,
COUNT( distinct   readmit_claimnumber     ) no_Readmits,
(cast(COUNT(distinct(readmit_claimnumber   )) as float)/cast(COUNT((ConsumerNK  )) as float)) *100 Perc_length_of_Stay,
SUM(LengthOfStay  ) length_of_stay,
cast(SUM(LengthOfStay  ) as float) / cast(COUNT(distinct isnull(readmit_claimnumber,0)   ) as float) Average_Length_of_Stay,
COUNT(distinct readmit_client_Id  )  Distinct_Total_Readmits ,
COUNT( ConsumerNK  ) Total_No_of_Discharges,
dg.CustomGroupValue   agegroup

--0-12
--13-17
--18-20
--21-34
--35-64
--65+"

from 
#temp t
Inner join dw.dimCustomReportGroups dg with (nolock) on dg.customgroupname = 'DMAReadmitAgeGroups' and  t.AgeValue between cast(dg.BeganAttributeCodeRange AS int) and cast(dg.EndAttributeCodeRange as int)
group by
dg.CustomGroupValue ,
DiagnosisGroup  ,DiagnosisGroupID
)

update t set 
t.no_Readmits =isnull(t1.no_Readmits,0) ,
t.Perc_length_of_Stay = isnull(t1.Perc_length_of_Stay,0.00) ,
t.Length_of_Stay = isnull(t1.length_of_stay,0) ,
t.Average_Length_of_Stay  = isnull(t1.Average_Length_of_Stay,0.00) ,
t.Distinct_Total_Readmits = isnull(t1.Distinct_Total_Readmits,0) ,
t.Total_No_of_Discharges =isnull(t1.Total_No_of_Discharges,0.00) 

from #temp_final t 
left outer join cte t1 on t.Discharge_Diagnosis = t1.DiagnosisGroup and t.age_group = t1.agegroup  and t.age_group <> 'Total'
where t.age_group <> 'Total'
;WITH    cte_tot
              AS ( SELECT  
               t99.discharge_diag_group  ,t99.Discharge_Diagnosis,
                            'Total' agegroup ,
                            SUM(no_Readmits) no_readmits ,
                            CASE WHEN sum(t99.Total_No_of_Discharges) =0 THEN 0 ELSE
                             ( ( SUM(CAST(no_readmits AS FLOAT))
                                / sum(CAST(t99.Total_No_of_Discharges  AS FLOAT)) ) * 100 ) END as Perc_length_of_Stay ,
                            CASE WHEN SUM(no_readmits)=0 THEN 0 ELSE
								( CAST(SUM(Average_Length_of_Stay ) AS FLOAT)
                              / CAST(SUM(no_readmits) AS FLOAT) ) END AS Average_Length_of_Stay ,
							SUM(Distinct_Total_Readmits) Distinct_Total_Readmits ,
                            sum(t99.Total_No_of_Discharges)  Total_No_of_Discharges ,
                            SUM(Length_of_Stay  ) Length_of_Stay
                   FROM     #temp_final  t99
                   --INNER JOIN #tempDiagGrpAdmitCount tdgac ON tdgac.diag_grp_desc = t99.diag_grp_desc
                   GROUP BY t99.discharge_diag_group ,t99.Discharge_Diagnosis
					)
               
update t set 
t.no_Readmits =isnull(t1.no_Readmits,0) ,
t.Perc_length_of_Stay = isnull(t1.Perc_length_of_Stay,0.00) ,
t.Length_of_Stay = isnull(t1.length_of_stay,0) ,
t.Average_Length_of_Stay  = isnull(t1.Average_Length_of_Stay,0.00) ,
t.Distinct_Total_Readmits = isnull(t1.Distinct_Total_Readmits,0) ,
t.Total_No_of_Discharges =isnull(t1.Total_No_of_Discharges,0.00) 

from #temp_final t 
left outer join cte_tot t1 on t.Discharge_Diagnosis = t1.Discharge_Diagnosis  and t.age_group = t1.agegroup  
where t.age_group = 'Total'

select * from #temp_final where discharge_diag_group = @diagnosis or @diagnosis = -300
drop table #temp 
end


drop table #discharges 
drop table #readmits 
drop table #temp_final



END