USE BIW
GO

CREATE PROCEDURE [REP].[DispositionByReferralTypeCallSummary]
	@StartDate DATETIME
	,@EndDate DATETIME
	,@ReferralType VARCHAR(50)
	,@Insurance INT
	,@CallCenterRep VARCHAR(MAX)
AS

/*------------------------------------------------------------------------------
	Title:		Disposition By Referral Type Call Summary
	File:		[Rep].[DispositionByReferralTypeCallSummary]
	Author:		Tim Amerson
	Date:		08/20/2013
	Desc:		Call counts by referral type with client detail information.
                                        
	Called By:
                        Reports:          UMA024 - Disposition By Referral Type Call Summary
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/20/2013		Tim Amerson     		6369			Created

	-----------------------------------------------------------------------------------*/
	
--DECLARE
--	@StartDate DATE = '1/1/13'
--	,@EndDate DATE = '1/31/13'
--	,@ReferralType VARCHAR(50) = '-2'
--	,@Insurance INT = -2
--	,@CallCenterRep VARCHAR(MAX) = -2
	
SELECT DISTINCT
	ReferralType = jRef.JunkValue
	,CallDisposition = jDisp.JunkValue
	,CallID = fc.CallID
	,CallDate = dStart.[DateName_en-US] + ' ' + tStart.StandardTime
	,ClientID = dc.ConsumerNK
	,ClientName = dc.FullName
	,CountyOfResidence = dc.County
	,CallCenterRepresentative = de.FullName

FROM
	dw.factCalls fc WITH(NOLOCK)
	INNER JOIN dw.dimJunk jDisp WITH(NOLOCK) ON fc.CallDispositionSK = jDisp.JunkSK
	INNER JOIN dw.dimJunk jRef WITH(NOLOCK) ON fc.ReferralTypeSK = jRef.JunkSK
	INNER JOIN dw.dimDate dStart WITH(NOLOCK) ON fc.CallStartDateSK = dStart.DateSK
	INNER JOIN dw.dimTime tStart WITH(NOLOCK) ON fc.CallStartTimeSK = tStart.TimeSK
	INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
	INNER JOIN dw.dimEmployee de WITH(NOLOCK) ON fc.EmployeeSK = de.EmployeeSK
	
	INNER JOIN dbo.cfn_split(@CallCenterRep, ',') fnRep ON fnRep.element = de.EmployeeNK
	
	LEFT JOIN dw.dimConsumers cElig WITH(NOLOCK) ON dc.ConsumerNK = cElig.ConsumerNK
	LEFT JOIN dw.factEligibility fe WITH(NOLOCK) ON cElig.ConsumerSK = fe.ConsumerSK
	LEFT JOIN dw.dimBenefitPlan bp WITH(NOLOCK) ON fe.BenefitPlanSK = bp.BenefitPlanSK

WHERE 1=1
	AND dStart.DateValue BETWEEN @StartDate AND @EndDate
	--AND ( de.EmployeeNK = @CallCenterRep OR @CallCenterRep = -2 )
	AND ( jRef.JunkNK = @ReferralType OR @ReferralType = '-2' )
	AND ( @Insurance = bp.InsurerID OR @Insurance = -2 )