USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ConsumerCrisisEventsPer10kPopulation]
( 
	@EndDt datetime,
	@PlanID int,
	@CountyCatchmentID varchar(max)
) AS

/*------------------------------------------------------------------------------
	Title:		Consumer Crisis Events Per 10k Population
	File:		ConsumerCrisisEventsPer10kPopulation
	Author:		Doug Cox
	Date:		02/18/2013
	Desc:		This report shows consumers who have received 3 or more crisis
				services (events) in the past year as well as the number per 
				10,000 eligible population 
					(distinct count of consumers/total eligible population X 10,000)			
                                        
	Called By:
                        Reports:          MCO Crisis Quarterly Report
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/13/2013		Doug Cox     			7062			Created
			1.1		03/25/2013		Doug Cox     			7062			Changed Services Filter
			1.2		03/29/2013		Doug Cox     			7062			Changed Services Filter again
			1.3		03/29/2013		Doug Cox				7062			Changed Eligibility Logic
			1.4		09/05/2013		Doug Cox				10090			Changed to ONLY USE ConsumerNK, not SK
																			AND Changed Medicaid Eligible to include Medicaid

	-----------------------------------------------------------------------------------*/

/*	TESTING	*/

--DECLARE @EndDt AS DATE = '8/31/2013';
--DECLARE @CountyCatchmentID AS varchar(max) = '-300';
--DECLARE @PlanID int = -200;

/*	END TESTING	*/

/* Date range is the year previous to the end date. */
DECLARE @BegDt AS DATE = DATEADD(YY,-1,@Enddt);

IF object_id('tempdb..#Crisis') is not null
BEGIN
    DROP TABLE #Crisis
END

IF object_id('tempdb..#MedicaidEligible') is not null
BEGIN
    DROP TABLE #MedicaidEligible
END

IF object_id('tempdb..#CrisisConsumers') is not null
BEGIN
    DROP TABLE #CrisisConsumers
END

IF object_id('tempdb..#Population') is not null
BEGIN
    DROP TABLE #Population
END

IF object_id('tempdb..#FinalStage') is not null
BEGIN
    DROP TABLE #FinalStage
END

/* Find all Crisis Events within date range */
SELECT DISTINCT
	do.OrganizationSK ,
	do.CatchmentID ,
	ROW_NUMBER () OVER (PARTITION BY fc.ConsumerSK ORDER BY fc.ConsumerSK, dd.DateValue) as InpRowNumber,
	dc.ConsumerNK AS ClientID,
	RTRIM(dc.LastName) + ', ' + RTRIM(dc.FirstName) AS ClientName,
	dc.DOB,
	datediff(yy,dc.DOB,GETDATE()) AS Age,
	bp.BenefitPlanShort AS Insurer,
	do.County,
	do.Catchment ,
	fc.ClaimNumber ,
	dd.DateValue AS DOS,
	diag.DiagnosisCode,
	diag.DiagnosisGroup AS DiagnosisCategory,
	ds.ServiceCode ,
	ds.ServiceDescriptionShort
INTO #Crisis
FROM dw.factClaims as fc with(nolock)
	INNER JOIN dw.dimConsumers as dc with(nolock) ON fc.ConsumerSK = dc.ConsumerSK
	INNER JOIN dw.dimServices as ds with(nolock) ON fc.ServicesSK = ds.ServicesSK
	-- Only Crisis Services:
	INNER JOIN dw.dimCustomReportGroups dcrg on ds.ServicesNK = dcrg.AttributeID --in this scenario - the Attribute ID is the Service ID (aka Service NK)
                                                                  and dcrg.CustomGroupName = 'CrisisServiceCodes'
	INNER JOIN dw.dimOrganization AS do with(nolock) ON fc.OrganizationSK = do.OrganizationSK
	INNER JOIN dw.dimDate as dd with(nolock) ON fc.DateOfServiceSK = dd.DateSK
	INNER JOIN dw.dimBenefitPlan as bp with(nolock) ON fc.BenefitPlanSK = bp.BenefitPlanSK
	INNER JOIN biw_stage.ODS.EstimatedCountyUninsured AS ecu with(nolock) ON ecu.County = do.County
	INNER JOIN dw.dimPlaceOfService AS dps with(nolock) ON dps.PlaceOfServiceSK = fc.PlaceOfServiceSK
	INNER JOIN dw.dimDiagnosis AS diag with(nolock) ON fc.Diagnosis1SK = diag.DiagnosisSK
WHERE 
	dd.DateValue > @BegDt and dd.DateValue <=@EndDt
	AND ( 	@CountyCatchmentID = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID , ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID , ',') )
		)
	AND ( 
			( @PlanID = bp.BenefitPlanSK ) OR -- Specific Plan
			( @PlanID = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
			( @PlanID = -200 ) -- ALL PLANS
		)
	AND fc.ConsumerSK > 0
	AND fc.StatusSK = 1
ORDER BY dc.ConsumerNK,
	dd.DateValue ;

/* Don't include if same claim number */
DELETE FROM t2
FROM #Crisis AS t1 
	INNER JOIN #Crisis AS t2 
		ON t1.ClientID = t2.ClientID
		 AND t1.CatchmentID = t2.CatchmentID
		 AND (t1.InpRowNumber + 1) <= t2.InpRowNumber
		 AND t2.ClaimNumber = t1.ClaimNumber
		 
/* Don't include if services on the same date */
DELETE FROM t2
FROM #Crisis AS t1 
	INNER JOIN #Crisis AS t2 
		ON t1.ClientID = t2.ClientID 
		 AND t1.CatchmentID = t2.CatchmentID
		 AND (t1.InpRowNumber + 1) <= t2.InpRowNumber
		 AND t2.DOS = t1.DOS

/* Don't include a 2nd event that happens within 24 hours */
DELETE FROM t2
FROM #Crisis AS t1 
	INNER JOIN #Crisis AS t2 
		ON t1.ClientID = t2.ClientID
		 AND t1.CatchmentID = t2.CatchmentID
		 AND (t1.InpRowNumber + 1) <= t2.InpRowNumber
		 AND t2.DOS = DATEADD(d,1,t1.DOS) 

/* Limit to Clients with 3 or more Crisis Events */
DELETE FROM #Crisis 
FROM #Crisis AS t3
INNER JOIN (SELECT CatchmentID, ClientID FROM #Crisis GROUP BY CatchmentID, ClientID HAVING COUNT(ClaimNumber) < 3) AS t4
ON t3.ClientID = t4.ClientID AND t3.CatchmentID = t4.CatchmentID

/* Build numerator by county */
SELECT 
	t5.ClientID,
	t5.ClientName,
	t5.DOB,
	t5.Age,
	t5.Insurer,
	t5.County,
	t5.Catchment,
	t5.CatchmentID,
	t5.DOS,
	t5.DiagnosisCode,
	t5.DiagnosisCategory,
	t5.ServiceCode,
	t5.ServiceDescriptionShort
INTO #CrisisConsumers
FROM #Crisis AS t5
ORDER BY t5.ClientID,
	t5.DOS

/* Find Medicaid Eligible by Catchment, Date, and Plan */
SELECT 
	do.CatchmentID,
	do.Catchment,
	COUNT(DISTINCT dc.ConsumerNK) AS MedicaidEligible
INTO #MedicaidEligible
FROM dw.factEligibility AS fe with(nolock) 
INNER JOIN dw.dimConsumers as dc with(nolock) ON dc.ConsumerSK = fe.ConsumerSK
INNER JOIN dw.dimDate as dd with(nolock) ON fe.DateSK = dd.DateSK
INNER JOIN dw.dimOrganization AS do with(nolock) ON fe.OrganizationSK = do.OrganizationSK
INNER JOIN dw.dimBenefitPlan AS bp with(nolock) ON fe.BenefitPlanSK = bp.BenefitPlanSK
WHERE dd.DateValue BETWEEN @BegDt AND @EndDt
	AND bp.InsurerID = 2  -- ONLY PULL MEDICAID
	AND ( 	@CountyCatchmentID = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID , ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID , ',') )
		)
GROUP BY
 	do.Catchment,
	do.CatchmentID

/* Build denominator by county */
SELECT 
	do.OrganizationSK,
	do.County,
	do.CatchmentID,
	do.Catchment,
	SUM(fp.[Population]) AS TotalPopulation,
	ECU.EstPercentUninsured AS EstPercentageUninsured,
	SUM(fp.[Population]) * ECU.EstPercentUninsured AS EstimateUninsured
INTO #Population
FROM DW.factPopulation AS fp with(nolock)
	INNER JOIN dw.dimOrganization AS do with(nolock) ON fp.OrganizationSK = do.OrganizationSK
	INNER JOIN biw_stage.ODS.EstimatedCountyUninsured AS ecu with(nolock) ON ecu.County = do.County
WHERE fp.[Year] = 2012
	AND ( 	@CountyCatchmentID = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID , ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID , ',') )
		)
GROUP BY 
	do.OrganizationSK,
	do.County,
	do.Catchment,
	do.CatchmentID,
	ECU.EstPercentUninsured

SELECT t1.CatchmentID,
	t1.Catchment, 
	SUM(t1.EstimateUninsured) AS TotalUninsured,
	(SELECT me.MedicaidEligible FROM #MedicaidEligible me WHERE me.CatchmentID = t1.CatchmentID) AS TotalEligible,
	SUM(t1.EstimateUninsured) + (SELECT me.MedicaidEligible FROM #MedicaidEligible me WHERE me.CatchmentID = t1.CatchmentID) AS EstimatedEligiblePopulation,
 	(SELECT COUNT(DISTINCT t2.ClientID) FROM #CrisisConsumers AS t2 WHERE t1.CatchmentID = t2.CatchmentID) AS CrisisConsumers,
	SUM(t1.TotalPopulation) AS TotalPopulation
INTO #FinalStage
FROM #Population AS t1
GROUP BY t1.CatchmentID,
	t1.Catchment

SELECT 
	pop.CatchmentID,
	Pop.Catchment AS Catchment,
	SUM(Pop.TotalPopulation) AS TotalPopulation,
	SUM(Pop.TotalUninsured) AS EstimatedUninsured,
	SUM(Pop.TotalEligible) AS MedicaidEligible,
	SUM(Pop.EstimatedEligiblePopulation) AS EstimatedEligiblePopulation,
	SUM(Pop.CrisisConsumers) AS CrisisConsumers,
	(SUM(CONVERT(FLOAT, Pop.CrisisConsumers) ) / SUM(Pop.TotalPopulation) ) * 10000 AS CrisisPerTotalPopulation,
	( SUM(Pop.CrisisConsumers) / SUM(Pop.EstimatedEligiblePopulation) ) * 10000 AS CrisisPerEligiblePopulation
FROM #FinalStage AS Pop
GROUP BY pop.CatchmentID, Pop.Catchment
UNION
SELECT 
	9999 AS CatchmentID,
	'Total' AS Catchment,
	SUM(Pop.TotalPopulation) AS TotalPopulation,
	SUM(Pop.TotalUninsured) AS EstimatedUninsured,
	SUM(Pop.TotalEligible) AS MedicaidEligible,
	SUM(Pop.EstimatedEligiblePopulation) AS EstimatedEligiblePopulation,
	SUM(Pop.CrisisConsumers) AS CrisisConsumers,
	(SUM(CONVERT(FLOAT, Pop.CrisisConsumers) ) / SUM(Pop.TotalPopulation) ) * 10000 AS CrisisPerTotalPopulation,
	( SUM(Pop.CrisisConsumers) / SUM(Pop.EstimatedEligiblePopulation) ) * 10000 AS CrisisPerEligiblePopulation
FROM #FinalStage AS Pop
GO
