USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ExtendedBillingDaysByProvider] ( @ProviderStatus INT, @ContractStatus INT, @ShowHeader INT ) AS

/*------------------------------------------------------------------------------
	Title:		Extended Billing Days By Provider
	File:		Rep.ExtendedBillingDaysByProvider.sql
	Author:		Doug Cox
	Date:		08/07/2013
	Desc:		Current contracts that have greater claim days then the standard 90 day rule
                                        
	Called By:
                Reports:          FIN018 - Extended Billing Days By Provider.rdl
                Stored Procs:     None

	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		08/07/2013		Doug Cox     			6387			Created

	-----------------------------------------------------------------------------------*/

	/*	TESTING	*/
	--DECLARE 
	--@ProviderStatus INT = 0, -- 1 = Active, 0 = Inactive, -2 = Both
	--@ContractStatus INT = -2, -- 1 = Active, 0 = Inactive, -2 = Both 
	--@ShowHeader INT	= 1
	/*	END TESTING	*/

	;WITH cteContract AS (
		SELECT	DISTINCT
				dProv.ProviderName,
				dProv.ProviderNK AS ProviderID,
				dProv.EntityType,
				dProv.StatusName,
				dProvContract.ProviderContractNK AS ProviderContractID,
				dProvContract.DaysAllowedClaimsSubmittal AS DaysAllowedforClaimSubmittal,
				ISNULL(dAdjDate.DateValue,'1-1-1900') AS ClaimsDayAdjustmentDate,
				dEmployee.FullName,
				ISNULL(fProvContractClaim.OldDaysAllowedClaimsSubmittal,0) AS OldDaysAllowedClaimsSubmittal,
				ISNULL(fProvContractClaim.NewDaysAllowedClaimsSubmittal,0) AS NewDaysAllowedClaimsSubmittal,
				fProvContractClaim.Comments,
				ROW_NUMBER() OVER ( PARTITION BY dProv.ProviderNK, dProvContract.ProviderContractSK ORDER BY dAdjDate.DateValue DESC ) AS RowNumber
		FROM	dw.dimProvider AS dProv with(nolock)
				INNER JOIN dw.factProviderContract AS fProvContract with(nolock) ON fProvContract.MainProviderSK = dProv.ProviderSK
				INNER JOIN dw.dimProviderContract AS dProvContract with(nolock) ON dProvContract.ProviderContractSK = fProvContract.ProviderContractSK
				LEFT OUTER JOIN dw.factProviderContractClaimDaysHistory AS fProvContractClaim with(nolock) ON fProvContractClaim.ProviderContractSK = fProvContract.ProviderContractSK
				LEFT OUTER JOIN dw.dimEmployee AS dEmployee with(nolock) ON dEmployee.EmployeeSK = fProvContractClaim.EmployeeSK
				LEFT OUTER JOIN dw.dimDate AS dAdjDate with(nolock) ON dAdjDate.DateSK = fProvContractClaim.ClaimsDayAdjustmentDateSK
		WHERE	dProv.ProviderNK = dProv.ParentProviderNK
				AND ( @ProviderStatus = -2 OR dProv.Active = @ProviderStatus )
				AND ( 
					@ContractStatus = -2 
					OR ( @ContractStatus = 1 AND GETDATE() BETWEEN dProvContract.ContractEffectiveDate AND dProvContract.ContractExpirationDate ) 
					OR ( @ContractStatus = 0 AND dProvContract.ContractExpirationDate < GETDATE() )
					)
				AND dProvContract.DaysAllowedClaimsSubmittal > 90
	)
	
	SELECT	*
	FROM	cteContract AS cte
	WHERE	cte.RowNumber = 1
	ORDER BY cte.ProviderName, cte.ProviderContractID
