USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[cspReportMedicaidStatistics]    Script Date: 08/01/2013 13:35:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO









-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[cspReportMedicaidStatistics]
@str_dt datetime,
@end_dt datetime,
@BenefitPlan int
AS

/*------------------------------------------------------------------------------
-- Title:	Medicaid Statistics
-- File:	[Rep].[MedicaidStatisticsReport]
-- Author:	Brian Angelo
-- Date:	04/16/2013
-- Desc:	Medicaid Statistics stored proc
--			
-- CalledBy:
-- 		Reports: "Medicaid Statistics"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	04/16/2013  Brian Angelo		8511	initial creation
--------------------------------------------------------------------------------*/

BEGIN

	SET NOCOUNT ON;

    
		--declare @str_dt datetime = '1/1/13',
		--@end_dt datetime = '1/31/13',
		--@BenefitPlan int = -200

		select distinct
		fc.ClaimNumber
		,fc.ClaimDetailNumber
		,fc.ClaimAdjudicationNumber
		,ServiceSummary = CASE 
			WHEN ds.ServiceCode IN (SELECT BeganAttributeCodeRange 
									FROM [BIW].[DW].[dimCustomReportGroups]
									WHERE CustomGroupName = 'RubiconServiceCodes') 
								AND dp.ICF = '1' 
			THEN 'ICF' ELSE ds.ServiceSummary END
		,fc.PaidAmount
		,fc.ConsumerSK
		,fc.UnitsBilled
		FROM
		[BIW].[DW].[factClaimsHistorical] fc WITH (NOLOCK)
		INNER JOIN [BIW].[DW].[dimDate] dd WITH (NOLOCK) ON fc.PaidDateSK = dd.DateSK
		INNER JOIN [BIW].[DW].[dimServices] ds WITH (NOLOCK) ON fc.ServicesSK = ds.ServicesSK
		INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH (NOLOCK) ON fc.BenefitPlanSK = dbp.BenefitPlanSK
		INNER JOIN [BIW].[DW].[dimProvider] dp WITH (NOLOCK) ON dp.ProviderSK = fc.ProviderSk
		WHERE dd.DateValue BETWEEN @str_dt AND @end_dt
		AND ((@BenefitPlan = -200) --All Plans
			  OR (@BenefitPlan = -100 AND dbp.InsurerID = 2) --All Medicaid Plans
			  OR (@BenefitPlan = dbp.BenefitPlanNK) --Specific Plan
			 )

    
END









GO


