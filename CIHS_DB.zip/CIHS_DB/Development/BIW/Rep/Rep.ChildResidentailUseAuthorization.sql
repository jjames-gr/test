USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ChildResidentailUseAuthorization]    Script Date: 09/25/2013 13:36:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ChildResidentailUseAuthorization] (
	@StartDate datetime,
	@EndDate datetime,
	@Catchment varchar(50) 
)
AS
/*------------------------------------------------------------------------------
-- Title:	Child Residentail Use Authorization
-- File:	[Rep].[ChildResidentailUseAuthorization]
-- Author:	Brian Angelo
-- Date:	09/17/2013
-- Desc:	Child Residentail Use Authorization stored proc
--			
-- CalledBy:
-- 		Reports: "Child Residentail Use Authorization"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	09/17/2013  	Brian Angelo	6295	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/*
	/*** Test Parameters ***/
    DECLARE @StartDate datetime = '6/1/13',
			@EndDate datetime = '6/30/13',
			@Catchment varchar(50) = '-300'
	--*/

	SELECT DISTINCT
	ds.ServiceCode
	,ds.ServiceDescriptionShort as ServiceDescription
	,dc.ConsumerNK as ClientID
	,dc.LastName
	,dc.FirstName
	,fa.AgeSK as AgeValue
	,fTAR.CalocusCalcScore
	,dd.DiagnosisCode as DiagnosisCode
	,dbp.BenefitPlanShort as BenefitPlan
	,dpParent.ProviderName + '/' + dp.ProviderName as ProviderSite
	,EffDate.DateValue as EffectiveFrom
	,ExpDate.DateValue as EffectiveTo
	,fa.AuthorizedUnits
	FROM  [BIW].[DW].[factAuthorizations] fa WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fa.ServicesSK
	INNER JOIN [BIW].[DW].[dimDate] EffDate WITH(NOLOCK) ON EffDate.DateSK = fa.EffectiveFromDateSK
	INNER JOIN [BIW].[DW].[dimDate] ExpDate WITH(NOLOCK) ON ExpDate.DateSK = fa.EffectiveToDateSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fa.OrganizationSK
	INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fa.ConsumerSK
	INNER JOIN [BIW].[DW].[factTreatmentAuthorizationRequest] fTAR WITH(NOLOCK) ON fTAR.TARID = fa.ReferenceNumber
	INNER JOIN [BIW].[DW].[factTARServiceToDiagnosis] fTARServDiag WITH(NOLOCK) ON fTARServDiag.TreatmentAuthorizationRequestSK = fTAR.FactTreatmentAuthorizationRequestSK
	INNER JOIN [BIW].[DW].[dimDiagnosis] dd WITH(NOLOCK) ON dd.DiagnosisSK = fTARServDiag.DiagnosisSK
	INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fa.BenefitPlanSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fa.ProviderSK
	INNER JOIN [BIW].[DW].[dimProvider] dpParent WITH(NOLOCK) ON dpParent.ProviderNK = dp.ParentProviderNK
	WHERE 1=1
	AND ds.ServicesNK IN (SELECT AttributeID FROM [BIW].[DW].[dimCustomReportGroups] WITH(NOLOCK)
							WHERE CustomGroupName = 'ChildResidentialAuthServices')
	AND EffDate.DateValue <= @EndDate
	AND ExpDate.DateValue >= @StartDate
	AND (@catchment = '-300'
				OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') ))



END


