USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalization]    Script Date: 08/29/2013 08:47:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




--USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalization_v1]    Script Date: 08/21/2013 13:44:39 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

----USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalization_v1]    Script Date: 08/19/2013 10:17:15 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

----USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalizationSummary_v1]    Script Date: 08/15/2013 09:57:28 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalizationSummary_1]    Script Date: 08/13/2013 10:44:09 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO





--USE BIW
----GO
--IF OBJECT_ID('tempdb..#tempins') IS NOT NULL    DROP TABLE #tempins
--IF OBJECT_ID('tempdb..#tempins2') IS NOT NULL    DROP TABLE #tempins2
--IF OBJECT_ID('tempdb..#tempins3') IS NOT NULL    DROP TABLE #tempins3

--IF OBJECT_ID('tempdb..#FollowUpClaims') IS NOT NULL    DROP TABLE #FollowUpClaims 
--IF OBJECT_ID('tempdb..#FollowUpClaims2') IS NOT NULL    DROP TABLE #FollowUpClaims2 
--IF OBJECT_ID('tempdb..#FollowUpClaims3') IS NOT NULL    DROP TABLE #FollowUpClaims3 

 
 /*-----------------------------------------------------------------------------
-- Title:  Follow-up After Hospitalization Summary
-- File:    
-- Author:        Melvin Black
-- Date: 7/1/2013
-- Desc:  [Rep].FollowUpAfterHospitalizationSummary
-- CalledBy:
--                           Reports: Follow-up After Hospitalization
--
--                           Stored Procs: None
--------------------------------------------------------------------------------
-- Change                History
-- Ver                   Date                     Author                     TixNo        Description
-- ---               ----------               ---------------				-----		--------------
-- 1.0                  7/1/2013				Melvin Black                 6393 		 Initial Development
	
----------------------------------------------------------------------------------
*/
CREATE PROCEDURE [REP].[FollowUpAfterHospitalization]
  
    @diagnosis INT ,
    @catchment NVARCHAR(MAX),
    @planfund INT,
    @str_dt DATETIME ,
    @end_dt DATETIME
AS 


--DECLARE @str_dt datetime, @end_dt datetime,  @catchment INT,   @planfund INT , @diagnosis INT 

--SET @str_dt = '1/1/2013' 
--SET @end_dt = '1/31/2013'
--SET @planfund = -200 -- 
--SET @diagnosis = 3-- 1 - MHH , 2 - SA  , 3 - MH
--SET @catchment = 1022

----------------------
 --Get MHH Data ------
----------------------  
IF   @diagnosis = 1
BEGIN
	  
	If OBJECT_ID('tempdb..#tempins') IS NOT NULL
		DROP TABLE #tempins  
	  
	SELECT  distinct
	  Case when co.AgeValue Between 5 and 13  Then 'Age 06-12' 
		  when co.AgeValue Between 12 and 18 Then 'Age 13-17' 
		  when co.AgeValue Between 17 and 21 Then 'Age 18-20' 
		  when co.AgeValue Between 20 and 35 Then 'Age 21-34' 
		  when co.AgeValue Between 36 and 65 Then 'Age 35-64' 
		  when co.AgeValue >= 65 Then 'Age 65+' End As AgeGroup,
	      Month(dtv.Datevalue) MonthOrder, 
	    Left(DateName(month,dtv.Datevalue),3) 
		+ '''' + right(convert(varchar,Year(dtv.Datevalue)),2) DisplayDate,
	  co.ConsumerNK			[Client ID],
	  co.ConsumerSK,
	  co.DOB				[Date of Birth],
	  co.AgeValue			[Age],
	  fc.ClaimNumber,
	  bt.BillTypeCodeNK		[Bill Type], -- RDD noted BillTypeNK	
	  srv.ServicesNK		[Discharge Service],
	  dia.DiagnosisCode		[Discharge Diagnosis],
	  dia.Diagnosis			[Discharge Diagnosis Description],
	  dia.DiagnosisGroupID    [DiagnosisGroupID],
	  pvr.ProviderNK		[Discharge Provider No.],
	  pvr.ProviderName		[Discharge Provider Name],
	  pls.[PlaceOfServiceCode] [PlaceOfServiceCode],
	  fc.ServiceLineRevenueCode ServiceLineRevenueCode,
	  dtv.Datevalue			[Follow Up Date],
	  los.DateSK            [DischargeDateSK],
	  ddt.DateValue         [Discharge Date],
	  srv.ServicesNK		[Follow Up Service],
	  dia.DiagnosisCode		[Follow Up Diagnosis],
	  dia.Diagnosis			[Follow Up Diagnosis Description],
	  pvr.ProviderNK		[Follow Up Provider No.],
	  pvr.ProviderName		[Follow Up Provider Name] 

	  
	  INTO #tempins
	  FROM DW.[factClaims] as fc
			JOIN DW.dimDate  			 dtv  with(nolock) on dtv.DateSK = fc.DateOfServiceSK
			JOIN DW.dimBenefitPlan	     ben with(nolock) on ben.BenefitPlanSK = fc.BenefitPlanSK
			JOIN DW.dimDiagnosis     	 dia with(nolock) on dia.DiagnosisSK  = fc.Diagnosis1SK 
			JOIN DW.dimOrganization  	 org with(nolock) on org.OrganizationSK = fc.OrganizationSK
			join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = fc.PlaceOfServiceSK
			JOIN DW.dimProvider  		 pvr with(nolock) on pvr.ProviderSK = fc.ProviderSK
			JOIN DW.dimServices 	 	 srv with(nolock) on srv.ServicesSK = fc.ServicesSK
			JOIN DW.dimAge       		 ag  with(nolock) on ag.AgeSK = fc.AgeSK
			JOIN DW.dimBillType    		 bt  with(nolock) on bt.BillTypeSK  = fc.BillTypeSK 
			JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = fc.ConsumerSK
			JOIN (select DISTINCT ClaimNumber, dateSK from DW.factLengthOfStay) los on los.ClaimNumber = fc.ClaimNumber
			JOIN DW.dimDate              ddt with(nolock)  on ddt.dateSK = los.DateSK
	 
	  WHERE dtv.DateValue BETWEEN @str_dt AND @end_dt
	  AND pls.PlaceOfServiceNK = 3 -- Global Filter 1 
	  AND fc.StatusSK = 1		  -- Global Filter 2
	  
		AND
			(
			( @planfund = ben.BenefitPlanNK ) OR -- 1 specific Plan
			( @planfund = -100 AND ben.InsurerID = 2 ) OR -- ALL Medicaid
			( @planfund = -200 ) -- ALL PLANS
		)
		AND(
	    
		 @catchment = '-300'
		 OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		 OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

			)


     AND DiagnosisGroupID = 3 -- MH/MHH
	 --Group by fc.AgeSK
	 

--------------------------------,
--- Follow Up Claims for MHH ---
---------------------------------

If OBJECT_ID('tempdb..#FollowUpClaims') IS NOT NULL
		DROP TABLE #FollowUpClaims 

Select distinct co.ConsumerNK, ClaimNumber, max(dt.DateValue)  FollowUpDate
 into #FollowUpClaims
 from  BIW.DW.factClaims   f
join BIW.DW.dimServices    s with(nolock) on s.ServicesSK = f.ServicesSK
JOIN DW.dimDiagnosis 	   dia with(nolock) on dia.DiagnosisSK  = f.Diagnosis1SK 
JOIN DW.dimDate            dt with(nolock) on dt.DateSK = f.DateOfServiceSK
join DW.dimPlaceOfService  pls with(nolock) on pls.PlaceOfServiceSK = f.PlaceOfServiceSK
JOIN DW.dimConsumers       co  with(nolock) on co.ConsumerSK = f .ConsumerSK
WHERE dt.DateValue Between Dateadd(dd,1,@str_dt) and Dateadd(dd,30,@end_dt)
AND
 (
	-- Group1_SC
	(convert(varchar,ServicesNK) IN 
	(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
	WHERE CustomGroupName = 'HEDISGroup1ServiceCodes'))

	OR 
	  
	-- Group2
	(convert(varchar,ServicesNK) IN 
	(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
					WHERE CustomGroupName = 'HEDISGroup2ServiceCodes')
	AND   [PlaceOfServiceCode] in
	(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
					WHERE CustomGroupName = 'HEDISGroup2PlaceOfService')
	)-- End Group 2
	
	OR   
	
	--Group3
	(convert(varchar,ServicesNK) IN 
	(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
			WHERE CustomGroupName = 'HEDISGroup3ServiceCodes')
	AND [PlaceOfServiceCode] in  (SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
				WHERE CustomGroupName = 'HEDISGroup3PlaceOfService')
	) --End Group 3
	 
	OR 
	
	-- Group4
	(ServiceLineRevenueCode in
		(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
			WHERE CustomGroupName = 'HEDISGroup4RevenueCodes')
	) --End Group 4
	
	OR 
	
	--Group 5
	(ServiceLineRevenueCode in
	(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
			WHERE CustomGroupName = 'HEDISGroup5RevenueCodes')
	AND DiagnosisCode in
	(SELECT  DISTINCT [DiagnosisCode] FROM [BIW].[DW].[dimDiagnosis]
	where
	(
	DiagnosisCode Between ( select [BeganAttributeCodeRange]	From DW.dimCustomReportGroups where CustomReportGroupID = 1836)
						AND (select [EndAttributeCodeRange]From DW.dimCustomReportGroups where  CustomReportGroupID = 1836)
	OR  DiagnosisCode Between (select [BeganAttributeCodeRange]	From DW.dimCustomReportGroups where CustomReportGroupID = 1842)
			AND(select [EndAttributeCodeRange]  From DW.dimCustomReportGroups where CustomReportGroupID = 1842)
	OR DiagnosisCode IN (select [BeganAttributeCodeRange]	From DW.dimCustomReportGroups where
		CustomGroupName = 'HEDISGroup5DiagnosisCodes'and [BeganAttributeCodeRange] = [EndAttributeCodeRange])
	)
	) --Diagnosis code in
	) --End Group 5

) --End AND

 
	group by co.ConsumerNK , ClaimNumber
	
-----------------------------
--- Get Detailed Results ---	
-----------------------------

Select  Distinct AgeGroup, [Date of Birth], [Age], tp.ClaimNumber,
[Client ID], 
[Bill Type],
[Discharge Service],
[Discharge Diagnosis],
[Discharge Diagnosis Description],
[DiagnosisGroupID],
[Discharge Provider No.],
[Discharge Provider Name],
[PlaceOfServiceCode],
ServiceLineRevenueCode,
[DischargeDateSK],
[Discharge Date],
[Follow Up Service],
[Follow Up Diagnosis],
[Follow Up Diagnosis Description],
[Follow Up Provider No.],
[Follow Up Provider Name], 
 min([Discharge Date])  [DischargeDate], min(FollowUpDate) FollowUpDate,
 datediff(dd,min([Discharge Date]), min(FollowUpDate)) FollowUpDays

from #tempins tp left join #FollowUpClaims fc
on tp.[Client ID] = fc.ConsumerNK

where IsNull(FollowUpDate, '12/31/2099') >= [Discharge Date]
group by
AgeGroup,
[Date of Birth],
[Age],
[Client ID],
tp.ClaimNumber,
[Bill Type],
[Discharge Service],
[Discharge Diagnosis],
[Discharge Diagnosis Description],
[DiagnosisGroupID],
[Discharge Provider No.],
[Discharge Provider Name],
[PlaceOfServiceCode],
ServiceLineRevenueCode,
[DischargeDateSK],
[Discharge Date],
[Follow Up Service],
[Follow Up Diagnosis],
[Follow Up Diagnosis Description],
[Follow Up Provider No.],
[Follow Up Provider Name] 

 
 
END
------------------------
-- Get SA Data --------
------------------------ 
IF   @diagnosis = 2
BEGIN
	
	If OBJECT_ID('tempdb..#tempins2') IS NOT NULL
		DROP TABLE #tempins2
	  
	SELECT  distinct
	  Case when co.AgeValue Between 5 and 13  Then 'Age 06-12' 
		  when co.AgeValue Between 12 and 18 Then 'Age 13-17' 
		  when co.AgeValue Between 17 and 21 Then 'Age 18-20' 
		  when co.AgeValue Between 20 and 35 Then 'Age 21-34' 
		  when co.AgeValue Between 36 and 65 Then 'Age 35-64' 
		  when co.AgeValue >= 65 Then 'Age 65+' End As AgeGroup,
	      Month(dtv.Datevalue) MonthOrder, 
	    Left(DateName(month,dtv.Datevalue),3) 
		+ '''' + right(convert(varchar,Year(dtv.Datevalue)),2) DisplayDate,
	  co.ConsumerNK			[Client ID],
	  co.ConsumerSK,
	  co.DOB				[Date of Birth],
	  co.AgeValue			[Age],
	  fc.ClaimNumber,
	  bt.BillTypeCodeNK		[Bill Type], -- RDD noted BillTypeNK	
	  srv.ServicesNK		[Discharge Service],
	  dia.DiagnosisCode		[Discharge Diagnosis],
	  dia.Diagnosis			[Discharge Diagnosis Description],
	  dia.DiagnosisGroupID    [DiagnosisGroupID],
	  pvr.ProviderNK		[Discharge Provider No.],
	  pvr.ProviderName		[Discharge Provider Name],
	  pls.[PlaceOfServiceCode] [PlaceOfServiceCode],
	  fc.ServiceLineRevenueCode ServiceLineRevenueCode,
	  dtv.Datevalue			[Follow Up Date],
	  los.DateSK            [DischargeDateSK],
	  ddt.DateValue         [Discharge Date],
	  srv.ServicesNK		[Follow Up Service],
	  dia.DiagnosisCode		[Follow Up Diagnosis],
	  dia.Diagnosis			[Follow Up Diagnosis Description],
	  pvr.ProviderNK		[Follow Up Provider No.],
	  pvr.ProviderName		[Follow Up Provider Name] 
   -- select * from #tempins
	  
	  INTO #tempins2
	  FROM DW.[factClaims] as fc
			JOIN DW.dimDate  			 dtv with(nolock) on dtv.DateSK = fc.DateOfServiceSK
			JOIN DW.dimBenefitPlan	     ben with(nolock) on ben.BenefitPlanSK = fc.BenefitPlanSK
			JOIN DW.dimDiagnosis     	 dia with(nolock) on dia.DiagnosisSK  = fc.Diagnosis1SK 
			JOIN DW.dimOrganization  	 org with(nolock) on org.OrganizationSK = fc.OrganizationSK
			join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = fc.PlaceOfServiceSK
			JOIN DW.dimProvider  		 pvr with(nolock) on pvr.ProviderSK = fc.ProviderSK
			JOIN DW.dimServices 	 	 srv with(nolock) on srv.ServicesSK = fc.ServicesSK
			JOIN DW.dimAge       		 ag  with(nolock) on ag.AgeSK = fc.AgeSK
			JOIN DW.dimBillType    		 bt  with(nolock) on bt.BillTypeSK  = fc.BillTypeSK 
			JOIN DW.dimConsumers         co  on co.ConsumerSK = fc.ConsumerSK
			JOIN (select DISTINCT ClaimNumber, dateSK from DW.factLengthOfStay) los on los.ClaimNumber = fc.ClaimNumber
			JOIN DW.dimDate              ddt with(nolock) on ddt.dateSK = los.DateSK
	 
	  WHERE dtv.DateValue BETWEEN @str_dt AND @end_dt
	  AND pls.PlaceOfServiceNK = 3 -- Global Filter 1 
	  AND fc.StatusSK = 1		  -- Global Filter 2
	  
		AND
			(
			( @planfund = ben.BenefitPlanNK ) OR -- 1 specific Plan
			( @planfund = -100 AND ben.InsurerID = 2 ) OR -- ALL Medicaid
			( @planfund = -200 ) -- ALL PLANS
		)
		AND(
	    
		 @catchment = '-300'
		 OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		 OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

			)


     AND DiagnosisGroupID = 4 -- SA
	 --Group by fc.AgeSK
	 
---------------------------------
--- Follow Up Claims for SA ---
---------------------------------

If OBJECT_ID('tempdb..#FollowUpClaims2') IS NOT NULL
		DROP TABLE #FollowUpClaims2 

Select distinct co.ConsumerNK, max(dt.DateValue)  FollowUpDate
 into #FollowUpClaims2
 from  BIW.DW.factClaims f
join BIW.DW.dimServices s with(nolock) on s.ServicesSK = f.ServicesSK
JOIN DW.dimDiagnosis 	 dia with(nolock) on dia.DiagnosisSK  = f.Diagnosis1SK 
JOIN DW.dimDate     dt with(nolock) on dt.DateSK = f.DateOfServiceSK
join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = f.PlaceOfServiceSK
JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = f .ConsumerSK
WHERE dt.DateValue Between Dateadd(dd,1,@str_dt) and Dateadd(dd,30,@end_dt)
AND DiagnosisGroupID = 4
 
	group by co.ConsumerNK

-----------------------------
--- Get Detailed Results ---	
-----------------------------

Select  Distinct AgeGroup, [Date of Birth], [Age], tp.ClaimNumber,
[Client ID], 
[Bill Type],
[Discharge Service],
[Discharge Diagnosis],
[Discharge Diagnosis Description],
[DiagnosisGroupID],
[Discharge Provider No.],
[Discharge Provider Name],
[PlaceOfServiceCode],
ServiceLineRevenueCode,
[DischargeDateSK],
[Discharge Date],
[Follow Up Service],
[Follow Up Diagnosis],
[Follow Up Diagnosis Description],
[Follow Up Provider No.],
[Follow Up Provider Name], 
 min([Discharge Date])  [DischargeDate], min(FollowUpDate) FollowUpDate,
 datediff(dd,min([Discharge Date]), min(FollowUpDate)) FollowUpDays

from #tempins2 tp left join #FollowUpClaims2 fc
on tp.[Client ID] = fc.ConsumerNK

where IsNull(FollowUpDate, '12/31/2099') >= [Discharge Date]
group by
AgeGroup,
[Date of Birth],
[Age],
[Client ID],
tp.ClaimNumber,
[Bill Type],
[Discharge Service],
[Discharge Diagnosis],
[Discharge Diagnosis Description],
[DiagnosisGroupID],
[Discharge Provider No.],
[Discharge Provider Name],
[PlaceOfServiceCode],
ServiceLineRevenueCode,
[DischargeDateSK],
[Discharge Date],
[Follow Up Service],
[Follow Up Diagnosis],
[Follow Up Diagnosis Description],
[Follow Up Provider No.],
[Follow Up Provider Name] 

 
 
 END
 
 
----------------------
 --Get MH Data ------
----------------------  
IF   @diagnosis = 3
BEGIN
	
	If OBJECT_ID('tempdb..#tempins3') IS NOT NULL
		DROP TABLE #tempins3
	  
	SELECT  distinct
	  Case when co.AgeValue Between 5 and 13  Then 'Age 06-12' 
		  when co.AgeValue Between 12 and 18 Then 'Age 13-17' 
		  when co.AgeValue Between 17 and 21 Then 'Age 18-20' 
		  when co.AgeValue Between 20 and 35 Then 'Age 21-34' 
		  when co.AgeValue Between 36 and 65 Then 'Age 35-64' 
		  when co.AgeValue >= 65 Then 'Age 65+' End As AgeGroup,
	      Month(dtv.Datevalue) MonthOrder, 
	    Left(DateName(month,dtv.Datevalue),3) 
		+ '''' + right(convert(varchar,Year(dtv.Datevalue)),2) DisplayDate,
	  co.ConsumerNK			[Client ID],
	  co.ConsumerSK,
	  co.DOB				[Date of Birth],
	  co.AgeValue			[Age],
	  fc.ClaimNumber,
	  bt.BillTypeCodeNK		[Bill Type], -- RDD noted BillTypeNK	
	  srv.ServicesNK		[Discharge Service],
	  dia.DiagnosisCode		[Discharge Diagnosis],
	  dia.Diagnosis			[Discharge Diagnosis Description],
	  dia.DiagnosisGroupID    [DiagnosisGroupID],
	  pvr.ProviderNK		[Discharge Provider No.],
	  pvr.ProviderName		[Discharge Provider Name],
	  pls.[PlaceOfServiceCode] [PlaceOfServiceCode],
	  fc.ServiceLineRevenueCode ServiceLineRevenueCode,
	  dtv.Datevalue			[Follow Up Date],
	  los.DateSK            [DischargeDateSK],
	  ddt.DateValue         [Discharge Date],
	  srv.ServicesNK		[Follow Up Service],
	  dia.DiagnosisCode		[Follow Up Diagnosis],
	  dia.Diagnosis			[Follow Up Diagnosis Description],
	  pvr.ProviderNK		[Follow Up Provider No.],
	  pvr.ProviderName		[Follow Up Provider Name] 
   -- select * from #tempins
	  
	  INTO #tempins3
	  FROM DW.[factClaims] as fc
			JOIN DW.dimDate  			 dtv with(nolock) on dtv.DateSK = fc.DateOfServiceSK
			JOIN DW.dimBenefitPlan	     ben with(nolock) on ben.BenefitPlanSK = fc.BenefitPlanSK
			JOIN DW.dimDiagnosis     	 dia with(nolock) on dia.DiagnosisSK  = fc.Diagnosis1SK 
			JOIN DW.dimOrganization  	 org with(nolock) on org.OrganizationSK = fc.OrganizationSK
			join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = fc.PlaceOfServiceSK
			JOIN DW.dimProvider  		 pvr with(nolock) on pvr.ProviderSK = fc.ProviderSK
			JOIN DW.dimServices 	 	 srv with(nolock) on srv.ServicesSK = fc.ServicesSK
			JOIN DW.dimAge       		 ag  with(nolock) on ag.AgeSK = fc.AgeSK
			JOIN DW.dimBillType    		 bt  with(nolock) on bt.BillTypeSK  = fc.BillTypeSK 
			JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = fc.ConsumerSK
			JOIN (select DISTINCT ClaimNumber, dateSK from DW.factLengthOfStay) los on los.ClaimNumber = fc.ClaimNumber
			JOIN DW.dimDate              ddt with(nolock) on ddt.dateSK = los.DateSK
	 
	  WHERE dtv.DateValue BETWEEN @str_dt AND @end_dt
	  AND pls.PlaceOfServiceNK = 3 -- Global Filter 1 
	  AND fc.StatusSK = 1		  -- Global Filter 2
	  
		AND
			(
			( @planfund = ben.BenefitPlanNK ) OR -- 1 specific Plan
			( @planfund = -100 AND ben.InsurerID = 2 ) OR -- ALL Medicaid
			( @planfund = -200 ) -- ALL PLANS
		)
		AND(
	    
		 @catchment = '-300'
		 OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		 OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

			)


     AND DiagnosisGroupID = 3 -- MH
	 --Group by fc.AgeSK
	 
---------------------------------
--- Follow Up Claims for SA ---
---------------------------------

If OBJECT_ID('tempdb..#FollowUpClaims3') IS NOT NULL
		DROP TABLE #FollowUpClaims3

Select distinct co.ConsumerNK, max(dt.DateValue)  FollowUpDate
 into #FollowUpClaims3
 from  BIW.DW.factClaims f
join BIW.DW.dimServices s with(nolock) on s.ServicesSK = f.ServicesSK
JOIN DW.dimDiagnosis 	 dia with(nolock) on dia.DiagnosisSK  = f.Diagnosis1SK 
JOIN DW.dimDate     dt with(nolock) on dt.DateSK = f.DateOfServiceSK
join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = f.PlaceOfServiceSK
JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = f .ConsumerSK
WHERE dt.DateValue Between Dateadd(dd,1,@str_dt) and Dateadd(dd,30,@end_dt)
AND DiagnosisGroupID = 3
 
	group by co.ConsumerNK

-----------------------------
--- Get Detailed Results ---	
-----------------------------

Select  Distinct AgeGroup, [Date of Birth], [Age], tp.ClaimNumber,
[Client ID], 
[Bill Type],
[Discharge Service],
[Discharge Diagnosis],
[Discharge Diagnosis Description],
[DiagnosisGroupID],
[Discharge Provider No.],
[Discharge Provider Name],
[PlaceOfServiceCode],
ServiceLineRevenueCode,
[DischargeDateSK],
[Discharge Date],
[Follow Up Service],
[Follow Up Diagnosis],
[Follow Up Diagnosis Description],
[Follow Up Provider No.],
[Follow Up Provider Name], 
 min([Discharge Date])  [DischargeDate], min(FollowUpDate) FollowUpDate,
 datediff(dd,min([Discharge Date]), min(FollowUpDate)) FollowUpDays

from #tempins3 tp left join #FollowUpClaims3 fc
on tp.[Client ID] = fc.ConsumerNK

where IsNull(FollowUpDate, '12/31/2099') >= [Discharge Date]
group by
AgeGroup,
[Date of Birth],
[Age],
[Client ID],
tp.ClaimNumber,
[Bill Type],
[Discharge Service],
[Discharge Diagnosis],
[Discharge Diagnosis Description],
[DiagnosisGroupID],
[Discharge Provider No.],
[Discharge Provider Name],
[PlaceOfServiceCode],
ServiceLineRevenueCode,
[DischargeDateSK],
[Discharge Date],
[Follow Up Service],
[Follow Up Diagnosis],
[Follow Up Diagnosis Description],
[Follow Up Provider No.],
[Follow Up Provider Name] 

 
END
 
 


 




GO


