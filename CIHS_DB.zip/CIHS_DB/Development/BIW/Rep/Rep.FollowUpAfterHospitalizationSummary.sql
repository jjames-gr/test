USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalizationSummary]    Script Date: 08/22/2013 15:04:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalizationSummary_v1]    Script Date: 08/19/2013 10:17:15 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalizationSummary_v1]    Script Date: 08/15/2013 09:57:28 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--USE [BIW]
--GO

--/****** Object:  StoredProcedure [REP].[FollowUpAfterHospitalizationSummary_1]    Script Date: 08/13/2013 10:44:09 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO





--USE BIW
----GO
--IF OBJECT_ID('tempdb..#tempins') IS NOT NULL    DROP TABLE #tempins
--IF OBJECT_ID('tempdb..#resultset') IS NOT NULL    DROP TABLE #resultset -- MHH
--IF OBJECT_ID('tempdb..#tempins2') IS NOT NULL    DROP TABLE #tempins2
--IF OBJECT_ID('tempdb..#resultset2') IS NOT NULL    DROP TABLE #resultset2-- MH
--IF OBJECT_ID('tempdb..#tempins3') IS NOT NULL    DROP TABLE #tempins3
--IF OBJECT_ID('tempdb..#resultset3') IS NOT NULL    DROP TABLE #resultset3-- SA

--IF OBJECT_ID('tempdb..#FollowUpClaims') IS NOT NULL    DROP TABLE #FollowUpClaims -- testing
--IF OBJECT_ID('tempdb..#FollowUpClaims2') IS NOT NULL    DROP TABLE #FollowUpClaims2 -- testing
--IF OBJECT_ID('tempdb..#FollowUpClaims3') IS NOT NULL    DROP TABLE #FollowUpClaims3 -- testing

 

 /*-----------------------------------------------------------------------------
-- Title:  Follow-up After Hospitalization Summary
-- File:    
-- Author:        Melvin Black
-- Date: 7/1/2013
-- Desc:  [Rep].FollowUpAfterHospitalizationSummary
-- CalledBy:
--                           Reports: Follow-up After Hospitalization
--
--                           Stored Procs: None
--------------------------------------------------------------------------------
-- Change                History
-- Ver                   Date                     Author                     TixNo        Description
-- ---               ----------               ---------------				-----		--------------
-- 1.0                  7/1/2013				Melvin Black                 6393 		 Initial Development
-- 1.1					8/23/2013				Brian ANgelo		
----------------------------------------------------------------------------------
----*/
CREATE PROCEDURE [REP].[FollowUpAfterHospitalizationSummary]
  
    @diagnosis INT ,
    @catchment NVARCHAR(MAX),
    @planfund INT,
    @str_dt DATETIME ,
    @end_dt DATETIME
AS 


--DECLARE @str_dt datetime, @end_dt datetime,  @catchment INT,   @planfund INT , @diagnosis INT 

--SET @str_dt = '3/1/2013' 
--SET @end_dt = '6/30/2013'
--SET @planfund = -200 -- 
--SET @diagnosis = 1-- 1 - MHH , 2 - SA  , 3 - MH
--SET @catchment = 1023

----------------------
 --Get MHH Data ------
----------------------  
IF   @diagnosis = 1
BEGIN
	
	IF OBJECT_ID('tempdb..#tempins') IS NOT NULL   DROP TABLE #tempins
	  
	SELECT  distinct
	  Case when co.AgeValue Between 5 and 13  Then 'Age 06-12' 
		  when co.AgeValue Between 12 and 18 Then 'Age 13-17' 
		  when co.AgeValue Between 17 and 21 Then 'Age 18-20' 
		  when co.AgeValue Between 20 and 35 Then 'Age 21-34' 
		  when co.AgeValue Between 36 and 65 Then 'Age 35-64' 
		  when co.AgeValue >= 65 Then 'Age 65+' End As AgeGroup,
	      Month(dtv.Datevalue) MonthOrder, 
	    Left(DateName(month,dtv.Datevalue),3) 
		+ '''' + right(convert(varchar,Year(dtv.Datevalue)),2) DisplayDate,
	  co.ConsumerNK			[Client ID],
	  co.ConsumerSK,
	  co.DOB				[Date of Birth],
	  co.AgeValue			[Age],
	  fc.ClaimNumber,
	  bt.BillTypeCodeNK		[Bill Type], -- RDD noted BillTypeNK	
	  srv.ServicesNK		[Discharge Service],
	  dia.DiagnosisCode		[Discharge Diagnosis],
	  dia.Diagnosis			[Discharge Diagnosis Description],
	  dia.DiagnosisGroupID    [DiagnosisGroupID],
	  pvr.ProviderNK		[Discharge Provider No.],
	  pvr.ProviderName		[Discharge Provider Name],
	  pls.[PlaceOfServiceCode] [PlaceOfServiceCode],
	  fc.ServiceLineRevenueCode ServiceLineRevenueCode,
	  dtv.Datevalue			[Follow Up Date],
	  los.DateSK            [DischargeDateSK],
	  ddt.DateValue         [Discharge Date],
	  srv.ServicesNK		[Follow Up Service],
	  dia.DiagnosisCode		[Follow Up Diagnosis],
	  dia.Diagnosis			[Follow Up Diagnosis Description],
	  pvr.ProviderNK		[Follow Up Provider No.],
	  pvr.ProviderName		[Follow Up Provider Name] 

	  
	  INTO #tempins
	  	  FROM DW.[factClaims] as fc
			JOIN DW.dimDate  			 dtv  with(nolock) on dtv.DateSK = fc.DateOfServiceSK
			JOIN DW.dimBenefitPlan	     ben with(nolock) on ben.BenefitPlanSK = fc.BenefitPlanSK
			JOIN DW.dimDiagnosis     	 dia with(nolock) on dia.DiagnosisSK  = fc.Diagnosis1SK 
			JOIN DW.dimOrganization  	 org with(nolock) on org.OrganizationSK = fc.OrganizationSK
			join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = fc.PlaceOfServiceSK
			JOIN DW.dimProvider  		 pvr with(nolock) on pvr.ProviderSK = fc.ProviderSK
			JOIN DW.dimServices 	 	 srv with(nolock) on srv.ServicesSK = fc.ServicesSK
			JOIN DW.dimAge       		 ag  with(nolock) on ag.AgeSK = fc.AgeSK
			JOIN DW.dimBillType    		 bt  with(nolock) on bt.BillTypeSK  = fc.BillTypeSK 
			JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = fc.ConsumerSK
			JOIN (select DISTINCT ClaimNumber, dateSK from DW.factLengthOfStay) los on los.ClaimNumber = fc.ClaimNumber
			JOIN DW.dimDate              ddt with(nolock)  on ddt.dateSK = los.DateSK
	 
	  WHERE dtv.DateValue BETWEEN @str_dt AND @end_dt
	  --AND fc.PlaceOfServiceSK = 3 -- Global Filter 1 -- Omit for Hedis reports
	  AND fc.StatusSK = 1		  -- Global Filter 2
	  
		AND
			(
			( @planfund = ben.BenefitPlanNK ) OR -- 1 specific Plan
			( @planfund = -100 AND ben.InsurerID = 2 ) OR -- ALL Medicaid
			( @planfund = -200 ) -- ALL PLANS
		)
		AND(
	    
		 @catchment = '-300'
		 OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		 OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

			)


     AND DiagnosisGroupID = 3 -- MH/MHH
	 --Group by fc.AgeSK
	 

--------------------------------,
--- Follow Up Claims for MHH ---
---------------------------------

IF OBJECT_ID('tempdb..#FollowUpClaims') IS NOT NULL   DROP TABLE #FollowUpClaims

Select distinct co.ConsumerNK, ClaimNumber, max(dt.DateValue)  FollowUpDate
 into #FollowUpClaims
 from  BIW.DW.factClaims   f
join BIW.DW.dimServices    s with(nolock) on s.ServicesSK = f.ServicesSK
JOIN DW.dimDiagnosis 	   dia with(nolock) on dia.DiagnosisSK  = f.Diagnosis1SK 
JOIN DW.dimDate            dt with(nolock) on dt.DateSK = f.DateOfServiceSK
join DW.dimPlaceOfService  pls with(nolock) on pls.PlaceOfServiceSK = f.PlaceOfServiceSK
JOIN DW.dimConsumers       co  with(nolock) on co.ConsumerSK = f .ConsumerSK
WHERE dt.DateValue Between Dateadd(dd,1,@str_dt) and Dateadd(dd,30,@end_dt)
AND
 (convert(varchar,ServicesNK)
				 							 
			IN -- Group1_SC
			(
			SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
			WHERE CustomGroupName = 'HEDISGroup1ServiceCodes'
			)

			-- Group2
			OR   (convert(varchar,ServicesNK)
			IN 
			(
				SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
							WHERE CustomGroupName = 'HEDISGroup2ServiceCodes')
			)
			AND   [PlaceOfServiceCode] in
			(
			SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
							WHERE CustomGroupName = 'HEDISGroup2PlaceOfService'
			)
			--Group3
			OR   (convert(varchar,ServicesNK))
			IN 
			(
			SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
					WHERE CustomGroupName = 'HEDISGroup3ServiceCodes'
			)AND [PlaceOfServiceCode] in  (SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
						WHERE CustomGroupName = 'HEDISGroup3PlaceOfService')

			-- Group4 
			OR ServiceLineRevenueCode in
			(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
					WHERE CustomGroupName = 'HEDISGroup4RevenueCodes')

			-- Group5
			OR (ServiceLineRevenueCode) in
			(SELECT distinct[BeganAttributeCodeRange] FROM [BIW].[DW].[dimCustomReportGroups]
					WHERE CustomGroupName = 'HEDISGroup5RevenueCodes')
			AND DiagnosisCode in
			(
			SELECT  DISTINCT
			[DiagnosisCode] FROM [BIW].[DW].[dimDiagnosis]
			where
			(
			DiagnosisCode 
				Between (
				select [BeganAttributeCodeRange]	From DW.dimCustomReportGroups where CustomReportGroupID = 1836
				)AND(select [EndAttributeCodeRange]From DW.dimCustomReportGroups where  CustomReportGroupID = 1836
				)
				OR 
				DiagnosisCode 
				Between (
				select [BeganAttributeCodeRange]	From DW.dimCustomReportGroups where CustomReportGroupID = 1842)
				AND(select [EndAttributeCodeRange]  From DW.dimCustomReportGroups where CustomReportGroupID = 1842)
   			
				OR DiagnosisCode
				IN (select [BeganAttributeCodeRange]	From DW.dimCustomReportGroups where
				CustomGroupName = 'HEDISGroup5DiagnosisCodes'and [BeganAttributeCodeRange] = [EndAttributeCodeRange])
			)


			)
	)
 
	group by co.ConsumerNK , ClaimNumber
	
	
---------------------
-- Get Population ---
------------------------	

 IF OBJECT_ID('tempdb..#Population') IS NOT NULL   DROP TABLE #Population
select DisplayDate, MonthOrder, AgeGroup, count(distinct [Client ID]) Population 
into #Population
from #tempins Group by AgeGroup, DisplayDate, MonthOrder

--------------------------------
IF OBJECT_ID('tempdb..#finalResults') IS NOT NULL   DROP TABLE #finalResults
Create Table #finalResults ( DisplayDate varchar(10), Monthorder int, DayRange varchar(10), AgeGroup varchar(10), Numerator int) 


;With cteDischargeDate (DisplayDate, MonthOrder, DateRange, AgeGroup,ClientID, DischargeDate)
As
(
Select DisplayDate, MonthOrder, '7day' DateRange, AgeGroup, [Client ID],  min([Discharge Date]) DischargeDate from #tempins
Group by   [Client ID], AgeGroup, DisplayDate, MonthOrder 
 ) 
 insert into #finalResults
 select DisplayDate, MonthOrder, DateRange, AgeGroup, count(*) numerator from cteDischargeDate dd join #FollowUpClaims  fc
 on fc.ConsumerNK = dd.ClientID
 AND DischargeDate <= FollowUpDate
 AND datediff(dd,DischargeDate,FollowUpDate) <= 7
 Group by AgeGroup, DateRange, DisplayDate, MonthOrder 
 
;With cteDischargeDate (DisplayDate, MonthOrder, DateRange, AgeGroup,ClientID, DischargeDate)
As
(
Select DisplayDate, MonthOrder, '30day' DateRange, AgeGroup, [Client ID],  min([Discharge Date]) DischargeDate from #tempins
Group by   [Client ID], AgeGroup, DisplayDate, MonthOrder 
 ) 
  insert into #finalResults
 select DisplayDate, MonthOrder, DateRange, AgeGroup, count(*) numerator from cteDischargeDate dd join #FollowUpClaims  fc
 on fc.ConsumerNK = dd.ClientID
 AND DischargeDate <= FollowUpDate
 AND datediff(dd,DischargeDate,FollowUpDate) <= 30
 Group by AgeGroup, DateRange, DisplayDate, MonthOrder 
 
   /* Insert 0 where no results occur to keep accurate population count */
 insert into #finalResults
 select DisplayDate, MonthOrder, '7Day', AgeGroup, 0
 FROM #Population p
 where DisplayDate+'7Day'+AgeGroup not in
  (select DisplayDate+DayRange+AgeGroup FROM #finalResults)
  
 insert into #finalResults
 select DisplayDate, MonthOrder, '30Day', AgeGroup, 0
 FROM #Population p
 where DisplayDate+'30Day'+AgeGroup not in
  (select DisplayDate+DayRange+AgeGroup FROM #finalResults)

 
---------------------------------
--- Generate Final Results -------
----------------------------------
select p.*, f.DayRange, Numerator 
from #population p left join  #finalResults f
on f.AgeGroup = p.AgeGroup AND f.DisplayDate = p.DisplayDate
   order by DayRange, DisplayDate, AgeGroup

 
END
------------------------
-- Get SA Data --------
------------------------ 
IF   @diagnosis = 2
BEGIN
	  
	  IF OBJECT_ID('tempdb..#tempins2') IS NOT NULL   DROP TABLE #tempins2
	  
	SELECT  distinct
	  Case when co.AgeValue Between 5 and 13  Then 'Age 06-12' 
		  when co.AgeValue Between 12 and 18 Then 'Age 13-17' 
		  when co.AgeValue Between 17 and 21 Then 'Age 18-20' 
		  when co.AgeValue Between 20 and 35 Then 'Age 21-34' 
		  when co.AgeValue Between 36 and 65 Then 'Age 35-64' 
		  when co.AgeValue >= 65 Then 'Age 65+' End As AgeGroup,
	      Month(dtv.Datevalue) MonthOrder, 
	    Left(DateName(month,dtv.Datevalue),3) 
		+ '''' + right(convert(varchar,Year(dtv.Datevalue)),2) DisplayDate,
	  co.ConsumerNK			[Client ID],
	  co.ConsumerSK,
	  co.DOB				[Date of Birth],
	  co.AgeValue			[Age],
	  fc.ClaimNumber,
	  bt.BillTypeCodeNK		[Bill Type], -- RDD noted BillTypeNK	
	  srv.ServicesNK		[Discharge Service],
	  dia.DiagnosisCode		[Discharge Diagnosis],
	  dia.Diagnosis			[Discharge Diagnosis Description],
	  dia.DiagnosisGroupID    [DiagnosisGroupID],
	  pvr.ProviderNK		[Discharge Provider No.],
	  pvr.ProviderName		[Discharge Provider Name],
	  pls.[PlaceOfServiceCode] [PlaceOfServiceCode],
	  fc.ServiceLineRevenueCode ServiceLineRevenueCode,
	  dtv.Datevalue			[Follow Up Date],
	  los.DateSK            [DischargeDateSK],
	  ddt.DateValue         [Discharge Date],
	  srv.ServicesNK		[Follow Up Service],
	  dia.DiagnosisCode		[Follow Up Diagnosis],
	  dia.Diagnosis			[Follow Up Diagnosis Description],
	  pvr.ProviderNK		[Follow Up Provider No.],
	  pvr.ProviderName		[Follow Up Provider Name] 
   -- select * from #tempins
	  
	  INTO #tempins2
		  FROM DW.[factClaims] as fc
			JOIN DW.dimDate  			 dtv with(nolock) on dtv.DateSK = fc.DateOfServiceSK
			JOIN DW.dimBenefitPlan	     ben with(nolock) on ben.BenefitPlanSK = fc.BenefitPlanSK
			JOIN DW.dimDiagnosis     	 dia with(nolock) on dia.DiagnosisSK  = fc.Diagnosis1SK 
			JOIN DW.dimOrganization  	 org with(nolock) on org.OrganizationSK = fc.OrganizationSK
			join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = fc.PlaceOfServiceSK
			JOIN DW.dimProvider  		 pvr with(nolock) on pvr.ProviderSK = fc.ProviderSK
			JOIN DW.dimServices 	 	 srv with(nolock) on srv.ServicesSK = fc.ServicesSK
			JOIN DW.dimAge       		 ag  with(nolock) on ag.AgeSK = fc.AgeSK
			JOIN DW.dimBillType    		 bt  with(nolock) on bt.BillTypeSK  = fc.BillTypeSK 
			JOIN DW.dimConsumers         co  on co.ConsumerSK = fc.ConsumerSK
			JOIN (select DISTINCT ClaimNumber, dateSK from DW.factLengthOfStay) los on los.ClaimNumber = fc.ClaimNumber
			JOIN DW.dimDate              ddt with(nolock) on ddt.dateSK = los.DateSK
	 
	  WHERE dtv.DateValue BETWEEN @str_dt AND @end_dt
	  --AND fc.PlaceOfServiceSK = 3 -- Global Filter 1 -- Omit for Hedis reports
	  AND fc.StatusSK = 1		  -- Global Filter 2
	  
		AND
			(
			( @planfund = ben.BenefitPlanNK ) OR -- 1 specific Plan
			( @planfund = -100 AND ben.InsurerID = 2 ) OR -- ALL Medicaid
			( @planfund = -200 ) -- ALL PLANS
		)
		AND(
	    
		 @catchment = '-300'
		 OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		 OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

			)


     AND DiagnosisGroupID = 4 -- SA
	 --Group by fc.AgeSK
	 
---------------------------------
--- Follow Up Claims for SA ---
---------------------------------

IF OBJECT_ID('tempdb..#FollowUpClaims2') IS NOT NULL   DROP TABLE #FollowUpClaims2

Select distinct co.ConsumerNK, max(dt.DateValue)  FollowUpDate
 into #FollowUpClaims2
 from  BIW.DW.factClaims f
join BIW.DW.dimServices s with(nolock) on s.ServicesSK = f.ServicesSK
JOIN DW.dimDiagnosis 	 dia with(nolock) on dia.DiagnosisSK  = f.Diagnosis1SK 
JOIN DW.dimDate     dt with(nolock) on dt.DateSK = f.DateOfServiceSK
join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = f.PlaceOfServiceSK
JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = f .ConsumerSK
WHERE dt.DateValue Between Dateadd(dd,1,@str_dt) and Dateadd(dd,30,@end_dt)
AND DiagnosisGroupID = 4
 
	group by co.ConsumerNK
	
---------------------
-- Get Population ---
------------------------	

 IF OBJECT_ID('tempdb..#Population2') IS NOT NULL   DROP TABLE #Population2
select DisplayDate, MonthOrder, AgeGroup, count(distinct [Client ID]) Population 
into #Population2
from #tempins2 Group by AgeGroup, DisplayDate, MonthOrder



--------------------------------
IF OBJECT_ID('tempdb..#finalResults2') IS NOT NULL   DROP TABLE #finalResults2
Create Table #finalResults2 ( DisplayDate varchar(10), Monthorder int, DayRange varchar(10), AgeGroup varchar(10), Numerator int) 


;With cteDischargeDate (DisplayDate, MonthOrder, DateRange, AgeGroup,ClientID, DischargeDate)
As
(
Select DisplayDate, MonthOrder, '7day' DateRange, AgeGroup, [Client ID],  min([Discharge Date]) DischargeDate from #tempins2
Group by   [Client ID], AgeGroup, DisplayDate, MonthOrder 
 ) 
 insert into #finalResults2
 select DisplayDate, MonthOrder, DateRange, AgeGroup, count(*) numerator from cteDischargeDate dd join #FollowUpClaims2  fc
 on fc.ConsumerNK = dd.ClientID
 AND DischargeDate <= FollowUpDate
 AND datediff(dd,DischargeDate,FollowUpDate) <= 7
 Group by AgeGroup, DateRange, DisplayDate, MonthOrder 
 
;With cteDischargeDate (DisplayDate, MonthOrder, DateRange, AgeGroup,ClientID, DischargeDate)
As
(
Select DisplayDate, MonthOrder, '30day' DateRange, AgeGroup, [Client ID],  min([Discharge Date]) DischargeDate from #tempins2
Group by   [Client ID], AgeGroup, DisplayDate, MonthOrder 
 ) 
  insert into #finalResults2
 select DisplayDate, MonthOrder, DateRange, AgeGroup, count(*) numerator from cteDischargeDate dd join #FollowUpClaims2  fc
 on fc.ConsumerNK = dd.ClientID
 AND DischargeDate <= FollowUpDate
 AND datediff(dd,DischargeDate,FollowUpDate) <= 30
 Group by AgeGroup, DateRange, DisplayDate, MonthOrder 
 
  /* Insert 0 where no results occur to keep accurate population count */
 insert into #finalResults2
 select DisplayDate, MonthOrder, '7Day', AgeGroup, 0
 FROM #Population2 p
 where DisplayDate+'7Day'+AgeGroup not in
  (select DisplayDate+DayRange+AgeGroup FROM #finalResults2)
  
 insert into #finalResults2
 select DisplayDate, MonthOrder, '30Day', AgeGroup, 0
 FROM #Population2 p
 where DisplayDate+'30Day'+AgeGroup not in
  (select DisplayDate+DayRange+AgeGroup FROM #finalResults2)

---------------------------------
--- Generate Final Results -------
----------------------------------
select p.*, f.DayRange, Numerator 
from #population2 p left join  #finalResults2 f
on f.AgeGroup = p.AgeGroup AND f.DisplayDate = p.DisplayDate
 order by DayRange, DisplayDate, AgeGroup
 
 END
 
------------------------
-- Get MH Data --------
------------------------ 
----------------------
 --Get MH Data ------
----------------------  
IF   @diagnosis = 3
BEGIN
	  
	  IF OBJECT_ID('tempdb..#tempins3') IS NOT NULL   DROP TABLE #tempins3
	  
	SELECT  distinct
	  Case when co.AgeValue Between 5 and 13  Then 'Age 06-12' 
		  when co.AgeValue Between 12 and 18 Then 'Age 13-17' 
		  when co.AgeValue Between 17 and 21 Then 'Age 18-20' 
		  when co.AgeValue Between 20 and 35 Then 'Age 21-34' 
		  when co.AgeValue Between 36 and 65 Then 'Age 35-64' 
		  when co.AgeValue >= 65 Then 'Age 65+' End As AgeGroup,
	      Month(dtv.Datevalue) MonthOrder, 
	    Left(DateName(month,dtv.Datevalue),3) 
		+ '''' + right(convert(varchar,Year(dtv.Datevalue)),2) DisplayDate,
	  co.ConsumerNK			[Client ID],
	  co.ConsumerSK,
	  co.DOB				[Date of Birth],
	  co.AgeValue			[Age],
	  fc.ClaimNumber,
	  bt.BillTypeCodeNK		[Bill Type], -- RDD noted BillTypeNK	
	  srv.ServicesNK		[Discharge Service],
	  dia.DiagnosisCode		[Discharge Diagnosis],
	  dia.Diagnosis			[Discharge Diagnosis Description],
	  dia.DiagnosisGroupID    [DiagnosisGroupID],
	  pvr.ProviderNK		[Discharge Provider No.],
	  pvr.ProviderName		[Discharge Provider Name],
	  pls.[PlaceOfServiceCode] [PlaceOfServiceCode],
	  fc.ServiceLineRevenueCode ServiceLineRevenueCode,
	  dtv.Datevalue			[Follow Up Date],
	  los.DateSK            [DischargeDateSK],
	  ddt.DateValue         [Discharge Date],
	  srv.ServicesNK		[Follow Up Service],
	  dia.DiagnosisCode		[Follow Up Diagnosis],
	  dia.Diagnosis			[Follow Up Diagnosis Description],
	  pvr.ProviderNK		[Follow Up Provider No.],
	  pvr.ProviderName		[Follow Up Provider Name] 
   -- select * from #tempins
	  
	  INTO #tempins3
	  FROM DW.[factClaims] as fc
			JOIN DW.dimDate  			 dtv with(nolock) on dtv.DateSK = fc.DateOfServiceSK
			JOIN DW.dimBenefitPlan	     ben with(nolock) on ben.BenefitPlanSK = fc.BenefitPlanSK
			JOIN DW.dimDiagnosis     	 dia with(nolock) on dia.DiagnosisSK  = fc.Diagnosis1SK 
			JOIN DW.dimOrganization  	 org with(nolock) on org.OrganizationSK = fc.OrganizationSK
			join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = fc.PlaceOfServiceSK
			JOIN DW.dimProvider  		 pvr with(nolock) on pvr.ProviderSK = fc.ProviderSK
			JOIN DW.dimServices 	 	 srv with(nolock) on srv.ServicesSK = fc.ServicesSK
			JOIN DW.dimAge       		 ag  with(nolock) on ag.AgeSK = fc.AgeSK
			JOIN DW.dimBillType    		 bt  with(nolock) on bt.BillTypeSK  = fc.BillTypeSK 
			JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = fc.ConsumerSK
			JOIN (select DISTINCT ClaimNumber, dateSK from DW.factLengthOfStay) los on los.ClaimNumber = fc.ClaimNumber
			JOIN DW.dimDate              ddt with(nolock) on ddt.dateSK = los.DateSK
	 
	  WHERE dtv.DateValue BETWEEN @str_dt AND @end_dt
	  --AND fc.PlaceOfServiceSK = 3 -- Global Filter 1 -- Omit for Hedis reports
	  AND fc.StatusSK = 1		  -- Global Filter 2
	  
		AND
			(
			( @planfund = ben.BenefitPlanNK ) OR -- 1 specific Plan
			( @planfund = -100 AND ben.InsurerID = 2 ) OR -- ALL Medicaid
			( @planfund = -200 ) -- ALL PLANS
		)
		AND(
	    
		 @catchment = '-300'
		 OR CONVERT(nvarchar, org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		 OR CONVERT(nvarchar, org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

			)


     AND DiagnosisGroupID = 3 -- MH
	 --Group by fc.AgeSK
	 
---------------------------------
--- Follow Up Claims for SA ---
---------------------------------

IF OBJECT_ID('tempdb..#FollowUpClaims3') IS NOT NULL   DROP TABLE #FollowUpClaims3

Select distinct co.ConsumerNK, max(dt.DateValue)  FollowUpDate
 into #FollowUpClaims3
 from  BIW.DW.factClaims f
join BIW.DW.dimServices s with(nolock) on s.ServicesSK = f.ServicesSK
JOIN DW.dimDiagnosis 	 dia with(nolock) on dia.DiagnosisSK  = f.Diagnosis1SK 
JOIN DW.dimDate     dt with(nolock) on dt.DateSK = f.DateOfServiceSK
join DW.dimPlaceOfService    pls with(nolock) on pls.PlaceOfServiceSK = f.PlaceOfServiceSK
JOIN DW.dimConsumers         co  with(nolock) on co.ConsumerSK = f .ConsumerSK
WHERE dt.DateValue Between Dateadd(dd,1,@str_dt) and Dateadd(dd,30,@end_dt)
AND DiagnosisGroupID = 3
 
	group by co.ConsumerNK
	
---------------------
-- Get Population ---
------------------------	

 IF OBJECT_ID('tempdb..#Population3') IS NOT NULL   DROP TABLE #Population3
select DisplayDate, MonthOrder, AgeGroup, count(distinct [Client ID]) Population 
into #Population3
from #tempins3 Group by AgeGroup, DisplayDate, MonthOrder


--------------------------------
IF OBJECT_ID('tempdb..#finalResults3') IS NOT NULL   DROP TABLE #finalResults3
Create Table #finalResults3 ( DisplayDate varchar(10), Monthorder int, DayRange varchar(10), AgeGroup varchar(10), Numerator int) 


;With cteDischargeDate (DisplayDate, MonthOrder, DateRange, AgeGroup,ClientID, DischargeDate)
As
(
Select DisplayDate, MonthOrder, '7day' DateRange, AgeGroup, [Client ID],  min([Discharge Date]) DischargeDate from #tempins3
Group by   [Client ID], AgeGroup, DisplayDate, MonthOrder 
 ) 
 insert into #finalResults3
 select DisplayDate, MonthOrder, DateRange, AgeGroup, count(*) numerator 
 from cteDischargeDate dd inner join #FollowUpClaims3  fc
 on fc.ConsumerNK = dd.ClientID
 AND DischargeDate <= FollowUpDate
 AND datediff(dd,DischargeDate,FollowUpDate) <= 7
 Group by AgeGroup, DateRange, DisplayDate, MonthOrder 
 
;With cteDischargeDate (DisplayDate, MonthOrder, DateRange, AgeGroup,ClientID, DischargeDate)
As
(
Select DisplayDate, MonthOrder, '30day' DateRange, AgeGroup, [Client ID],  min([Discharge Date]) DischargeDate from #tempins3
Group by   [Client ID], AgeGroup, DisplayDate, MonthOrder 
 ) 
  insert into #finalResults3
 select DisplayDate, MonthOrder, DateRange, AgeGroup, count(*) numerator 
 from cteDischargeDate dd inner join #FollowUpClaims3  fc
 on fc.ConsumerNK = dd.ClientID
 AND DischargeDate <= FollowUpDate
 AND datediff(dd,DischargeDate,FollowUpDate) <= 30
 Group by AgeGroup, DateRange, DisplayDate, MonthOrder 
 
 /* Insert 0 where no results occur to keep accurate population count */
 insert into #finalResults3
 select DisplayDate, MonthOrder, '7Day', AgeGroup, 0
 FROM #Population3 p
 where DisplayDate+'7Day'+AgeGroup not in
  (select DisplayDate+DayRange+AgeGroup FROM #finalResults3)
  
 insert into #finalResults3
 select DisplayDate, MonthOrder, '30Day', AgeGroup, 0
 FROM #Population3 p
 where DisplayDate+'30Day'+AgeGroup not in
  (select DisplayDate+DayRange+AgeGroup FROM #finalResults3)

---------------------------------
--- Generate Final Results -------
----------------------------------

select p.AgeGroup, p.DisplayDate, p.MonthOrder, p.[Population], f.DayRange, f.Numerator 
from #population3 p left join  #finalResults3 f
on f.AgeGroup = p.AgeGroup AND f.DisplayDate = p.DisplayDate
order by DayRange, DisplayDate, AgeGroup

END
 
 


 

GO


