USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[AuthorizationsByProviderAndAuthDate]    Script Date: 09/13/2013 15:38:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [REP].[AuthorizationsByProviderAndAuthDate]
	@StartDate DATE ,
	@EndDate DATE,
	@Provider NVARCHAR(MAX),
	@Catchment VARCHAR(MAX),
	@BenPlan INT,
	@ServDefID NVARCHAR(MAX)
	--@Serv NVARCHAR(MAX) 

AS

/*
	------------------------------------------------------------------------------
	Title:		Authorizations by Provider and Auth Start Date Range
	File:		[REP].[AuthorizationsByProviderAndAuthDate]
	Author:		Divya Lakshmi
	Date:		07/11/2013
	Desc:		Report to diaplay authorization data grouped by Provider,Service 
	            and Catchment for a defined Authorization reporting range
                                        
	Called By:
                        Reports:	PVD004 - AuthorizationsByProviderAndAuthDate.rdl
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/11/2013		Divya Lakshmi    		6284			  Created

	-----------------------------------------------------------------------------------
*/

--DECLARE
--	@StartDate DATE = '1/1/2010',
--	@EndDate DATE = '3/31/2010',
--	@Provider NVARCHAR(MAX)=-2,--20210
--	@Catchment VARCHAR(MAX)=-300,
--	@BenPlan INT = -200,
--	@ServDefID NVARCHAR(MAX) = 1
--	--@Serv NVARCHAR(MAX) = 171




	SELECT DISTINCT
	    fa.authorizationNumber,
	    dp1.ProviderName,
	    ds.ServiceDescriptionShort,
	    ds.ServiceCode,
	    dEffFROM.DateValue as EffFrom,
		dEffTO.DateValue as EffTo,
		fa.AuthorizedUnits,
		fa.UsedUnits,
	    dc.ConsumerNK,
	    dc.LastName,
		dc.FirstName,
		dc.MiddleName,
		ISNULL(dc.AddressLine1,'') + ' ' + ISNULL(dc.AddressLine2,'') +  ' ' +ISNULL( dc.City,'') + ' ' + 
		ISNULL(dc.State,'') + ' ' + ISNULL(dc.PostalCode,'') Address,
		do.Catchment,
		do.County,
		dbp.BenefitPlanShort,
		ds.ServiceDefinitionID,
		ds.ServicesNK
		
	FROM
		dw.factAuthorizations fa WITH(NOLOCK)
		INNER JOIN dw.dimBenefitPlan dbp WITH(NOLOCK) ON fa.BenefitPlanSK = dbp.BenefitPlanSK
		INNER JOIN dw.dimServices ds WITH(NOLOCK) ON fa.ServicesSK = ds.ServicesSK
		INNER JOIN dw.dimOrganization do WITH(NOLOCK) ON fa.OrganizationSK = do.OrganizationSK
		INNER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fa.ConsumerSK = dc.ConsumerSK
		INNER JOIN dw.dimProvider dp WITH(NOLOCK) ON fa.ProviderSK = dp.ProviderSK
		INNER JOIN dw.dimDate dEffFROM WITH(NOLOCK) ON fa.EffectiveFromDateSK = dEffFROM.DateSK
		INNER JOIN dw.dimDate dEffTO WITH(NOLOCK) ON fa.EffectiveToDateSK = dEffTO.DateSK
	   -- INNER JOIN dw.dimServices ds1 WITH(NOLOCK) ON ds1.ServicesNK= ds.ServicesNK
	   	INNER JOIN dw.dimProvider dp1 WITH(NOLOCK) ON dp1.ProviderNK= dp.ParentProviderNK
        INNER JOIN dw.factProviderContract fpc WITH(NOLOCK) ON  dp1.ProvidersK=fpc.MainProviderSK
        INNER JOIN dbo.cfn_split(@Provider , ',') AS prov ON prov.element = dp1.ProviderNK
        INNER JOIN dbo.cfn_split(@ServDefID , ',') fn ON fn.element = ds.ServiceDefinitionID
     --   INNER JOIN dbo.cfn_split(@Serv , ',') fn1 ON fn1.element = ds.ServicesNK


WHERE
	fa.EffectiveFromDateSK <= fpc.ContractExpirationBeginDateSK
	AND fa.EffectiveToDateSK > fpc.ContractEffectiveBeginDateSK
	AND fpc.ActiveContractFlag=1
  --  AND dEffFROM.DateValue between @StartDate and @EndDate
    AND dEffFROM.DateValue <=@EndDate
    AND dEffTO.DateValue >=@StartDate

	AND
	(
		( @BenPlan = dbp.BenefitPlanNK ) OR -- 1 specific Plan
		( @BenPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
		( @BenPlan = -200 ) -- ALL PLANS
	)
	AND
	(
		@catchment = '-300'
		OR do.CatchmentID IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR do.OrganizationNK IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)














GO


