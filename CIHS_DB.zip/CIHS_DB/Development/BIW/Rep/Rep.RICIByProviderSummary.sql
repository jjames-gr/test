USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[RICIByProviderSummary]    Script Date: 09/23/2013 14:03:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[RICIByProviderSummary]
	@StartDate datetime,
	@EndDate datetime,
	@Provider int,
	@Type varchar(50),
	@ContractStatus varchar(50),
	@Catchment varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /*
	/*** Test Parameters ***/
	DECLARE @StartDate datetime,
			@EndDate datetime,
			@Provider int,
			@Type varchar(50),
			@ContractStatus varchar(50),
			@Catchment varchar(50)
		
	SET @StartDate = '6/1/13'
	SET @EndDate = '6/30/13'
	SET @Provider = -2
	SET @Type = '-1'  --'ProviderIncident'    --'RestrictiveIntervention'
	SET @ContractStatus = '-1'
	SET @Catchment = '-300'
	--*/

	SELECT DISTINCT
	dp.ProviderName as ProviderName
	,dp.ProviderNK as SiteID
	,dp.County as ProviderCounty
	,dpParent.ProviderName as MainProviderID
	,fi.IncidentsID as CIRIRefNumber
	,ddInOc.DateValue as DateCommited
	,ddInOc.DateValue as IncidentDate
	,did.HomeLME as HomeLME
	,dic.IncidentConsumerLastName as ConsumerLastName
	,dic.IncidentConsumerFirstName as ConsumerFirstName
	,dic.IncidentConsumerID as ConsumerID
	,did.IncidentCountyLocation as County
	,did.IncidentCodeDescription as IC_RIDescription
	,did.IncidentLevelDescription as LevelDescription
	,dpParent.ProviderName as SiteName
	,ddRec.DateValue as ReceivedDate
	,ddLearned.DateValue as LearnedDate
	,did.IncidentServiceType as ServiceType
	,ISNULL(did.PrimaryDiagnosis,'None') as Diagnosis
	,did.WaiverServiceStatus as CWaiverServices
	,did.IncidentLocationDescription as Location
	,dic.IncidentConsumerCounty as ConsumerCountyArea
	,did.ProviderServiceArea as ProviderArea
	,did.IncidentContractStatus as ContractStatus
	,djDFS.JunkShortValue as DFSInvestigated
	,djDMADMH.JunkShortValue as DMADMHNotified
	,djDSS.JunkShortValue as DSSInvestigated
	,djGN.JunkShortValue as GuardianNotified
	,djLME.JunkShortValue as LMEIntervention
	,djNLE.JunkShortValue as NotifiedLawEnforcement
	,POCCompleted.JunkShortValue as POCCompleted
	,DMADMHInvestigated.JunkShortValue as DMADMHInvestigated
	,DHSRInvestigated.JunkShortValue as DHSRInvestigated
	,NotifyDFS.JunkShortValue as NotifyDFS
	,POCRequested.JunkShortValue as POCRequested
	,ProviderInvestigation.JunkShortValue as ProviderInvestigation
	,ProviderNotifiedExternalAgency.JunkShortValue as ProviderNotifiedExternalAgency
	,QMInvestigation.JunkShortValue as QMInvestigation
	,QMRemediation.JunkShortValue as QMRemediation
	,ReportedToDHSR.JunkShortValue as ReportedToDHSR
	,ReportedToDSS.JunkShortValue as ReportedToDSS
	,ReportedToHealthCareRegistry.JunkShortValue as ReportedToHealthCareRegistry
	,RequestedPsychologicalAutopsy.JunkShortValue as RequestedPsychologicalAutopsy
	,ReviewedByMedicalDirectorPending.JunkShortValue as ReviewedByMedicalDirectorPending
	,ReviewedByMedicalDirectorResolved.JunkShortValue as ReviewedByMedicalDirectorResolved
	,StaffTerminated.JunkShortValue as StaffTerminated
	FROM [BIW].[DW].[factIncidents] fi WITH(NOLOCK)
	INNER JOIN [BIW].[DW].[dimIncidentDetails] did WITH(NOLOCK) ON did.IncidentDetailsSK = fi.IncidentDetailsSK
	INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fi.ProviderSK
	INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.County = dp.County
	INNER JOIN [BIW].[DW].[dimProvider] dpParent WITH(NOLOCK) ON dpParent.ProviderNK = dp.ParentProviderNK
	INNER JOIN [BIW].[DW].[dimIncidentConsumer] dic WITH(NOLOCK) ON dic.IncidentConsumerSK = fi.IncidentConsumerSK
	INNER JOIN [BIW].[DW].[dimDate] ddInOc WITH(NOLOCK) ON ddInOc.DateSK = fi.IncidentOccurredDateSK
	INNER JOIN [BIW].[DW].[dimDate] ddLearned WITH(NOLOCK) ON ddLearned.DateSK = fi.IncidentLearnedDateSK
	INNER JOIN [BIW].[DW].[dimDate] ddRec WITH(NOLOCK) ON ddRec.DateSK = fi.IncidentRecordReceivedDateSK
	INNER JOIN [BIW].[DW].[dimJunk] djDFS WITH(NOLOCK) ON djDFS.JunkSK = fi.DFSInvestigatedFlagSK
	INNER JOIN [BIW].[DW].[dimJunk] djDMADMH WITH(NOLOCK) ON djDMADMH.JunkSK = fi.DMADMHNotifiedFlagSK
	INNER JOIN [BIW].[DW].[dimJunk] djDSS WITH(NOLOCK) ON djDSS.JunkSK = fi.DSSInvestigatedFlagSK
	INNER JOIN [BIW].[DW].[dimJunk] djGN WITH(NOLOCK) ON djGN.JunkSK = fi.GuardianNotifiedFlagSK
	INNER JOIN [BIW].[DW].[dimJunk] djLME WITH(NOLOCK) ON djLME.JunkSK = fi.LMEInterventionFlagSK
	INNER JOIN [BIW].[DW].[dimJunk] djNLE WITH(NOLOCK) ON djNLE.JunkSK = fi.NotifiedLawEnforcementFlagSK
	INNER JOIN [BIW].[DW].[dimJunk] POCCompleted WITH(NOLOCK) ON fi.POCCompletedFlagSK = POCCompleted.JunkSK 
	INNER JOIN [BIW].[DW].[dimJunk] DMADMHInvestigated WITH(NOLOCK) ON fi.DFSInvestigatedFlagSK = DMADMHInvestigated.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] DHSRInvestigated WITH(NOLOCK) ON fi.DHSRInvestigatedFlagSK = DHSRInvestigated.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] NotifyDFS WITH(NOLOCK) ON fi.DFSNotifiedFlagSK = NotifyDFS.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] POCRequested WITH(NOLOCK) ON fi.POCRequestedFlagSK = POCRequested.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ProviderInvestigation WITH(NOLOCK) ON fi.ProviderInvestigationFlagSK = ProviderInvestigation.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ProviderNotifiedExternalAgency WITH(NOLOCK) ON fi.ProviderNotifiedExternalAgencyFlagSK = ProviderNotifiedExternalAgency.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] QMInvestigation WITH(NOLOCK) ON fi.QMInvestigationFlagSK = QMInvestigation.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] QMRemediation WITH(NOLOCK) ON fi.QMRemediationFlagSK = QMRemediation.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ReportedToDHSR WITH(NOLOCK) ON fi.ReportedToDHSRFlagSK = ReportedToDHSR.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ReportedToDSS WITH(NOLOCK) ON fi.ReportedToDSSFlagSK = ReportedToDSS.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ReportedToHealthCareRegistry WITH(NOLOCK) ON fi.ReportedToHealthCareRegistryFlagSK = ReportedToHealthCareRegistry.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] RequestedPsychologicalAutopsy WITH(NOLOCK) ON fi.RequestedPsychologicalAutopsyFlagSK = RequestedPsychologicalAutopsy.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ReviewedByMedicalDirectorPending WITH(NOLOCK) ON fi.ReviewedByMedicalDirectorPendingFlagSK = ReviewedByMedicalDirectorPending.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] ReviewedByMedicalDirectorResolved WITH(NOLOCK) ON fi.ReviewedByMedicalDirectorResolvedFlagSK = ReviewedByMedicalDirectorResolved.JunkSK
	INNER JOIN [BIW].[DW].[dimJunk] StaffTerminated WITH(NOLOCK) ON fi.StaffTerminatedFlagSK = StaffTerminated.JunkSK
	WHERE 1=1
	AND ddInOc.DateValue BETWEEN @StartDate AND @EndDate
	AND (dp.ProviderNK = @Provider OR @Provider = -2)
	AND (did.IncidentRecordSource = @Type OR @Type = '-1' )
	AND (did.IncidentContractStatus = @ContractStatus OR @ContractStatus = '-1')
    AND (@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') ) 
			)
    
    
END





GO


