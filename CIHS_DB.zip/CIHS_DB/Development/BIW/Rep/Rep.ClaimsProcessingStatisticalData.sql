USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ClaimsProcessingStatisticalData]    Script Date: 08/28/2013 14:53:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[ClaimsProcessingStatisticalData] 
(
	@strDate DATETIME,
	@endDate DATETIME,
	@benPlan INT
)
AS

/*------------------------------------------------------------------------------
	Title:		Claims Processing Statistical Data
	File:		[Rep].[ClaimsProcessingStatisticalData]
	Author:		Karissa Martindale
	Date:		05/30/13
	Desc:		Claims Processing Statistical Data
                                        
	Called By:
                        Reports:          CLM008 - ClaimsProcessingStatData
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/30/2013		Karissa Martindale   	6314			Created
			2.0		8/20/2013		Justin Ward				6314			Changed Adjudicated Date to Recieved Date for age group Calculation
	
-----------------------------------------------------------------------------------*/

--DECLARE
--	@strDate DATETIME = '5/16/13',
--	@endDate DATETIME = '6/15/13',
--	@benPlan INT = -100

SELECT DISTINCT
	CASE 
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) BETWEEN 0 AND 3 THEN '<=3'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 4 THEN '4'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 5 THEN '5'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 6 THEN '6'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 7 THEN '7' 
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 8 THEN '8' 
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 9 THEN '9' 
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) = 10 THEN '10'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) BETWEEN 11 AND 14 THEN '11 - 14'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) BETWEEN 15 AND 21 THEN '15 - 21'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) BETWEEN 22 AND 48 THEN '22 - 48'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) BETWEEN 49 AND 60 THEN '49 - 60'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) BETWEEN 61 AND 90 THEN '61 - 90'
		WHEN DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) >90 THEN '>90'
	END as ageGroup,
	fClaim.AdjudicationDateSK,
	fClaim.ReceivedDateSK,
	fClaim.DateOfServiceSK,
	fClaim.PaidDateSK,
	fClaim.ClaimDetailNumber,
	fClaim.PaidAmount,
	DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) as AginginDays
 INTO #tempDates
 FROM
	BIW.DW.factClaimCheck fCheck
	INNER JOIN BIW.DW.factClaims fClaim WITH(NOLOCK) ON fCheck.ClaimCheckSK = fClaim.ClaimCheckSK
	INNER JOIN BIW.DW.dimJunk dJunk WITH(NOLOCK) ON fClaim.CleanClaimSK = dJunk.JunkSK AND dJunk.JunkEntity = 'CleanClaim'
 	INNER JOIN BIW.DW.dimBenefitPlan dBenPlan WITH(NOLOCK) ON fClaim.BenefitPlanSK = dBenPlan.BenefitPlanSK
 	INNER JOIN BIW.DW.dimDate dPaid WITH(NOLOCK) ON fClaim.PaidDateSK = dPaid.DateSK
 	INNER JOIN BIW.DW.dimDate dRec WITH(NOLOCK) ON fClaim.ReceivedDateSK = dRec.DateSK
 	INNER JOIN BIW.DW.dimDate dAdj WITH(NOLOCK) ON fClaim.AdjudicationDateSK = dAdj.DateSK
 WHERE
	dRec.DateValue BETWEEN @strDate AND @endDate
	--dAdj.DateValue BETWEEN @strDate AND @endDate
	AND fCheck.ClaimCheckNK <> 8032
	AND fCheck.VoidedCheckSK <> 7
	AND fCheck.ClaimCheckDateSK is not null
	AND fClaim.AdjudicatedAmount is not null
	AND fClaim.CapitatedSK = 10
	AND fClaim.Deleted <> 1
	AND CleanClaimSK = 16 
	AND(
		( @benPlan = dBenPlan.BenefitPlanSK ) OR -- 1 specific Plan
		( @benPlan = -100 AND dBenPlan.InsurerID = 2 ) OR -- ALL Medicaid
		( @benPlan = -200 ) -- ALL PLANS
	)
	AND DATEDIFF(DAY, dRec.DateValue, dPaid.DateValue) >= 0
	ORDER BY ageGroup, ClaimDetailNumber

	
SELECT
	ageGroup,
	COUNT(tDates.ClaimDetailNumber) as numberCleanClaimsPaid,
	SUM(tDates.PaidAmount) as dollarCleanClaimsPaid,
	SUM(tDates.AginginDays) as daysforAverage,
	SUM(DATEDIFF(DAY, dosDate.DateValue, recDate.DateValue)) as servDateRecievedDate,
	SUM(DATEDIFF(DAY, dosDate.DateValue, adjDate.DateValue)) as servDateAdjDate,
	SUM(DATEDIFF(DAY, dosDate.DateValue, paidDate.DateValue)) as servDatePaidDate,
	SUM(DATEDIFF(DAY, recDate.DateValue, adjDate.DateValue)) as recDateAdjDate,
	SUM(DATEDIFF(DAY, recDate.DateValue, paidDate.DateValue)) as recDatePaidDate,
	SUM(DATEDIFF(DAY, adjDate.DateValue, paidDate.DateValue)) as adjDatePaidDate
INTO #tempFinal
FROM
	#tempDates tDates
	INNER JOIN BIW.DW.dimDate adjDate WITH(NOLOCK) ON tDates.AdjudicationDateSK = adjDate.DateSK
	INNER JOIN BIW.DW.dimDate recDate WITH(NOLOCK) ON tDates.ReceivedDateSK = recDate.DateSK
	INNER JOIN BIW.DW.dimDate dosDate WITH(NOLOCK) ON tDates.DateOfServiceSK = dosDate.DateSK
	INNER JOIN BIW.DW.dimDate paidDate WITH(NOLOCK) ON tDates.PaidDateSK = paidDate.DateSK
GROUP BY ageGroup

--If 14 rows are returned no reason to run while loop
DECLARE @ages VARCHAR(MAX) = ('<=3,4,5,6,7,8,9,10,11 - 14,15 - 21,22 - 48,49 - 60,61 - 90,>90') 

SELECT 
	fnp.element 
INTO #fillerTable
FROM 
	#tempFinal tF
	RIGHT JOIN dbo.cfn_split(@ages , ',') fnp ON fnp.element = tF.ageGroup
WHERE
	ageGroup is null

DECLARE @i INT = (SELECT COUNT(element) FROM #fillerTable)
WHILE @i > 0  
	BEGIN
		DECLARE @currentAge VARCHAR(MAX) = (SELECT TOP(1) * FROM #fillerTable)
		INSERT INTO #tempFinal VALUES (@currentAge, 0, 0.00, 0, 0, 0, 0, 0, 0, 0)
		DELETE FROM #fillerTable WHERE element = @currentAge
		SET @i = (SELECT COUNT(element) FROM #fillerTable)	
	END

SELECT * FROM #tempFinal

DROP TABLE #tempDates
DROP TABLE #tempFinal
DROP TABLE #fillerTable


--select * from #tempFinal
--select (SUM(numberCleanClaimsPaid))/(SUM(recDatePaidDate)) from #tempFinal
--select SUM(numberCleanClaimsPaid), SUM(recDatePaidDate) from #tempFinal


