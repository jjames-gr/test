USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[CSPRChildResidential]
(
	@strDate DATE,
	@endDate DATE,
	@insPlan INT,
	@age INT,
	@catchment INT,
	@reportType INT
) AS

/*------------------------------------------------------------------------------
	Title:		CSPR Child Residential
	File:		[Rep].[CSPRChildResidential]
	Author:		Karissa Martindale
	Date:		06/11/13
	Desc:		Looks a residential treatment Level 2-program, 3 and 4 at the summary level.

				The detail report looks at Level 1 - Family, Level 2 - TFC, Level 2 - Program,
				Residential Level 3-4, PRTF and critical 5.
                                        
	Called By:
                        Reports:          QMG001 - CSPRChildResidential
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/11/2013		Karissa Martindale   	6532			Created
			1.1		07/16/2013		Doug Cox				6532			Changes
	
-----------------------------------------------------------------------------------*/

--DECLARE
--	@strDate DATETIME = '1/1/13',
--	@endDate DATETIME = '1/3/13',
--	@insPlan INT = -200,
--	@age INT = 1, -- Child 0-17 (1), Adult 18-20 (2), Adult 21+ (3), ALL (-1)
--	@catchment VARCHAR(MAX) = '1022',--'-300',
--	@reportType INT = 1 --1 Summary 2 Detail

	IF object_id('tempdb..#tempNumerator') is not null
		BEGIN
			DROP TABLE #tempNumerator
		END
	IF object_id('tempdb..#tempDenominator') is not null
		BEGIN
			DROP TABLE #tempDenominator
		END

SELECT DISTINCT
	ServiceLevels.CustomGroupValue AS ServiceLevel,
	SUM(fClaims.PaidAmount + fClaims.CreditAmount) as Dollars,
	SUM(fClaims.UnitsBilled) AS UnitsBilled,
	COUNT(DISTINCT dProv.ProviderNK) AS ProvidersPaid,
	dOrg.County,
	COUNT(DISTINCT dCon.ConsumerNK) as Numerator,
	AgeGroups.CustomGroupValue AS AgeGroup
INTO #tempNumerator
FROM
	DW.factClaims AS fClaims WITH(NOLOCK)
	INNER JOIN DW.dimProvider AS dProv WITH(NOLOCK) ON fClaims.ProviderSK = dProv.ProviderSK
	INNER JOIN DW.dimOrganization AS dOrg WITH(NOLOCK) ON fClaims.OrganizationSK = dOrg.OrganizationSK
	INNER JOIN DW.dimServices AS dServ WITH(NOLOCK) ON fClaims.ServicesSK = dServ.ServicesSK
	INNER JOIN DW.dimConsumers AS dCon WITH(NOLOCK) ON fClaims.ConsumerSK = dCon.ConsumerSK
	INNER JOIN DW.dimBenefitPlan AS dimBenP WITH(NOLOCK) ON fClaims.BenefitPlanSK = dimBenP.BenefitPlanSK
	INNER JOIN DW.dimDate AS dDOS WITH(NOLOCK) ON fClaims.DateOfServiceSK = dDOS.DateSK
	INNER JOIN DW.dimDiagnosis AS dDiag WITH(NOLOCK) ON fClaims.Diagnosis1SK = dDiag.DiagnosisSK
	INNER JOIN DW.dimCustomReportGroups AS AgeGroups WITH(NOLOCK) ON CustomGroupName = 'CSPRChildResidentialAgeGroups'
										AND fClaims.AgeSK BETWEEN BeganAttributeCodeRange AND EndAttributeCodeRange
	INNER JOIN DW.dimCustomReportGroups AS ServiceLevels WITH(NOLOCK) ON ServiceLevels.CustomGroupName = 'CSPRChildResidentialLevelOfService'
										AND dServ.ServicesNK = ServiceLevels.AttributeID
WHERE
	dDOS.DateValue BETWEEN @strDate AND @endDate
	AND (
			@catchment = '-300'
			OR CONVERT(nvarchar, dOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, dOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		)
	AND	(
			( @insPlan = dimBenP.BenefitPlanNK ) OR -- 1 specific Plan
			( @insPlan = -100 AND dimBenP.InsurerID = 2 ) OR -- ALL Medicaid
			( @insPlan = -200 ) -- ALL PLANS
		)
	AND (
			(@reportType = 1 --Summary 
--				AND dServ.ServicesNK IN (    52, 75,     134, 135, 136, 137, 138, 189, 190, 191) 
				AND ServiceLevels.CustomGroupValue IN ('Level 2-Program' , 'Level 3' , 'Level 4')
			)
			OR
			(@reportType = 2 --Detail
--				AND dServ.ServicesNK IN (35, 52, 75, 87, 134, 135, 136, 137, 138, 189, 190, 191, 194, 197, 1348)
			)
		)
	AND fClaims.PaidSK = 9 --Paid Claims
	AND dDiag.DiagnosisGroupID in (3,4)
	AND
	(
		(@age = 1 AND AgeGroups.CustomGroupValue = 'Child 0-17')
		OR (@age = 2 AND AgeGroups.CustomGroupValue = 'Adult 18-20')
		OR (@age = 3 AND AgeGroups.CustomGroupValue = 'Adult 21+')
		OR (@age = -1)
	)
GROUP BY
	ServiceLevels.CustomGroupValue,
	dOrg.County,
	AgeGroups.CustomGroupValue

--SELECT * FROM #tempNumerator

SELECT DISTINCT
	dOrg.County,
	AgeGroups.CustomGroupValue as AgeGroup, 
	COUNT(DISTINCT dCon.ConsumerNK) as Denominator,
	ServiceLevels.CustomGroupValue as ServiceLevel
INTO #tempDenominator
FROM
	DW.factClaims AS fClaims WITH(NOLOCK)
	INNER JOIN DW.dimOrganization AS dOrg WITH(NOLOCK) ON fClaims.OrganizationSK = dOrg.OrganizationSK
	INNER JOIN DW.dimServices AS dServ WITH(NOLOCK) ON fClaims.ServicesSK = dServ.ServicesSK
	INNER JOIN DW.dimConsumers AS dCon WITH(NOLOCK) ON fClaims.ConsumerSK = dCon.ConsumerSK
	INNER JOIN DW.dimBenefitPlan AS dimBenP WITH(NOLOCK) ON fClaims.BenefitPlanSK = dimBenP.BenefitPlanSK
	INNER JOIN DW.dimDate AS dDOS WITH(NOLOCK) ON fClaims.DateOfServiceSK = dDOS.DateSK
	INNER JOIN DW.dimDiagnosis AS dDiag WITH(NOLOCK) ON fClaims.Diagnosis1SK = dDiag.DiagnosisSK
	INNER JOIN DW.dimCustomReportGroups AS AgeGroups WITH(NOLOCK) ON AgeGroups.CustomGroupName = 'CSPRChildResidentialAgeGroups'
										AND fClaims.AgeSK BETWEEN AgeGroups.BeganAttributeCodeRange AND AgeGroups.EndAttributeCodeRange
	INNER JOIN DW.dimCustomReportGroups AS ServiceLevels WITH(NOLOCK) ON ServiceLevels.CustomGroupName = 'CSPRChildResidentialLevelOfService'
WHERE
	dDOS.DateValue BETWEEN @strDate AND @endDate
	AND(
		@catchment = '-300'
		OR CONVERT(nvarchar, dOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, dOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)
	AND(
		( @insPlan = dimBenP.BenefitPlanNK ) OR -- 1 specific Plan
		( @insPlan = -100 AND dimBenP.InsurerID = 2 ) OR -- ALL Medicaid
		( @insPlan = -200 ) -- ALL PLANS
	)
	AND fClaims.PaidSK = 9 --Paid Claims
	AND dDiag.DiagnosisGroupID in (2,3,4)
	AND
	(
		(@age = 1 AND AgeGroups.CustomGroupValue = 'Child 0-17')
		OR (@age = 2 AND AgeGroups.CustomGroupValue = 'Adult 18-20')
		OR (@age = 3 AND AgeGroups.CustomGroupValue = 'Adult 21+')
		OR (@age = -1)
	)
GROUP BY
	dOrg.County,
	AgeGroups.CustomGroupValue,
	ServiceLevels.CustomGroupValue

SELECT	DISTINCT
		tD.County,
		tD.ServiceLevel,
		ISNULL(tN.Dollars,0) AS Dollars,
		ISNULL(tN.UnitsBilled,0) AS UnitsBilled,
		ISNULL(tN.ProvidersPaid,0) AS ProvidersPaid,
		ISNULL(tN.Numerator,0) AS Numerator,
		tD.Denominator
FROM	#tempDenominator as tD 
		LEFT OUTER JOIN #tempNumerator as tN ON tn.AgeGroup = tD.AgeGroup AND tN.County = tD.County AND tD.ServiceLevel = tN.ServiceLevel

