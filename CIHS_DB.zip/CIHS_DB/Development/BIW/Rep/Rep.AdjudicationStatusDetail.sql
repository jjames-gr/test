USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[AdjudicationStatusDetail]    Script Date: 06/12/2013 12:33:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [Rep].[AdjudicationStatusDetail]
	@StartDate DATETIME
	,@EndDate DATETIME
AS


/*------------------------------------------------------------------------------
	Title:		Adjudication Status Detail - Provider Sort
	File:		[Rep].[AdjudicationStatusDetail]
	Author:		Divya Lakshmi
	Date:		06/03/2013
	Desc:		Adjudication Status Detail Report
                                        
	Called By:
                        Reports:     CLM326 - AdjudicationStatusDetail.rdl
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/03/2013		Divya Lakshmi     		6275			Created

	-----------------------------------------------------------------------------------*/

--DECLARE @StartDate DATETIME,@EndDate DATETIME
--set	@StartDate = '1/1/2012'
--set	@EndDate   = '1/31/2012'
	
SELECT DISTINCT 
    p.providername,
	rc.ReasonCodeNK as DenialReasonCode,
	rc.description as description,
	cast(rc.reasoncodenk as varchar(100)) + '-' + rc.Description as reasondesc,
	--fc.reasoncodesk,
	fc.DateOfServiceSK as DateOfService,
	c.ConsumerNK as ClientID,
	c.FirstName as FirstName,
    c.LastName as LastName,
    s.ServiceCode as ServiceCode,	
    s.Modifier1 as Modifier1,	
    s.Modifier2 as Modifier2,
	fc.ClaimNumber as ClaimNumber,
    fc.StatusSK as StatID,	
    fc.COBPlan as COBInsurer,	
    p.NPI as NPINumber,	
	fc.AdjustedAmount as AdjustedAmount,
	fc.AdjudicationDateSK

FROM

	DW.factClaims fc
	INNER JOIN DW.dimDate Dt with(nolock) ON fc.AdjudicationDateSK = Dt.DateSK
	INNER JOIN DW.dimReasonCodes rc with(nolock)  ON fc.ReasonCodeSK = rc.ReasonCodeSK
    INNER JOIN DW.dimConsumers c with(nolock)  ON fc.ConsumerSK = c.ConsumerSK
	INNER JOIN DW.dimProvider p with(nolock) ON fc.ProviderSK = p.ProviderSK
    INNER JOIN DW.dimServices s with(nolock)  ON fc.ServicesSK = s.ServicesSK
    INNER JOIN biw.dw.dimCustomReportGroups cr on s.ServicesNK  not between
               cr.BeganAttributeCodeRange and cr.EndAttributeCodeRange
               and CustomGroupName = 'AdjudicatedStatusDetailRServiceIDs'

	
WHERE
 rc.ReasonCodeNK NOT IN (select rc.ReasonCodeNK from biw.dw.dimReasonCodes rc inner join biw.dw.dimCustomReportGroups c on rc.ReasonCodeNK = c.AttributeID and CustomGroupName = 'AdjudicatedStatusDetailReasonCodes')
 AND fc.StatusSK IN ( 2, 3 )
 AND   Dt.DateValue BETWEEN @StartDate AND @EndDate
 AND (fc.COBInsurance  <>'--Unknown--' or fc.COBInsurance is null)
 AND (fc.COBPlan <> '--Unknown--' or fc.COBPlan is null)
 AND p.ETLCurrentRow=1
 AND s.ServiceCode not like '%All%'
 --and s.ServicesSK<>-1
 --and p.ProviderSK<>-1
ORDER BY
	p.ProviderName
		
	














GO


