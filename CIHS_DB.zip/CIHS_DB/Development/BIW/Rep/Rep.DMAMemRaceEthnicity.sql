USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[DMAMemRaceEthnicity]    Script Date: 07/22/2013 15:25:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO













CREATE PROCEDURE [REP].[DMAMemRaceEthnicity]  
(
	@strDate DATETIME,
	@endDate DATETIME,
	@insPlan INT,
	@catchment NVARCHAR(MAX) 
)AS
/*------------------------------------------------------------------------------
	Title:		DMA Race Ethnicity Diversity of Membership 
	File:		[REP].[DMAMemRaceEthnicity]
	Author:		Divya Lakshmi
	Date:		06/06/2013
	Desc:		DMA Race Ethnicity Diversity of Membership - HEDIS
                                        
	Called By:
                        Reports:          STA002 - DMAMemRaceEthnicity
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/06/2013		Divya Lakshmi   	     6377			Created
	
-----------------------------------------------------------------------------------*/
--DECLARE
--	@strDate DATETIME = '1/1/2013',
--	@endDate DATETIME = '3/31/2013',
--	@insPlan INT = -200,
--	@catchment NVARCHAR(MAX)  =-300-- 1021
	
    DECLARE @known_race NUMERIC
    DECLARE @total_client NUMERIC
    DECLARE @known_eth NUMERIC
    
SELECT DISTINCT
	c.ConsumerNK,
	c.ConsumerSK,
	c.FullName,
	Case	WHEN c.race = '--Unknown--' THEN 'Unknown'
	WHEN  c.race is null THEN 'Unknown'
	ELSE c.Race 
	END as race,
	CASE WHEN c.EthnicityID IN ( 72, 73, 74, 75 )
                 THEN 'Hispanic or Latino'
                 WHEN c.EthnicityID = 76 THEN 'Not Hispanic or Latino'
                 ELSE 'Unknown'
            END AS Ethnicity,
	ISNULL(NULLIF(c.GenderCode, '--'), 'U') as GenderCode,
	bp.BenefitPlanNK,
	bp.benefitplanshort,
	o.Catchment
	into #temp
FROM BIW.DW.factEligibility fe WITH(NOLOCK) 
	 INNER JOIN BIW.DW.dimConsumers c WITH(NOLOCK) ON fe.ConsumerSK = c.ConsumerSK
	 INNER JOIN BIW.DW.dimOrganization o WITH(NOLOCK) ON fe.OrganizationSK = o.OrganizationSK
	 INNER JOIN BIW.DW.dimBenefitPlan bp WITH(NOLOCK) ON fe.BenefitPlanSK = bp.BenefitPlanSK
	 INNER JOIN BIW.DW.dimDate dDate WITH(NOLOCK) ON fe.DateSK = dDate.DateSK
	 INNER JOIN BIW.DW.dimDate dExp WITH(NOLOCK) ON ISNULL(NULLIF(fe.ExpirationDateSK, -1), 29990101) = dExp.DateSK
WHERE 
	dDate.DateValue <= @enddate
	AND dExp.DateValue >= @endDate		
	AND	(
	
			@catchment = '-300'
			OR CONVERT(nvarchar, o.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, o.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

		)

		AND(
		( @insPlan = bp.BenefitPlanNK ) OR -- 1 specific Plan
		( @insPlan = -100 AND bp.InsurerID = 2 ) OR -- ALL Medicaid
		( @insPlan = -200 ) -- ALL PLANS
	)
GROUP BY
	o.Catchment, c.ConsumerNK,c.ConsumerSK, c.FullName,  c.GenderCode,c.Race,c.EthnicityID,bp.BenefitPlanNK,bp.BenefitPlanShort


   SELECT  @total_client = COUNT(distinct ConsumerNK )
            FROM    #temp

            SELECT  @known_race = COUNT(distinct ConsumerNK)
            FROM    #temp
            WHERE   race not like '%Unknown%'

            SELECT  @known_eth = COUNT(distinct ConsumerNK)
            FROM    #temp
            WHERE   ethnicity not like '%Unknown%'
                
             
                 select 
                 t.race,
                 t.ethnicity,
                 count(distinct ConsumerNK) cnt,
                 ( COUNT(distinct ConsumerNK) / @total_client ) * 100 AS ind_percent ,
                 @total_client total_client,
                 ( @known_race / @total_client ) * 100 race_percent,
                 ( @known_eth / @total_client ) * 100 eth_percent ,
                 t.GenderCode
                 
                 from #temp t
                 group by race,Ethnicity,GenderCode
                 union select distinct 'Alaskan Native','Hispanic or Latino', 0 cnt,0 AS ind_percent ,
                  @total_client total_client,
                 ( @known_race / @total_client ) * 100 race_percent,
                 ( @known_eth / @total_client ) * 100 eth_percent ,
                  'M'
                 
                 from #temp t
                  union select distinct 'Alaskan Native','Not Hispanic or Latino', 0 cnt,0 AS ind_percent ,
                  @total_client total_client,
                 ( @known_race / @total_client ) * 100 race_percent,
                 ( @known_eth / @total_client ) * 100 eth_percent ,
                  'M'
                 
                 from #temp t
       
drop table #temp










GO


