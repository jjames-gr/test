USE BIW
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [REP].[SpecialNeedsPopulations]
(
	@StartDate DATETIME,
	@EndDate DATETIME,
	@BenPlan NVARCHAR(MAX),
	@Catchment NVARCHAR(MAX),
	@SpecPop NVARCHAR(MAX)
)
AS

/*------------------------------------------------------------------------------
	Title:		Special Needs Populations
	File:		[REP].[SpecialNeedsPopulations] 
	Author:		Tim Amerson
	Date:		09/23/13
	Desc:		Identifies B Waiver members who meet the "Special Populations"
				catagories specified in the Waiver - based on Claim.
				To identify Waiver Special Populations and ensure they are
				receiving appropriate services and/or Care Coordination.
                                        
	Called By:
                        Reports:          UMA036 - Special Needs Populations 
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		09/23/2013		Tim Amerson			   	6285			Created
-----------------------------------------------------------------------------------*/

--DECLARE
--	@StartDate DATETIME = '1/1/2013',
--	@EndDate DATETIME = '1/31/2013',
--	@BenPlan INT = -200,
--	@Catchment NVARCHAR(MAX) = -300,
--	@SpecPop NVARCHAR(100) = 123

SELECT *
INTO #tmpCon
FROM biw.dw.dimConsumers

create clustered index idxConsumer on #tmpCon (ConsumerNK)

SELECT DISTINCT
	PlaceHolder = 1
	,ConsumerID = dc.ConsumerNK
	,ConsumerFirstName = dc.FirstName
	,ConsumerLastName = dc.LastName
	,DateOfBirth = dc.DOB
	,ConsumerAge = dc.Age
	,SpecialPopulationGroup = fc.SpecialDiagnosisGroup
	,fc.DateOfServiceSK
	--,InsuranceNumber = fe.InsuranceNumber
	,County = do.County
	,Catchment = do.Catchment

INTO
	#tmpClaims
	
FROM
	--biw.dw.factEligibility fe WITH(NOLOCK)
	biw.dw.factClaims fc WITH(NOLOCK)
	INNER JOIN biw.dw.dimDate dos WITH(NOLOCK) ON fc.DateOfServiceSK = dos.DateSK
	INNER JOIN biw.dw.dimBenefitPlan bp WITH(NOLOCK) ON fc.BenefitPlanSK = bp.BenefitPlanSK
	INNER JOIN biw.dw.dimOrganization do WITH(NOLOCK) ON fc.OrganizationSK = do.OrganizationSK
	INNER JOIN biw.dw.dimConsumers dc WITH(NOLOCK) ON fc.ConsumerSK = dc.ConsumerSK
	INNER JOIN BIW.dbo.cfn_split(@BenPlan,',') fnBP ON bp.BenefitPlanNK = fnBP.element
	INNER JOIN BIW.dbo.cfn_split(@SpecPop,',') fnSpecPop ON fc.SpecialDiagnosisGroup = fnSpecPop.element

WHERE 1=1
	AND dc.ConsumerNK <> -1
	AND dos.DateValue BETWEEN @StartDate AND @EndDate
	AND
	(
		@catchment = '-300'
		OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
		OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
	)

create clustered index idxConClaims on #tmpClaims (ConsumerID)


SELECT DISTINCT
	*

FROM
(
	SELECT DISTINCT
		tc.*
		,InsuranceNumber = fe.InsuranceNumber
		,DOJInvolvement = dj.JunkValue
		,LOCType = srASAM.ScoreName
		,LOCLevel = srASAM.ResultLevelOfCare

	FROM
		#tmpClaims tc
		
		INNER JOIN #tmpCon consConnect1 WITH(NOLOCK) ON tc.ConsumerID = consConnect1.ConsumerNK
		INNER JOIN biw.dw.factEligibility fe WITH(NOLOCK) ON consConnect1.ConsumerSK = fe.ConsumerSK AND tc.DateOfServiceSK = fe.DateSK
		
		INNER JOIN #tmpCon consConnect2 WITH(NOLOCK) ON tc.ConsumerID = consConnect2.ConsumerNK
		INNER JOIN biw.dw.factConsumerTags ct WITH(NOLOCK) ON consConnect2.ConsumerSK = ct.ConsumerSK
		INNER JOIN biw.dw.dimJunk dj WITH(NOLOCK) ON ct.ConsumerTagSK = dj.JunkSK
			AND dj.JunkNK IN ( SELECT CAST( crg.AttributeID AS VARCHAR(MAX) ) FROM biw.dw.dimCustomReportGroups crg WHERE crg.CustomGroupName = 'SpecialNeedsPopDOJInvolvement' ) --'641' , '650' , '723' )
		
		INNER JOIN #tmpCon consConnect3 WITH(NOLOCK) ON tc.ConsumerID = consConnect3.ConsumerNK
		INNER JOIN biw.dw.factTreatmentAuthorizationRequest ft WITH(NOLOCK) ON consConnect3.ConsumerSK = ft.ConsumerSK
		INNER JOIN biw.dw.dimScoreResults srASAM WITH(NOLOCK) ON ft.ASAMResultSK = srASAM.ScoreResultsSK

	UNION ALL

	SELECT DISTINCT
		tc.*
		,InsuranceNumber = fe.InsuranceNumber
		,DOJInvolvement = dj.JunkValue
		,LOCType = srCAL.ScoreName
		,LOCLevel = srCAL.ResultLevelOfCare

	FROM
		#tmpClaims tc
		
		INNER JOIN #tmpCon consConnect1 WITH(NOLOCK) ON tc.ConsumerID = consConnect1.ConsumerNK
		INNER JOIN biw.dw.factEligibility fe WITH(NOLOCK) ON consConnect1.ConsumerSK = fe.ConsumerSK AND tc.DateOfServiceSK = fe.DateSK
		
		INNER JOIN #tmpCon consConnect2 WITH(NOLOCK) ON tc.ConsumerID = consConnect2.ConsumerNK
		INNER JOIN biw.dw.factConsumerTags ct WITH(NOLOCK) ON consConnect2.ConsumerSK = ct.ConsumerSK
		INNER JOIN biw.dw.dimJunk dj WITH(NOLOCK) ON ct.ConsumerTagSK = dj.JunkSK
			AND dj.JunkNK IN ( SELECT CAST( crg.AttributeID AS VARCHAR(MAX) ) FROM biw.dw.dimCustomReportGroups crg WHERE crg.CustomGroupName = 'SpecialNeedsPopDOJInvolvement' ) --'641' , '650' , '723' )
		
		INNER JOIN #tmpCon consConnect3 WITH(NOLOCK) ON tc.ConsumerID = consConnect3.ConsumerNK
		INNER JOIN biw.dw.factTreatmentAuthorizationRequest ft WITH(NOLOCK) ON consConnect3.ConsumerSK = ft.ConsumerSK
		INNER JOIN biw.dw.dimScoreResults srCAL WITH(NOLOCK) ON ft.CalocusResultSK = srCAL.ScoreResultsSK

	UNION ALL

	SELECT DISTINCT
		tc.*
		,InsuranceNumber = fe.InsuranceNumber
		,DOJInvolvement = dj.JunkValue
		,LOCType = srLOC.ScoreName
		,LOCLevel = srLOC.ResultLevelOfCare

	FROM
		#tmpClaims tc
		
		INNER JOIN #tmpCon consConnect1 WITH(NOLOCK) ON tc.ConsumerID = consConnect1.ConsumerNK
		INNER JOIN biw.dw.factEligibility fe WITH(NOLOCK) ON consConnect1.ConsumerSK = fe.ConsumerSK AND tc.DateOfServiceSK = fe.DateSK
		
		INNER JOIN #tmpCon consConnect2 WITH(NOLOCK) ON tc.ConsumerID = consConnect2.ConsumerNK
		INNER JOIN biw.dw.factConsumerTags ct WITH(NOLOCK) ON consConnect2.ConsumerSK = ct.ConsumerSK
		INNER JOIN biw.dw.dimJunk dj WITH(NOLOCK) ON ct.ConsumerTagSK = dj.JunkSK
			AND dj.JunkNK IN ( SELECT CAST( crg.AttributeID AS VARCHAR(MAX) ) FROM biw.dw.dimCustomReportGroups crg WHERE crg.CustomGroupName = 'SpecialNeedsPopDOJInvolvement' ) --'641' , '650' , '723' )
		
		INNER JOIN #tmpCon consConnect3 WITH(NOLOCK) ON tc.ConsumerID = consConnect3.ConsumerNK
		INNER JOIN biw.dw.factTreatmentAuthorizationRequest ft WITH(NOLOCK) ON consConnect3.ConsumerSK = ft.ConsumerSK
		INNER JOIN biw.dw.dimScoreResults srLOC WITH(NOLOCK) ON ft.LocusResultSK = srLOC.ScoreResultsSK
	
) subQ

drop table #tmpCon
drop table #tmpClaims