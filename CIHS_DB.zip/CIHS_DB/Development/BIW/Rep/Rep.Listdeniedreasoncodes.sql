USE [BIW]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[Listdeniedreasoncodes]
AS

/*------------------------------------------------------------------------------
	Title:		List Denied reason codes
	File:		[Rep].[Listdeniedreasoncodes]
	Author:		Karen Roslund
	Date:		06/04/13
	Desc:		This listing of denied reason codes  can be used to fill the available 
					values for the reasoncode Parameter.
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/04/2013		Karen roslund   						Created
			
	
*/

/* Get Listing of available denied reasoncodes */
	SELECT distinct dr.ReasonCodeNK ,
		dr.reasoncodeSK,
		dr.Description,
		2 as reasonOrder 
	FROM dw.factClaims fc with (nolock)
	inner join DW.dimReasonCodes  as dr with(nolock) on fc.ReasonCodeSK  = dr.ReasonCodesK  
	where fc.StatusSK in (2,3)
	UNION
	SELECT -2 AS ReasonCodeNK ,
		-2 AS reasoncodeSK ,
		'All',
		1 as reasonOrder 

	ORDER BY reasonOrder, dr.Description  
	
	go