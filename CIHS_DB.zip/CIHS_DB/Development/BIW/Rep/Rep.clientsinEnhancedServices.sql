USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[clientsinEnhancedServices]    Script Date: 09/25/2013 14:37:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[clientsinEnhancedServices]

	@eff_dt DATE, 
	@end_dt DATE, 
	@catchment varchar(max)

AS


/*------------------------------------------------------------------------------
	Title:		Clients in Enhanced Services
	File:		[clientsinEnhancedServices]
	Author:		Karen Roslund
	Date:		05/30/2013
	Desc:		Created to show clients with auths for current enhanced services
                                        
	Called By:
                        Reports:          clientsinEnhancedServices
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/30/2013		Karen Roslund 			6327			Created
            1.1		08/1/2013		Karen Roslund 			6327			added master provider and site provider to the report and used the new logic to pull catchment
            2.0		09/25/2013		Justin Ward				6327			Add sum to Auth Units, Cleaned up code
	-----------------------------------------------------------------------------------*/


--DECLARE

--@eff_dt DATE = '1/1/2013', 
--@end_dt DATE = '1/31/2013', 
--@catchment varchar(max) = '-300'

SELECT 
	Client.ConsumerNK,
	Client.FirstName,
	Client.LastName,
	Client.Age,
	Auths.OrganizationSK ,
	Client.County,
	Serv.ServiceDefinition,
	MainProv.ProviderName,
	SiteProv.ProviderName site_name, 
	SiteProv.County Site_county,  
	Auths.AuthorizationNumber,
	EffDate.[DateName_en-US] effective_From_date,
	ExpDate.[DateName_en-US] effect_end_date,
	ServToBen.DailyMaxServices,
	ServToBen.WeeklyMaxServices,
	ServToBen.MonthlyMaxServices,
	ServToBen.YearlyMaxServices,
	SUM(Auths.AuthorizedUnits) as AuthorizedUnits,--Added to Summation to get all like authorization records on the same row JW 9/25/13
	BenPlan.BenefitPlan  
 
FROM
	DW.factAuthorizations Auths with (nolock)
	INNER JOIN DW.dimBenefitPlan BenPlan WITH(NOLOCK) ON Auths.BenefitPlanSK = BenPlan.BenefitPlanSK
	INNER JOIN DW.dimBenefitPlan BenJoin WITH(NOLOCK) ON BenPlan.BenefitPlanNK = BenJoin.BenefitPlanNK
	INNER JOIN DW.dimConsumers Client with (nolock) on Auths.ConsumerSK = Client.ConsumerSK
	INNER JOIN DW.dimServices Serv with (nolock) on Auths.ServicesSK = Serv.ServicesSK 
	INNER JOIN DW.dimServices ServJoin with (nolock) on Serv.ServicesNK = ServJoin.ServicesNK 
	INNER JOIN DW.factServicesBenefitPlan ServToBen with (nolock) on ServJoin.ServicesSK = ServToBen.ServicesSK and BenJoin.BenefitPlanSK = ServToBen.BenefitPlanSK 
	INNER JOIN DW.dimProvider MainProv with (nolock) on Auths.MasterProviderSK  = MainProv.ProviderSK 
	INNER JOIN DW.dimProvider SiteProv with (nolock) on Auths.ProvidersK = SiteProv.ProviderSK   
	INNER JOIN DW.dimDate EffDate with (nolock) on Auths.EffectiveFromDateSK  = EffDate.DateSK 
	INNER JOIN DW.dimDate ExpDate with (nolock) on Auths.EffectiveToDateSK = ExpDate.DateSK 
	INNER JOIN DW.dimOrganization Org with (nolock) on Auths.OrganizationSK = Org.OrganizationSK 

WHERE 
	ServToBen.BasicServiceFlag <> 1
	AND EffDate.DateValue  <= @end_dt 
	AND ExpDate.DateValue >= @eff_dt 
	AND Serv.ServicesNK NOT IN (SELECT AttributeID FROM dw.dimCustomReportGroups WHERE CustomGroupName = 'EnhancedServiceExclusionCodes')
	AND  
		(

			@catchment = '-300'
			OR CONVERT(nvarchar, Org.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, Org.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

		)
		
GROUP BY
	ConsumerNK,
	Client.FirstName,
	Client.LastName,
	Client.Age,
	Auths.OrganizationSK ,
	Client.County,
	Serv.ServiceDefinition,
	MainProv.ProviderName,
	SiteProv.ProviderName , 
	SiteProv.County ,  
	Auths.AuthorizationNumber,
	EffDate.[DateName_en-US] ,
	ExpDate.[DateName_en-US] ,
	ServToBen.DailyMaxServices,
	ServToBen.WeeklyMaxServices,
	ServToBen.MonthlyMaxServices,
	ServToBen.YearlyMaxServices,
	BenPlan.BenefitPlan
	
ORDER BY
	AuthorizationNumber

 
 