USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[STRAppointmentDump]    Script Date: 09/16/2013 09:07:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







CREATE PROCEDURE [REP].[STRAppointmentDump]
     @StartDate DATE = '1/1/13'
    ,@EndDate DATE = '1/31/13'
    ,@SeverityType VARCHAR(50)
      
AS

/*------------------------------------------------------------------------------
      Title:       STR Appointment Dump
      File:        [REP].[STRAppointmentDump]
      Author:      Divya Lakshmi
      Date:        08/22/2013
      Desc:        Data dump for STR appointment information
                                        
      Called By:
                        Reports:     UMA027 - STRAppointmentDump.rdl
                       
      -----------------------------------------------------------------------------------
      Version History:
      
                  Ver         Date              Author                        TixNo             Description
                  ---         ----------        ---------------               -----             -----------
                  1.0         08/22/2013        Divya Lakshmi                 6527              Created

      -----------------------------------------------------------------------------------*/
      
--DECLARE
--       @StartDate DATE = '1/1/13'
--      ,@EndDate DATE = '1/31/13'
--      ,@SeverityType varchar(max) = '-2'

SELECT DISTINCT
jSev.JunkValue AS ReferralType,
CASE WHEN jSev.JunkNK = 1 THEN 'Emergent'
                        WHEN jSev.JunkNK = 2 THEN 'Urgent'
                        WHEN jSev.JunkNK = 3 THEN 'Routine'
                        WHEN jSev.JunkNK = 2 AND DATEDIFF(day, dScreen.DateValue,dApp.DateValue) > 14
                              THEN 'Urgent Non Complaint'
                        WHEN jSev.JunkNK = 3 AND DATEDIFF(day, dScreen.DateValue,dApp.DateValue) > 2
                              THEN 'Routine Non Complaint'
END AS urgency ,
dp1.ProviderName + ' '+ dp.ProviderName AS ProviderName,
CASE WHEN fSTR.ScreenDateSK <>-1  THEN dScreen.DateValue
     ELSE dApp.DateValue
END AS ScreenDate, 
CASE WHEN fSTR.ScreenDateSK <>-1  THEN fstr.ScreenDateSK
     ELSE fa.AppointmentCreateDateSK
END AS ScreenDateSK, 
--jda.JunkValue AS DeclinedOrAccepted,  
CASE WHEN jda.JunkValue ='yes'  THEN 'Accepted'
     ELSE 'Declined'
END AS DeclinedOrAccepted,  
dAppoint.DateValue AS AppointmentDate ,                
fSTR.ScreeningTriageReferralID AS STRID,
jrd.JunkValue AS ReasonDeclined,
dSTR.ScreeningTriageReferralProvDetComments AS DeclinedComments,
dc.FullName AS ConsumerName,
dc.ConsumerNK AS ConsumerID,
dc.DOB,
dc.County,
japp.JunkValue AS AppointmentStatus,

CASE WHEN jdis.JunkValue ='Unknown'  THEN ''
     ELSE jdis.JunkValue
END AS DischargeFacility,
CASE WHEN dis.DateValue ='1900-01-01' THEN Null
     ELSE dis.DateValue
END AS DischargeDate,
ds.ServiceDescription,
dac.AppointmentComments AS AppointmentComments,
dp.ProviderName AS STRProviderAttempt
,de.FullName AS AppointmentCreator
into #temp
FROM
      dw.factAppointments fa WITH(NOLOCK)
      LEFT OUTER JOIN dw.dimJunk jApp WITH(NOLOCK) ON fa.AppointmentStatusSK = jApp.JunkSK
      LEFT OUTER JOIN dw.dimJunk jdis WITH(NOLOCK) ON fa.DischargeFacilityTypeSK = jdis.JunkSK
      LEFT OUTER JOIN dw.dimDate dis WITH(NOLOCK) ON fa.DischargeDateSk = dis.DateSK   
      LEFT OUTER JOIN dw.dimDate dAppoint WITH(NOLOCK) ON fa.AppointmentDateSK= dAppoint.DateSK   
      LEFT OUTER JOIN dw.factScreeningTriageReferral fSTR WITH(NOLOCK) ON fa.ScreeningTriageReferralSK=fSTR.ScreeningTriageReferralSK
      LEFT OUTER JOIN dw.factScreeningTriageReferralProvDet fSTRP WITH(NOLOCK) ON fa.ScreeningTriageReferralSK=fSTRP.ScreeningTriageReferralSK
      LEFT OUTER JOIN dw.dimScreeningTriageReferralProvDetComments dSTR WITH(NOLOCK) ON fSTRP.ScreeningTriageReferralProvDetCommentsSK=dSTR.ScreeningTriageReferralProvDetCommentsSK
      LEFT OUTER JOIN dw.dimConsumers dc WITH(NOLOCK) ON fa.ConsumerSK = dc.ConsumerSK
      LEFT OUTER JOIN dw.dimProvider dp WITH(NOLOCK) ON (fa.ProviderSK = dp.ProviderSK or fSTRP.ProviderSK=dp.ProviderSK)
      LEFT OUTER JOIN dw.dimProvider dp1 WITH(NOLOCK) ON dp1.ProviderNK = dp.ParentProviderNK
      LEFT OUTER JOIN dw.dimEmployee de WITH(NOLOCK) ON fa.AppointmentCreatorSK= de.EmployeeSK
      LEFT OUTER JOIN dw.dimServices ds WITH(NOLOCK) ON (fa.ServicesSK = ds.ServicesSK or fSTRP.ServicesSK=ds.ServicesSK)
      LEFT OUTER JOIN dw.dimAppointmentComments dac WITH(NOLOCK) ON fa.AppointmentCommentsSK = dac.AppointmentCommentsSK
      LEFT OUTER JOIN dw.dimDate dScreen WITH(NOLOCK) ON fSTR.ScreenDateSK = dScreen.DateSK
      LEFT OUTER JOIN dw.dimDate dApp WITH(NOLOCK) ON fa.AppointmentCreateDateSK = dApp.DateSK
      LEFT OUTER JOIN dw.dimJunk jSev WITH(NOLOCK) ON fSTR.NeedSeveritySK = jSev.JunkSK
      LEFT OUTER JOIN dw.dimJunk jda WITH(NOLOCK) ON fSTRP.AppointmentAcceptedSK = jda.JunkSK
      LEFT OUTER JOIN dw.dimJunk jrd WITH(NOLOCK) ON fSTRP.AppointmentReasonSK = jrd.JunkSK
      

WHERE 
       1=1 
       AND dc.Active=1
       AND dScreen.DateValue BETWEEN @StartDate AND @EndDate
       AND ( jSev.JunkNK = @SeverityType OR @SeverityType = '-2' )
       AND fSTR.ConsumerSK>0
       AND fSTR.CurrentSTRStatusSK  IN (Select JunkSK from DW.dimJunk where JunkNK in (1,3) and JunkEntity = 'STRStatus')
       AND fSTR.SubmittedFlagSK IN (Select JunkSK from DW.dimJunk where JunkNK in (1) and JunkEntity = 'Boolean')
       AND fSTR.STREntryType IN (Select JunkSK from DW.dimJunk where JunkNK in (1) and JunkEntity = 'EntryType')


----Shows newly enrolled consumers--------------------------------------
    SELECT DISTINCT t.* into #enroll
     FROM     #temp t 
              INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON    t.ConsumerID = c.ConsumerNK
     WHERE c.CreateDate BETWEEN @StartDate AND DATEADD(dd, 1,@EndDate)
---end-----------------------------------------------------------------------

---Looks for consumers without Claims for Last 60 days-----------------------     
                
    SELECT DISTINCT t.ConsumerID,dos.datevalue into #temp1
    FROM     #temp t 
             INNER JOIN dw.dimConsumers c WITH(NOLOCK) ON t.ConsumerID=c.ConsumerNK
             INNER JOIN dw.factClaims fc WITH(NOLOCK) ON c.ConsumerSK=fc.ConsumerSK
             INNER JOIN dw.dimDate dos WITH(NOLOCK) ON fc.DateOfServiceSK = dos.DateSK
    WHERE   
    fc.DateOfServiceSK between (t.ScreenDateSK-60) and (t.ScreenDateSK+1)
    
                       
   -------------end--------------------------------------------------------------------------


    SELECT  t.*
    FROM    #temp t
    WHERE   t.ConsumerID NOT IN ( SELECT ConsumerID
                                 FROM  #temp1)
    UNION      
    SELECT  * FROM    #enroll 
    ORDER BY STRID
            
           drop table #temp
           drop table #temp1
           drop table #enroll
        

            
            




GO


