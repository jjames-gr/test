USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[ListAge]    Script Date: 06/06/2013 09:20:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [Rep].[ListAge]
AS

/*------------------------------------------------------------------------------
	Title:		[Rep].[ListAge]
	File:		[Rep].[ListAge]
	Author:		Tim Amerson
	Date:		05/30/2013
	Desc:		
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		5/31/2013		Tim Amerson				----			Drop Down for Age
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		INNER JOIN dbo.cfn_split(@Age , ',') fnAge ON fnAge.element = da.StateGroupID
		

	-----------------------------------------------------------------------------------*/

SELECT DISTINCT 
	da.StateGroupID
	, da.StateGroup
FROM DW.dimAge as da with(nolock)
ORDER BY da.StateGroup


GO


