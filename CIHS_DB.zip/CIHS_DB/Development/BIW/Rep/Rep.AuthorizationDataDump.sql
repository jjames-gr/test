USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[AuthorizationDataDump]    Script Date: 08/28/2013 09:57:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
CREATE PROCEDURE [REP].[AuthorizationDataDump]
	@EffectiveStartDate datetime,
	@EffectiveEndDate datetime,
	@AgeGroup int,   -- Child=1, '18-20'=2, 'Adult'=3, All=-1
	@DiagnosisGroup int,
	@BenefitPlan int,
	@UserLogin VARCHAR(MAX)
AS
/*------------------------------------------------------------------------------
-- Title:	Authorization Data Dump
-- File:	[Rep].[AuthorizationDataDump]
-- Author:	Brian Angelo
-- Date:	08/12/2013
-- Desc:	Authorization Data Dump stored proc
--			
-- CalledBy:
-- 		Reports: "AuthorizationDataDump"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/12/2013  	Brian Angelo	6280	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

/*
/*** Test Parameters ***/
DECLARE @EffectiveStartDate datetime,
		@EffectiveEndDate datetime,
		@AgeGroup int,   -- Child=1, '18-20'=2, 'Adult'=3, All=-1
		@DiagnosisGroup int,
		@BenefitPlan int,
		@UserLogin VARCHAR(MAX)
		
SET @EffectiveStartDate = '1/1/13'
SET @EffectiveEndDate = '1/31/13'
SET @AgeGroup = -1
SET @DiagnosisGroup = -300
SET @BenefitPlan = -200
SET @UserLogin = 'Brian.Angelo'
--*/

DECLARE @filenm  AS VARCHAR(2000),
        @FilePath AS VARCHAR(75),
        @UserPath AS VARCHAR(75),
        @ProcName AS VARCHAR(100) = OBJECT_NAME(@@ProcID),
        @raiseErrorMsg VARCHAR(255)
        
IF @UserLogin is null
   BEGIN
      SET @raiseErrorMsg = 'User Login cannot be null. Aborting procedure.'
      RAISERROR (@raiseErrorMsg, 16, 1)
      RETURN
   END
IF NOT EXISTS ( SELECT  1
                FROM    BIW.DW.dimEmployee
                WHERE   AccountName like '%' + @UserLogin )
   BEGIN
      SET @raiseErrorMsg = 'User Login of ' +  @UserLogin + ' is not a valid user. Aborting procedure.'
      RAISERROR (@raiseErrorMsg, 16, 1)
      RETURN
   END
   
SELECT  @FilePath = EmployeeBulkReportPath
FROM    dw.dimEmployee
WHERE   AccountName like '%' + @UserLogin
      
SET @filenm = @FilePath + '\' + 'authorization_data_dump' + 
              CONVERT(VARCHAR(8),GETDATE(), 112) +
              REPLACE(CONVERT(VARCHAR(20),GETDATE(), 114), ':', '') +
              '.csv' 

IF OBJECT_ID('tempdb..#tempContractRates') IS NOT NULL
		DROP TABLE #tempContractRates

--Get contract rates and average together
SELECT 
dp.ProviderNK
,ds.ServicesNK
,AVg(fPCR.ContractRate) as ContractRate
INTO #tempContractRates
FROM [BIW].[DW].[factProviderContractRates] fPCR WITH(NOLOCK) 
INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON fPCR.ProviderSK = dp.ProviderSK
INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON fPCR.ServicesSK = ds.ServicesSK
INNER JOIN [BIW].[DW].[dimDate] ddEffFrom WITH(NOLOCK) ON ddEffFrom.DateSK = fPCR.ContractRateEffectiveDateSK
INNER JOIN [BIW].[DW].[dimDate] ddEffTo WITH(NOLOCK) ON ddEffTo.DateSK = fpCR.ContractRateExpirationDateSK
WHERE 1=1
AND ddEffFrom.DateValue <= DATEADD(day, 1, @EffectiveEndDate)
AND ddEffTo.DateValue >= @EffectiveStartDate
GROUP BY
dp.ProviderNK
,ds.ServicesNK


CREATE CLUSTERED INDEX rates ON #tempContractRates(ProviderNK, ServicesNK);

IF OBJECT_ID('tempdb..#tempResults') IS NOT NULL
		DROP TABLE #tempResults

--Get all valid results based on parameters
SELECT 
fa.AuthorizationMasterID as AuthID
,fa.AuthorizationNumber as AuthNumber
,dc.ConsumerNK as ConsumerID
,dc.FirstName as ConsumerFirst
,dc.LastName as ConsumerLast
,dc.DOB as ConsumerDOB
,dc.Gender as ConsumerGender
,do.County as County
,dc.Ethnicity as Ethnicity
,dpMP.ProviderNK as MasterProviderID 
,dpMP.ProviderName as ProviderName
,dp.ProviderNK as ProviderID
,dp.ProviderName as SiteName
,dd.DiagnosisGroup as DiagGroupDesc
,dd.DiagnosisCode as DiagCode
,fa.SpecialDiagnosisGroup as SpecDiagGrp  
,dsrASAM.ResultDescription as ASAM
,dsrCALOCUS.ResultDescription as CALOCUS
,dsrLOCUS.ResultDescription as LOCUS
,dbp.BenefitPlanShort as BenefitPlanDesc
,ddEffFrom.DateValue as EffectiveDate
,ddEffTo.DateValue as EndDate
,fa.AuthorizedUnits as Units
,fa.AuthorizedDailyMaxUnits as DailyMax
,fa.AuthorizedWeeklyMaxUnits as WeeklyMax
,fa.AuthorizedMonthlyMaxUnits as MonthlyMax
,fa.AuthorizedYearlyMaxUnits as YearlyMax
,ds.ServiceDefinition as ServiceDefinitionDesc
,ds.ServiceCode as ServiceCode
,ds.Modifier1 as ModID1
,ds.Modifier2 as ModID2
,dp.ProviderNK
,ds.ServicesNK
INTO #tempResults
FROM [BIW].[DW].[factAuthorizations] fa WITH(NOLOCK)
INNER JOIN [BIW].[DW].[dimDate] ddEffFrom WITH(NOLOCK) ON ddEffFrom.DateSK = fa.EffectiveFromDateSK
INNER JOIN [BIW].[DW].[dimDate] ddEffTo WITH(NOLOCK) ON ddEffTo.DateSK = fa.EffectiveToDateSK
INNER JOIN [BIW].[DW].[dimConsumers] dc WITH(NOLOCK) ON dc.ConsumerSK = fa.ConsumerSK
INNER JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.OrganizationSK = fa.OrganizationSK
INNER JOIN [BIW].[DW].[dimProvider] dp WITH(NOLOCK) ON dp.ProviderSK = fa.ProviderSK
INNER JOIN [BIW].[DW].[dimProvider] dpMP WITH(NOLOCK) ON dpMP.ProviderSK = fa.MasterProviderSK
INNER JOIN [BIW].[DW].[dimDiagnosis] dd WITH(NOLOCK) ON dd.DiagnosisSK = fa.DiagnosisSK
INNER JOIN [BIW].[DW].[dimServices] ds WITH(NOLOCK) ON ds.ServicesSK = fa.ServicesSK
INNER JOIN [BIW].[DW].[dimBenefitPlan] dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fa.BenefitPlanSK
INNER JOIN [BIW].[DW].[factTreatmentAuthorizationRequest] fTAR WITH(NOLOCK) ON fTAR.TARID = fa.ReferenceNumber
INNER JOIN [BIW].[DW].[dimScoreResults] dsrASAM WITH(NOLOCK) ON dsrASAM.ScoreResultsSK = fTAR.ASAMResultSK
INNER JOIN [BIW].[DW].[dimScoreResults] dsrCALOCUS WITH(NOLOCK) ON dsrCALOCUS.ScoreResultsSK = fTAR.CalocusResultSK
INNER JOIN [BIW].[DW].[dimScoreResults] dsrLOCUS WITH(NOLOCK) ON dsrLOCUS.ScoreResultsSK = fTAR.LocusResultSK
WHERE 1=1
AND ddEffFrom.DateValue <= DATEADD(day, 1, @EffectiveEndDate)
AND ddEffTo.DateValue >= @EffectiveStartDate
AND (( @BenefitPlan = dbp.BenefitPlanSK ) OR -- 1 specific Plan
	( @BenefitPlan = -100 AND dbp.InsurerID = 2 ) OR -- ALL Medicaid
	( @BenefitPlan = -200 ) ) -- ALL PLANS 
AND (dd.DiagnosisGroupID = @DiagnosisGroup OR @DiagnosisGroup = -300)
AND (CASE	WHEN DATEDIFF(year, dc.DOB, ddEffFrom.DateValue) < 18 THEN 1
			WHEN DATEDIFF(year, dc.DOB, ddEffFrom.DateValue) BETWEEN 18 AND 20 THEN 2
			WHEN DATEDIFF(year, dc.DOB, ddEffFrom.DateValue) > 20 THEN 3
			END = @AgeGroup 
			OR @AgeGroup = -1)


CREATE CLUSTERED INDEX results ON #tempResults(ProviderNK, ServicesNK);

IF OBJECT_ID('tempdb..#tempFinal') IS NOT NULL
		DROP TABLE #tempFinal

--Join rates to valid records based on Service and Provider
SELECT 
AuthID
,tr.AuthNumber
,tr.ConsumerID
,tr.ConsumerFirst
,tr.ConsumerLast
,tr.ConsumerDOB
,tr.ConsumerGender
,tr.County
,tr.Ethnicity
,tr.MasterProviderID 
,tr.ProviderName
,tr.ProviderID
,tr.SiteName
,tr.DiagGroupDesc
,tr.DiagCode
,tr.SpecDiagGrp  
,tr.ASAM
,tr.CALOCUS
,tr.LOCUS
,tr.BenefitPlanDesc
,tr.EffectiveDate
,tr.EndDate
,tr.Units
,tr.DailyMax
,tr.WeeklyMax
,tr.MonthlyMax
,tr.YearlyMax
,tr.ServiceDefinitionDesc
,tr.ServiceCode
,tr.ModID1
,tr.ModID2
,tcr.ContractRate
,tcr.ContractRate * tr.Units as AuthorizedAmount
INTO #tempFinal
FROM #tempResults tr
LEFT JOIN #tempContractRates tcr ON tcr.ProviderNK = tr.ProviderNK AND tcr.ServicesNK = tr.ServicesNK

--Drop tables since they're no longer needed
DROP TABLE #tempContractRates
DROP TABLE #tempResults

IF @UserLogin IS NOT NULL
       BEGIN
           DELETE FROM ODS.DataExports WHERE StoredProcedure = @ProcName;
           INSERT INTO ODS.DataExports ( StoredProcedure, DataValues )
                  SELECT @ProcName,
						'AuthID' + ',' +
						'AuthNumber' + ',' +
						'ConsumerID' + ',' +
						'ConsumerFirst' + ',' +
						'ConsumerLast' + ',' +
						'ConsumerDOB' + ',' +
						'ConsumerGender' + ',' +
						'County' + ',' +
						'Ethnicity' + ',' +
						'MasterProviderID ' + ',' +
						'ProviderName' + ',' +
						'ProviderID' + ',' +
						'SiteName' + ',' +
						'DiagGroupDesc' + ',' +
						'DiagCode' + ',' +
						'SpecDiagGrp  ' + ',' +
						'ASAM' + ',' +
						'CALOCUS' + ',' +
						'LOCUS' + ',' +
						'BenefitPlanDesc' + ',' +
						'EffectiveDate' + ',' +
						'EndDate' + ',' +
						'Units' + ',' +
						'DailyMax' + ',' +
						'WeeklyMax' + ',' +
						'MonthlyMax' + ',' +
						'YearlyMax' + ',' +
						'ServiceDefinitionDesc' + ',' +
						'ServiceCode' + ',' +
						'ModID1' + ',' +
						'ModID2' + ',' +
						'ContractRate' + ',' +
						'AuthorizedAmount'
						AS txt
			      UNION ALL
                  SELECT DISTINCT
                        @ProcName,
                        '"' + CAST(AuthID as varchar(20)) + '"' + ',' +
						'"' + CAST(AuthNumber as varchar(20)) + '"' + ',' +
						'"' + CAST(ConsumerID as varchar(20)) + '"' + ',' +
						'"' + ISNULL(ConsumerFirst,'') + '"' + ',' +
						'"' + ISNULL(ConsumerLast,'') + '"' + ',' +
						'"' + CAST(ConsumerDOB as varchar(20)) + '"' + ',' +
						'"' + ISNULL(ConsumerGender,'') + '"' + ',' +
						'"' + ISNULL(County,'') + '"' + ',' +
						'"' + ISNULL(Ethnicity,'') + '"' + ',' +
						'"' + CAST(MasterProviderID as varchar(20)) + '"' + ',' +
						'"' + ISNULL(ProviderName,'') + '"' + ',' +
						'"' + CAST(ProviderID as varchar(20)) + '"' + ',' +
						'"' + ISNULL(SiteName,'') + '"' + ',' +
						'"' + ISNULL(DiagGroupDesc,'') + '"' + ',' +
						'"' + ISNULL(DiagCode,'') + '"' + ',' +
						'"' + ISNULL(SpecDiagGrp,'') + '"' + ',' +
						'"' + ISNULL(ASAM,'') + '"' + ',' +
						'"' + CAST(CALOCUS as varchar(20)) + '"' + ',' +
						'"' + CAST(LOCUS as varchar(20)) + '"' + ',' +
						'"' + ISNULL(BenefitPlanDesc,'') + '"' + ',' +
						'"' + CAST(EffectiveDate as varchar(20)) + '"' + ',' +
						'"' + CAST(EndDate as varchar(20)) + '"' + ',' +
						'"' + CAST(Units as varchar(20)) + '"' + ',' +
						'"' + CAST(DailyMax as varchar(20)) + '"' + ',' +
						'"' + CAST(WeeklyMax as varchar(20)) + '"' + ',' +
						'"' + CAST(MonthlyMax as varchar(20)) + '"' + ',' +
						'"' + CAST(YearlyMax as varchar(20)) + '"' + ',' +
						'"' + ISNULL(ServiceDefinitionDesc,'') + '"' + ',' +
						'"' + ISNULL(ServiceCode,'') + '"' + ',' +
						'"' + ISNULL(ModID1,'') + '"' + ',' +
						'"' + ISNULL(ModID2,'') + '"' + ',' +
						'"' + CAST(ContractRate as varchar(20)) + '"' + ',' +
						'"' + CAST(AuthorizedAmount as varchar(20)) + '"' 
                 FROM    #tempFinal
				 OPTION (MAXDOP 1)
				 		
				 DECLARE @cmd VARCHAR(1000) ,
                         @rc INT = 0                    
                         
                 SET @cmd = 'bcp.exe "SELECT DataValues FROM BIW.ODS.DataExports WITH (NOLOCK)' + 
                            ' WHERE StoredProcedure = ' + '''' + @ProcName + '''' + ' ORDER BY RowID" QUERYOUT "c:\Temp\'
                            + RTRIM(@@SERVICENAME) + '\output.csv" -q -c -t "," -S "'
                            + RTRIM(@@SERVERNAME) + '" -T'
                                                       				                            
                 EXECUTE master..xp_cmdshell @cmd, NO_OUTPUT
                     
                 IF @@error <> 0
                      OR @rc <> 0 
                    BEGIN
                      RAISERROR('xp_cmdshell bcp failed !!!',16,1)
                      RETURN
                    END
                 SET @cmd = 'move c:\Temp\' + RTRIM(@@SERVICENAME) + '\output.csv "'
                           + RTRIM(@filenm) + '"'
                 EXECUTE master..xp_cmdshell @cmd, no_output
                 
                 IF @@error <> 0
                      OR @rc <> 0 
                 BEGIN
                    RAISERROR('xp_cmdshell move failed !!!',16,1)
                    RETURN
                 END    
                 
                     SELECT  
                             'EXPORT' AS [Data],
                             @filenm AS [FileLocation]
                            
       END
       
END








GO


