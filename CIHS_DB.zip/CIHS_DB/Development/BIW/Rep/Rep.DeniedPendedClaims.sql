USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[DeniedPendedClaims]    Script Date: 06/18/2013 14:54:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[DeniedPendedClaims] 
(
	@adj_str_date DATETIME,
	@adj_end_date DATETIME,
	@CountyCatchmentID NVARCHAR(MAX),
	@fund_plan INT--,
	--@rpt_type
)
	WITH RECOMPILE
AS --rep.DeniedPendedClaims '10/1/2012', '12/31/2012', '1021', '2'

/*------------------------------------------------------------------------------
	Title:		Denied/Pended Claims	
	File:	    [Rep].[DeniedPendedClaims] 
	Author:		Karissa Martindale
	Date:		3/1/2013
	Desc:		Identifies denied and pended claim information based upon provider or reason.						
                                        
	Called By:
                        Reports:          rpt_active_used_reason_codes.rdl
                        Stored Procs:     [Rep].[DeniedPendedClaims] 
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		3/1/2013		Karissa Martindale    	6363    		Created

--	-----------------------------------------------------------------------------------*/
--DECLARE 
--	@adj_str_date DATETIME = '6/1/13',
--	@adj_end_date DATETIME = '6/30/13',
--	@CountyCatchmentID NVARCHAR(MAX) = '-300',
--	@fund_plan INT = -1--,

	SELECT DISTINCT 
		CASE
			WHEN 
				fClaim.StatusSK = 1
			THEN 'Approved'
			WHEN 
				fClaim.StatusSK = 2
				AND fClaim.ReasonCodeSK NOT IN (Select ReasonCodeSK from BIW.DW.dimReasonCodes WHERE CategoryID = 4 OR ReasonCodeNK IN (795,720, 1167, 1168, 1169))
			THEN 'Denied'
			WHEN 
				fClaim.StatusSK = 2
				AND fClaim.ReasonCodeSK IN (Select ReasonCodeSK from BIW.DW.dimReasonCodes WHERE CategoryID = 4 OR ReasonCodeNK IN (795,720, 1167, 1168, 1169))
			THEN 'Excluded Denied'
			WHEN 
				fClaim.StatusSK = 3
			THEN 'Pending'
			ELSE ''
		END AS [type], 
		dimReasCode.CategoryID, 
		CASE fClaim.StatusSK
		WHEN 3 THEN fClaim.AdjustedAmount
		ELSE 0.00
		END as pendedAmount,
		CASE fClaim.StatusSK
		WHEN 2 THEN fClaim.AdjustedAmount
		ELSE 0.00
		END as adjustedAmount,
		fClaim.StatusSK,
		dimReasCode.ReasonCodeNK,
		dimProv.ProviderNK,
		dimProv.ProviderName,
		dimOrg.Catchment,
		dimReasCode.[Description],
		dimOrg.County,
		fClaim.ClaimNumber,
		dimCon.ConsumerNK,
		dimCon.FullName,
		fClaim.DateOfServiceSK,
		dimServ.ServicesNK,
		dimServ.ServiceCode,
		COUNT(fClaim.factClaimsSK) as numClaimLines,
		SUM(fClaim.ClaimAmount) as claimedAmount,
		fClaim.factClaimsSK,
		fClaim.ServicesSK,
		0 as totalPend,
		0 as totalAdj,
		0 as totalCount,
		0 as totalSum,
		0 as totalCountD,
		0 as totalSumD
	INTO #temp1
	FROM
		BIW.DW.factClaims fClaim WITH(NOLOCK)
		INNER JOIN BIW.DW.dimOrganization dimOrg WITH(NOLOCK) ON fClaim.OrganizationSK = dimOrg.OrganizationSK
		INNER JOIN BIW.DW.dimProvider dimProv WITH(NOLOCK) ON fClaim.ProviderSK = dimProv.ProviderSK
		INNER JOIN BIW.DW.dimReasonCodes dimReasCode WITH(NOLOCK) ON fClaim.ReasonCodeSK = dimReasCode.ReasonCodeSK
		INNER JOIN BIW.DW.dimConsumers dimCon WITH(NOLOCK) ON fClaim.ConsumerSK = dimCon.ConsumerSK
		INNER JOIN BIW.DW.dimServices dimServ WITH(NOLOCK) ON fClaim.ServicesSK = dimServ.ServicesSK
		INNER JOIN BIW.DW.dimDate dimD WITH(NOLOCK) ON fClaim.AdjudicationDateSK = dimD.DateSK
		INNER JOIN BIW.DW.dimBenefitPlan dimBenPlan WITH(NOLOCK) ON fClaim.BenefitPlanSK = dimBenPlan.BenefitPlanSK
	WHERE
		fClaim.Deleted = 0
		AND ((fClaim.StatusSK = 1 AND fClaim.ReasonCodeSK IN (Select ReasonCodeSK from BIW.DW.dimReasonCodes WHERE CategoryID = 4 OR ReasonCodeNK IN (795,720, 1167, 1168, 1169)))
			 OR 
			 (fClaim.StatusSK IN (2,3) AND dimServ.ServicesNK NOT IN (select AttributeID from dw.dimCustomReportGroups where CustomGroupName = 'DeniedPendedClaimsServiceCodes'))
			 OR fClaim.StatusSK = 3)
		AND dimD.DateValue BETWEEN @adj_str_date AND @adj_end_date
		AND (@fund_plan = -1 OR dimBenPlan.InsurerID = @fund_plan)
	    AND
	    (
		  @CountyCatchmentID = '-300' --All Catchments
		  OR CONVERT(nvarchar, dimOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID, ',') ) --Specific Catchment
		  OR CONVERT(nvarchar, dimOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CountyCatchmentID, ',') ) --Specific County
	    )
	Group by dimReasCode.ReasonCodeNK, fClaim.ReasonCodeSK, dimReasCode.[Description], fClaim.ClaimNumber, dimCon.ConsumerNK, dimCon.FullName,
	fClaim.StatusSK, 
	dimProv.ProviderNK, dimProv.ProviderName, fClaim.DateOfServiceSK, dimServ.ServiceCode,
	dimOrg.Catchment, dimOrg.County, 
	fClaim.AdjustedAmount,
	fClaim.factClaimsSK, fClaim.ServicesSK,
	dimReasCode.CategoryID, dimServ.ServicesNK
    
    SELECT  StatusSK,
			CASE StatusSK
			WHEN 3 THEN SUM(AdjustedAmount) 
			ELSE 0.00
			END as totalPended,
			CASE StatusSK
			WHEN 2 THEN SUM(AdjustedAmount)
			ELSE 0.00
			END as totalAdjusted
    INTO #totalTemp
    FROM    #temp1
    GROUP BY StatusSK
    
    SELECT COUNT(factClaimsSK) as totalCD,
		   ISNULL(SUM(claimedAmount),0) as totalSD
    INTO #grandTotalsDen
    FROM #temp1 t
    WHERE StatusSK = 1 OR StatusSK = 2 AND t.ServicesSK NOT IN (select AttributeID from dw.dimCustomReportGroups where CustomGroupName = 'DeniedPendedClaimsServiceCodes')
    
    SELECT COUNT(factClaimsSK) as totalCN,
		   ISNULL(SUM(claimedAmount),0) as totalSN
    INTO #grandTotalsNum
    FROM #temp1 t
    WHERE StatusSK = 2 AND t.ServicesSK NOT IN (select AttributeID from dw.dimCustomReportGroups where CustomGroupName = 'DeniedPendedClaimsServiceCodes')
    
    Update #temp1
    SET totalPend = totalPended,
		totalAdj = totalAdjusted,
		totalCount = totalCN,
		totalSum = totalSN,
		totalCountD = totalCD,
		totalSumD = totalSD
	FROM #grandTotalsDen grandD,
		 #grandTotalsNum grandN,
		 #temp1 base 
		 INNER JOIN #totalTemp tot ON base.StatusSK= tot.StatusSK
		 
	Select * from #temp1
	Order by ConsumerNK
    
    DROP TABLE #totalTemp    
    DROP TABLE #temp1
    DROP TABLE #grandTotalsDen
    DROP TABLE #grandTotalsNum
