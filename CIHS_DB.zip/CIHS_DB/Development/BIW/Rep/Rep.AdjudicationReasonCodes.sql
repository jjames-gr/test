USE [BIW]
GO

/****** Object:  StoredProcedure [Rep].[AdjudicationReasonCodes]    Script Date: 07/11/2013 13:45:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [Rep].[AdjudicationReasonCodes] 
@Active bit
AS


--DECLARE @Active int
--SET @Active =0
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	

/*------------------------------------------------------------------------------
	Title:		Adjudication Reason Codes
	File:	    [Rep].[AdjudicationReasonCodes] 
	Author:		Divya Lakshmi
	Date:		7/1/2013
	Desc:		This report displays Actively used Claim Adjudication Reason Codes		
                                        
	Called By:
                        Reports:          rpt_active_used_reason_codes.rdl
                        Stored Procs:     [Rep].[AdjudicationReasonCodes] 
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		7/1/2013		Divya Lakshmi    		6271    			Created

	-----------------------------------------------------------------------------------*/							
		
	IF @Active = 0 
        BEGIN									
	SELECT DISTINCT RC.REASONCODENK									
	,rc.ReasonCodeSK									
	,RC.CODE									
	,RC.DESCRIPTION									
	FROM DW.dimReasonCodes RC INNER JOIN DW.factClaimsHistorical FCH ON RC.ReasonCodeSK = FCH.ReasonCodeSK
	WHERE RC.Active=0										
	UNION									
	SELECT DISTINCT RC.REASONCODENK									
	,rc.ReasonCodeSK									
	,RC.CODE									
	,RC.DESCRIPTION									
	FROM DW.dimReasonCodes RC INNER JOIN DW.factClaims FC ON RC.ReasonCodeSK = FC.ReasonCodeSK
	WHERE RC.Active=0										
	ORDER BY RC.ReasonCodeNK	
								
	END									
		
	IF @Active = 1
        BEGIN								
	SELECT DISTINCT RC.REASONCODENK									
	,rc.ReasonCodeSK									
	,RC.CODE									
	,RC.DESCRIPTION									
	FROM DW.dimReasonCodes RC									
	WHERE RC.Active = 1									
END


END


GO


