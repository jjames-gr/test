USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[ConsumerTags]    Script Date: 08/28/2013 08:36:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [REP].[ConsumerTags]
	@Tag int,
	@StartDate datetime,
	@EndDate datetime,
	@Catchment varchar(50)
AS
/*------------------------------------------------------------------------------
-- Title:	Consumer Tags
-- File:	[Rep].[ConsumerTags]
-- Author:	Brian Angelo
-- Date:	08/13/2013
-- Desc:	Consumer Tags stored proc
--			
-- CalledBy:
-- 		Reports: "Consumer Tags"
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	08/13/2013  	Brian Angelo	6324	initial creation
--------------------------------------------------------------------------------*/
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
    /*
	/*** Test Parameters ***/
	DECLARE @Tag int,
			@StartDate datetime,
			@EndDate datetime,
			@Catchment varchar(50)
			
	SET @Tag = -1
	SET @StartDate = '6/1/13'
	SET @EndDate = '6/30/13'
	SET @Catchment = '1021,1022,1023,1024'
	--*/

	
	IF OBJECT_ID('tempdb..#tempResults') IS NOT NULL
		DROP TABLE #tempResults

	;WITH cteResults as (
		SELECT DISTINCT
		dj.JunkValue as TagName
		,dcTag.ConsumerNK as ConsumerID
		,dcTag.FirstName + ' ' + dcTag.LastName as ConsumerName
		,IsNull(dctag.AddressLine1,'') + ' ' + IsNull(dcTag.AddressLine2,'') + ' ' + IsNull(dcTag.City,'') + ' ' + IsNull(dcTag.[State],'') + ' ' + IsNull(dcTag.PostalCode,'') as ConsumerAddress
		,dcTag.DOB as DOB
		,dcTag.AgeValue as Age
		,dcTag.County as County
		,Min(ddEff.DateValue) as TagEffectiveDate
		,Max(ddExp.DateValue) as TagEndDate
		,dcTag.ClinicalHomeProviderName as ClinicalHome
		FROM [BIW].[DW].[factConsumerTags] fct WITH(NOLOCK) 
		INNER JOIN [BIW].[DW].[dimJunk] dj WITH(NOLOCK) ON dj.JunkSK = fct.ConsumerTagSK AND JunkEntity = 'ConsumerTags'
		INNER JOIN [BIW].[DW].[dimDate] ddEff WITH(NOLOCK) ON ddEff.DateSK = fct.ConsumerTagEffectiveDateSK
		INNER JOIN [BIW].[DW].[dimDate] ddExp WITH(NOLOCK) ON ddExp.DateSK = fct.ConsumerTagExpirationDateSK
		INNER JOIN [BIW].[DW].[dimConsumers] dcTag WITH(NOLOCK) ON dcTag.ConsumerSK = fct.ConsumerSK
		LEFT JOIN [BIW].[DW].[dimOrganization] do WITH(NOLOCK) ON do.County = dcTag.County
		INNER JOIN [BIW].[DW].[dimConsumers] dcDiag WITH(NOLOCK) ON dcTag.ConsumerNK = dcDiag.ConsumerNK
		LEFT JOIN [BIW].[DW].[factConsumerDiagnosis] fcd WITH(NOLOCK) ON fcd.ConsumerSK = dcDiag.ConsumerSK
		WHERE 1=1
		AND IsNull(fcd.EmployeeSK,-1) != 0
		AND IsNull(fcd.DiagnosisExpirationDateSK, 29991231) = 29991231
		AND fct.ConsumerTagActiveFlag = 1
		AND ddEff.DateValue <= @EndDate
		AND ddExp.DateValue >= @StartDate
		AND (CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') ))
		AND (dj.JunkNK = @Tag OR @Tag = -1)
		GROUP BY 
		dj.JunkValue
		,dcTag.ConsumerNK
		,dcTag.FirstName + ' ' + dcTag.LastName
		,IsNull(dctag.AddressLine1,'') + ' ' + IsNull(dcTag.AddressLine2,'') + ' ' + IsNull(dcTag.City,'') + ' ' + IsNull(dcTag.[State],'') + ' ' + IsNull(dcTag.PostalCode,'') 
		,dcTag.DOB
		,dcTag.AgeValue
		,dcTag.County
		,dcTag.ClinicalHomeProviderName
	) --END cte
	
	SELECT *
	,ROW_NUMBER() OVER (PARTITION BY ConsumerID ORDER BY TagName) as rn
	INTO #tempResults
	FROM cteResults
	
	
    
    SELECT 
    tr.TagName
	,tr.ConsumerID
	,tr.ConsumerName
	,tr.ConsumerAddress
	,tr.DOB
	,tr.Age
	,tr.County
	,tr.TagEffectiveDate
	,tr.TagEndDate
	,tr.ClinicalHome
	,ISNULL((SELECT DISTINCT TagName + ', ' FROM #tempResults AS t 
			WHERE t.ConsumerID = tr.ConsumerID 
			AND t.rn > 1 
			AND t.TagName != tr.TagName
			FOR XML PATH('') ),'  ')  AS OtherTags 
    FROM #tempResults tr
    WHERE tr.rn = 1
    ORDER BY tr.ConsumerID
    
    DROP TABLE #tempResults
    
    
END






GO


