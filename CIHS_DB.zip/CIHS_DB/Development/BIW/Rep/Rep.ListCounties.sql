USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListCounties] AS

/*------------------------------------------------------------------------------
	Title:		List Counties
	File:		rep.ListCounties
	Author:		Doug Cox
	Date:		07/15/2013
	Desc:		This listing of Counties can be used to fill the available values for County Parameters
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/15/2013		Doug Cox     			Many			Created
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		

	-----------------------------------------------------------------------------------*/

-- Get counties for drop down
SELECT
	do.OrganizationNK AS ccID,
	do.County AS ccName
FROM dw.dimOrganization as do with(nolock)