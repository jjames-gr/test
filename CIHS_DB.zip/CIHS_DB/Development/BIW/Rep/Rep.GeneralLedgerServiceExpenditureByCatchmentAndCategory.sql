USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[GeneralLedgerServiceExpenditureByCatchmentAndCategory]    Script Date: 09/18/2013 13:08:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








CREATE PROCEDURE [REP].[GeneralLedgerServiceExpenditureByCatchmentAndCategory]
	@str_dt datetime, 
	@end_dt datetime
AS

/*------------------------------------------------------------------------------
	Title:		General Ledger Service Expenditures by Catchment and Category
	File:		[Rep].[GeneralLedgerServiceExpenditureByCatchmentAndCategory]
	Author:		Karen Roslund
	Date:		05/24/2013
	Desc:		To report service expenditures by category for each catchment area.
                                        
	Called By:
                        Reports:          Fin GeneralLedgerServiceExpenditureByCatchmentAndCategory
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/24/2013		Karen Roslund    		6395			Created
			1.1		09/18/2013		Brian Angelo			6395			Changed SQL to pull details and do summary in RDL
	-----------------------------------------------------------------------------------*/

--declare @str_dt datetime, @end_dt datetime
--set @str_dt = '6/1/2013'
--set @end_dt = '6/30/2013'



SELECT
fch.ClaimNumber,
fch.ClaimDetailNumber,
fch.ClaimAdjudicationNumber,
dateofserv.[DateName_en-US] date_of_service,
adjud.[DateName_en-US] adjudication_date, 
serv.ServiceCode,
IsNull(serv.Modifier1, ''),
p.ProviderName,
org.Catchment,
serv.ServiceSummary,
diag.DiagnosisGroup, 
bp.BenefitPlanShort,
mac.CategoryName as MedicaidCategoryName,
gl.GLAccount as GLAccount,
fac.ApprovedClaimAmount   
FROM [BIW].[DW].[factApprovedClaims] fac WITH(NOLOCK)
INNER JOIN [BIW].[DW].[factClaimsHistorical] fch WITH(NOLOCK) on fac.factClaimsHistoricalSK = fch.factClaimsHistoricalSK 
INNER JOIN [BIW].[DW].[dimDate] dateofserv WITH(NOLOCK) on fch.DateOfServiceSK = dateofserv.DateSK 
INNER JOIN [BIW].[DW].[dimDate] adjud WITH(NOLOCK) on fch.AdjudicationDateSK  = adjud .DateSK 
INNER JOIN [BIW].[DW].[dimProvider] p WITH(NOLOCK) on fch.ProviderSK = p.ProviderSK 
INNER JOIN [BIW].[DW].[dimOrganization] org WITH(NOLOCK) on fac.OrganizationSK = org.OrganizationSK 
INNER JOIN [BIW].[DW].[dimServices] serv WITH(NOLOCK) on fac.ServicesSK = serv.ServicesSK 
INNER JOIN [BIW].[DW].[dimDiagnosis] diag WITH(NOLOCK) on fac.Diagnosis1SK = diag.DiagnosisSK
INNER JOIN [BIW].[DW].[dimBenefitPlan] bp WITH(NOLOCK) on fac.BenefitPlanSK = bp.BenefitPlanSK  
INNER JOIN [BIW].[DW].[dimDate] d WITH(NOLOCK) on fac.ApprovedTransactionDateSK = d.DateSK 
INNER JOIN [BIW].[DW].[dimMedicaidAidCategory] mac WITH(NOLOCK) ON mac.MedicaidAidCategorySK = fch.MedicaidAidCategorySK
INNER JOIN [BIW].[DW].[dimGLAccount] gl WITH(NOLOCK) ON fac.GLAccountSK = gl.GLAccountSK
WHERE 1=1
AND d.DateValue between @str_dt and @end_dt 






GO


