USE [BIW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[UtilizationRateBySpecialtyDiagGroupAndServiceCat] 
	( 
		@StartDate DATE, 
		@EndDate DATE,
		@Insurer INT,
		@AgeGroup VARCHAR(20),
		@CatchmentCounty VARCHAR(MAX)
	) AS

/*------------------------------------------------------------------------------
	Title:		UtilizationRateBySpecialtyDiagGroupAndServiceCat
	File:		[Rep].[UtilizationRateBySpecialtyDiagGroupAndServiceCat]
	Author:		Doug Cox
	Date:		07/29/13
	Desc:		Consumer Special Diagnostic Grouping with Service Category

	Called By:
                        Reports:          CLM023 - Utilization Rate by Specialty Diagnostic Grouping and Service Category
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		07/29/2013		Doug Cox				6548			Created
	
-----------------------------------------------------------------------------------*/

--	DECLARE
--		@StartDate DATE = '1/1/13', 
--		@EndDate DATE = '1/31/13',
--		@Insurer INT = -2,
--		@AgeGroup VARCHAR(20) = '<ALL>',
--		@CatchmentCounty VARCHAR(MAX) = '-300'

	SELECT	DISTINCT
			dServices.ServiceSummary,
			CASE WHEN ISNULL(fClaims.SpecialDiagnosisGroup,'Non-Targeted') = 'Non-Targeted' THEN '2' ELSE '1' END AS SpecDiagGroupType,
			ISNULL(fClaims.SpecialDiagnosisGroup,'Non-Targeted') AS SpecialDiagnosisGroup,
			SUM(fAuths.AuthorizedUnits) AS A,
			SUM(fAuths.UsedUnits) AS AC,
			CASE WHEN SUM(fAuths.AuthorizedUnits) > 0 THEN CONVERT( FLOAT,SUM(fAuths.UsedUnits)) / SUM(fAuths.AuthorizedUnits) ELSE 0 END AS AR,
			SUM(fClaims.UnitsClaimed) AS NC,
			CASE WHEN SUM(fAuths.AuthorizedUnits) > 0 THEN ( CONVERT( FLOAT,SUM(fAuths.UsedUnits)) + SUM(fClaims.UnitsClaimed) ) / ( SUM(fAuths.AuthorizedUnits) + SUM(fClaims.UnitsClaimed) ) ELSE 0 END AS TR
	FROM	dw.factClaims AS fClaims with(nolock)
			INNER JOIN dw.factAuthorizations AS fAuths with(nolock) ON fClaims.AuthorizationNumber = fAuths.AuthorizationNumber
			INNER JOIN dw.dimServices AS dServices with(nolock) ON fClaims.ServicesSK = dServices.ServicesSK
			INNER JOIN dw.dimOrganization AS dOrg with(nolock) ON dOrg.OrganizationSK = fClaims.OrganizationSK
			INNER JOIN dw.dimDate AS DOS with(nolock) ON DOS.DateSK = fClaims.DateOfServiceSK
			INNER JOIN dw.dimBenefitPlan AS bp with(nolock) ON bp.BenefitPlanSK = fClaims.BenefitPlanSK
			INNER JOIN dw.dimDiagnosis AS dDiags with(nolock) ON dDiags.DiagnosisSK = fClaims.Diagnosis1SK
			INNER JOIN dw.dimCustomReportGroups AS AgeGroup with(nolock) ON AgeGroup.CustomGroupName = 'UtilizationRateAgeGroup'
										AND fClaims.AgeSK BETWEEN AgeGroup.BeganAttributeCodeRange AND AgeGroup.EndAttributeCodeRange
	WHERE	fClaims.StatusSK = 1
			AND fAuths.AuthorizationNumber > '0'
			AND dos.DateValue BETWEEN @StartDate AND @EndDate
			AND (
				@CatchmentCounty = '-300'
				OR CONVERT(nvarchar, dOrg.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@CatchmentCounty, ',') )
				OR CONVERT(nvarchar, dOrg.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@CatchmentCounty, ',') )
				)
			AND (
				( @Insurer = bp.InsurerID ) OR -- 1 specific Plan
				( @Insurer = -2 ) -- ALL PLANS
				)
			AND ( @AgeGroup = '<ALL>' OR  @AgeGroup = AgeGroup.CustomGroupValue )
	GROUP BY
			dServices.ServiceSummary,
			fClaims.SpecialDiagnosisGroup