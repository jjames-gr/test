USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[DMANetworkProviderContractedServices]    Script Date: 09/04/2013 13:23:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[DMANetworkProviderContractedServices] 
(
	@effDate DATE,
	@expDate DATE,
	@servSum INT,
	@benPlan INT,
	@catchment VARCHAR(MAX),
	@avaStatus INT
)
AS

/*------------------------------------------------------------------------------
	Title:		
	File:		[REP].[DMANetworkProviderContractedServices] 
	Author:		Karissa Martindale
	Date:		8/8/13
	Desc:		
                                        
	Called By:
                        Reports:          
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		8/8/2013		Karissa Martindale   	6373			Created
-----------------------------------------------------------------------------------*/

--DECLARE
--	@effDate DATE = '8/27/13',
--	@expDate DATE = '8/27/13',
--	@servSum INT = 6,
--	@benPlan INT = 2,
--	@catchment VARCHAR(MAX) = '-300',
--	@avaStatus INT = -300

SELECT DISTINCT 
	dOrg.County,
	dServ.ServiceDefinition,
	dServ.ServiceDescription,
	dServ.ServiceSummary,
	masterProv.ProviderName as masterProvName,
	dProv.ProviderName as siteName,
	masterProv.ProviderNK as masterCount,
	dProv.ProviderNK as siteCount,
	dOrg.CatchmentID,
	dOrg.OrganizationNK
FROM
	DW.factProviderContract	fPContract WITH(NOLOCK) 
	INNER JOIN dw.dimProviderContract dPContract WITH(NOLOCK) ON fPContract.ProviderContractSK = dPContract.ProviderContractSK
	INNER JOIN DW.dimServices dServ WITH(NOLOCK) ON fPContract.ServicesSK = dServ.ServicesSK
	INNER JOIN DW.dimProvider dProv WITH(NOLOCK) ON fPContract.ProviderSK = dProv.ProviderSK
	INNER JOIN dw.dimProvider masterProv WITH(NOLOCK) ON dProv.ParentProviderNK = masterProv.ProviderNK
	INNER JOIN dw.dimDate dContractEff WITH(NOLOCK) ON fPContract.ContractEffectiveBeginDateSK = dContractEff.DateSK
	INNER JOIN dw.dimDate dContractExp WITH(NOLOCK) ON fPContract.ContractExpirationBeginDateSK = dContractExp.DateSK
	INNER JOIN dw.dimProvider dProvJoin WITH(NOLOCK) ON dProv.ProviderNK = dProvJoin.ProviderNK 
	INNER JOIN dw.factProviderCatchmentServed fPCatch WITH(NOLOCK) ON fPCatch.ProviderSK = dProvJoin.ProviderSK
	INNER JOIN dw.dimJunk dJunk WITH(NOLOCK) ON fPCatch.CatchmentSK = dJunk.JunkSK
	INNER JOIN dw.dimOrganization dOrg WITH(NOLOCK) ON CAST(dJunk.JunkNK as varchar) = CAST(dOrg.CatchmentID as varchar)
	INNER JOIN dw.dimBenefitPlan dBenPlan WITH(NOLOCK) ON fPContract.InsurerSK = dBenPlan.InsurerID
WHERE
    fPContract.ContractEffectiveBeginDateSK <= convert(int, convert(varchar, @expDate, 112))
    and  fPContract.ContractExpirationBeginDateSK >= convert(int, convert(varchar, @effDate, 112)) 
	
	AND fPContract.DeletedContractFlag = 0
	AND dProv.StatusID = 49
	AND (dPContract.ProviderContractTypeID = @avaStatus OR @avaStatus = -300)
	AND dProv.Active = 1
	AND dServ.Active = 1
	AND
	(
		@catchment = -2
		OR dOrg.CatchmentID = @catchment
	)
	AND (dServ.ServiceSummaryID = @servSum OR @servSum = -2)
	AND
	(
		( @benPlan = dBenPlan.InsurerID ) 
		OR ( @benPlan = -300 AND dBenPlan.InsurerID IN (1,2)) -- State and Medicaid
	)
	AND dProv.ProviderNK <> 24662
order by County, ServiceDefinition