USE [BIW]
GO
/****** Object:  StoredProcedure [Rep].[ListCatchmentCounties]    Script Date: 06/13/2013 12:35:11 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Rep].[ListCatchmentCounties]
AS

/*------------------------------------------------------------------------------
	Title:		List Catchment Counties
	File:		rep.ListCatchmentCounties
	Author:		Doug Cox
	Date:		02/18/2013
	Desc:		This listing of Counties and Catchments can be used to fill the
					available values for County/Catchment Parameters
                                        
	Called By:
                        Reports:          Many
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		02/18/2013		Doug Cox     			7062			Created
			2.0		06/18/2013		Tim Amerson				----			Update logic to match agreed definitions from BIW meeting
	
	Usage directions:
	-- Add the following to your WHERE CLAUSE:
		
		(
	
			@catchment = '-300'
			OR CONVERT(nvarchar, do.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
			OR CONVERT(nvarchar, do.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )

		)

	-----------------------------------------------------------------------------------*/

-- <ALL> option for drop down
SELECT
	'-300' as ccID
	, -300 as ccOrder
	, '<ALL>' as ccName
UNION

-- <ALL Cardinal Innovations> option for drop down
SELECT
	ccID =
		REPLACE
		(
			  (
				SELECT DISTINCT
					 do.CatchmentID AS [data()]
				FROM dw.dimOrganization as do with(nolock)
				WHERE do.CatchmentID > 0
				FOR XML PATH('') 
			  ),
			  ' ', ','
		)
	, -200 as ccOrder
	, '<ALL Cardinal Innovations>' as ccName
UNION

-- Get catchments for drop down
SELECT DISTINCT
	CONVERT(NVARCHAR(MAX), do.CatchmentID) AS ccID,
	do.CatchmentSequence AS ccOrder,
	do.Catchment AS ccName
FROM dw.dimOrganization as do with(nolock)
WHERE do.CatchmentID >= 0
UNION

-- Get counties for drop down
SELECT
	CONVERT(NVARCHAR(MAX), do.OrganizationNK) AS ccID,
	100 AS ccOrder,
	do.County AS ccName
FROM dw.dimOrganization as do with(nolock)
WHERE do.OrganizationNK > 3
UNION

SELECT
	'-1, 2' as ccID
	, 300 as ccOrder
	, 'Unknown County' as ccName
UNION

-- Get Unknown value for drop down
SELECT
	'-1' as ccID
	, 300 as ccOrder
	, 'Unknown Catchment' as ccName
UNION
-- Get Out Of State value for drop down
SELECT
	'3' as ccID
	, 200 as ccOrder
	, 'Out Of State' as ccName

ORDER BY ccOrder, ccName
