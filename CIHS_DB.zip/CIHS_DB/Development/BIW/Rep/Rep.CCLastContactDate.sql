USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[CCLastContactDate]    Script Date: 09/09/2013 10:16:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [REP].[CCLastContactDate] 

	@startDate DATE,
	@endDate DATE, 
	@catchment varchar(max),
	@careDisability int,
	@benPlan varchar(max),
	@coord int
AS

/*------------------------------------------------------------------------------
-- Title:	CC Last Contact Date
-- File:	[Rep].[CCLastContactDate]
-- Author:	Justin Ward
-- Date:	08/29/2013
-- Desc:	Care Coordinators that have not had a contact longer than 8 minutes during the reporting month.
--			
-- CalledBy:
-- 		Reports: CC Last Contact Date
--
-- 		Stored Procs: None
--------------------------------------------------------------------------------
-- Change	History
-- Ver	 	Date		Author  			TixNo	Description
-- ---		----------	---------------		-----	----------------------------
-- 1.0	  	8/29/2013	Justin Ward			8945	initial creation
 
--------------------------------------------------------------------------------*/


BEGIN

--DECLARE
--	@startDate DATE = '8/1/2013',
--	@endDate DATE = '8/31/2013', 
--	@catchment varchar(max) = '1040,1039,1040,1041,1042,1043',
--	@careDisability int = -2,
--	@benPlan varchar(max) = '1,2,3,4,5,6,7,8',
--	@coord int = -2
	

;WITH cteInitial as (

SELECT DISTINCT
	Client.ConsumerNK as ConsumerID,
	Client.FullName as ConsumerName,
	AssignedCareCoord.FullName as EmployeeName, 
	MAX(Catchment.JunkValue) as Catchment,
	MAX(DOS.DateValue) as LastContactDate,
	SUM(ProgNotes.TotalMinutesWithClient) as TotalMinutesWithClient,
	ROW_NUMBER () OVER (Partition by Client.ConsumerNK Order by CareDischargeDate.DateValue DESC) as CurrentCC

FROM 
	DW.factProgressNotes ProgNotes WITH(NOLOCK) 
	INNER JOIN dw.dimEmployee Emp WITH(NOLOCK) on ProgNotes.CaseManagerSK = Emp.EmployeeSK
	INNER JOIN DW.dimConsumers Client WITH(NOLOCK) on Client.ConsumerSK = ProgNotes.ConsumerSK
	INNER JOIN DW.dimDate DOS WITH(NOLOCK) on DOS.DateSK = ProgNotes.DateOfServiceSK
	INNER JOIN DW.dimJunk ProgStat WITH(NOLOCK) on ProgStat.JunkSK = ProgNotes.ProgressStatusSK
	INNER JOIN DW.dimJunk Catchment WITH(NOLOCK) on Catchment.JunkSK = ProgNotes.CatchmentSK
		and Catchment.JunkEntity = 'AreaCatchments'
	--The join below makes sure that only care coords and support facilitators are pulled
	INNER JOIN DW.dimJunk ContType WITH(NOLOCK) on ContType.JunkSK = ProgNotes.CareContactTypeSK
		and ContType.JunkNK in ('1037','1038')
	INNER JOIN DW.dimServices Serv WITH(NOLOCK) on Serv.ServicesSK = ProgNotes.ServicesSK
	INNER JOIN DW.dimBenefitPlan BenPlan WITH(NOLOCK) on BenPlan.BenefitPlanSK = ProgNotes.BenefitPlanSK
	INNER JOIN DW.dimConsumers ConJoin WITH(NOLOCK) ON Client.ConsumerNK = ConJoin.ConsumerNK
	INNER JOIN DW.factCareCoordAdmissions fCareCoord WITH(NOLOCK) ON fCareCoord.ConsumerSK = ConJoin.ConsumerSK
	INNER JOIN DW.dimDate CareDischargeDate WITH(NOLOCK) ON fCareCoord.CareCoordDischargeDateSK = CareDischargeDate.DateSK
	INNER JOIN DW.dimEmployee AssignedCareCoord WITH(NOLOCK) ON fCareCoord.CareCoordinatorSK = AssignedCareCoord.EmployeeSK
	INNER JOIN DW.dimEmployee AssignedSuppFac WITH(NOLOCK) ON fCareCoord.SupportFacilitorSK = AssignedSuppFac.EmployeeSK
	INNER JOIN DW.dimJunk CareDisability WITH(NOLOCK) ON fCareCoord.CareDisabilityGroupSK = CareDisability.JunkSK
	INNER JOIN dbo.cfn_split(@catchment , ',') AS pCatch ON pCatch.element = Catchment.JunkNK
	INNER JOIN dbo.cfn_split(@benPlan , ',') AS pBP ON pBP.element = BenPlan.BenefitPlanNK


WHERE 1=1
	AND Serv.ServicesNK = 1386
	AND ProgStat.JunkValue in ('SUBMITTED', 'APPROVED')
	AND Client.Active = 1
	and Emp.Active = 1
	AND DOS.DateValue between @startDate and @endDate
	AND ( @careDisability = '-2' OR CareDisability.JunkNK = CAST(@careDisability as varchar))
	AND (@coord = -2 OR (@coord = AssignedCareCoord.EmployeeNK OR @coord = AssignedSuppFac.EmployeeNK))

GROUP BY 
	Client.ConsumerNK,
	Client.FullName,
	AssignedCareCoord.FullName,
	CareDischargeDate.DateValue


)

SELECT *
FROM cteInitial cI
WHERE  TotalMinutesWithClient < 8 and CurrentCC = 1
ORDER BY ConsumerName

END 
