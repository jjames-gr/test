USE [BIW]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create procedure [Rep].[DenialsbyCode]
@reason_code nvarchar(max), @str_dt datetime, @end_dt datetime, @prov_id nvarchar(max)
as
/*------------------------------------------------------------------------------
	Title:		Denials by Code
	File:		[DenialsbyCode]
	Author:		Karen Roslund
	Date:		05/30/2013
	Desc:		How to notify providers of all of the denials.  May send letters to the providers.
                                        
	Called By:
                        Reports:          denialsbycode
                        Stored Procs:     None
                       
	-----------------------------------------------------------------------------------
	Version History:
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		05/30/2013		Karen Roslund 			6359			Created

	-----------------------------------------------------------------------------------*/



--declare @reason_code nvarchar(max), @str_dt datetime, @end_dt datetime, @prov_id nvarchar(max)

--set @reason_code = '76,765'
--set @str_dt = '1/1/2012'
--set @end_dt = '1/31/2012'
--set @prov_id = 20253


select 
dreas.Description,
dreas.ReasonCodeNK,
c.ConsumerNK Client_ID,
c.LastName Client_Last_Name,
c.FirstName Client_First_Name,
fc.ClaimNumber,
d.[DateName_en-US] Date_of_Service,
s.ServiceCode,
s.Modifier1,
s.Modifier2,
dp.ProviderNK,
dp.ProviderName, 
dp.npi as NPI_Number, 
dpsfl.sflNPI as SFL_NPI_Number,
dpsfl.SFLProviderAddress  AddressLine1,
dpsfl.SFLProviderCity  City,
dpsfl.SFLProviderState  State,
dpsfl.SFLProviderZip  PostalCode,
fc.ClaimAmount,
fc.AdjustedAmount,
dproc.[DateName_en-US] Processed_Date,
dstatus.JunkValue 
From 
dw.factClaims fc with (nolock)
Inner Join dw.dimConsumers c with (nolock) on fc.ConsumerSK = c.ConsumerSK 
Inner join DW.dimServices s with (nolock) on fc.ServicesSK = s.ServicesSK 
Inner join dw.dimDate d with (nolock) on fc.DateOfServiceSK = d.DateSK 
inner join DW.dimDate dproc with (nolock) on fc.AdjudicationDateSK = dproc.DateSK 
inner join dw.dimProvider dp with (nolock) on fc.ProviderSK = dp.ProviderSK 
Inner join dw.dimSFLProvider dpsfl with (nolock) on fc.SFLProviderSK = dpsfl.sflProviderSK 
Inner Join DW.dimReasonCodes dreas with (nolock) on fc.ReasonCodeSK = dreas.ReasonCodeSK
INNER JOIN dbo.cfn_split(@reason_code,',') fnreason ON fnreason.element = dreas.ReasonCodeNK 
INNER JOIN dbo.cfn_split(@prov_id, ',') fnprov ON fnprov.element = dp.ProviderNK 
Inner Join dw.dimJunk dstatus with (nolock) on fc.StatusSK = dstatus.JunkSK 
Where
 fc.StatusSK in (2,3)
 and d.DateValue between @str_dt and @end_dt 
 
 