USE [BIW]
GO
/****** Object:  StoredProcedure [REP].[ContractedServicesbyProviderandSite]    Script Date: 09/12/2013 10:29:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [REP].[ContractedServicesbyProviderandSite]
		@contractStartDate DateTime,
		@contractEndDate DateTime,
		@catchment varchar (max),
		@county varchar(max), 
		@provider VARCHAR (MAX),
		@insurer varchar (max),
		@services VARCHAR (MAX),
		@availStatus VARCHAR (MAX),
		@clientSpecific INT
   
AS

/*------------------------------------------------------------------------------
	Title:		Contracted Services by Provider and Site				
	File:		[Rep].[ContractedServicesbyProviderandSite]
	Author:		Kevin Hamilton	
	Date:		06/12/2013
	Desc:		Listing of the Services available for a provider with subgroupings by plan, and then site.	
			

                                        
	Called By:
                        Reports:        PVD002-ContractedServicesbyProviderandSite	
			


                       
	-----------------------------------------------------------------------------------
	Version History:()
      
			Ver		Date			Author					TixNo			Description
			---		----------		---------------			-----			-----------
			1.0		06/12/2013		Kevin Hamilton     		6343			Created

--	-----------------------------------------------------------------------------------*/
--DECLARE @contractStartDate DateTime,
--		@contractEndDate DateTime ,
--		@catchment VARCHAR (MAX),
--		@county VARCHAR (MAX), 
--		@provider VARCHAR (MAX),
--		@insurer VARCHAR (MAX),
--		@services VARCHAR (MAX), 
--		@availStatus VARCHAR (MAX), 
--		--@activeStatus VARCHAR(MAX),
--		@clientSpecific INT
		
--SET @contractStartDate = '9/19/2013'
--SET @contractEndDate = '9/19/2013' 
--SET @catchment = '1021,1022,1023,1024'
--SET @county = 'BUNCOMBE'
--SET @provider = '21710'
--SET @insurer = 2
--SET @services = '35'
----SET @availStatus = '1,10'
----SET @activeStatus = '49'
--SET @clientSpecific = 0

select dserv.* 
      into #serv
      FROM BIW.DW.dimServices dServ WITH(NOLOCK)
            INNER JOIN dbo.cfn_split(@services , ',') fn ON fn.element = dServ.ServicesNK
            
            create unique clustered index idx_service on #serv (ServicesSK) 
select *
      into #prov
      from biw.dw.dimProvider dprov
      INNER JOIN dbo.cfn_split(@provider , ',') fnp ON fnp.element = dProv.ProviderNK
      
      create unique clustered index idx_provider on #prov (ProviderSK) 
      

    
SELECT DISTINCT 
	ins.Insurer,
	ins.InsurerID,
	dp2.ProviderNK,
	dp2.ProviderName,
	p.ProviderName  as SiteName,
	p.ProviderNK as SiteID,
	p.AddressLine1 as SiteAddress,
	p.City as SiteCity,
	p.State as SiteState,
	p.PostalCode as SiteZipCode,
	p.County as SiteCounty,
	CatchmentsServed = 
		   REPLACE
			  (
					REPLACE
					(
							(
								SELECT Distinct
									  REPLACE(RTRIM(ISNULL(junk.JunkValue, '')),' ', CHAR(127)) AS [data()]
								FROM
									 dw.factProviderCatchmentServed pcs
									 INNER JOIN dw.dimProvider pp on pcs.ProviderSK = p.ProviderSK
									 INNER JOIN dw.dimJunk junk on pcs.CatchmentSK = junk.JunkSK 
								WHERE
									  p.ProviderNK  = pp.ProviderNK 
								
								FOR XML PATH('') 
							),
							' ', '; '
					),
					CHAR(127), ' '
			  ),
	CASE When p.StatusID = 49 Then 'Active'
	ELSE 'Inactive'
	END as ActiveStatus,
	p.AvailableStatusCode,
	p.AvailableStatusID,
	p.AvailableStatus as AvailabilityStatus,
	s.ServiceDescriptionShort as ContractedService,	
	s.ServicesNK,
	s.ServiceCode,
	s.Modifier1,
	s.Modifier2,
	s.ServiceDescriptionShort,
	s.ServiceDefinition,
	ddfpceff.DateValue as ContractEffectiveDate,
	ddfpcexp.DateValue as ContractExpirationDate,
	pcr.ActiveContractRateFlag,
	pcr.ContractRate, 
	ddcreff.DateValue as ContractRateEffectiveDate,
	ddcreex.DateValue as ContractRateExpirationDate,
	dpc.ProviderContractNK,
	fpc.ClientSpecificFlag
	
	
FROM  
	DW.factProviderContract fpc 
	INNER JOIN DW.dimProviderContract dpc with(nolock) ON dpc.ProviderContractSK = fpc.ProviderContractSK 
	INNER JOIN dw.dimProvider p on p.ProviderSK = fpc.ProviderSK 
	INNER JOIN dw.dimProvider dp2 on p.ParentProviderNK = dp2.ProviderNK 
	INNER JOIN dw.factProviderCatchmentServed pcs on p.ProviderSK = pcs.ProviderSK 
	INNER JOIN dw.dimJunk junk on pcs.CatchmentSK = junk.JunkSK 
	INNER JOIN DW.dimBenefitPlan ins with(nolock) ON ins.InsurerID = fpc.InsurerSK 
	INNER JOIN DW.dimServices s with(nolock)ON fpc.ServicesSK = s.ServicesSK 
	INNER JOIN DW.factProviderContractRates pcr with(nolock) ON dpc.ProviderContractSK = pcr.ProviderContractSK 
	INNER JOIN DW.dimDate ddfpceff with(nolock) ON ddfpceff.DateSK = fpc.ContractEffectiveBeginDateSK
	INNER JOIN DW.dimDate ddfpcexp with(nolock) ON ddfpcexp.DateSK = fpc.ContractExpirationBeginDateSK 
	INNER JOIN DW.dimDate ddcreff with(nolock)ON ddcreff.DateSK = pcr.ContractRateEffectiveDateSK 	
												AND ddcreff.DateValue <= ddfpcexp.DateValue
	INNER JOIN DW.dimDate ddcreex with(nolock)ON ddcreex.DateSK = pcr.ContractRateExpirationDateSK 
												AND ddcreex.DateValue >= ddfpceff.DateValue 
	LEFT JOIN DW.dimOrganization org with(nolock) on org.County = p.County
	INNER JOIN #prov dprov on dp2.ProviderSK = dprov.providerSK
	INNER JOIN #serv dserv on s.ServicesSK = dserv.ServicesSK
	INNER JOIN dbo.cfn_split(@county, ',') fnp ON fnp.element = p.County
	INNER JOIN dbo.cfn_split(@catchment, ',') cat ON cat.element = ISNULL(junk.JunkNK,0)
	INNER JOIN dbo.cfn_split(@insurer,',') ins2 ON ins2.element = ins.InsurerID 
	--INNER JOIN dbo.cfn_split(@availStatus   ,',')  p2 ON p2.element = p.AvailableStatusID   
	
	
WHERE 
		dp2.ProviderNK <> 1 --not equal to test
		AND dp2.Active = 1
		AND p.StatusID = 49 --equal to 'contracted'
		AND fpc.DeletedContractFlag = 0
		AND ddfpceff.DateValue   <= @contractEndDate 
		AND ddfpcexp.DateValue  >= @contractStartDate
		AND fpc.ClientSpecificFlag = @clientSpecific  
		and fpC.ActiveContractFlag = 1
	
		
			
			
	ORDER BY ProviderName 	
		

	DROP TABLE #serv
	DROP Table #prov 
	
	
	
	
	
	
