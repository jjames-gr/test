USE [BIW]
GO

/****** Object:  StoredProcedure [REP].[cspReportQMProviderLPBillingAuditSampling]    Script Date: 06/20/2013 09:13:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [REP].[cspReportQMProviderLPBillingAuditSampling]
    (
		@ConsumerID int,
		@ProviderID int,
		@ProviderType int,
		@SampleCount int,
		@StartDate DATETIME,
		@EndDate DATETIME,
		@catchment nvarchar(50)
    )
AS 
/*------------------------------------------------------------------------------
-- Title:	QM Provider and LP Billing Audit Sampling Report
-- File:	[Rep].[cspReportQMProviderLPBillingAuditSampling]
-- Author:	Brian Angelo
-- Date:	05/15/2013
-- Desc:	Sample of Claims by Sample Count and Claim Date Range			
--                                          
-- CalledBy:
--          Reports: ""
--          Stored Procs: None
--------------------------------------------------------------------------------
-- Change	Hisory
-- Ver      Date		Author			TixNo    Description
-- ---      ----------	--------------- -----    ----------------------------
   1.0		5/15/13		Brian Angelo	6501	 QM Provider and LP Billing Audit Sampling Report Conversion
--------------------------------------------------------------------------------
*/


/* Testing parameters
DECLARE @ConsumerID int
	SET @ConsumerID = -1
DECLARE @ProviderID int
	SET @ProviderID = 20482     
DECLARE @ProviderType int
	SET @ProviderType = 1
DECLARE @SampleCount int
	SET @SampleCount = 30--1
Declare	@StartDate DATETIME
	SET @StartDate ='12/1/2012'	
Declare	@EndDate DATETIME
	SET @EndDate = '12/31/2012' 
DECLARE @catchment nvarchar(50)
	SET @catchment = '1021'
--*/

BEGIN


IF @ConsumerID IS NULL
	SET @ConsumerID = -1

IF OBJECT_ID(N'tempdb.dbo.#TempAllRecords') IS NOT NULL
	DROP TABLE #TempAllRecords

SELECT
dc.ConsumerNK   AS ConsumerID
,dc.LastName + ', ' + dc.FirstName	 AS ConsumerName
,dc.DOB	   AS ConsumerDOB
,fc.ClaimNumber		AS ClaimNumber
,DateOfService.[DateName_en-US] AS DateOfService -- where DW.factClaims.DateOfServiceSK = DW.dimDate.[DateName_en-US]   
,ds.ServicesSK
,ISNULL(ds.ServiceCode,'')+ISNULL(ds.Modifier1,'')+ISNULL(ds.Modifier2,'') as ServiceCodeModifier
,ds.ServiceDescription AS ServiceDescription  
,fc.UnitsBilled	 AS UnitsBilled
,ISNULL(fc.PaidAmount, 0) + ISNULL(fc.CreditAmount, 0) AS PaidAmount
,dbp.BenefitPlan AS BenefitPlan
,ds.ServiceSummary AS ServiceSummary 
,clin.NPI   AS ClinicianNPINum
,prov.ProviderName
INTO #TempAllRecords
FROM	DW.factClaims fc WITH(NOLOCK)
			INNER JOIN DW.dimServices ds WITH(NOLOCK) ON ds.ServicesSK = fc.ServicesSK
			INNER JOIN DW.dimConsumers dc WITH(NOLOCK) ON dc.ConsumerSK = fc.ConsumerSK
			INNER JOIN DW.dimBenefitPlan dbp WITH(NOLOCK) ON dbp.BenefitPlanSK = fc.BenefitPlanSK
			INNER JOIN DW.dimClinician clin WITH(NOLOCK) ON clin.ClinicianSK = fc.ClinicianSK
			INNER JOIN DW.dimProvider prov WITH(NOLOCK) ON prov.ProviderSK = fc.ProviderSK

			INNER JOIN DW.dimOrganization catchment WITH (NOLOCK) on fc.OrganizationSK = catchment.OrganizationSK 
				AND  (@catchment = '-300'
				OR CONVERT(nvarchar, catchment.CatchmentID) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				OR CONVERT(nvarchar, catchment.OrganizationNK) IN ( SELECT element FROM dbo.cfn_split(@catchment, ',') )
				)

			INNER JOIN DW.dimDate DateOfService WITH(NOLOCK) ON fc.DateOfServiceSK = DateOfService.DateSK
							AND DateOfService.DateValue BETWEEN @StartDate and @EndDate
		
WHERE	
PaidAmount > 0
and PaidAmount IS NOT NULL
and (fc.PaidSK = 9 OR fc.CapitatedSK = 11)
and (@ProviderID=prov.ProviderNK OR (@ProviderID=-2 and @ConsumerID!=-1))  --Default to -1 if consumer selected
and (@ConsumerID=ConsumerNK OR (@ConsumerID=-1 and @ProviderID!=-2))       --Default to -1 if provider is selected


IF OBJECT_ID(N'tempdb.dbo.#TempServices') IS NOT NULL
	DROP TABLE #TempServices
	
CREATE TABLE #TempServices (ServicesSK int)


IF (@ProviderType = 1) --Provider
	BEGIN
		INSERT INTO #TempServices
		SELECT ServicesSK 
		FROM [BIW].[DW].[dimServices] ds
		WHERE ( ds.ServiceSummary LIKE '%Innovations%'
             OR ds.ServiceSummary LIKE '%Residential%'
             OR ds.ServiceSummary LIKE '%Outpatient%'
             OR ds.ServiceSummary LIKE '%Community%' 
             OR ds.ServiceSummary LIKE '%1915 (b)(3) Services%'
             OR ds.ServiceSummary LIKE '%Community Support%'
             OR ds.ServiceSummary LIKE '%BH Long Term Residential%'
             OR ds.ServiceSummary LIKE '%Crisis Services%'
             OR ds.ServiceSummary LIKE '%PRTF (Psychiatric Residential Treatment Facility)%'
             OR ds.ServiceSummary LIKE '%Partial Hosp/Day Tx%'
             OR ds.ServiceSummary LIKE '%MST/IIHS%'
             OR ds.ServiceSummary LIKE '%Psych Rehab%'
             OR ds.ServiceSummary LIKE '%ACTT (Assertive Community Treatment Team)%'
             )
        AND ds.active = 1
        AND ds.ServiceCode NOT IN (select BeganAttributeCodeRange 
										from dw.dimCustomReportGroups 
										where CustomGroupName = 'QMAuditExcludeServiceCodes')					
	END
	
IF (@ProviderType = 2) --LIP
	BEGIN
		INSERT INTO #TempServices
		SELECT ServicesSK 
		FROM [BIW].[DW].[dimServices] ds
		WHERE ds.ServiceSummary LIKE '%Outpatient%'
            AND ds.active = 1
            AND ds.ServiceCode NOT IN (select BeganAttributeCodeRange 
										from dw.dimCustomReportGroups 
										where CustomGroupName = 'QMAuditExcludeServiceCodes') 		
    END

DELETE FROM #TempAllRecords
WHERE ServicesSK NOT IN (SELECT ServicesSK FROM #TempServices)


SELECT TOP ( @SampleCount )
	ts.*
FROM
	( select 
		*
		, ROW_NUM_SERVICES = ROW_NUMBER() OVER ( PARTITION BY t.ServicesSK ORDER BY t.ServicesSK, NewID() DESC )
	from
		#TempAllRecords t
	) as ts
ORDER BY
	ts.ROW_NUM_SERVICES, ClaimNumber --RANDOM_CONSUMER 

IF OBJECT_ID(N'tempdb.dbo.#TempAllRecords') IS NOT NULL
	DROP TABLE #TempAllRecords
	
IF OBJECT_ID(N'tempdb.dbo.#TempServices') IS NOT NULL
	DROP TABLE #TempServices


END





GO


