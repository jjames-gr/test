﻿
CREATE PROCEDURE [DW].[ListCatchmentCounty]
AS
/*------------------------------------------------------------------------------
Title:	List Catchment County
File:	BIW.DW.ListCatchmentCounty
Author:	Jason Workman and Doug Cox
Date:	02/14/2013
Desc:	UDF to List Catchments and Counties for Parameters for Reports

Called By:
	Reports: Unknown
	Stored Procs: Unknown

Change History
	Ver	Date		Author  			TixNo	Description
	---	----------	---------------		-----	--------------------------------
	1.0	02/14/2013  Doug Cox      		7062	initial creation
--------------------------------------------------------------------------------*/

-- <ALL> option for drop down
SELECT
	-1 as ccID
	, -1 as ccOrder
	, '<ALL>' as ccName

UNION

-- Get catchments for drop down
SELECT
	[key_id] as ccID
	, seq as ccOrder
	, pick_value + ' Catchment' as ccName
FROM
	QM.dbo.tbl_Custom_Pick_List with(nolock)
WHERE
	pick_list_id = 135

UNION

-- Get counties for drop down
SELECT
	REGION_ID as ccID
	, 100 as ccOrder
	, COUNTY as ccName
FROM
	QM.dbo.tbl_Regions with(nolock)
WHERE
	REGION_ID >= 4

UNION

-- Get Out Of State value for drop down
SELECT
	REGION_ID as ccID
	, 200 as ccOrder
	, COUNTY as ccName
FROM
	QM.dbo.tbl_Regions with(nolock)
WHERE
	REGION_ID = 3
	
UNION

-- Get Unknown value for drop down
SELECT
	REGION_ID as ccID
	, 300 as ccOrder
	, COUNTY as ccName
FROM
	QM.dbo.tbl_Regions with(nolock)
WHERE
	REGION_ID = 2

-- Order all values -> <ALL>, Catchments, Counties, Out Of State, Unknown
ORDER BY ccOrder