﻿
/***===============================================================================================
== Name:		[DW].[Load_ApprovedClaimsReKey] 
== Created:		5/3/2013
== Author:		Frankie L Timmons Jr.
== Description: Pulls together the approved claims with the claim historical data
==				to Re-Key factClaimHistoricalSK
===================================================================================================
== Parameters:
==	
===================================================================================================
== Version:		1.0.000
===============================================================================================***/

CREATE procedure [DW].[Load_ApprovedClaimsReKey]
as
Begin

Select a.[ApprovedClaimsSK],a.[ApprovedClaimsNK],a.[DexDateSK],a.[GLClaimAdjudicationNumber],a.[ApprovedClaimAmount],a.[ApprovedTransactionDateSK]
Into #MissingSK
from biw.dw.factApprovedClaims as a left outer join
     biw.dw.factClaimsHistorical as b on a.[factClaimsHistoricalSK] = b.[factClaimsHistoricalSK]
where b.[factClaimsHistoricalSK] is null

Create unique clustered index idxMissingSK on #MissingSK ([ApprovedClaimsSK],[ApprovedClaimsNK],[DexDateSK],[GLClaimAdjudicationNumber])

/*
select m.ApprovedClaimsSK,
	convert(bigint, GL_ClaimAdj) GL_ClaimAdj,
	TRXDATE,
	ApprovedClaimAmount,
	ApprovedClaimNK,
	DEX_ROW_TS
Into #GLM
from #MissingSK as m inner join
(
select REPLACE(REPLACE(REPLACE(GL3.ordocnum, 'C', ''), 'I',''), 'R', '')  GL_ClaimAdj,
	   GL3.DEX_ROW_ID ApprovedClaimNK,
	   convert(int, convert(varchar, trxdate,112))TRXDATE,
	   sum(GL3.debitamt- GL3.crdtamnt) as ApprovedClaimAmount,
	   CONVERT(INT, CONVERT(varchar, GL3.DEX_ROW_TS,112)) DEX_ROW_TS
from [PBHC-NewReport].[PBLME].[dbo].[GL30000] as GL3
where GL3.ormstrid LIKE 'CI%'AND GL3.ordocnum LIKE 'CI%'AND GL3.dscriptn = 'Purchases' AND GL3.voided = 0 
group by 
			REPLACE(REPLACE(REPLACE(GL3.ordocnum, 'C', ''), 'I',''), 'R', '') ,
			GL3.DEX_ROW_ID,
			convert(int, convert(varchar, trxdate,112)),
			CONVERT(INT, CONVERT(varchar, GL3.DEX_ROW_TS,112))
			
union
			
select REPLACE(REPLACE(REPLACE(GL2.ordocnum, 'C', ''), 'I',''), 'R', '')  GL_ClaimAdj,
			GL2.DEX_ROW_ID ApprovedClaimNK,
			convert(int, convert(varchar, trxdate,112))TRXDATE,
			sum(gl2.debitamt- gl2.crdtamnt) as ApprovedClaimAmount,
			CONVERT(INT, CONVERT(varchar, GL2.DEX_ROW_TS,112)) DEX_ROW_TS
from [PBHC-NewReport].[PBLME].[dbo].[GL20000] as GL2 
where GL2.ormstrid LIKE 'CI%' AND GL2.ordocnum LIKE 'CI%' AND GL2.dscriptn = 'Purchases' 
			AND GL2.voided = 0 
group by 
			REPLACE(REPLACE(REPLACE(GL2.ordocnum, 'C', ''), 'I',''), 'R', '') ,
			GL2.DEX_ROW_ID,
			convert(int, convert(varchar, trxdate,112)),
			CONVERT(INT, CONVERT(varchar, GL2.DEX_ROW_TS,112))
 ) orp on m.[ApprovedClaimsNK] = orp.[ApprovedClaimNK] and m.[DexDateSK] = orp.[DEX_ROW_TS] 
          and m.[GLClaimAdjudicationNumber] = orp.[GL_ClaimAdj]
          
create unique clustered index idxGL on #GLM (ApprovedClaimsSK,GL_ClaimAdj, ApprovedClaimNK, DEX_ROW_TS)*/

select
	ch.factClaimsHistoricalSK,
	ch.AdjudicationDateSK AdjudicationBegDateSK,
	ch.ClaimAdjudicationNumber,
	ch.glaccountsk,
	ch.createdatesk,
	ch.providersk,
	ch.servicessk,
	ch.organizationsk,
	ch.BenefitPlanSK, 
	ch.diagnosis1sk, 
	ch.paidsk, 
	ch.capitatedsk,
	Row_Number()over(Partition By ClaimAdjudicationNumber order by AdjudicationDateSK, factClaimsHistoricalSK) CurRank
into #Rank1
from biw.dw.factClaimsHistorical ch
where
	--only pull history records where gl data has a claim adj reocrd
	ClaimAdjudicationNumber in (select distinct GLClaimAdjudicationNumber from #MissingSK )

create unique clustered index idxRank on #Rank1(ClaimAdjudicationNumber, CurRank)


select gl.ApprovedClaimsSK,
	t.factClaimsHistoricalSK,
	t.AdjudicationDateSK,
	t.ClaimAdjudicationNumber,
	t.GLAccountsk,
	t.CreateDateSK,
	t.ProviderSK,
	t.ServicesSK,
	t.OrganizationSK,
	t.BenefitPlanSK, 
	t.Diagnosis1SK, 
	t.PaidSK, 
	t.CapitatedSK,
    GL.[ApprovedClaimsNK],
	GL.[ApprovedTransactionDateSK],
	GL.[ApprovedClaimAmount],
	GL.[DexDateSK]
Into #TempApprovedClaims
from #MissingSK gl Left outer join 
     (select r.factClaimsHistoricalSK,
						r.AdjudicationBegDateSK AdjudicationDateSK,
						r.AdjudicationBegDateSK,
						isnull(r2.AdjudicationBegDateSK-1,99991231) AdjudicationEndDateSK,
						r.ClaimAdjudicationNumber,
						r.GLAccountsk,
						r.CreateDateSK,
						r.ProviderSK,
						r.ServicesSK,
						r.OrganizationSK,
						r.BenefitPlanSK, 
						r.Diagnosis1SK, 
						r.PaidSK, 
						r.CapitatedSK
					from #Rank1 r
					left outer join #Rank1 r2 on r2.ClaimAdjudicationNumber = r.ClaimAdjudicationNumber
					and r.CurRank = r2.CurRank - 1
				) t on gl.GLClaimAdjudicationNumber = t.ClaimAdjudicationNumber
						and gl.DexDateSK between t.AdjudicationBegDateSK and t.AdjudicationEndDateSK
						
						
create unique clustered index idxTempApprovedClaims on #TempApprovedClaims(ApprovedClaimsSK,factClaimsHistoricalSK,ClaimAdjudicationNumber)

--select * from #TempApprovedClaims
--where [factClaimsHistoricalSK] is null

Update BIW.DW.factApprovedClaims
set [factClaimsHistoricalSK] = isnull(tac.[factClaimsHistoricalSK],-1),
	[GLAccountsk] = isnull(tac.[GLAccountsk],-1),
	[ClaimCreateDateSK]= isnull(tac.[CreateDateSK],-1),
	[ProviderSK]= isnull(tac.[ProviderSK],-1),
	[ServicesSK]= isnull(tac.[ServicesSK],-1),
	[OrganizationSK]= isnull(tac.[OrganizationSK],-1),
	[BenefitPlanSK]= isnull(tac.[BenefitPlanSK],-1), 
	[Diagnosis1SK]= isnull(tac.[Diagnosis1SK],-1), 
	[ApprovedStatusSK] = case when dj1.junknk = 0 and dj2.junknk = 0 and p.providernk <> 20790 then 29
                              when dj1.junknk = 0 and p.providernk = 20790 then 30
                              when dj1.junknk = 0 and dj2.junknk = 1 and p.providernk <> 20790 then 31
                              when dj1.junknk = 1 and dj2.junknk = 0 and p.providernk <> 20790 then 32
                              when dj1.junknk = 1 and p.providernk = 20790 then 33
                              when dj1.junknk = 1 and dj2.junknk = 1 and p.providernk <> 20790 then 34
                              else -1 end
  
from BIW.DW.factApprovedClaims as fac inner join
     #TempApprovedClaims as tac on fac.[ApprovedClaimsSK] = tac.[ApprovedClaimsSK] left outer join
     biw.dw.dimJunk as dj1 on tac.paidsk = dj1.junksk left outer join
     biw.dw.dimJunk as dj2 on tac.CapitatedSK = dj2.junksk left outer join
     biw.dw.dimProvider as p on tac.providersk = p.providersk



Drop table #Rank1
Drop table #TempApprovedClaims
--Drop table #GLM
Drop table #MissingSK


end