﻿CREATE PROCEDURE [DW].[CleanupClaims] 
	@ETLInsertProjectExecutionID INT 
AS
BEGIN

--Historical Claims dups in Processed table
;
WITH RECS_Historical AS (
select 
	ROW_NUMBER() OVER (PARTITION BY DateofServiceSK, AdjudicationDateSK, ClaimNumber, ClaimDetailNumber, ClaimAdjudicationNumber ORDER BY DateofServiceSK, AdjudicationDateSK, ClaimNumber, ClaimDetailNumber, ClaimAdjudicationNumber) as rownum,
	DateOfServiceSK, 
	AdjudicationDateSK, 
	ClaimNumber, 
	ClaimDetailNumber, 
	ClaimAdjudicationNumber
from biw_stage.Processed.factClaimsHistorical
where etlinsertprojectexecutionid = @ETLInsertProjectExecutionID)

delete from RECS_Historical
where rownum > 1

--Claims dups in Processed table
;
WITH RECS AS (
select 
	ROW_NUMBER() OVER (PARTITION BY DateofServiceSK, ClaimNumber, ClaimDetailNumber, ClaimAdjudicationNumber ORDER BY DateofServiceSK, ClaimNumber, ClaimDetailNumber, ClaimAdjudicationNumber) as rownum,
	DateOfServiceSK, 
	ClaimNumber, 
	ClaimDetailNumber, 
	ClaimAdjudicationNumber
from biw_stage.Processed.factClaims
where etlinsertprojectexecutionid = @ETLInsertProjectExecutionID)

DELETE from RECS
where RowNum > 1

--Remove Claims from BIW that are being re-inserted from Processed table
delete dw.factClaims 
from dw.factClaims a
where exists (select * from biw_stage.processed.factClaims b 
	where a.DateOfServiceSK = b.DateOfServiceSK and
	a.ClaimNumber = b.ClaimNumber and
	a.ClaimDetailNumber = b.ClaimDetailNumber and
	a.ClaimAdjudicationNumber = b.ClaimAdjudicationNumber and
	ETLInsertProjectExecutionID = @ETLInsertProjectExecutionID)
	
--Remove Historical Claims from BIW that are being re-inserted from Processed table
delete dw.factClaimsHistorical
from dw.factClaimsHistorical a
where exists (select * from biw_stage.processed.factClaimsHistorical b 
	where a.DateOfServiceSK = b.DateOfServiceSK and
	a.AdjudicationDateSK = b.AdjudicationDateSK and 
	a.ClaimNumber = b.ClaimNumber and
	a.ClaimDetailNumber = b.ClaimDetailNumber and
	a.ClaimAdjudicationNumber = b.ClaimAdjudicationNumber and
	ETLInsertProjectExecutionID = @ETLInsertProjectExecutionID)	


--Remove non current claims from factClaims
--Added by B. Lang on 3/21/2013
delete dw.factClaims
where ClaimAdjudicationNumber in (select claim_adj_id from [pbhc-newreport].qm.dbo.tbl_claims_adj where current_xn = 0)

END