﻿CREATE TABLE [DW].[factProviderContact] (
    [ProviderContactSK]           INT           IDENTITY (1, 1) NOT NULL,
    [ProviderSK]                  INT           NOT NULL,
    [ProviderContactsSK]          INT           NOT NULL,
    [ProviderContactNK]           INT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NULL,
    [ETLModifiedDate]             DATETIME      NULL,
    [ETLChecksumType1]            NVARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT           NULL,
    [ETLUpdateProjectExecutionID] INT           NULL,
    [ETLDMLOperation]             TINYINT       NULL
);

