﻿CREATE TABLE [DW].[dimScoreResults] (
    [ScoreResultsSK]              INT           NOT NULL,
    [ScoreResultsNK]              INT           NOT NULL,
    [ScoreID]                     INT           NOT NULL,
    [ScoreName]                   VARCHAR (124) NOT NULL,
    [RangeLow]                    INT           NOT NULL,
    [RangeHigh]                   INT           NULL,
    [ResultDescription]           VARCHAR (255) NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [PK_dimScoreResults] PRIMARY KEY NONCLUSTERED ([ScoreResultsNK] ASC, [ScoreID] ASC)
);



