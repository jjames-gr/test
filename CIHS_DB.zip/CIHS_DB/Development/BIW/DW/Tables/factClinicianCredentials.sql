﻿CREATE TABLE [DW].[factClinicianCredentials] (
    [ClinicianCredentialsSK]      INT      IDENTITY (1, 1) NOT NULL,
    [ClinicianSK]                 INT      NOT NULL,
    [ClinicianCredentialsNK]      INT      NOT NULL,
    [CredentialIssueDateSK]       INT      NOT NULL,
    [CredentialExpireDateSK]      INT      NULL,
    [ETLCreatedDate]              DATETIME NULL,
    [ETLModifedDate]              DATETIME NULL,
    [ETLInsertProjectExecutionID] INT      NULL,
    [ETLUpdateProjectExecutionID] INT      NULL,
    CONSTRAINT [factClinicianCredentials_PK] PRIMARY KEY CLUSTERED ([ClinicianCredentialsSK] ASC, [ClinicianSK] ASC, [ClinicianCredentialsNK] ASC, [CredentialIssueDateSK] ASC)
);



