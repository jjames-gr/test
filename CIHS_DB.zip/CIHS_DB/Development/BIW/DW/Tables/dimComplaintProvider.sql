﻿CREATE TABLE [DW].[dimComplaintProvider] (
    [ComplaintProviderSK]         INT           NOT NULL,
    [ComplaintProviderNK]         INT           NOT NULL,
    [ComplaintProvider]           VARCHAR (255) NULL,
    [ComplaintDepartmentSK]       INT           NOT NULL,
    [ComplaintProviderAddress1]   VARCHAR (255) NULL,
    [ComplaintProviderAddress2]   VARCHAR (255) NULL,
    [ComplaintProviderCity]       VARCHAR (50)  NULL,
    [ComplaintProviderState]      VARCHAR (25)  NULL,
    [ComplaintProviderPostalCode] VARCHAR (25)  NULL,
    [ComplaintProviderCounty]     VARCHAR (50)  NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([ComplaintProviderSK] ASC)
);

