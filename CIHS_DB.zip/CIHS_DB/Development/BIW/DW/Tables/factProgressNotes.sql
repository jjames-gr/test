﻿CREATE TABLE [DW].[factProgressNotes] (
    [ProgressServiceNotesSK]      INT          IDENTITY (1, 1) NOT NULL,
    [ProgressNoteID]              INT          NOT NULL,
    [ProgressNotesServicesID]     INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [DateOfServiceSK]             INT          NOT NULL,
    [NotesCreatedDateSK]          INT          NOT NULL,
    [NotesSubmittedDateSK]        INT          NOT NULL,
    [ProgressNotesSK]             INT          NOT NULL,
    [ProgressStatusSK]            INT          NOT NULL,
    [CaseManagerSK]               INT          NOT NULL,
    [CatchmentSK]                 INT          NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [DiagnosisSK]                 INT          NOT NULL,
    [PlaceOfServiceSK]            INT          NOT NULL,
    [BenefitPlanSK]               INT          NOT NULL,
    [DaysElapsedNotesCreation]    INT          NULL,
    [DurationWithClientHours]     INT          NULL,
    [DurationWithClientMinutes]   INT          NULL,
    [TotalTimeWithClient]         CHAR (10)    NULL,
    [TotalMinutesWithClient]      INT          NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    [ETLDMLOperation]             TINYINT      NULL,
    [CareContactTypeSK]           INT          NULL,
    [DaysElaspsedNotesSubmitted]  INT          NULL,
    CONSTRAINT [factProgressNotes_PK] PRIMARY KEY CLUSTERED ([ProgressNoteID] ASC, [ProgressNotesServicesID] ASC, [ConsumerSK] ASC, [DateOfServiceSK] ASC, [NotesCreatedDateSK] ASC, [NotesSubmittedDateSK] ASC, [ProgressNotesSK] ASC, [ProgressStatusSK] ASC, [CaseManagerSK] ASC, [CatchmentSK] ASC, [ServicesSK] ASC, [DiagnosisSK] ASC, [PlaceOfServiceSK] ASC, [BenefitPlanSK] ASC)
);



