CREATE TABLE [DW].[factApprovedClaims](
	[ApprovedClaimsSK] [bigint] IDENTITY(1,1) NOT NULL,
	[factClaimsHistoricalSK] [bigint] NOT NULL,
	[ApprovedClaimsNK] [int] NOT NULL,
	[ApprovedTransactionDateSK] [int] NOT NULL,
	[DEXDateSK][int] NOT NULL,
	[GLAccountSK] [int] NOT NULL,
	[ClaimCreateDateSK] [int] NOT NULL,
	[ProviderSK] [int] NOT NULL,
	[ApprovedStatusSK] [int] NOT NULL,
	[ServicesSK] [int] NOT NULL,
	[OrganizationSK] [int] NOT NULL,
	[BenefitPlanSK] [int] NOT NULL,
	[Diagnosis1SK] [int] NOT NULL,
	[ApprovedClaimAmount] [money] NULL,
	[GLClaimAdjudicationNumber][int] NULL,
	[ETLCreatedDate] [datetime] NOT NULL,
	[ETLModifiedDate] [datetime] NOT NULL,
	[ETLChecksumType1] [varchar](32) NULL,
	[ETLInsertProjectExecutionID] [int] NOT NULL,
	[ETLUpdateProjectExecutionID] [int] NOT NULL,
 CONSTRAINT [PK_factApprovedClaims] PRIMARY KEY CLUSTERED 
([factClaimsHistoricalSK] ASC,[ApprovedClaimsNK] ASC,[ApprovedTransactionDateSK] ASC,[GLAccountSK] ASC,[ProviderSK] ASC,[ServicesSK] ASC,
 [ApprovedStatusSK] ASC,[OrganizationSK] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]