﻿CREATE TABLE [DW].[factLengthOfStay] (
    [ProviderSK]                  INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [ServiceSK]                   INT          NOT NULL,
    [DateSK]                      INT          NOT NULL,
    [ClinicianSK]                 INT          NOT NULL,
    [OrganizationSK]              INT          NOT NULL,
    [AgeSK]                       INT          NOT NULL,
    [BenefitPlanSK]               INT          NOT NULL,
    [PlaceOfServiceSK]            INT          NOT NULL,
    [LengthOfStay]                INT          NOT NULL,
    [ClaimNumber]                 INT          NOT NULL,
    [ClaimAdjudicationNumber]     INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [pk_factLengthOfStay] PRIMARY KEY NONCLUSTERED ([ProviderSK] ASC, [ConsumerSK] ASC, [ServiceSK] ASC, [DateSK] ASC, [ClinicianSK] ASC, [OrganizationSK] ASC, [AgeSK] ASC, [BenefitPlanSK] ASC, [PlaceOfServiceSK] ASC, [ClaimNumber] ASC, [ClaimAdjudicationNumber] ASC)
);






GO
CREATE CLUSTERED INDEX [idx_factLengthOfStay]
    ON [DW].[factLengthOfStay]([DateSK] ASC, [ClaimNumber] ASC, [ClaimAdjudicationNumber] ASC) WITH (FILLFACTOR = 100, ALLOW_PAGE_LOCKS = OFF, ALLOW_ROW_LOCKS = OFF);

