﻿CREATE TABLE [DW].[factApplications] (
    [ApplicationSK]               INT      NOT NULL,
    [ApplicationReceiveDateSK]    INT      NOT NULL,
    [ApplicationStatusSK]         INT      NOT NULL,
    [ApplicationEventSK]          INT      NOT NULL,
    [ApplicationInformationSK]    INT      NOT NULL,
    [ETLCreatedDate]              DATETIME NOT NULL,
    [ETLModifiedDate]             DATETIME NOT NULL,
    [ETLInsertProjectExecutionID] INT      NOT NULL,
    [ETLUpdateProjectExecutionID] INT      NOT NULL,
    CONSTRAINT [factApplications_PK] PRIMARY KEY CLUSTERED ([ApplicationSK] ASC)
);

