﻿CREATE TABLE [DW].[factClinicianProvider] (
    [ClinicianProviderSK]              INT          IDENTITY (1, 1) NOT NULL,
    [ClinicianProviderNK]              INT          NOT NULL,
    [ClinicianSK]                      INT          NOT NULL,
    [ClinicianNK]                      INT          NOT NULL,
    [ProviderSK]                       INT          NOT NULL,
    [ProviderNK]                       INT          NOT NULL,
    [ClinicianProviderEffectiveDateSK] INT          NOT NULL,
    [ClinicianProviderExpireDateSK]    INT          NOT NULL,
    [ETLCreatedDate]                   DATETIME     NULL,
    [ETLModifiedDate]                  DATETIME     NULL,
    [ETLChecksumType1]                 VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID]      INT          NULL,
    [ETLUpdateProjectExecutionID]      INT          NULL,
    CONSTRAINT [factClinicianProvider_PK] PRIMARY KEY CLUSTERED ([ClinicianProviderNK] ASC, [ClinicianSK] ASC, [ClinicianNK] ASC, [ProviderSK] ASC, [ProviderNK] ASC, [ClinicianProviderEffectiveDateSK] ASC, [ClinicianProviderExpireDateSK] ASC)
);



