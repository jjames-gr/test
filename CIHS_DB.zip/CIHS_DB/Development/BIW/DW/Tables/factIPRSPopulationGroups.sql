﻿CREATE TABLE [DW].[factIPRSPopulationGroups] (
    [IPRSPopulationGroupSK]       INT          IDENTITY (1, 1) NOT NULL,
    [IPRSPopulationGroupNK]       INT          NOT NULL,
    [ConsumerSK]                  INT          NOT NULL,
    [PopulationGroupSK]           INT          NOT NULL,
    [EffectiveDateSK]             INT          NOT NULL,
    [ExpirationDateSK]            INT          NOT NULL,
    [ActiveFlag]                  BIT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLChecksumType2]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL
);

