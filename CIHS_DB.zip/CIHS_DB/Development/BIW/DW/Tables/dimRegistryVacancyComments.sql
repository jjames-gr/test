﻿CREATE TABLE [DW].[dimRegistryVacancyComments] (
    [RegistryVacancyCommentsSK]      INT           NOT NULL,
    [RegistryVacancyCommentsNK]      INT           NOT NULL,
    [RegistryVacancyCommentsContact] VARCHAR (128) NULL,
    [RegistryVacancyCommentsPhone]   VARCHAR (64)  NULL,
    [RegistryVacancyComments]        VARCHAR (MAX) NULL,
    [ETLCreatedDate]                 DATETIME      NOT NULL,
    [ETLModifiedDate]                DATETIME      NOT NULL,
    [ETLChecksumType1]               VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]               VARCHAR (32)  NULL,
    [ETLCurrentRow]                  BIT           NOT NULL,
    [ETLEffectiveFrom]               DATETIME      NOT NULL,
    [ETLEffectiveTo]                 DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID]    INT           NOT NULL,
    [ETLUpdateProjectExecutionID]    INT           NOT NULL
);

