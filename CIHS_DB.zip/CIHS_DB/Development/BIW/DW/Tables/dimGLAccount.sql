﻿CREATE TABLE [DW].[dimGLAccount] (
    [GLAccountSK]                 INT          NOT NULL,
    [GLAccountNK]                 INT          NOT NULL,
    [GP_ACCT_ID]                  INT          NULL,
    [CompanyID]                   INT          NOT NULL,
    [CompanyCode]                 VARCHAR (8)  NOT NULL,
    [CompanyDescription]          VARCHAR (32) NOT NULL,
    [Company]                     AS           (([CompanyCode]+' - ')+[CompanyDescription]),
    [CostCenterID]                INT          NOT NULL,
    [CostCenterCode]              VARCHAR (8)  NOT NULL,
    [CostCenterDescription]       VARCHAR (32) NOT NULL,
    [CostCenter]                  AS           (([CostCenterCode]+' - ')+[CostCenterDescription]),
    [AccountID]                   INT          NOT NULL,
    [AccountCode]                 VARCHAR (8)  NOT NULL,
    [Account]                     VARCHAR (64) NOT NULL,
    [SubAccountID]                INT          NOT NULL,
    [SubAccountCode]              VARCHAR (8)  NOT NULL,
    [AccountTypeID]               INT          NOT NULL,
    [AccountType]                 VARCHAR (32) NOT NULL,
    [PostingTypeID]               INT          NOT NULL,
    [PostingType]                 VARCHAR (32) NOT NULL,
    [StatusID]                    INT          NOT NULL,
    [Status]                      VARCHAR (32) NOT NULL,
    [TypicalBalanceID]            INT          NOT NULL,
    [TypicalBalance]              VARCHAR (32) NOT NULL,
    [FixedOrVariableID]           INT          NOT NULL,
    [FixedOrVariable]             VARCHAR (32) NOT NULL,
    [AccountCategoryID]           INT          NOT NULL,
    [AccountCategory]             VARCHAR (32) NOT NULL,
    [GLAccount]                   AS           (((((([CompanyCode]+'-')+[CostCenterCode])+'-')+[AccountCode])+'-')+[SubAccountCode]),
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLChecksumType2]            VARCHAR (32) NULL,
    [ETLCurrentRow]               BIT          NOT NULL,
    [ETLEffectiveFrom]            DATETIME     NOT NULL,
    [ETLEffectiveTo]              DATETIME     NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [PK_dimGLAccount] PRIMARY KEY CLUSTERED ([GLAccountSK] ASC) WITH (FILLFACTOR = 100, ALLOW_PAGE_LOCKS = OFF, ALLOW_ROW_LOCKS = OFF)
);


GO
CREATE NONCLUSTERED INDEX [IX_dimGLAccount_NK]
    ON [DW].[dimGLAccount]([GLAccountNK] ASC)
    INCLUDE([GLAccountSK]);

