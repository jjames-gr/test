﻿CREATE TABLE [DW].[factGrievanceFollowups] (
    [GrievanceFollowupSK]         INT          IDENTITY (1, 1) NOT NULL,
    [GrievanceFollowupNK]         INT          NOT NULL,
    [GrievanceFollowupItemSK]     INT          NOT NULL,
    [GrievancesSK]                INT          NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factGrievanceFollowups_PK] PRIMARY KEY CLUSTERED ([GrievanceFollowupSK] ASC)
);





