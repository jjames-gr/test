﻿CREATE TABLE [DW].[dimComplaintType] (
    [ComplaintTypeSK]             INT           NOT NULL,
    [ComplaintTypeNK]             INT           NOT NULL,
    [ComplaintType]               VARCHAR (250) NULL,
    [ComplaintCategorySK]         INT           NOT NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([ComplaintTypeSK] ASC)
);

