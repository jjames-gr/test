﻿CREATE TABLE [DW].[dimBanding] (
    [BandingSK]                   INT          NOT NULL,
    [BandingGroup]                VARCHAR (32) NOT NULL,
    [BandingGroupID]              INT          NOT NULL,
    [BandingValue]                INT          NOT NULL,
    [Band]                        VARCHAR (32) NOT NULL,
    [BandID]                      INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLChecksumType2]            VARCHAR (32) NULL,
    [ETLCurrentRow]               BIT          NOT NULL,
    [ETLEffectiveFrom]            DATETIME     NOT NULL,
    [ETLEffectiveTo]              DATETIME     NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [pk_dimBanding] PRIMARY KEY CLUSTERED ([BandingSK],[BandingGroupID])
);

