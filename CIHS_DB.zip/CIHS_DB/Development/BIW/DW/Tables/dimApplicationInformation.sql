﻿CREATE TABLE [DW].[dimApplicationInformation] (
    [ApplicationInformationSK]    INT           NOT NULL,
    [ApplicationInformationNK]    INT           NOT NULL,
    [Comment]                     VARCHAR (MAX) NULL,
    [ApplicationName]             VARCHAR (255) NULL,
    [Address1]                    VARCHAR (255) NULL,
    [Address2]                    VARCHAR (255) NULL,
    [City]                        VARCHAR (50)  NULL,
    [State]                       VARCHAR (50)  NULL,
    [Zip]                         VARCHAR (50)  NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NOT NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [dimApplicationInformation_PK] PRIMARY KEY CLUSTERED ([ApplicationInformationSK] ASC)
);

