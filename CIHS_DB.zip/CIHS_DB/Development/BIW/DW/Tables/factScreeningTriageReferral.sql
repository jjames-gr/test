﻿CREATE TABLE [DW].[factScreeningTriageReferral] (
    [ScreeningTriageReferralSK]             INT          IDENTITY (1, 1) NOT NULL,
    [ConsumerSK]                            BIGINT       NOT NULL,
    [ScreeningTriageReferralOrganizationSK] INT          NOT NULL,
    [NeedSeveritySK]                        INT          NOT NULL,
    [CalocusResultSK]                       INT          NOT NULL,
    [LocusResultSK]                         INT          NOT NULL,
    [ScreenDateSK]                          INT          NOT NULL,
    [SubmittedFlagSK]                       INT          NOT NULL,
    [CallID]                                INT          NULL,
    [ScreeningTriageReferralID]             INT          NOT NULL,
    [CurrentSTRStatusSK]                    INT          NOT NULL,
    [STREntryType]                          INT          NOT NULL,
    [ETLCreatedDate]                        DATETIME     NOT NULL,
    [ETLModifiedDate]                       DATETIME     NOT NULL,
    [ETLChecksumType1]                      VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID]           INT          NOT NULL,
    [ETLUpdateProjectExecutionID]           INT          NOT NULL,
    CONSTRAINT [factScreeningTriageReferral_PK] PRIMARY KEY CLUSTERED ([ConsumerSK] ASC, [ScreeningTriageReferralOrganizationSK] ASC, [NeedSeveritySK] ASC, [CalocusResultSK] ASC, [ScreenDateSK] ASC, [SubmittedFlagSK] ASC, [ScreeningTriageReferralID] ASC, [CurrentSTRStatusSK] ASC, [STREntryType] ASC)
);







