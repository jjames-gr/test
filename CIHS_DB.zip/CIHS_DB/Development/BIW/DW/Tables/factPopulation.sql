﻿CREATE TABLE [DW].[factPopulation] (
    [FactPopulationSK]            INT          NOT NULL,
    [OrganizationSK]              INT          NOT NULL,
    [AgeSK]                       INT          NOT NULL,
    [YearSK]                      INT          NOT NULL,
    [Year]                        INT          NULL,
    [Population]                  INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [pk_factPopulation] PRIMARY KEY CLUSTERED ([FactPopulationSK] ASC, [OrganizationSK] ASC, [AgeSK] ASC, [YearSK] ASC)
);




GO


