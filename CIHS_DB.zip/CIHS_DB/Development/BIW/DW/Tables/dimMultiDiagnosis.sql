﻿CREATE TABLE [DW].[dimMultiDiagnosis] (
    [MultiDiagnosisSK]   INT           NOT NULL,
    [MultiDiagnosisCode] VARCHAR (6)   NULL,
    [MultiDiagnosisName] VARCHAR (100) NULL,
	CONSTRAINT [pk_dimMultiDiagnosis] PRIMARY KEY CLUSTERED ([MultiDiagnosisSK])
);

