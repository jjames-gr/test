﻿CREATE TABLE [DW].[temp_recs] (
    [EffectiveFrom]    DATETIME      NULL,
    [EffectiveTo]      DATETIME      NULL,
    [run_order]        BIGINT        NULL,
    [row_num]          BIGINT        NULL,
    [new_id]           INT           NULL,
    [ConsumerSK]       BIGINT        NOT NULL,
    [MasterConsumerSK] BIGINT        NULL,
    [ConsumerNK]       INT           NOT NULL,
    [FullName]         VARCHAR (513) NOT NULL,
    [DOB]              DATE          NULL,
    [ETLModifiedDate]  DATETIME      NOT NULL,
    [ETLCurrentRow]    BIT           NOT NULL,
    [ETLEffectiveFrom] DATETIME      NOT NULL,
    [ETLEffectiveTo]   DATETIME      NOT NULL
);

