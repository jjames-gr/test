﻿CREATE TABLE [DW].[factClinicianLicense] (
    [ClinicianLicenseSK]          INT          IDENTITY (1, 1) NOT NULL,
    [ClinicianSK]                 INT          NOT NULL,
    [ClinicianLicenseNK]          INT          NOT NULL,
    [LicenseSK]                   INT          NOT NULL,
    [LicenseNumber]               VARCHAR (20) NULL,
    [LicenseIssueDateSK]          INT          NOT NULL,
    [LicenseExpireDateSK]         INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifedDate]              DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLupdateProjectExecutionID] INT          NULL,
    CONSTRAINT [factClinicianLicense_PK] PRIMARY KEY CLUSTERED ([ClinicianLicenseSK] ASC, [ClinicianSK] ASC, [ClinicianLicenseNK] ASC, [LicenseSK] ASC)
);



