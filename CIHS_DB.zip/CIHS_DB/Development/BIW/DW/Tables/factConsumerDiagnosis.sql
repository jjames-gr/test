﻿CREATE TABLE [DW].[factConsumerDiagnosis] (
    [ConsumerDiagnosisSK]         INT          IDENTITY (1, 1) NOT NULL,
    [ConsumerDiagnosisNK]         INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [ConsumerNK]                  INT          NOT NULL,
    [DiagnosisSK]                 INT          NOT NULL,
    [DiagnosisNK]                 INT          NOT NULL,
    [DiagnosisClassSK]            INT          NOT NULL,
    [DiagnosisEffectiveDateSK]    INT          NOT NULL,
    [DiagnosisExpirationDateSK]   INT          NOT NULL,
    [ConsumerDiagnosisActiveFlag] BIT          NULL,
    [EmployeeSK]                  INT          NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factConsumerDiagnosis_PK_New] PRIMARY KEY CLUSTERED ([ConsumerDiagnosisNK] ASC, [ConsumerSK] ASC, [ConsumerNK] ASC, [DiagnosisSK] ASC, [DiagnosisClassSK] ASC, [DiagnosisEffectiveDateSK] ASC)
);



