﻿CREATE TABLE [DW].[dimGrievanceComments] (
    [GrievanceCommentsSK]         INT            NOT NULL,
    [GrievanceCommentsNK]         INT            NOT NULL,
    [Grievance]                   VARCHAR (MAX)  NULL,
    [ResolutionDesired]           VARCHAR (1000) NULL,
    [ResolutionComments]          VARCHAR (2000) NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([GrievanceCommentsSK] ASC)
);

