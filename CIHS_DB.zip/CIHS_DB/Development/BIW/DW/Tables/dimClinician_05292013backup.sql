﻿CREATE TABLE [DW].[dimClinician_05292013backup] (
    [ClinicianSK]                 INT           NOT NULL,
    [ClinicianNK]                 INT           NOT NULL,
    [Prefix]                      VARCHAR (16)  NOT NULL,
    [FirstName]                   VARCHAR (64)  NOT NULL,
    [LastName]                    VARCHAR (64)  NOT NULL,
    [FullName]                    VARCHAR (129) NOT NULL,
    [MiddleName]                  VARCHAR (32)  NOT NULL,
    [NPI]                         VARCHAR (32)  NULL,
    [MCD]                         VARCHAR (16)  NULL,
    [Active]                      BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [LastNameFirst]               VARCHAR (147) NULL
);

