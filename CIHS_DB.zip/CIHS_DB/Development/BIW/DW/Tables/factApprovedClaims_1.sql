﻿CREATE TABLE [DW].[factApprovedClaims] (
    [ApprovedClaimsSK]            BIGINT       IDENTITY (1, 1) NOT NULL,
    [factClaimsHistoricalSK]      BIGINT       NOT NULL,
    [ApprovedClaimsNK]            INT          NOT NULL,
    [ApprovedTransactionDateSK]   INT          NOT NULL,
    [GLAccountSK]                 INT          NOT NULL,
    [ClaimCreateDateSK]           INT          NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [ApprovedStatusSK]            INT          NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [OrganizationSK]              INT          NOT NULL,
    [DEXDateSK]                   INT          NULL,
    [GLClaimAdjudicationNumber]   INT          NULL,
    [TableName]                   VARCHAR (32) NULL,
    [BenefitPlanSK]               INT          NOT NULL,
    [Diagnosis1SK]                INT          NOT NULL,
    [ApprovedClaimAmount]         MONEY        NULL,
    [GLBatchNumber]               VARCHAR (15) NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [PK_factApprovedClaims1] PRIMARY KEY CLUSTERED ([factClaimsHistoricalSK] ASC, [ApprovedClaimsNK] ASC, [ApprovedTransactionDateSK] ASC, [GLAccountSK] ASC, [ProviderSK] ASC, [ServicesSK] ASC, [ApprovedStatusSK] ASC, [OrganizationSK] ASC)
);









