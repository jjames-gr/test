﻿CREATE TABLE [DW].[factProviderCatchmentServed] (
    [ProviderCatchmentServedSK]   INT          IDENTITY (1, 1) NOT NULL,
    [ProviderCatchmentServedNK]   INT          NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [CatchmentSK]                 INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLChecksumType2]            VARCHAR (32) NULL,
    [ETLCurrentRow]               BIT          NULL,
    [ETLEffectiveFrom]            DATETIME     NULL,
    [ETLEffectiveTo]              DATETIME     NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLUpdateProjctExecutionID]  INT          NULL,
    [ETLDMLOperation]             TINYINT      NULL,
    CONSTRAINT [factProviderCatchmentServed_PK] PRIMARY KEY CLUSTERED ([ProviderCatchmentServedNK] ASC, [ProviderSK] ASC, [CatchmentSK] ASC)
);







