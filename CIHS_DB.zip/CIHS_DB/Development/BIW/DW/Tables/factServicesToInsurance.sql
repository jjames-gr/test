﻿CREATE TABLE [DW].[factServicesToInsurance] (
    [ServicesToInsuranceSK]       INT          IDENTITY (1, 1) NOT NULL,
    [ServicesToInsuranceNK]       INT          NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [InsurerSK]                   INT          NOT NULL,
    [EffectiveDateSK]             INT          NOT NULL,
    [ExpirationDateSK]            INT          NOT NULL,
    [IsCapFlag]                   BIT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [PK_factServicesToInsurance] PRIMARY KEY CLUSTERED ([ServicesSK] ASC, [InsurerSK] ASC, [EffectiveDateSK] ASC, [ExpirationDateSK] ASC)
);

