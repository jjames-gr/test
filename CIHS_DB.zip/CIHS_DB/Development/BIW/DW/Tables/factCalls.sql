﻿CREATE TABLE [DW].[factCalls] (
    [CallSK]                      INT          IDENTITY (1, 1) NOT NULL,
    [CallCreateDateSK]            INT          NOT NULL,
    [ReferralTypeSK]              INT          NOT NULL,
    [CallStartDateSK]             INT          NOT NULL,
    [CallStartTimeSK]             INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [EmployeeSK]                  INT          NOT NULL,
    [CallDispositionSK]           INT          NOT NULL,
    [CallID]                      INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factCalls_PK] PRIMARY KEY CLUSTERED ([CallSK] ASC, [CallID] ASC, [CallCreateDateSK] ASC, [ReferralTypeSK] ASC, [CallStartDateSK] ASC, [CallStartTimeSK] ASC, [ConsumerSK] ASC, [EmployeeSK] ASC)
);





