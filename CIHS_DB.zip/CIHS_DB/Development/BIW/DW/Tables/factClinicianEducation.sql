﻿CREATE TABLE [DW].[factClinicianEducation] (
    [ClinicianEducationSK]        INT          IDENTITY (1, 1) NOT NULL,
    [ClinicianSK]                 INT          NOT NULL,
    [ClinicianEducationNK]        CHAR (10)    NOT NULL,
    [EducationDegreeSK]           INT          NOT NULL,
    [EducationDegreeDateSK]       INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLUpdateProjectExecutionID] INT          NULL,
    CONSTRAINT [factClinicianEducation_PK] PRIMARY KEY CLUSTERED ([ClinicianEducationSK] ASC, [ClinicianSK] ASC, [EducationDegreeSK] ASC, [EducationDegreeDateSK] ASC)
);



