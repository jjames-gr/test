﻿CREATE TABLE [DW].[factScreeningTriageReferralProvDet] (
    [ScreeningTriageReferralProvDetSK]         INT          IDENTITY (1, 1) NOT NULL,
    [ProviderAttemptID]                        INT          NOT NULL,
    [AppointmentDateSK]                        INT          NOT NULL,
    [ScreeningTriageReferralSK]                INT          NOT NULL,
    [AppointmentAcceptedSK]                    INT          NOT NULL,
    [AppointmentReasonSK]                      INT          NOT NULL,
    [ServicesSK]                               INT          NOT NULL,
    [ProviderSK]                               INT          NOT NULL,
    [ScreeningTriageReferralProvDetCommentsSK] INT          NOT NULL,
    [ETLCreatedDate]                           DATETIME     NOT NULL,
    [ETLModifiedDate]                          DATETIME     NOT NULL,
    [ETLChecksumType1]                         VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID]              INT          NOT NULL,
    [ETLUpdateProjectExecutionID]              INT          NOT NULL,
    CONSTRAINT [factScreeningTriageReferralProvDet_PK] PRIMARY KEY CLUSTERED ([ScreeningTriageReferralProvDetSK] ASC, [ProviderAttemptID] ASC, [AppointmentDateSK] ASC, [ScreeningTriageReferralSK] ASC, [AppointmentAcceptedSK] ASC, [AppointmentReasonSK] ASC, [ServicesSK] ASC, [ProviderSK] ASC, [ScreeningTriageReferralProvDetCommentsSK] ASC)
);



