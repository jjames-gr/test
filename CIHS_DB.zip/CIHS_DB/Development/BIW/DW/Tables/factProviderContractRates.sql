﻿CREATE TABLE [DW].[factProviderContractRates] (
    [ProviderContractRateSK]       INT      IDENTITY (1, 1) NOT NULL,
    [ProviderContractRateNK]       INT      NOT NULL,
    [ProviderContractSK]           INT      NOT NULL,
    [ProviderSK]                   INT      NOT NULL,
    [ServicesSK]                   INT      NOT NULL,
    [LicenseSK]                    INT      NOT NULL,
    [ContractRate]                 MONEY    NULL,
    [ActiveContractRateFlag]       INT      NULL,
    [ContractRateEffectiveDateSK]  INT      NOT NULL,
    [ContractRateExpirationDateSK] INT      NULL,
    [ETLCreateDate]                DATETIME NULL,
    [ETLModifiedDate]              DATETIME NULL,
    [ETLInsertProjectExecutionID]  INT      NULL,
    [ETLUpdateProjectExecutionID]  INT      NULL,
    CONSTRAINT [factProviderContractRates_PK] PRIMARY KEY CLUSTERED ([ProviderContractRateNK] ASC, [ProviderSK] ASC, [ServicesSK] ASC, [LicenseSK] ASC, [ContractRateEffectiveDateSK] ASC)
);





