﻿CREATE TABLE [DW].[dimclinician] (
    [ClinicianSK]                 INT           NOT NULL,
    [ClinicianNK]                 INT           NOT NULL,
    [Prefix]                      VARCHAR (16)  NOT NULL,
    [FirstName]                   VARCHAR (64)  NOT NULL,
    [MiddleName]                  VARCHAR (32)  NOT NULL,
    [LastName]                    VARCHAR (64)  NOT NULL,
    [FullName]                    AS            (([FirstName]+' ')+[LastName]),
    [LastNameFirst]               AS            (rtrim((((ltrim(rtrim([LastName]))+', ')+ltrim(rtrim([FirstName])))+' ')+ltrim(rtrim([Prefix])))),
    [AddressLine1]                VARCHAR (256) NULL,
    [AddressLine2]                VARCHAR (256) NULL,
    [City]                        VARCHAR (256) NULL,
    [State]                       VARCHAR (256) NULL,
    [PostalCode]                  VARCHAR (256) NULL,
    [County]                      VARCHAR (256) NULL,
    [Phone]                       VARCHAR (15)  NULL,
    [DOB]                         DATETIME      NULL,
    [SSN]                         VARCHAR (11)  NULL,
    [ClinicianEmail]              VARCHAR (50)  NULL,
    [NPI]                         VARCHAR (32)  NULL,
    [MCD]                         VARCHAR (16)  NULL,
    [Active]                      BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [PK_dimClinician1] PRIMARY KEY CLUSTERED ([ClinicianSK] ASC, [ClinicianNK] ASC) WITH (ALLOW_PAGE_LOCKS = OFF, ALLOW_ROW_LOCKS = OFF)
);





