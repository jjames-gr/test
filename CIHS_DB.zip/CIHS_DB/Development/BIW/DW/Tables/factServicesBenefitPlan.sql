﻿CREATE TABLE [DW].[factServicesBenefitPlan] (
    [ServicesBenefitPlanSK]         INT          NOT NULL,
    [ServicesBenefitPlanNK]         INT          NOT NULL,
    [ServicesSK]                    INT          NOT NULL,
    [BenefitPlanSK]                 INT          NOT NULL,
    [EffectiveDateSK]               INT          NOT NULL,
    [ExpirationDateSK]              INT          NOT NULL,
    [AuthorizationAllowedFlag]      BIT          NULL,
    [BasicUnitMultiple]             INT          NULL,
    [BillableFlag]                  BIT          NULL,
    [DailyMaxServices]              INT          NULL,
    [WeeklyMaxServices]             INT          NULL,
    [MonthlyMaxServices]            INT          NULL,
    [LifetimeMaxServices]           INT          NULL,
    [YearlyMaxServices]             INT          NULL,
    [BasicServiceFlag]              BIT          NULL,
    [CapFlag]                       BIT          NULL,
    [ClinicianBasedFlag]            BIT          NULL,
    [DiagnosticRelatedGroupingFlag] BIT          NULL,
    [RoomBoardFlag]                 BIT          NULL,
    [StartOfWeek]                   INT          NULL,
    [UtilizationRate]               DECIMAL (18) NULL,
    [ETLCreatedDate]                DATETIME     NOT NULL,
    [ETLModifiedDate]               DATETIME     NOT NULL,
    [ETLChecksumType1]              VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID]   INT          NOT NULL,
    [ETLUpdateProjectExecutionID]   INT          NOT NULL,
    CONSTRAINT [PK_factServicesBenefitPlan] PRIMARY KEY CLUSTERED ([ServicesSK] ASC, [BenefitPlanSK] ASC, [EffectiveDateSK] ASC, [ExpirationDateSK] ASC)
);



