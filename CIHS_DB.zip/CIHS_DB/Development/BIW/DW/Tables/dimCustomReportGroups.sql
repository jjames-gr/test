﻿CREATE TABLE [DW].[dimCustomReportGroups] (
    [CustomReportGroupID]     INT           IDENTITY (1, 1) NOT NULL,
    [CustomGroupName]         VARCHAR (70)  NULL,
    [AttributeID]             INT           NULL,
    [BeganAttributeCodeRange] VARCHAR (100) NULL,
    [EndAttributeCodeRange]   VARCHAR (10)  NULL,
    [CustomGroupValue]        VARCHAR (50)  NULL,
    [Comments]                VARCHAR (300) NULL,
    [ETLCreatedDate]          DATETIME      DEFAULT (getdate()) NOT NULL,
    [ETLModifiedDate]         DATETIME      DEFAULT (getdate()) NOT NULL,
    [ETLCreatedBy]            VARCHAR (50)  NOT NULL,
    [ETLModifiedBy]           VARCHAR (50)  NOT NULL,
    PRIMARY KEY CLUSTERED ([CustomReportGroupID] ASC)
);



