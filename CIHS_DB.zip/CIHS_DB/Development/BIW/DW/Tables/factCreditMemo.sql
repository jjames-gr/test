﻿CREATE TABLE [DW].[factCreditMemo] (
    [CreditMemoSK]                   INT          IDENTITY (1, 1) NOT NULL,
    [CreditMemoNK]                   INT          NOT NULL,
    [ClaimCheckSK]                   INT          NULL,
    [ProviderSK]                     INT          NOT NULL,
    [VoidedCreditMemoSK]             INT          NULL,
    [CreditMemoDateSK]               INT          NOT NULL,
    [CreditMemoApplyAmount]          MONEY        NOT NULL,
    [CreditMemo]                     VARCHAR (50) NOT NULL,
    [SourceClaimAdjudicationNumber]  INT          NOT NULL,
    [AppliedClaimAdjudicationNumber] INT          NOT NULL,
    [ETLCreatedDate]                 DATETIME     NOT NULL,
    [ETLModifiedDate]                DATETIME     NOT NULL,
    [ETLChecksumType1]               VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID]    INT          NOT NULL,
    [ETLUpdateProjectExecutionID]    INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([CreditMemoSK] ASC)
);





