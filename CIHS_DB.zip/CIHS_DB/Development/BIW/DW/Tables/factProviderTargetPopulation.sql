﻿CREATE TABLE [DW].[factProviderTargetPopulation] (
    [ProviderTargetPopulationSK]  INT          IDENTITY (1, 1) NOT NULL,
    [ProviderTargetPopulationNK]  INT          NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [TargetPopulation]            VARCHAR (10) NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLUpdateProjectExecutionID] INT          NULL,
    CONSTRAINT [factProviderTargetPopulation_PK] PRIMARY KEY CLUSTERED ([ProviderTargetPopulationSK] ASC, [ProviderSK] ASC)
);

