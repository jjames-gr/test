﻿CREATE TABLE [DW].[factAppointments] (
    [AppointmentSK]               INT          IDENTITY (1, 1) NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [ScreeningTriageReferralSK]   INT          NOT NULL,
    [AppointmentCreateDateSK]     INT          NOT NULL,
    [AppointmentDateSK]           INT          NOT NULL,
    [DischargeDateSK]             INT          NOT NULL,
    [DischargeFacilityTypeSK]     INT          NOT NULL,
    [AppointmentStatusSK]         INT          NOT NULL,
    [AppointmentCommentsSK]       INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [AppointmentID]               INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factAppointments_PK] PRIMARY KEY CLUSTERED ([AppointmentSK] ASC, [ProviderSK] ASC, [ServicesSK] ASC, [ScreeningTriageReferralSK] ASC, [AppointmentCreateDateSK] ASC, [AppointmentDateSK] ASC, [AppointmentStatusSK] ASC, [AppointmentCommentsSK] ASC, [ConsumerSK] ASC, [AppointmentID] ASC)
);





