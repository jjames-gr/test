﻿CREATE TABLE [DW].[dimTaxonomyCodes] (
    [TaxonomyCodeSK]              INT           NOT NULL,
    [TaxonomyCodeNK]              INT           NOT NULL,
    [TaxonomyCode]                VARCHAR (25)  NULL,
    [TaxonomyCategory]            VARCHAR (80)  NULL,
    [TaxonomyGroup]               VARCHAR (100) NULL,
    [TaxonomyDescription]         VARCHAR (100) NULL,
    [TaxonomyActive]              BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL
);

