﻿CREATE TABLE [DW].[factApplicationEvent] (
    [ApplicationEventSK]             INT      IDENTITY (1, 1) NOT NULL,
    [ApplicationEventNK]             INT      NOT NULL,
    [ApplicationID]                  INT      NOT NULL,
    [ApplicationEventID]             INT      NOT NULL,
    [ApplicantSK]                    INT      NOT NULL,
    [ApplicationReceiveDateSK]       INT      NOT NULL,
    [ApplicationTypeSK]              INT      NOT NULL,
    [ApplicationStatusSK]            INT      NOT NULL,
    [ApplicationEventDescriptionSK]  INT      NOT NULL,
    [ApplicationEventActiveSK]       INT      NOT NULL,
    [MaxApplicationEventDueByDateSK] INT      NOT NULL,
    [ActualApplicationEventDateSK]   INT      NOT NULL,
    [ApplicationEventSequence]       INT      NOT NULL,
    [ETLCreatedDate]                 DATETIME NOT NULL,
    [ETLModifiedDate]                DATETIME NOT NULL,
    [ETLInsertProjectExecutionID]    INT      NOT NULL,
    [ETLUpdateProjectExecutionID]    INT      NOT NULL,
    CONSTRAINT [PK_factApplicationEvent] PRIMARY KEY CLUSTERED ([ApplicationEventNK] ASC, [ApplicationID] ASC, [ApplicantSK] ASC, [ApplicationReceiveDateSK] ASC, [ApplicationTypeSK] ASC, [ApplicationStatusSK] ASC, [ApplicationEventDescriptionSK] ASC, [ActualApplicationEventDateSK] ASC)
);





