﻿CREATE TABLE [DW].[factCOB] (
    [COBSK]                       INT           NOT NULL,
    [COBNK]                       INT           NOT NULL,
    [ConsumerSK]                  BIGINT        NOT NULL,
    [COBEffectiveDateSK]          INT           NOT NULL,
    [COBExpirationDateSK]         INT           NOT NULL,
    [OtherInsurance]              VARCHAR (300) NULL,
    [OtherPlan]                   VARCHAR (30)  NULL,
    [COBOtherInsurance]           VARCHAR (256) NULL,
    [ETLCreateDate]               DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL
);



