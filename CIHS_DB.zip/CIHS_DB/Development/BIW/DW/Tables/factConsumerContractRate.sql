﻿CREATE TABLE [DW].[factConsumerContractRate] (
    [ConsumerContractRateSK]           INT      IDENTITY (1, 1) NOT NULL,
    [ConsumerContractRateNK]           INT      NOT NULL,
    [ConsumerSK]                       BIGINT   NOT NULL,
    [ProviderSK]                       INT      NOT NULL,
    [ServicesSK]                       INT      NOT NULL,
    [ConsumerContractEffectiveDateSK]  INT      NOT NULL,
    [ConsumerContractExpirationDateSK] INT      NULL,
    [ConsumerContractRate]             MONEY    NULL,
    [ConsumerContractRateActiveFlag]   BIT      NOT NULL,
    [ETLCreatedDate]                   DATETIME NULL,
    [ETLModifiedDate]                  DATETIME NULL,
    [ETLInsertProjectExecutionID]      INT      NULL,
    [ETLUpdateProjectExecutionID]      INT      NULL,
    CONSTRAINT [factClientContractRate_PK] PRIMARY KEY CLUSTERED ([ConsumerContractRateSK] ASC, [ConsumerContractRateNK] ASC, [ConsumerSK] ASC, [ProviderSK] ASC, [ServicesSK] ASC, [ConsumerContractEffectiveDateSK] ASC)
);







