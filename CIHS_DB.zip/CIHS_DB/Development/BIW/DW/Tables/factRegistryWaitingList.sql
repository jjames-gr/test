﻿CREATE TABLE [DW].[factRegistryWaitingList] (
    [RegistryWaitingListSK]       INT          IDENTITY (1, 1) NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [EffectiveDateSK]             INT          NOT NULL,
    [CreateDateSK]                INT          NOT NULL,
    [UpdateDateSK]                INT          NOT NULL,
    [RemovedDateSK]               INT          NOT NULL,
    [RemovedByUserSK]             INT          NOT NULL,
    [ServiceTypeSK]               INT          NOT NULL,
    [RegistryClientStatusSK]      INT          NOT NULL,
    [WaitingClientID]             INT          NOT NULL,
    [EmergentFlag]                BIT          NULL,
    [NonAmbulatoryFlag]           BIT          NULL,
    [AwaitingInnovationsFlag]     BIT          NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL
);



