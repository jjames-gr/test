﻿CREATE TABLE [DW].[factCareCoordAdmissions] (
    [CareCoordAdmissionsSK]       INT          IDENTITY (1, 1) NOT NULL,
    [CareCoordAdmissionID]        INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [CareCoordAdmissionsDateSK]   INT          NOT NULL,
    [CareCoordDischargeDateSK]    INT          NOT NULL,
    [CareDisabilityGroupSK]       INT          NOT NULL,
    [CareCoordinatorSK]           INT          NOT NULL,
    [SupportFacilitorSK]          INT          NOT NULL,
    [SecondaryCareCoordinatorSK]  INT          NOT NULL,
    [CatchmentSK]                 INT          NOT NULL,
    [ActiveAdmissionFlag]         BIT          NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factCareCoordAdmissions_PK] PRIMARY KEY CLUSTERED ([CareCoordAdmissionID] ASC, [ConsumerSK] ASC, [CareCoordAdmissionsDateSK] ASC, [CareCoordDischargeDateSK] ASC, [CareDisabilityGroupSK] ASC, [CareCoordinatorSK] ASC, [SupportFacilitorSK] ASC, [SecondaryCareCoordinatorSK] ASC, [CatchmentSK] ASC)
);



