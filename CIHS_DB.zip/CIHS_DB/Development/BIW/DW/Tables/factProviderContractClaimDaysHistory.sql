﻿CREATE TABLE [DW].[factProviderContractClaimDaysHistory] (
    [ProviderContractClaimDaysHistorySK] INT           IDENTITY (1, 1) NOT NULL,
    [ProviderContractClaimDaysHistoryNK] INT           NOT NULL,
    [ProviderContractSK]                 INT           NOT NULL,
    [EmployeeSK]                         INT           NOT NULL,
    [ClaimsDayAdjustmentDateSK]          INT           NULL,
    [OldDaysAllowedClaimsSubmittal]      INT           NULL,
    [NewDaysAllowedClaimsSubmittal]      INT           NULL,
    [Comments]                           VARCHAR (500) NULL,
    [ETLCreateDate]                      DATETIME      NULL,
    [ETLModifiedDate]                    DATETIME      NULL,
    [ETLInsertProjectExecutionID]        INT           NULL,
    [ETLUpdateProjectExecutionID]        INT           NULL,
    CONSTRAINT [factProviderContractClaimDaysHistory_PK] PRIMARY KEY CLUSTERED ([ProviderContractClaimDaysHistorySK] ASC, [ProviderContractClaimDaysHistoryNK] ASC, [ProviderContractSK] ASC, [EmployeeSK] ASC)
);



