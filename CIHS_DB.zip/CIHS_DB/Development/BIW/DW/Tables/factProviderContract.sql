﻿CREATE TABLE [DW].[factProviderContract] (
    [factProviderContractSK]        INT      IDENTITY (1, 1) NOT NULL,
    [ProviderSK]                    INT      NOT NULL,
    [MainProviderSK]                INT      NOT NULL,
    [ServicesSK]                    INT      NOT NULL,
    [ProviderContractDetailNK]      INT      NOT NULL,
    [ProviderContractSK]            INT      NOT NULL,
    [ContractEffectiveBeginDateSK]  INT      NOT NULL,
    [ContractExpirationBeginDateSK] INT      NULL,
    [InsurerSK]                     INT      NOT NULL,
    [SuspendedFlag]                 BIT      NULL,
    [SubCapitatedFlag]              BIT      NULL,
    [AuthorizationRequestedFlag]    BIT      NULL,
    [ClientSpecificFlag]            BIT      NULL,
    [DeletedContractFlag]           BIT      NULL,
    [ActiveContractFlag]            BIT      NULL,
    [ETLCreateDate]                 DATETIME NULL,
    [ETLModifiedDate]               DATETIME NULL,
    [ETLInsertProjectExecutionID]   INT      NULL,
    [ETLUpdateProjectExecutionID]   INT      NULL,
    CONSTRAINT [factProviderContract_PK] PRIMARY KEY CLUSTERED ([factProviderContractSK] ASC, [ProviderSK] ASC, [MainProviderSK] ASC, [ServicesSK] ASC, [ProviderContractDetailNK] ASC, [ProviderContractSK] ASC, [ContractEffectiveBeginDateSK] ASC, [InsurerSK] ASC)
);





