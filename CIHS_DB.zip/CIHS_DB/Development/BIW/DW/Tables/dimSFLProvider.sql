﻿CREATE TABLE [DW].[dimSFLProvider] (
    [SFLProviderSK]               INT           NOT NULL,
    [SFLnpi]                      VARCHAR (32)  NULL,
    [SFLProviderID]               INT           NULL,
    [SFLProviderName]             VARCHAR (256) NULL,
    [SFLProviderAddress]          VARCHAR (256) NULL,
    [SFLProviderCity]             VARCHAR (256) NULL,
    [SFLProviderState]            VARCHAR (256) NULL,
    [SFLProviderZip]              VARCHAR (255) NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [PK_dimSFLProvider] PRIMARY KEY CLUSTERED ([SFLProviderSK] ASC)
);

