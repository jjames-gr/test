﻿CREATE TABLE [DW].[dimApplicant] (
    [ApplicantSK]                 INT            NOT NULL,
    [ApplicantNK]                 INT            NOT NULL,
    [ApplicantComment]            VARCHAR (2750) NULL,
    [ApplicantName]               VARCHAR (255)  NULL,
    [ApplicantAddress1]           VARCHAR (255)  NULL,
    [ApplicantAddress2]           VARCHAR (255)  NULL,
    [ApplicantCity]               VARCHAR (50)   NULL,
    [ApplicantState]              VARCHAR (50)   NULL,
    [ApplicantZip]                VARCHAR (50)   NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    CONSTRAINT [PK_dimApplication] PRIMARY KEY CLUSTERED ([ApplicantSK] ASC)
);





