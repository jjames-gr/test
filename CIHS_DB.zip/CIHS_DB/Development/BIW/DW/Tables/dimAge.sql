﻿CREATE TABLE [DW].[dimAge] (
    [AgeSK]                       INT          NOT NULL,
    [AgeValue]                    SMALLINT     NOT NULL,
    [AgeName]                     AS           (CONVERT([varchar](8),[AgeValue],(0))+' Years'),
    [GroupID]                     SMALLINT     NOT NULL,
    [Group]                       VARCHAR (32) NOT NULL,
    [StateGroupID]                SMALLINT     NULL,
    [StateGroup]                  VARCHAR (32) NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLChecksumType2]            VARCHAR (32) NULL,
    [ETLCurrentRow]               BIT          NOT NULL,
    [ETLEffectiveFrom]            DATETIME     NOT NULL,
    [ETLEffectiveTo]              DATETIME     NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [PK_dimAge] PRIMARY KEY NONCLUSTERED ([AgeSK] ASC)
);


GO
CREATE CLUSTERED INDEX [Test]
    ON [DW].[dimAge]([AgeSK] ASC) WITH (FILLFACTOR = 100);

