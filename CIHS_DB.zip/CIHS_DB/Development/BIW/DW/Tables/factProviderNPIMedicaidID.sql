﻿CREATE TABLE [DW].[factProviderNPIMedicaidID] (
    [ProviderMedicaidIDSK]        INT          IDENTITY (1, 1) NOT NULL,
    [ProviderMedicaidIDNK]        INT          NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [MedicaidNumber]              VARCHAR (9)  NOT NULL,
    [NPINumber]                   VARCHAR (10) NOT NULL,
    [NPIDescription]              CHAR (10)    NULL,
    [CABHAFlag]                   BIT          NULL,
    [ActiveFlag]                  BIT          NULL,
    [ETLCreateDate]               DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLUpdateProjectExecutionID] INT          NULL,
    CONSTRAINT [factProviderNPIMedicaidID_PK] PRIMARY KEY CLUSTERED ([ProviderMedicaidIDSK] ASC, [ProviderMedicaidIDNK] ASC, [ProviderSK] ASC, [MedicaidNumber] ASC, [NPINumber] ASC)
);



