﻿CREATE TABLE [DW].[factGrievanceWork] (
    [GrievanceWorkSK]             INT          IDENTITY (1, 1) NOT NULL,
    [GrievanceWorkNK]             INT          NOT NULL,
    [GrievanceID]                 INT          NULL,
    [GrievanceWorkCommentsSK]     INT          NOT NULL,
    [GrievanceWorkDateSK]         INT          NOT NULL,
    [GrievancesSK]                INT          NOT NULL,
    [GrievanceWorkUserSK]         INT          NOT NULL,
    [GrievanceWorkActive]         BIT          NOT NULL,
    [GrievanceWorkTypeSK]         INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factComplaintWork_PK] PRIMARY KEY CLUSTERED ([GrievanceWorkSK] ASC)
);

