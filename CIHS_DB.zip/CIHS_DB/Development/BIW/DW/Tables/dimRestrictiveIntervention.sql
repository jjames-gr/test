﻿CREATE TABLE [DW].[dimRestrictiveIntervention] (
    [RestrictiveInterventionSK]              INT           NOT NULL,
    [RestrictiveInterventionTypeID]          INT           NOT NULL,
    [RestrictiveInterventionCodeID]          INT           NOT NULL,
    [PurposeID]                              INT           NOT NULL,
    [RestrictiveInterventionDescription]     VARCHAR (25)  NULL,
    [RestrictiveInterventionCodeDescription] VARCHAR (100) NULL,
    [RestrictiveInterventionPurpose]         VARCHAR (50)  NULL,
    [ETLCreatedDate]                         DATETIME      NOT NULL,
    [ETLModifiedDate]                        DATETIME      NOT NULL,
    [ETLChecksumType1]                       VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]                       VARCHAR (32)  NULL,
    [ETLCurrentRow]                          BIT           NOT NULL,
    [ETLEffectiveFrom]                       DATETIME      NOT NULL,
    [ETLEffectiveTo]                         DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID]            INT           NOT NULL,
    [ETLUpdateProjectExecutionID]            INT           NOT NULL,
    CONSTRAINT [PK_dimRestrictiveIntervention] PRIMARY KEY CLUSTERED ([RestrictiveInterventionSK] ASC)
);

