﻿CREATE TABLE [DW].[factClaimCheck] (
    [ClaimCheckSK]                INT          IDENTITY (1, 1) NOT NULL,
    [ClaimCheckNK]                INT          NOT NULL,
    [ClaimCheckNumber]            VARCHAR (20) NULL,
    [ProviderSK]                  INT          NOT NULL,
    [VoidedCheckSK]               INT          NULL,
    [ClaimCheckDateSK]            INT          NOT NULL,
    [ClaimCreateCheckDateSK]      INT          NOT NULL,
    [ClaimCheckAmount]            MONEY        NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([ClaimCheckSK] ASC)
);



