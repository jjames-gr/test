﻿CREATE TABLE [DW].[dimProvider] (
    [ProviderSK]                  INT               NOT NULL,
    [ProviderNK]                  INT               NOT NULL,
    [ParentProviderNK]            INT               NOT NULL,
    [Active]                      BIT               NOT NULL,
    [StatusID]                    INT               NOT NULL,
    [StatusCode]                  VARCHAR (16)      NOT NULL,
    [StatusName]                  VARCHAR (256)     NOT NULL,
    [ProviderTypeID]              INT               NOT NULL,
    [ProviderTypeCode]            VARCHAR (16)      NOT NULL,
    [ProviderType]                VARCHAR (256)     NOT NULL,
    [EntityTypeID]                INT               NOT NULL,
    [EntityTypeCode]              VARCHAR (16)      NOT NULL,
    [EntityType]                  VARCHAR (128)     NOT NULL,
    [ProviderName]                VARCHAR (256)     NOT NULL,
    [AddressLine1]                VARCHAR (256)     NULL,
    [AddressLine2]                VARCHAR (256)     NULL,
    [City]                        VARCHAR (256)     NULL,
    [State]                       VARCHAR (256)     NULL,
    [PostalCode]                  VARCHAR (256)     NULL,
    [County]                      VARCHAR (256)     NULL,
    [Latitude]                    VARCHAR (64)      NULL,
    [Longitude]                   VARCHAR (64)      NULL,
    [Location]                    [sys].[geography] NULL,
    [GeoEntityType]               VARCHAR (64)      NULL,
    [GeoAddress]                  VARCHAR (512)     NULL,
    [ICFID]                       TINYINT           NOT NULL,
    [ICF]                         VARCHAR (16)      NOT NULL,
    [NPI]                         VARCHAR (32)      NULL,
    [AvailableStatusID]           INT               NULL,
    [AvailableStatusCode]         VARCHAR (10)      NULL,
    [AvailableStatus]             VARCHAR (100)     NULL,
    [TaxStatusID]                 INT               NULL,
    [TaxStatus]                   VARCHAR (20)      NULL,
    [AllTargetPopulations]        VARCHAR (100)     NULL,
    [FederalTaxID]                VARCHAR (32)      NULL,
    [MailingAddressLine1]         VARCHAR (256)     NULL,
    [MailingAddressLine2]         VARCHAR (256)     NULL,
    [MailingCity]                 VARCHAR (128)     NULL,
    [MailingState]                VARCHAR (32)      NULL,
    [MailingZip]                  VARCHAR (32)      NULL,
    [ETLCreatedDate]              DATETIME          NOT NULL,
    [ETLModifiedDate]             DATETIME          NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)      NULL,
    [ETLChecksumType2]            VARCHAR (32)      NULL,
    [ETLCurrentRow]               BIT               NOT NULL,
    [ETLEffectiveFrom]            DATETIME          NOT NULL,
    [ETLEffectiveTo]              DATETIME          NOT NULL,
    [ETLInsertProjectExecutionID] INT               NOT NULL,
    [ETLUpdateProjectExecutionID] INT               NOT NULL,
    CONSTRAINT [pk_dimProvider] PRIMARY KEY CLUSTERED ([ProviderSK] ASC, [ProviderNK] ASC, [ParentProviderNK] ASC)
);












GO


