﻿CREATE TABLE [DW].[factTreatmentAuthorizationRequest] (
    [FactTreatmentAuthorizationRequestSK] INT          IDENTITY (1, 1) NOT NULL,
    [ConsumerSK]                          BIGINT       NOT NULL,
    [CreateDateSK]                        INT          NOT NULL,
    [ProviderSK]                          INT          NOT NULL,
    [AssessmentDateSK]                    INT          NOT NULL,
    [SubmitDateSK]                        INT          NOT NULL,
    [OriginalSubmitDateSK]                INT          NOT NULL,
    [UpdatedDateSK]                       INT          NOT NULL,
    [LocusResultSK]                       INT          NOT NULL,
    [CalocusResultSK]                     INT          NOT NULL,
    [ASAMResultSK]                        INT          NOT NULL,
    [RequestTypeSK]                       INT          NOT NULL,
    [ReviewProgCodeSK]                    INT          NOT NULL,
    [SpecialtyCodeSK]                     INT          NOT NULL,
    [TARID]                               INT          NOT NULL,
    [CalocusCalcScore]                    INT          NULL,
    [ExpeditedFlag]                       INT          NULL,
    [ETLCreatedDate]                      DATETIME     NULL,
    [ETLModifiedDate]                     DATETIME     NULL,
    [ETLChecksumType1]                    VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID]         INT          NOT NULL,
    [ETLUpdateProjectExecutionID]         INT          NOT NULL,
    CONSTRAINT [PK_factTreatmentAuthorizationRequest] PRIMARY KEY CLUSTERED ([ConsumerSK] ASC, [CreateDateSK] ASC, [ProviderSK] ASC, [AssessmentDateSK] ASC, [SubmitDateSK] ASC, [OriginalSubmitDateSK] ASC, [UpdatedDateSK] ASC, [LocusResultSK] ASC, [CalocusResultSK] ASC, [ASAMResultSK] ASC, [RequestTypeSK] ASC, [SpecialtyCodeSK] ASC, [TARID] ASC)
);







