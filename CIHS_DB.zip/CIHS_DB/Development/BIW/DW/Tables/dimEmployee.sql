﻿CREATE TABLE [DW].[dimEmployee] (
    [EmployeeSK]                  INT           NOT NULL,
    [EmployeeNK]                  INT           NOT NULL,
    [FirstName]                   VARCHAR (256) NOT NULL,
    [LastName]                    VARCHAR (256) NOT NULL,
    [FullName]                    AS            (([FirstName]+' ')+[LastName]),
    [AccountName]                 VARCHAR (256) NULL,
    [Active]                      BIT           NOT NULL,
    [MiddleInitial]               CHAR (1)      NULL,
    [IsAgentFlag]                 BIT           DEFAULT ((0)) NOT NULL,
    [EmployeeBulkReportPath]      VARCHAR (32)  NULL,
    [EmployeePhone]               VARCHAR (25)  NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [PK_dimEmployee2] PRIMARY KEY CLUSTERED ([EmployeeSK] ASC) WITH (FILLFACTOR = 100, ALLOW_PAGE_LOCKS = OFF, ALLOW_ROW_LOCKS = OFF)
);








GO


