﻿CREATE TABLE [DW].[dimProgressNotes] (
    [ProgressNotesSK]             INT            NOT NULL,
    [ProgressNotesNK]             INT            NOT NULL,
    [PurposeOfNote]               VARCHAR (100)  NULL,
    [InterventionNote]            VARCHAR (5000) NULL,
    [EffectiveNotes]              VARCHAR (250)  NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL
);

