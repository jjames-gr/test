﻿CREATE TABLE [DW].[factConsumerTags] (
    [ConsumerTagsSK]              INT          IDENTITY (1, 1) NOT NULL,
    [ConsumerTagsNK]              INT          NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [ConsumerTagSK]               INT          NULL,
    [ConsumerTagEffectiveDateSK]  INT          NULL,
    [ConsumerTagExpirationDateSK] INT          NULL,
    [ConsumerTagActiveFlag]       BIT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLUpdateProjectExecutionID] INT          NULL
);



