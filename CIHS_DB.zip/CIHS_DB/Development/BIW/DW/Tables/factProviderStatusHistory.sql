﻿CREATE TABLE [DW].[factProviderStatusHistory] (
    [ProviderStatusHistorySK]       INT          IDENTITY (1, 1) NOT NULL,
    [ProviderSK]                    INT          NOT NULL,
    [ProviderNK]                    INT          NOT NULL,
    [ProviderStatusSK]              INT          NOT NULL,
    [ProvideraAvailableSK]          INT          NOT NULL,
    [ProviderStatusEffectiveDateSK] INT          NOT NULL,
    [ProviderStatusEndDateSK]       INT          NOT NULL,
    [ETLCreatedDate]                DATETIME     NOT NULL,
    [ETLModifiedDate]               DATETIME     NOT NULL,
    [ETLChecksumType1]              VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID]   INT          NOT NULL,
    [ETLUpdateProjectExecutionID]   INT          NOT NULL
);

