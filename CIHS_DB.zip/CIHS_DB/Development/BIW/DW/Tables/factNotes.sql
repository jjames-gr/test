﻿CREATE TABLE [DW].[factNotes] (
    [NotesSK]                     INT          IDENTITY (1, 1) NOT NULL,
    [NoteID]                      INT          NOT NULL,
    [NoteType]                    VARCHAR (15) NOT NULL,
    [CallID]                      INT          NOT NULL,
    [CallCareNotesSK]             INT          NOT NULL,
    [NoteCreateDateSK]            INT          NOT NULL,
    [DocTypeDescriptionSK]        INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [EmployeeSK]                  INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factNotes_PK] PRIMARY KEY CLUSTERED ([NotesSK] ASC, [NoteID] ASC, [NoteType] ASC, [CallID] ASC)
);



