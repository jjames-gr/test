﻿CREATE TABLE [DW].[factAuthorizations] (
    [FactAuthorizationsSK]               INT          IDENTITY (1, 1) NOT NULL,
    [FactAuthorizationsNK]               INT          NOT NULL,
    [AuthorizationMasterID]              INT          DEFAULT ((-1)) NOT NULL,
    [CreateDateSK]                       INT          NOT NULL,
    [EffectiveFromDateSK]                INT          NOT NULL,
    [EffectiveToDateSK]                  INT          NOT NULL,
    [ProcessedDateSK]                    INT          NOT NULL,
    [OrganizationSK]                     INT          NOT NULL,
    [ConsumerSK]                         BIGINT       NOT NULL,
    [ProviderSK]                         INT          NOT NULL,
    [MasterProviderSK]                   INT          NOT NULL,
    [ServicesSK]                         INT          NOT NULL,
    [DiagnosisSK]                        INT          NOT NULL,
    [BenefitPlanSK]                      INT          NOT NULL,
    [AgeSK]                              INT          NOT NULL,
    [AuthorizationDetailLastUpdatedBySK] INT          NULL,
    [AuthorizationLastUpdatedBySK]       INT          NULL,
    [SpecialDiagnosisGroupSK]            INT          NULL,
    [AuthorizedDailyMaxUnits]            INT          NULL,
    [AuthorizedWeeklyMaxUnits]           INT          NULL,
    [AuthorizedMonthlyMaxUnits]          INT          NULL,
    [AuthorizedYearlyMaxUnits]           INT          NULL,
    [AuthorizedLifetimeMaxUnits]         INT          NULL,
    [AuthorizedLengthOfStay]             INT          NULL,
    [AuthorizedUnits]                    INT          NOT NULL,
    [UsedUnits]                          INT          NULL,
    [AuthorizationNumber]                VARCHAR (16) NOT NULL,
    [ReferenceNumber]                    INT          NULL,
    [ETLCreatedDate]                     DATETIME     NOT NULL,
    [ETLModifiedDate]                    DATETIME     NOT NULL,
    [ETLChecksumType1]                   VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID]        INT          NOT NULL,
    [ETLUpdateProjectExecutionID]        INT          NOT NULL,
    CONSTRAINT [PK_factAuthorizations] PRIMARY KEY CLUSTERED ([FactAuthorizationsNK] ASC, [AuthorizationMasterID] ASC, [CreateDateSK] ASC, [EffectiveFromDateSK] ASC, [EffectiveToDateSK] ASC, [ProcessedDateSK] ASC, [OrganizationSK] ASC, [ConsumerSK] ASC, [ProviderSK] ASC, [MasterProviderSK] ASC, [ServicesSK] ASC, [DiagnosisSK] ASC, [BenefitPlanSK] ASC)
);












GO



GO


