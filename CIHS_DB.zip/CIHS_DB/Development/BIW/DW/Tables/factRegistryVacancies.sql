﻿CREATE TABLE [DW].[factRegistryVacancies] (
    [RegistryVacanciesSK]         INT          IDENTITY (1, 1) NOT NULL,
    [CreateDateSK]                INT          NOT NULL,
    [RegistryVacancyCommentsSK]   INT          NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [ServiceTypeSK]               INT          NOT NULL,
    [OpeningSiteSK]               INT          NOT NULL,
    [OpeningDateSK]               INT          NOT NULL,
    [VacancyStatusSK]             INT          NOT NULL,
    [RegistryDiagnosisTypeSK]     INT          NOT NULL,
    [AgePreferenceSK]             INT          NOT NULL,
    [AmbulatoryPreferenceSK]      INT          NOT NULL,
    [GenderPreferenceSK]          INT          NOT NULL,
    [NumberOfBeds]                SMALLINT     NULL,
    [ETLCreatedDate]              DATETIME     NULL,
    [ETLModifiedDate]             DATETIME     NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [PK_factRegistryVacancies] PRIMARY KEY NONCLUSTERED ([RegistryVacancyCommentsSK] ASC, [ProviderSK] ASC, [ServicesSK] ASC, [OpeningSiteSK] ASC, [OpeningDateSK] ASC, [VacancyStatusSK] ASC, [ServiceTypeSK] ASC, [RegistryDiagnosisTypeSK] ASC, [AgePreferenceSK] ASC, [AmbulatoryPreferenceSK] ASC, [GenderPreferenceSK] ASC)
);

