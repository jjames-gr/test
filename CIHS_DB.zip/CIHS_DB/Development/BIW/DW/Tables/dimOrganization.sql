﻿CREATE TABLE [DW].[dimOrganization] (
    [OrganizationSK]              INT           NOT NULL,
    [OrganizationNK]              INT           NOT NULL,
    [County]                      VARCHAR (256) NOT NULL,
    [CountyCode]                  CHAR (10)     NULL,
    [CountyNumber]                VARCHAR (25)  NULL,
    [CatchmentID]                 INT           NOT NULL,
    [Catchment]                   VARCHAR (256) NOT NULL,
    [CatchmentSequence]           INT           NOT NULL,
    [CatchmentOnlineDate]         DATE          NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NULL,
    [ETLChecksumType2]            VARCHAR (32)  NOT NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [PK_dimOrganization] PRIMARY KEY CLUSTERED ([OrganizationSK] ASC)
);





