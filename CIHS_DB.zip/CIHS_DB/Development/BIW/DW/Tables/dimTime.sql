﻿CREATE TABLE [DW].[dimTime] (
    [TimeSK]                      INT       IDENTITY (1, 1) NOT NULL,
    [TimeNK]                      CHAR (8)  NOT NULL,
    [Hour]                        CHAR (2)  NOT NULL,
    [MilitaryHour]                CHAR (2)  NOT NULL,
    [Minute]                      CHAR (2)  NOT NULL,
    [Second]                      CHAR (2)  NOT NULL,
    [AmPm]                        CHAR (2)  NOT NULL,
    [StandardTime]                CHAR (11) NULL,
    [ETLCreatedDate]              DATETIME  DEFAULT (getdate()) NULL,
    [ETLModifiedDate]             DATETIME  DEFAULT (getdate()) NULL,
    [ETLCurrentRow]               INT       DEFAULT ((1)) NULL,
    [ETLEffectiveFrom]            DATETIME  DEFAULT ('1/1/1900') NULL,
    [ETLEffectiveTo]              DATETIME  DEFAULT ('12/31/9999') NULL,
    [ETLInsertProjectExecutionID] INT       DEFAULT ((-1)) NULL,
    [ETLUpdateProjectExecutionID] INT       DEFAULT ((-1)) NULL,
    CONSTRAINT [PK_DW.dimTime] PRIMARY KEY CLUSTERED ([TimeSK] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IDX_DW.dimTime_StandardTime]
    ON [DW].[dimTime]([StandardTime] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_DW.dimTime_AmPm]
    ON [DW].[dimTime]([AmPm] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_DW.dimTime_Second]
    ON [DW].[dimTime]([Second] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_DW.dimTime_Minute]
    ON [DW].[dimTime]([Minute] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_DW.dimTime_MilitaryHour]
    ON [DW].[dimTime]([MilitaryHour] ASC) WITH (FILLFACTOR = 90);


GO
CREATE NONCLUSTERED INDEX [IDX_DW.dimTime_Hour]
    ON [DW].[dimTime]([Hour] ASC) WITH (FILLFACTOR = 90);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IDX_DW.dimTime_Time]
    ON [DW].[dimTime]([TimeNK] ASC) WITH (FILLFACTOR = 90);

