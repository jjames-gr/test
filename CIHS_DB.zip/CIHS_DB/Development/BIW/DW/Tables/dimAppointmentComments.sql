﻿CREATE TABLE [DW].[dimAppointmentComments] (
    [AppointmentCommentsSK]       INT            NOT NULL,
    [AppointmentCommentsID]       INT            NOT NULL,
    [ProviderAttemptID]           INT            NOT NULL,
    [AppointmentComments]         VARCHAR (5000) NULL,
    [AppointmentDeclinedComments] VARCHAR (5000) NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    CONSTRAINT [dimAppointmentComments_PK] PRIMARY KEY CLUSTERED ([AppointmentCommentsSK] ASC, [AppointmentCommentsID] ASC, [ProviderAttemptID] ASC)
);



