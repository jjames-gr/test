﻿CREATE TABLE [DW].[factEligibility] (
    [DateSK]                      INT          NOT NULL,
    [OrganizationSK]              INT          NOT NULL,
    [ConsumerSK]                  BIGINT       NOT NULL,
    [BenefitPlanSK]               INT          NOT NULL,
    [AgeSK]                       INT          NOT NULL,
    [ActionSK]                    INT          NOT NULL,
    [Action]                      TINYINT      NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    [factEligibilitySK]           BIGINT       IDENTITY (1, 1) NOT NULL,
    [MedicaidAidCategorySK]       INT          NOT NULL,
    [InsuranceNumber]             VARCHAR (50) NULL,
    [ExpirationDateSK]            INT          NULL
)
WITH (DATA_COMPRESSION = PAGE);







GO
