﻿CREATE TABLE [DW].[factPlanningBudgets] (
    [DateSK]                      INT          NOT NULL,
    [BudgetPeriodID]              TINYINT      NOT NULL,
    [BudgetYearID]                SMALLINT     NOT NULL,
    [BudgetSK]                    INT          NOT NULL,
    [DiagnosisGroupID]            INT          NOT NULL,
    [ServiceSummaryID]            INT          NOT NULL,
    [CatchmentID]                 INT          NULL,
    [GLAccountSK]                 INT          NOT NULL,
    [BenefitPlanSK]               INT          NOT NULL,
    [BudgetAmount]                MONEY        NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL
);





