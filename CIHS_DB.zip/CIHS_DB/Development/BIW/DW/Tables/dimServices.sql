﻿CREATE TABLE [DW].[dimServices] (
    [ServicesSK]                  INT           NOT NULL,
    [ServicesNK]                  INT           NOT NULL,
    [ServiceCode]                 VARCHAR (16)  NOT NULL,
    [ServiceDescription]          VARCHAR (256) NULL,
    [ServiceDescriptionShort]     VARCHAR (32)  NULL,
    [Modifier1]                   VARCHAR (8)   NULL,
    [Modifier2]                   VARCHAR (8)   NULL,
    [Active]                      BIT           NOT NULL,
    [ServiceSummaryID]            INT           NOT NULL,
    [ServiceSummary]              VARCHAR (64)  NOT NULL,
    [ServiceDefinitionID]         INT           NOT NULL,
    [ServiceDefinition]           VARCHAR (256) NOT NULL,
    [IsBasic]                     VARCHAR (8)   NULL,
    [MedicareEligibleCodeFlag]    VARCHAR (16)  NULL,
    [ProviderICFFlag]             VARCHAR (16)  NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL
);










GO


