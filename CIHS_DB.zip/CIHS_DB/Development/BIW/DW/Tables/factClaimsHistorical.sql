﻿CREATE TABLE [DW].[factClaimsHistorical] (
    [factClaimsHistoricalSK]           BIGINT         IDENTITY (1, 1) NOT NULL,
    [CreateDateSK]                     INT            NOT NULL,
    [ReceivedDateSK]                   INT            NOT NULL,
    [DueDateSK]                        INT            NOT NULL,
    [DateOfServiceSK]                  INT            NOT NULL,
    [AdjudicationDateSK]               INT            NOT NULL,
    [OrganizationSK]                   INT            NOT NULL,
    [ConsumerSK]                       BIGINT         NOT NULL,
    [ProviderSK]                       INT            NOT NULL,
    [ServicesSK]                       INT            NOT NULL,
    [Diagnosis1SK]                     INT            NOT NULL,
    [Diagnosis2SK]                     INT            NOT NULL,
    [Diagnosis3SK]                     INT            NOT NULL,
    [Diagnosis4SK]                     INT            NOT NULL,
    [BenefitPlanSK]                    INT            NOT NULL,
    [EmployeeSK]                       INT            NOT NULL,
    [PlaceOfServiceSK]                 INT            NOT NULL,
    [AgeSK]                            INT            NOT NULL,
    [ClinicianSK]                      INT            NOT NULL,
    [BillingNPINumber]                 VARCHAR (10)   NULL,
    [RenderingNPINumber]               VARCHAR (10)   NULL,
    [ReasonCodeSK]                     INT            NOT NULL,
    [StatusSK]                         INT            NOT NULL,
    [PaidSK]                           INT            NOT NULL,
    [CapitatedSK]                      INT            NOT NULL,
    [GLAccountSK]                      INT            NOT NULL,
    [ClaimAmount]                      MONEY          NOT NULL,
    [AdjustedAmount]                   MONEY          NOT NULL,
    [AdjudicatedAmount]                MONEY          NOT NULL,
    [PaidAmount]                       MONEY          NOT NULL,
    [CapitatedAmount]                  MONEY          NOT NULL,
    [CreditAmount]                     MONEY          NOT NULL,
    [UnitsBilled]                      INT            NOT NULL,
    [UnitsClaimed]                     INT            NOT NULL,
    [ClaimNumber]                      INT            NOT NULL,
    [ClaimDetailNumber]                INT            NOT NULL,
    [ClaimAdjudicationNumber]          INT            NOT NULL,
    [ReferenceNumber]                  INT            NULL,
    [ReSubReferenceNumber]             VARCHAR (32)   NULL,
    [Deleted]                          BIT            NOT NULL,
    [PaidDateSK]                       INT            NOT NULL,
    [AgingInDays]                      SMALLINT       NULL,
    [AgingInMonths]                    SMALLINT       NULL,
    [CleanClaimSK]                     TINYINT        NOT NULL,
    [PaperClaimSK]                     TINYINT        NOT NULL,
    [BillTypeSK]                       INT            NOT NULL,
    [MedicaidAidCategorySK]            INT            NOT NULL,
    [GroupedServicesSK]                INT            NOT NULL,
    [COBAmount]                        MONEY          NULL,
    [ConsumerLiabilityAmount]          MONEY          NULL,
    [ContractRate]                     MONEY          NULL,
    [SourceClaimAdjudicationNumber]    INT            NULL,
    [ServiceLineRevenueCode]           VARCHAR (20)   NULL,
    [ModCode]                          VARCHAR (4)    NULL,
    [ClaimTypeSK]                      INT            NULL,
    [SFLProviderSK]                    INT            NULL,
    [AdjudicationReasonNotesSK]        INT            NULL,
    [AuthorizationNumber]              VARCHAR (16)   NULL,
    [AdjudicationReasonAdjustedAmount] MONEY          NULL,
    [COBInsurance]                     VARCHAR (1024) NULL,
    [COBPlan]                          VARCHAR (512)  NULL,
    [HIPAAPayer]                       VARCHAR (256)  NULL,
    [ClaimCheckSK]                     INT            NULL,
    [TaxonomyCodeSK]                   INT            NULL,
    [IPRSSentDateSK]                   INT            NULL,
    [IPRSSentStatusCode]               CHAR (1)       NULL,
    [IPRSDiagnosisSK]                  INT            NULL,
    [IPRSReasonSK]                     INT            NULL,
    [ETLCreatedDate]                   DATETIME       NOT NULL,
    [ETLModifiedDate]                  DATETIME       NOT NULL,
    [ETLChecksumType1]                 VARCHAR (32)   NULL,
    [ETLInsertProjectExecutionID]      INT            NOT NULL,
    [ETLUpdateProjectExecutionID]      INT            NOT NULL,
    CONSTRAINT [pk_factClaimsHistorical] PRIMARY KEY NONCLUSTERED ([factClaimsHistoricalSK] ASC, [ClaimAdjudicationNumber] ASC, [ClaimNumber] ASC, [ClaimDetailNumber] ASC, [CreateDateSK] ASC, [ReceivedDateSK] ASC, [DueDateSK] ASC, [DateOfServiceSK] ASC, [AdjudicationDateSK] ASC, [PaidDateSK] ASC, [OrganizationSK] ASC, [ConsumerSK] ASC, [ProviderSK] ASC, [ServicesSK] ASC, [ClinicianSK] ASC, [GLAccountSK] ASC)
);








GO



GO



GO



GO



GO



GO




