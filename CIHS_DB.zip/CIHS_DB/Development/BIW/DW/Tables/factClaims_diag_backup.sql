﻿CREATE TABLE [DW].[factClaims_diag_backup] (
    [factClaimsSK]      BIGINT       NOT NULL,
    [ClaimNumber]       INT          NOT NULL,
    [ClaimDetailNumber] INT          NOT NULL,
    [diag1]             INT          NULL,
    [DiagnosisNK]       INT          NOT NULL,
    [DiagnosisCode]     VARCHAR (16) NOT NULL,
    [Diagnosis1SK]      INT          NOT NULL,
    [Diagnosis2SK]      INT          NOT NULL,
    [DiagnosisSK]       INT          NOT NULL
);

