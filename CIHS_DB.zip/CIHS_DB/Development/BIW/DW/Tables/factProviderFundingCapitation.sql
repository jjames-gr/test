﻿CREATE TABLE [DW].[factProviderFundingCapitation] (
    [FundingCapitationSK]         INT            IDENTITY (1, 1) NOT NULL,
    [FundingCapitationNK]         INT            NOT NULL,
    [CapitationStartDateSK]       INT            NOT NULL,
    [CapitationEndDateSK]         INT            NOT NULL,
    [ProviderSK]                  INT            NOT NULL,
    [ClientCatchmentSK]           INT            NOT NULL,
    [ServiceDefinitionSK]         INT            NOT NULL,
    [AllCapitatedServiceCodes]    VARCHAR (5000) NULL,
    [CapitationAmount]            MONEY          NULL,
    [UsedAmount]                  MONEY          NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL
);



