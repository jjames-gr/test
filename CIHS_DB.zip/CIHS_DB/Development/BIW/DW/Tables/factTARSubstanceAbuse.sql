﻿CREATE TABLE [DW].[factTARSubstanceAbuse] (
    [TARSubstanceAbuseSK]             INT          IDENTITY (1, 1) NOT NULL,
    [TreatmentAuthorizationRequestSK] INT          NOT NULL,
    [SubstanceSK]                     INT          NOT NULL,
    [LastUsedDateSK]                  INT          NOT NULL,
    [CreateDateSK]                    INT          NOT NULL,
    [SubstanceAbuseFrequencySK]       INT          NOT NULL,
    [SubstanceAbuseRouteSK]           INT          NOT NULL,
    [SubstanceAbusePrioritySK]        INT          NOT NULL,
    [TARSubstanceAbuseID]             INT          NOT NULL,
    [ETLCreatedDate]                  DATETIME     NULL,
    [ETLModifiedDate]                 DATETIME     NULL,
    [ETLChecksumType1]                VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID]     INT          NOT NULL,
    [ETLUpdateProjectExecutionID]     INT          NOT NULL,
    CONSTRAINT [PK_factTARSubstanceAbuse] PRIMARY KEY CLUSTERED ([TreatmentAuthorizationRequestSK] ASC, [SubstanceSK] ASC, [LastUsedDateSK] ASC, [SubstanceAbuseFrequencySK] ASC, [SubstanceAbuseRouteSK] ASC, [TARSubstanceAbuseID] ASC)
);



