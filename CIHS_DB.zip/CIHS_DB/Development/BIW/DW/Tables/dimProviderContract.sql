﻿CREATE TABLE [DW].[dimProviderContract] (
    [ProviderContractSK]          INT            NOT NULL,
    [ProviderContractNK]          INT            NULL,
    [DaysAllowedClaimsSubmittal]  INT            NULL,
    [ActiveContractFlag]          BIT            NULL,
    [ProviderContractTypeID]      INT            NULL,
    [ProviderContractTypeCode]    VARCHAR (10)   NULL,
    [ProviderContractType]        VARCHAR (100)  NULL,
    [ContractComments]            VARCHAR (2000) NULL,
    [ContractTerminationDate]     DATETIME       NULL,
    [ContractEffectiveDate]       DATE           NULL,
    [ContractExpirationDate]      DATE           NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL
);



