﻿CREATE TABLE [DW].[dimIncidentConsumer] (
    [IncidentConsumerSK]          INT          NOT NULL,
    [IncidentConsumerFirstName]   VARCHAR (50) NULL,
    [IncidentConsumerLastName]    VARCHAR (50) NULL,
    [IncidentRecordSource]        VARCHAR (25) NOT NULL,
    [IncidentConsumerID]          VARCHAR (20) NOT NULL,
    [IncidentConsumerCounty]      VARCHAR (50) NULL,
    [IncidentConsumerDOB]         DATETIME     NULL,
    [IncidentConsumerRace]        VARCHAR (5)  NULL,
    [IncidentConsumerGender]      CHAR (10)    NULL,
    [IncidentConsumerArea]        VARCHAR (30) NULL,
    [CurrentConsumerFlag]         INT          NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            CHAR (32)    NOT NULL,
    [ETLChecksumType2]            CHAR (32)    NOT NULL,
    [ETLCurrentRow]               INT          NOT NULL,
    [ETLEffectiveFrom]            DATETIME     NOT NULL,
    [ETLEffectiveTo]              DATETIME     NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [dimIncidentConsumer_PK] PRIMARY KEY CLUSTERED ([IncidentConsumerSK] ASC)
);

