﻿CREATE TABLE [DW].[factAppointmentsToServices] (
    [AppointmentsToServicesSK]    INT          IDENTITY (1, 1) NOT NULL,
    [AppointmentID]               INT          NOT NULL,
    [AppointmentSK]               INT          NOT NULL,
    [ServicesSK]                  INT          NOT NULL,
    [ProviderSK]                  INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [factAppointmentsToServices_PK] PRIMARY KEY CLUSTERED ([AppointmentsToServicesSK] ASC)
);



