﻿CREATE TABLE [DW].[dimGrievanceResolutionTime] (
    [GrievanceResolutionTimeSK]         INT           NOT NULL,
    [GrievanceResolutionTime]           VARCHAR (100) NOT NULL,
    [GrievanceResolutionTimeBeginRange] INT           NULL,
    [GrievanceResolutionTimeEndRange]   INT           NULL,
    [ETLCreatedDate]                    DATETIME      NOT NULL,
    [ETLModifiedDate]                   DATETIME      NOT NULL,
    [ETLChecksumType1]                  VARCHAR (32)  NOT NULL,
    [ETLInsertProjectExecutionID]       INT           NOT NULL,
    [ETLUpdateProjectExecutionID]       INT           NOT NULL
);

