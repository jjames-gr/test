﻿CREATE TABLE [DW].[factProviderRep] (
    [ProviderRepSK]               INT      IDENTITY (1, 1) NOT NULL,
    [ProviderRepNK]               INT      NOT NULL,
    [ProviderSK]                  INT      NOT NULL,
    [JobSK]                       INT      NOT NULL,
    [EmployeeSK]                  INT      NOT NULL,
    [ETLCreateDate]               DATETIME NULL,
    [ETLModifiedDate]             DATETIME NULL,
    [ETLInsertProjectExecutionID] INT      NULL,
    [ETLUpdateProjectExecutionID] INT      NULL,
    CONSTRAINT [factProviderRep_PK] PRIMARY KEY CLUSTERED ([ProviderRepSK] ASC, [ProviderSK] ASC, [JobSK] ASC, [EmployeeSK] ASC)
);



