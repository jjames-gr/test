﻿CREATE TABLE [DW].[dimReasonCodes] (
    [ReasonCodeSK]                INT            NOT NULL,
    [ReasonCodeNK]                INT            NOT NULL,
    [Code]                        VARCHAR (16)   NOT NULL,
    [Description]                 VARCHAR (1280) NOT NULL,
    [CategoryID]                  INT            NOT NULL,
    [Category]                    VARCHAR (32)   NOT NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    [Active]                      BIT            NULL,
    CONSTRAINT [PK_dimReasonCodes] PRIMARY KEY CLUSTERED ([ReasonCodeSK] ASC)
);




GO
CREATE NONCLUSTERED INDEX [IX_dimReasonCodes_NK]
    ON [DW].[dimReasonCodes]([ReasonCodeNK] ASC)
    INCLUDE([ReasonCodeSK]);

