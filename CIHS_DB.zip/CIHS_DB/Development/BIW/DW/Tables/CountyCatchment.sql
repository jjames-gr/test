﻿CREATE TABLE [DW].[CountyCatchment] (
    [ClientID]                    INT           NOT NULL,
    [PlanID]                      INT           NOT NULL,
    [DOS]                         DATETIME      NOT NULL,
    [CountyID]                    INT           NULL,
    [CountyCode]                  VARCHAR (10)  NULL,
    [County]                      VARCHAR (255) NULL,
    [CatchmentID]                 INT           NOT NULL,
    [Catchment]                   VARCHAR (255) NULL,
    [ins_number]                  VARCHAR (25)  NULL,
    [BenefitPlanID]               INT           NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NULL,
    [ETLUpdatedDate]              DATETIME      NULL,
    [COA]                         VARCHAR (5)   NULL,
    CONSTRAINT [pk_CountyCatchment] PRIMARY KEY CLUSTERED ([ClientID] ASC, [PlanID] ASC, [DOS] ASC, [CatchmentID] ASC)
);









