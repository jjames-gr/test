﻿CREATE TABLE [DW].[dimComplaintWorkComments] (
    [ComplaintWorkCommentsSK]     INT           NOT NULL,
    [ComplaintWorkCommentsNK]     INT           NOT NULL,
    [ComplaintWorkTypeSK]         INT           NOT NULL,
    [ComplaintKeywords]           VARCHAR (255) NULL,
    [ComplaintWorkDescription]    VARCHAR (MAX) NULL,
    [ComplaintSK]                 INT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL
);





