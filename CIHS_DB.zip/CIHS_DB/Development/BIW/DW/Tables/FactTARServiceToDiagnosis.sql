﻿CREATE TABLE [DW].[factTARServiceToDiagnosis] (
    [TARServiceToDiagnosisSK]         INT           IDENTITY (1, 1) NOT NULL,
    [TarServiceID]                    INT           NOT NULL,
    [TreatmentAuthorizationRequestSK] INT           NOT NULL,
    [DiagnosisSK]                     INT           NOT NULL,
    [ServicesSK]                      INT           NOT NULL,
    [BenefitPlanSK]                   INT           NOT NULL,
    [ActionTakenSK]                   INT           NOT NULL,
    [ServiceStartDateSK]              INT           NOT NULL,
    [ServiceEndDateSK]                INT           NOT NULL,
    [ProviderSK]                      INT           NOT NULL,
    [ReturnHistoryComment]            VARCHAR (256) NULL,
    [EmployeeSK]                      INT           NOT NULL,
    [TARServiceCreateDateSK]          INT           NOT NULL,
    [TARServiceUpdateDateSK]          INT           NOT NULL,
    [ETLCreatedDate]                  DATETIME      NULL,
    [ETLModifiedDate]                 DATETIME      NULL,
    [ETLChecksumType1]                VARCHAR (32)  NULL,
    [ETLInsertProjectExecutionID]     INT           NOT NULL,
    [ETLUpdateProjectExecutionID]     INT           NOT NULL,
    CONSTRAINT [PK_factTARServiceToDiagnosis] PRIMARY KEY CLUSTERED ([TarServiceID] ASC, [TreatmentAuthorizationRequestSK] ASC, [DiagnosisSK] ASC, [ServicesSK] ASC, [BenefitPlanSK] ASC, [ProviderSK] ASC, [ActionTakenSK] ASC, [ServiceStartDateSK] ASC, [ServiceEndDateSK] ASC, [EmployeeSK] ASC, [TARServiceCreateDateSK] ASC, [TARServiceUpdateDateSK] ASC)
);







