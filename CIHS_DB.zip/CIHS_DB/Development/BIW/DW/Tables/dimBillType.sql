﻿CREATE TABLE [DW].[dimBillType] (
    [BillTypeSK]                  INT          NOT NULL,
    [BillTypeCodeNK]              VARCHAR (4)  NOT NULL,
    [BillTypeGroup]               VARCHAR (25) NOT NULL,
    [BillTypeName]                VARCHAR (25) NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLChecksumType2]            VARCHAR (32) NULL,
    [ETLCurrentRow]               BIT          NOT NULL,
    [ETLEffectiveFrom]            DATETIME     NOT NULL,
    [ETLEffectiveTo]              DATETIME     NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [pk_dimBillType] PRIMARY KEY CLUSTERED ([BillTypeSK] ASC)
);



