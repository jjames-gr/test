﻿CREATE TABLE [DW].[factPlanningActuals] (
    [FiscalYear]                  SMALLINT     NOT NULL,
    [FiscalMonthInYear]           TINYINT      NOT NULL,
    [CatchmentID]                 INT          NOT NULL,
    [ServiceSummaryID]            INT          NOT NULL,
    [GLAccountSK]                 INT          NOT NULL,
    [PlanningActual]              MONEY        NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    CONSTRAINT [pk_factPlanningActuals] PRIMARY KEY CLUSTERED ([GLAccountSK] ASC, [FiscalYear] ASC, [FiscalMonthInYear] ASC, [CatchmentID] ASC, [ServiceSummaryID] ASC)
);



