﻿CREATE VIEW [DW].[trainServiceForecast_PBH_Structure] AS

SELECT
	CONVERT(DATE,CONVERT(VARCHAR(16), dD.MonthInYear) + '/1/' + CONVERT(VARCHAR(16), dD.YearValue)) AS TimeSeries
	,CONVERT(VARCHAR(16), dO.CatchmentID) + '|' + CONVERT(VARCHAR(16),dS.ServiceSummaryID) AS CatchmentServiceSummaryID
	,SUM(fC.AdjudicatedAmount) AS AdjudicatedAmount
FROM
	[DW].[factClaims] AS fC
	INNER JOIN [DW].dimDate AS dD ON
		(dD.[DateSK] != -1
		AND fC.DateOfServiceSK = dD.DateSK
		AND dD.DateSK BETWEEN
			(SELECT
				D2.[DateSK]
			FROM
				DW.[dimDate] AS D1
				INNER JOIN DW.[dimDate] AS D2 ON
					DATEPART(YYYY,DATEADD(MM,-27, D1.[DateValue])) = D2.[YearValue]
					AND DATEPART(MONTH,DATEADD(MM,-27, D1.[DateValue])) = D2.[MonthInYear]
					AND D2.[IsLastDayInMonth] = 1
			WHERE
				D1.[IsCurrentDate] = 1)
		AND
			(SELECT
				D2.[DateSK]
			FROM
				DW.[dimDate] AS D1
				INNER JOIN DW.[dimDate] AS D2 ON
					DATEPART(YYYY,DATEADD(MM,-3, D1.[DateValue])) = D2.[YearValue]
					AND DATEPART(MONTH,DATEADD(MM,-3, D1.[DateValue])) = D2.[MonthInYear]
					AND D2.[IsLastDayInMonth] = 1
			WHERE
				D1.[IsCurrentDate] = 1)
		)
	INNER JOIN [DW].[dimServices] AS dS ON
		fC.[ServicesSK] = dS.[ServicesSK]
		AND dS.[ServiceSummaryID] != -1
	INNER JOIN [DW].[dimOrganization] AS dO ON
		fC.[OrganizationSK] = dO.[OrganizationSK]
		AND dO.[Catchment] = 'PBH'
		AND dO.[CatchmentID] != -1
	INNER JOIN [DW].[dimJunk] AS dJ ON
		fC.[StatusSK] = dJ.[JunkSK]
		AND dJ.[JunkEntity] = 'ClaimAdjudicatedStatus'
		AND dj.[JunkValue] = 'Approved'
GROUP BY
	CONVERT(DATE,CONVERT(VARCHAR(16), dD.MonthInYear) + '/1/' + CONVERT(VARCHAR(16), dD.YearValue))
	,CONVERT(VARCHAR(16), dO.CatchmentID) + '|' + CONVERT(VARCHAR(16),dS.ServiceSummaryID)