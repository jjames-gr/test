﻿CREATE VIEW DW.factPlanningServiceForecast
AS
SELECT     CONVERT(INT, SUBSTRING(F.[Catchment Service Summary ID], 1, CHARINDEX('|', F.[Catchment Service Summary ID], 1) - 1)) AS CatchmentID, CONVERT(INT, 
                      SUBSTRING(F.[Catchment Service Summary ID], CHARINDEX('|', F.[Catchment Service Summary ID], 1) + 1, 32)) AS ServiceSummaryID, 
                      F.[Expression.$TIME] AS DateValue, F.[Expression.Adjudicated Amount] AS PlanningForecast, dD.FiscalMonthInYear, dD.FiscalYear
FROM         OPENROWSET('MSOLAP', 'Provider=MSOLAP.4;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=BIW;Data Source=PBHC-NEWREPORT', 
                      'SELECT Flattened
		[ServicesForecast_PBH_MIXED].[Catchment Service Summary ID]
		,PredictTimeSeries([ServicesForecast_PBH_MIXED].[Adjudicated Amount], 6, REPLACE_MODEL_CASES)
	FROM
		[ServicesForecast_PBH_MIXED]
	PREDICTION JOIN (
		WITH
			MEMBER CatchmentServiceSummaryID AS (
				[Organization].[COC Catchment].CURRENTMEMBER.Member_Key
				+ "|" +
				[Services].[Services].CURRENTMEMBER.Member_Key
			)
			MEMBER TimeSeries AS (
				Cstr([Date Of Service].[Calendar].CURRENTMEMBER.Member_Value)
				+ "/1/" +
				Cstr([Date Of Service].[Calendar].CURRENTMEMBER.Parent.Parent.Member_Value)
			)

		SELECT
			{[Measures].[TimeSeries]
			,[Measures].[CatchmentServiceSummaryID]
			,[Measures].[Planning Actual]} ON 0
			,{[Date Of Service].[Calendar].[Month].MEMBERS
			* ([Services].[Services].[Service Summary].MEMBERS - [Services].[Services].[Service Summary].&[-1])
			* [Organization].[COC Catchment].[Catchment].[PBH]
			* ([FiscalTodaySet].ITEM(0).ITEM(0).Parent.Lag(27) : [FiscalTodaySet].ITEM(0).ITEM(0).Parent.Lag(3))} ON 1
		FROM
			[BIW]
	) AS t ON
			[ServicesForecast_PBH_MIXED].[Catchment Service Summary ID] = t.[[Measures]].[CatchmentServiceSummaryID]]]
			AND [ServicesForecast_PBH_MIXED].[Time Series] = t.[[Measures]].[TimeSeries]]]
			AND [ServicesForecast_PBH_MIXED].[Adjudicated Amount] = t.[[Measures]].[Planning Actual]]]')
                       AS F INNER JOIN
                      DW.dimDate AS dD ON F.[Expression.$TIME] = dD.DateValue
GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPaneCount', @value = 1, @level0type = N'SCHEMA', @level0name = N'DW', @level1type = N'VIEW', @level1name = N'factPlanningServiceForecast';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane1', @value = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "dD"
            Begin Extent = 
               Top = 6
               Left = 236
               Bottom = 65
               Right = 396
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "F"
            Begin Extent = 
               Top = 6
               Left = 434
               Bottom = 110
               Right = 676
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', @level0type = N'SCHEMA', @level0name = N'DW', @level1type = N'VIEW', @level1name = N'factPlanningServiceForecast';

