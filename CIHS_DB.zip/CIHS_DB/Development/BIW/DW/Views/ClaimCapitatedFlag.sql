﻿CREATE VIEW [DW].[ClaimCapitatedFlag] AS

SELECT
	*
FROM
	[DWV].[Junk]
WHERE
	[JunkEntity] = 'ClaimCapitatedFlag'