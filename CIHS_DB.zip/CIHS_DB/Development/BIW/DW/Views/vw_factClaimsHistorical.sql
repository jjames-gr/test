﻿



/*WHERE     (Deleted <> 1) DKB - 6/21/12 allow deleted rows in for Finance reporting*/
CREATE VIEW [DW].[vw_factClaimsHistorical]
AS
SELECT     DW.factClaimsHistorical.CreateDateSK, DW.factClaimsHistorical.ReceivedDateSK, DW.factClaimsHistorical.DueDateSK, DW.factClaimsHistorical.DateOfServiceSK, DW.factClaimsHistorical.AdjudicationDateSK, 
                      DW.factClaimsHistorical.OrganizationSK, DW.factClaimsHistorical.ConsumerSK, DW.factClaimsHistorical.ProviderSK, DW.factClaimsHistorical.ServicesSK, DW.factClaimsHistorical.Diagnosis1SK, 
                      DW.factClaimsHistorical.Diagnosis2SK, DW.factClaimsHistorical.Diagnosis3SK, DW.factClaimsHistorical.Diagnosis4SK, DW.factClaimsHistorical.BenefitPlanSK, DW.factClaimsHistorical.EmployeeSK, 
                      DW.factClaimsHistorical.PlaceOfServiceSK, DW.factClaimsHistorical.AgeSK, DW.factClaimsHistorical.ClinicianSK, DW.factClaimsHistorical.ReasonCodeSK, DW.factClaimsHistorical.StatusSK, 
                      DW.factClaimsHistorical.PaidSK, DW.factClaimsHistorical.CapitatedSK, DW.factClaimsHistorical.GLAccountSK, DW.factClaimsHistorical.ClaimAmount, DW.factClaimsHistorical.AdjustedAmount, 
                      DW.factClaimsHistorical.AdjudicatedAmount, DW.factClaimsHistorical.PaidAmount, DW.factClaimsHistorical.CapitatedAmount, DW.factClaimsHistorical.CreditAmount, DW.factClaimsHistorical.UnitsBilled, 
                      DW.factClaimsHistorical.UnitsClaimed, DW.factClaimsHistorical.ClaimNumber, DW.factClaimsHistorical.ClaimDetailNumber, DW.factClaimsHistorical.ClaimAdjudicationNumber, 
                      DW.factClaimsHistorical.ReferenceNumber, DW.factClaimsHistorical.ReSubReferenceNumber, DW.factClaimsHistorical.Deleted, DW.factClaimsHistorical.PaidDateSK, DW.factClaimsHistorical.AgingInDays, 
                      DW.factClaimsHistorical.AgingInMonths, CONVERT(int, DW.factClaimsHistorical.CleanClaimSK) AS CleanClaimSK, DW.factClaimsHistorical.ETLCreatedDate, DW.factClaimsHistorical.ETLModifiedDate, 
                      DW.factClaimsHistorical.ETLChecksumType1, DW.factClaimsHistorical.ETLInsertProjectExecutionID, DW.factClaimsHistorical.ETLUpdateProjectExecutionID, DW.dimJunk.JunkSK AS DeletedSK, 
                      DATEDIFF(dd, ds.DateValue, dp.DateValue) AS DaysServicetoProcess, DATEDIFF(dd, ds.DateValue, dr.DateValue) AS DaysServicetoReceive, DATEDIFF(dd, 
                      dr.DateValue, dp.DateValue) AS DaysReceivetoProcess, CASE WHEN DW.factClaimsHistorical.AdjudicatedAmount > 0 THEN DATEDIFF(dd, dr.DateValue, dpaid.DateValue) 
                      ELSE NULL END AS DaysReceivetoPaid, CASE WHEN DW.factClaimsHistorical.AdjudicatedAmount > 0 THEN DATEDIFF(dd, dp.DateValue, dpaid.DateValue) ELSE NULL 
                      END AS DaysProcessedtoPaid, CONVERT(int, DW.factClaimsHistorical.PaperClaimSK) AS PaperClaimSK, DW.factClaimsHistorical.factClaimsHistoricalSK,
                      DW.factClaimsHistorical.BillTypeSK, null as client_srv_cat
FROM         DW.factClaimsHistorical WITH (NOLOCK) INNER JOIN
                      DW.dimJunk WITH (NOLOCK) ON DW.factClaimsHistorical.Deleted = DW.dimJunk.JunkNK AND DW.dimJunk.JunkEntity = 'Boolean' INNER JOIN
                      DW.dimDate AS dr WITH (NOLOCK) ON DW.factClaimsHistorical.ReceivedDateSK = dr.DateSK INNER JOIN
                      DW.dimDate AS dp WITH (NOLOCK) ON DW.factClaimsHistorical.AdjudicationDateSK = dp.DateSK INNER JOIN
                      DW.dimDate AS ds WITH (NOLOCK) ON DW.factClaimsHistorical.DateOfServiceSK = ds.DateSK INNER JOIN
                      DW.dimDate AS dpaid WITH (NOLOCK) ON DW.factClaimsHistorical.PaidDateSK = dpaid.DateSK 
                      /** JJames 11/30/12
						Removing join as this join is back to QM, and the data back in QM has duplicates.
						Will be adding the logic back in via the DW (if the business need is presented)
					  **/
                      --LEFT OUTER JOIN DW.EnhancedBasic ON DW.factClaimsHistorical.ClaimAdjudicationNumber = DW.EnhancedBasic.claim_adj_id
GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPaneCount', @value = 2, @level0type = N'SCHEMA', @level0name = N'DW', @level1type = N'VIEW', @level1name = N'vw_factClaimsHistorical';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane2', @value = N'Flags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 53
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1950
         Width = 2265
         Width = 2190
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 3300
         Alias = 3240
         Table = 1755
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', @level0type = N'SCHEMA', @level0name = N'DW', @level1type = N'VIEW', @level1name = N'vw_factClaimsHistorical';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane1', @value = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[29] 4[22] 2[23] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = -168
         Left = 0
      End
      Begin Tables = 
         Begin Table = "factClaims (DW)"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 302
               Right = 271
            End
            DisplayFlags = 280
            TopColumn = 30
         End
         Begin Table = "dimJunk (DW)"
            Begin Extent = 
               Top = 6
               Left = 432
               Bottom = 238
               Right = 665
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "dr"
            Begin Extent = 
               Top = 6
               Left = 703
               Bottom = 125
               Right = 936
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "dp"
            Begin Extent = 
               Top = 126
               Left = 703
               Bottom = 245
               Right = 936
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ds"
            Begin Extent = 
               Top = 150
               Left = 348
               Bottom = 269
               Right = 581
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "dpaid"
            Begin Extent = 
               Top = 190
               Left = 580
               Bottom = 309
               Right = 813
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "EnhancedBasic (DW)"
            Begin Extent = 
               Top = 247
               Left = 851
               Bottom = 366
               Right = 1025
            End
            Display', @level0type = N'SCHEMA', @level0name = N'DW', @level1type = N'VIEW', @level1name = N'vw_factClaimsHistorical';

