﻿CREATE VIEW [DW].[ClaimPaidFlag] AS

SELECT
	*
FROM
	[DWV].[Junk]
WHERE
	[JunkEntity] = 'ClaimAdjudicationPaidFlag'