﻿CREATE VIEW [DW].[factServiceForecast] AS

SELECT
	CONVERT(INT,SUBSTRING(fARIMA.[Catchment Service Summary ID],1,CHARINDEX('|',fARIMA.[Catchment Service Summary ID],1)-1)) AS CatchmentID
	,CONVERT(INT,SUBSTRING(fARIMA.[Catchment Service Summary ID],CHARINDEX('|',fARIMA.[Catchment Service Summary ID],1)+1,32)) AS ServiceSummaryID
	,fARIMA.[Expression.$TIME] AS DateValue
	,dD.DateSK
	,fARIMA.[Expression.Adjudicated Amount] AS ForecastAmount_ARIMA
	,fARTXP.[Expression.Adjudicated Amount] AS ForecastAmount_ARTXP
	,fMIXED.[Expression.Adjudicated Amount] AS ForecastAmount_Mixed
FROM
	OPENROWSET('MSOLAP', 'Provider=MSOLAP.4;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=BIW;Data Source=PBHC-NEWREPORT',
    'SELECT Flattened
		[Catchment Service Summary ID]
		,PredictTimeSeries([Adjudicated Amount], -5, 12)
	FROM
		[ServicesForecast_PBH_ARIMA]') AS fARIMA
	INNER JOIN OPENROWSET('MSOLAP', 'Provider=MSOLAP.4;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=BIW;Data Source=PBHC-NEWREPORT',
    'SELECT Flattened
		[Catchment Service Summary ID]
		,PredictTimeSeries([Adjudicated Amount], -5, 12)
	FROM
		[ServicesForecast_PBH_ARTXP]') AS fARTXP ON
		CONVERT(VARCHAR(32),fARIMA.[Catchment Service Summary ID]) = CONVERT(VARCHAR(32),fARTXP.[Catchment Service Summary ID])
		AND CONVERT(VARCHAR(32),fARIMA.[Expression.$TIME]) = CONVERT(VARCHAR(32),fARTXP.[Expression.$TIME])
	INNER JOIN OPENROWSET('MSOLAP', 'Provider=MSOLAP.4;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=BIW;Data Source=PBHC-NEWREPORT',
    'SELECT Flattened
		[Catchment Service Summary ID]
		,PredictTimeSeries([Adjudicated Amount], -5, 12)
	FROM
		[ServicesForecast_PBH_MIXED]') AS fMIXED ON
		CONVERT(VARCHAR(32),fARIMA.[Catchment Service Summary ID]) = CONVERT(VARCHAR(32),fMIXED.[Catchment Service Summary ID])
		AND CONVERT(VARCHAR(32),fARIMA.[Expression.$TIME]) = CONVERT(VARCHAR(32),fMIXED.[Expression.$TIME])
	INNER JOIN [DW].[dimDate] AS dD ON
		fARIMA.[Expression.$TIME] = dD.[DateValue]