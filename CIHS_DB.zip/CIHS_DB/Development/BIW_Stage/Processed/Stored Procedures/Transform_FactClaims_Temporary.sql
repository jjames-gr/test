﻿
CREATE PROCEDURE [Processed].[Transform_FactClaims_Temporary]
-- =============================================
-- Author:		Justin James
-- Create date: 03/15/2012
-- Description:	Transfrom of FactClaims for BIW. Code exceeds 4000 characters.
-- =============================================

	@etlProjectExecutionID int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT Distinct -- 8/10 DKB distinct is needed for matching on Ins_ID instead of Plan_ID on the client_Insurance could return multiple rows
	tCM.[claim_mst_id]
	,tCD.[claim_det_id]
	,tCA.[claim_adj_id]
	,CONVERT(DATE,tCM.[create_dt]) AS create_dt
	,CONVERT(DATE,tCM.[recd_dt]) AS recd_dt
	,CONVERT(DATE,tCM.[due_dt]) AS due_dt
	,CONVERT(DATE,tCA.[claim_dt]) AS claim_dt 
	,tCM.[prov_no]
	,tCM.[client_id]
	,COALESCE(tCM.[prin_diag],tCD.[diag1]) AS Diag1
	,COALESCE(tCM.[adm_diag],tCD.[diag2]) AS Diag2
	,tCM.[Other_diag1] AS Diag3
	,tCM.[Other_diag2] AS Diag4
	,tCD.[srvc_id]
	,tCA.[claim_amt]
	,tCA.[adjusted_amt]
	,tCA.[adjudicated_amt]
	,tCA.[units]
	,tCA.[adjudicated_units]
	,tCD.[pos_id]
	,COALESCE(tCM.[prov_npi_no], tCD.[rendering_prov_npi]) AS ClinicianNPI
	,ISNULL(tCA.[plan_id],-1) as plan_id
	,0 as [region_id]
	,0 as orderPlan --case When tCI.[Plan_id] = tCA.[plan_id] then 1 else 2 end as orderPlan
	,COALESCE(tCA.[update_by_id],tCD.[update_by_id],tCM.[update_by_id],tCA.[create_by_id],tCD.[create_by_id],tCM.[create_by_id]) AS updated_by_id
	,CONVERT(DATE,COALESCE(tCAR.create_dt,tCA.[update_dt],tCD.[update_dt],tCM.[update_dt],tCA.[create_dt],tCD.[create_dt],tCM.[create_dt])) AS updated_dt
	,tCA.[paid_amt]
	,tCA.[capitated_amt]
	,tCA.[credit_memo_apply_amt]
	,CONVERT(VARCHAR(64),tCA.[paid_flag]) AS paid_flag
	,CONVERT(VARCHAR(64),tCA.[is_capitated]) AS is_capitated
	,LTRIM(RTRIM(tCA.[adj_reason_cd])) AS adj_reason_cd
	,CONVERT(VARCHAR(64),tCA.[status_id]) AS status_id
	,tCM.[ref_no]
	,tCM.[resub_ref_no]
	,tCA.[gp_acct_id]
	,tCM.[deleted]
	,Case when tCKD.check_id = 8032 then convert(Date,tCMD.Create_dt) else convert(DATE,tCKD.[Create_dt]) end AS PaidDate  -- Per Dolores 7/10/2012 always take the Create date for credit Memo
	,tCKD.check_id
	,tCA.source_adj_id
	,case when ltrim(rtrim(tcm.bill_type)) IS null then '-1'
	else 
		right(replicate('0000',4) + ltrim(rtrim(tcm.bill_type)),4)
	end as bill_type,
	CASE fsg.client_srv_cat
		WHEN 'Basic Augmented Services' THEN CAST('0' as char(3))
		WHEN 'Basic Services' THEN CAST('1' as char(3))
		WHEN 'Enhanced Services' THEN CAST('2' as char(3))
		ELSE NULL
	END as client_srv_cat_id
	,tca.cob_amt,tca.contract_rate,isnull(tcd.rev_code,'') as rev_code
	,CAST(ISNULL(tcd.mod1_id, '') AS VARCHAR(2)) + CAST(ISNULL(tcd.mod2_id, '') AS VARCHAR(2)) as ModCode
	,ltrim(rtrim(tcm.claim_type)) as [claim_type]
	,isnull(tca.cob_amt,0) + isnull(tcar.adjusted_amt,0) as ConsumerLiabilityAmount
	
	/*Added Columns For Sprint 5: Frankie Timmons Jr 3/21/2013*/
	,isnull(tcar.adjusted_amt,0) as [AdjudicationReasonAdjustedAmt]
	,convert(bigint,tca.auth_id) as [auth_id],ltrim(rtrim(tCAR.notes)) as [Notes] 
	,tCM.[SFL_NPI],tCM.[SFL_Provider_ID],tCM.[SFL_Provider_Name],tCM.[SFL_Provider_Address],tCM.[SFL_Provider_City]
	,tCM.[SFL_Provider_State],tCM.[SFL_Provider_Zip]
	/*Added Columns For Sprint 5: Frankie Timmons Jr 3/28/2013*/
	,ISNULL(cob.COB_Insurance,'Unknown') as COBPlan
	,ISNULL(cob.COB_Other_Insurance,'Unknown') as COBInsurance
    ,isnull(tcm.[hipaa_payer_id],'') as [hipaa_payer_id]
                  

FROM
	[Raw].[CI_tbl_claims_master] AS tCM
	INNER JOIN [Raw].[CI_tbl_claims_det] AS tCD ON
		tCM.[claim_mst_id] = tCD.[claim_mst_id]
		AND tCM.[ETLInsertProjectExecutionID] = tCD.[ETLInsertProjectExecutionID]		
	INNER JOIN [Raw].[CI_tbl_claims_adj] AS tCA ON
		tCM.[claim_mst_id] = tCA.[claim_mst_id]
		AND tCD.[claim_det_id] = tCA.[claim_det_id]
		AND tCA.[current_xn] = 1
		AND tCM.[ETLInsertProjectExecutionID] = tCA.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN raw.CI_tbl_claims_adj_reason tCAR ON 
		tCA.claim_adj_id = tCAR.claim_adj_id 
		AND tCA.adj_reason_cd = tCAR.adj_reason_cd
		AND tCA.[ETLInsertProjectExecutionID] = tCAR.[ETLInsertProjectExecutionID] 
	Left outer Join Raw.CI_tbl_ben_plans_to_insurance tBPI  -- DKB 8/27/2012 Changed to Left outer since there are PlanID of 0 and Null that would not match. 
		on tCA.plan_id = tBPI.plan_id
		and tCA.ETLInsertProjectExecutionID = tBPI.ETLInsertProjectExecutionID	
	LEFT OUTER JOIN [Raw].[CI_tbl_check_det] AS tCKD ON
		tCA.[check_id] = tCKD.[check_id]
		AND tCA.[ETLInsertProjectExecutionID] = tCKD.[ETLInsertProjectExecutionID]
		and tCKD.voided <> 1
	LEFT OUTER JOIN (SELECT MIN(create_dt) as create_dt, apply_to_claim_adj_id, ETLInsertProjectExecutionID 
						FROM RAW.CI_tbl_credit_memo_det 
						GROUP BY apply_to_claim_adj_id, ETLInsertProjectExecutionID) tcmd On
		tCA.claim_adj_id = tcmd.apply_to_claim_adj_id
		and tCA.[ETLInsertProjectExecutionID] = tcmd.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN raw.ci_tbl_report_fact_utilization_by_srvc_grouping fsg on
		tCA.claim_adj_id = fsg.claim_adj_id	
	LEFT OUTER JOIN Raw.Client_COB_Lookup cob on
		cob.client_id = tcm.client_id
WHERE tCM.[ETLInsertProjectExecutionID] = @etlProjectExecutionID

Order by Plan_ID, Client_id
OPTION (FAST 50000)

END