﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE Processed.Transform_IncidentDetails @ETLInsertProjectExecutionID int
AS
BEGIN
	SELECT  distinct INCIDENT_ID as IncidentDetailsNK,'ProviderIncident' as RecordSource,
CASE WHEN waiver_srvc_status = 1 THEN 'Yes' ELSE 'No' END AS WaiverServiceStatus,
CASE 
  WHEN tpi.srvc_code = 'U' THEN 'Unknown'
  WHEN tpi.srvc_code = 'P' THEN 'Periodic'
  WHEN tpi.srvc_code = 'D' THEN 'Day/Night'
  WHEN tpi.srvc_code = 'R' THEN 'Residential'
  ELSE 'Unknown' END AS ServiceType,
 CASE LOC_CODE_ID
  WHEN 1 THEN 'Provider Premises'
  WHEN 2 THEN 'Consumers Legal Residence'
  WHEN 3 THEN 'Community'
  WHEN 4 THEN 'Other'  
  ELSE 'Unknown'
    END AS IncidentLocationDescription,
    psa.DESCRIPTION as ProviderServiceArea,
    st.DESCRIPTION as ContractStatus,
    REPLACE(REPLACE(pri_diagnosis, CHAR(13), ''),CHAR(10), '') as PrimaryDiagnosis,
    tpi.CONSUMER_COUNTY as ConsumerCountyLocation,
    tpi.incident_county as IncidentCountyLocation,
 til.description as IncidentLevelDescription,
 REPLACE(REPLACE(ic.description, CHAR(13), ''),CHAR(10), ' ') as IncidentCodeRestrictiveInterventionCodeDescription,
 ISNULL(rgt.GroupType,'Other Incident') as GroupType,
 '' as RestrictiveInterventionBlockDescription,
 '' as RestrictievInterventionDetails,ha.Description HostLME,
cha.Description HomeLME
FROM raw.ci_tbl_prov_incident tpi LEFT OUTER JOIN 
     raw.ci_tbl_service_area sa on sa.area_id = tpi.consumer_area_id and sa.[ETLInsertProjectExecutionID] = tpi.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     raw.ci_tbl_Service_Area psa on tpi.prov_area_id = psa.AREA_ID and psa.[ETLInsertProjectExecutionID] = tpi.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     raw.ci_tbl_Status st on tpi.CONT_STATUS_ID = st.STATUS_ID and st.[ETLInsertProjectExecutionID] = tpi.[ETLInsertProjectExecutionID] INNER JOIN 
     raw.ci_tbl_Incident_Level til on tpi.INCIDENT_LEVEL_ID = til.INCIDENT_LEVEL_ID and til.[ETLInsertProjectExecutionID] = tpi.[ETLInsertProjectExecutionID] INNER JOIN 
     raw.ci_tbl_Incident_Code ic on tpi.INCIDENT_CODE_ID = ic.INCIDENT_CODE_ID and ic.[ETLInsertProjectExecutionID] = tpi.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     Blue212.biw_stage.ods.RIGroupType rgt on rgt.IncidentCodeID = tpi.INCIDENT_CODE_ID LEFT OUTER JOIN 
     raw.ci_tbl_host_area as ha on tpi.host_area_id = ha.host_area_id LEFT OUTER JOIN 
     raw.ci_tbl_host_area as cha on tpi.consumer_host_area_id = cha.host_area_id
where tpi.[ETLInsertProjectExecutionID] = @ETLInsertProjectExecutionID

UNION ALL 

SELECT 
 ri.RI_ID as IncidentDetailsNK,
 'RestrictiveIntervention' as RecordSource,
 CASE WHEN waiver_srvc_status = 1 THEN 'Yes'
  ELSE 'No'
 END AS WaiverServiceStatus,
 CASE 
  WHEN ri.service_type_code = 'U' THEN 'Unknown'
  WHEN ri.service_type_code = 'P' THEN 'Periodic'
  WHEN ri.service_type_code = 'D' THEN 'Day/Night'
  WHEN ri.service_type_code = 'R' THEN 'Residential'
  ELSE 'Unknown'
 END AS ServiceType,
 CASE LOC_CODE_ID
  WHEN 1 THEN 'Provider Premises'
  WHEN 2 THEN 'Consumers Legal Residence'
  WHEN 3 THEN 'Community'
  WHEN 4 THEN 'Other'  
  ELSE 'Unknown'
    END AS IncidentLocationDescription,
    psa.DESCRIPTION as ProviderServiceArea,
    st.DESCRIPTION as ContractStatus,
    'NONE' as PrimaryDiagnosis,
    ri.CONSUMER_COUNTY as ConsumerCountyLocation,
    ri.RI_COUNTY as IncidentCountyLocation,
 til.description as IncidentLevelDescription,
 ric.RI_CODE_DESC as IncidentCodeRestrictiveInterventionCodeDescription,
 'Restrictive Intervention' as GroupType,
  rid.BLOCK_DESCRIP as RestrictiveInterventionBlockDescription,
 rid.DETAIL_TEXT as RestrictievInterventionDetails,
 ha.Description HostLME,
cha.Description HomeLME
FROM raw.ci_tbl_Restrictive_Interv ri LEFT OUTER JOIN 
     raw.ci_tbl_service_area sa on sa.area_id = ri.client_area_id and sa.[ETLInsertProjectExecutionID] = ri.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     raw.ci_tbl_Service_Area psa on ri.prov_area_id = psa.AREA_ID and psa.[ETLInsertProjectExecutionID] = ri.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     raw.ci_tbl_Status st on ri.CONT_STATUS_ID = st.STATUS_ID and st.[ETLInsertProjectExecutionID] = ri.[ETLInsertProjectExecutionID] INNER JOIN 
     raw.ci_tbl_Incident_Level til on ri.INCIDENT_LEVEL_ID = til.INCIDENT_LEVEL_ID and til.[ETLInsertProjectExecutionID] = ri.[ETLInsertProjectExecutionID] INNER JOIN 
     raw.ci_tbl_ri_codes ric on ri.RI_CODE_ID = ric.RI_CODE_ID and ric.[ETLInsertProjectExecutionID] = ri.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     raw.ci_tbl_Restrictive_Intv_Detail rid on ri.RI_ID = rid.RI_ID and rid.[ETLInsertProjectExecutionID] = ri.[ETLInsertProjectExecutionID] LEFT OUTER JOIN 
     raw.ci_tbl_host_area as ha on ri.host_area_id = ha.host_area_id LEFT OUTER JOIN 
     raw.ci_tbl_host_area as cha on ri.consumer_host_area_id = cha.host_area_id
where ri.[ETLInsertProjectExecutionID] = @ETLInsertProjectExecutionID
END