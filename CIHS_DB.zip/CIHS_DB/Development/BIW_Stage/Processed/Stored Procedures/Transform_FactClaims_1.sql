﻿CREATE PROCEDURE [Processed].[Transform_FactClaims]
-- =============================================
-- Author:		Justin James
-- Create date: 03/15/2013
-- Description:	Transfrom of FactClaims for BIW. Code exceeds 4000 characters.
--
--	Original Version	03/15/2013
--
--	4/25/2013 - B. Lang	-	removed project ID from join for check detail and credit memo since checks and credit memo 
--							for a claim may not come in on the same project execution as the claim
--  4/29/2013 - B. Lang - utilized temp table to pull claim\claim det\claim adj first for performance reasons
--	5/1/2013	B. Lang	-	Changed join to the COB data to include claim adj ID
--  5/25/2013 - B. Lang -  Change Diag 1 and Diag 2 codes to be based on claim detail first than use claim master
--  5/29/2013	J. James	- changing cast type for client_srv_cat to be char(1) instead of char(3); 
--							  char(3) was causing Grouped Services for claims to not match
--	5/31/2013	J.James		Added new columns/logic for Medicaid County and Medicaid Category
--  6/17/2013   B. Lang		Made following changes to improve performance:
--								-moved the Catchment data into a temp table and added indexes
--								-moved the lookup for Medicaid Aid into the second query
--  6/17/2013	J. James	Added logic for determining ServicesSK because dimServices is now a Type 2 dimension
--	7/30/2013	J. James	Added '0100' and '0183' to ODS.ServicesICFFlagDependency table because tbl_claims_det.srvc_code has leading '0'
--								which was not being accounted for before
--							Changed logic for join to DW.DimServices to check where icf.ServiceCode was in the table (to make the lookup dynamic)
-- 8/7/2013 Gokarn KC  Added the logic to pull the records for Claims based on IPRS data group.
                           -- Added the logic by ci_tbl_IPRS_Claims_sent based on claim_adj_id.
--  8/12/2013	B. Lang		-  Changed ClinicianNPI to look at RenderingNPI first, then AttendingProviderNPI
--  8/15/2013	B. Lang		- Added BillingNPINumber and RenderingBPINiumber 
-- =============================================

	@etlProjectExecutionID int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
--truncate temporary holding table
Truncate table raw.TempClaims;
	
--with recs as (	
--select
--ROW_NUMBER() OVER (PARTITION BY ClientID, planid order by enddate) as RowNum
--,CountyID as regionid
--,CONVERT(VARCHAR(32),clientid) as clientid
--,enddate
--,planid
--,MedicaidCategory
--FROM Raw.Catchment
--)	

select
ROW_NUMBER() OVER (PARTITION BY ClientID, planid order by enddate) as RowNum
,CountyID as regionid
,CONVERT(VARCHAR(32),clientid) as clientid
,enddate
,planid
,MedicaidCategory
into #recs
FROM Raw.Catchment

create index idxRecs on #recs(RowNum,RegionID, ClientID, PlanID,  EndDate)



	
--Pull main claim data
select
	tCM.[claim_mst_id]
	,tCD.[claim_det_id]
	,tCA.[claim_adj_id]
	,CONVERT(DATE,tCM.[create_dt]) AS create_dt
	,CONVERT(DATE,tCM.[recd_dt]) AS recd_dt
	,CONVERT(DATE,tCM.[due_dt]) AS due_dt
	,CONVERT(DATE,tCA.[claim_dt]) AS claim_dt 
	,tCM.[prov_no]
	,tCM.[client_id]
	,COALESCE(tCD.[diag1],tCM.[prin_diag]) AS Diag1
	,COALESCE(tCD.[diag2],tCM.[adm_diag]) AS Diag2
	,tCM.[Other_diag1] AS Diag3
	,tCM.[Other_diag2] AS Diag4
	,tCD.[srvc_id]
	,tCD.[srvc_code]
	,tCA.[claim_amt]
	,tCA.[adjusted_amt]
	,tCA.[adjudicated_amt]
	,tCA.[units]
	,tCA.[adjudicated_units]
	,tCD.[pos_id]
	--,COALESCE(tCM.[prov_npi_no], tCD.[rendering_prov_npi]) AS ClinicianNPI
	,COALESCE(tCD.[rendering_prov_npi],tCM.[AttendingProviderNPI]) AS ClinicianNPI
	,ISNULL(tCA.[plan_id],-1) as plan_id
	,0 as [region_id]
	,0 as orderPlan --case When tCI.[Plan_id] = tCA.[plan_id] then 1 else 2 end as orderPlan
	,COALESCE(tCA.[update_by_id],tCD.[update_by_id],tCM.[update_by_id],tCA.[create_by_id],tCD.[create_by_id],tCM.[create_by_id]) AS updated_by_id
	,CONVERT(DATE,COALESCE(tCA.[update_dt],tCD.[update_dt],tCM.[update_dt],tCA.[create_dt],tCD.[create_dt],tCM.[create_dt])) AS updated_dt
	,tCA.[paid_amt]
	,tCA.[capitated_amt]
	,tCA.[credit_memo_apply_amt]
	,CONVERT(VARCHAR(64),tCA.[paid_flag]) AS paid_flag
	,CONVERT(VARCHAR(64),tCA.[is_capitated]) AS is_capitated
	,LTRIM(RTRIM(tCA.[adj_reason_cd])) AS adj_reason_cd
	,CONVERT(VARCHAR(64),tCA.[status_id]) AS status_id
	,tCM.[ref_no]
	,tCM.[resub_ref_no]
	,tCA.[gp_acct_id]
	,tCM.[deleted]
	,tCA.source_adj_id
	,case when ltrim(rtrim(tcm.bill_type)) IS null then '-1'
	else 
		right(replicate('0000',4) + ltrim(rtrim(tcm.bill_type)),4)
	end as bill_type
	,CAST(ISNULL(tcd.mod1_id, '') AS VARCHAR(2)) + CAST(ISNULL(tcd.mod2_id, '') AS VARCHAR(2)) as ModCode
	,ltrim(rtrim(tcm.claim_type)) as [claim_type]
	,tca.contract_rate
	,isnull(tcd.rev_code,'') as rev_code
	,tca.cob_amt
	,tCM.[SFL_NPI],tCM.[SFL_Provider_ID],tCM.[SFL_Provider_Name],tCM.[SFL_Provider_Address],tCM.[SFL_Provider_City]
	,tCM.[SFL_Provider_State],tCM.[SFL_Provider_Zip]
    ,isnull(tcm.[hipaa_payer_id],'') as [hipaa_payer_id]
    ,tca.check_id
    ,tcm.[ETLInsertProjectExecutionID]
    --Added By Frankie Timmons Jr 5/9/2013
    ,convert(bigint, tca.auth_id) auth_id
    ,LTRIM(RTRIM(tCD.taxonomy_code)) AS taxonomy_code
    ,tcm.prov_npi_no
    ,tcd.rendering_prov_npi
into #Claims
FROM
	[Raw].[CI_tbl_claims_master] AS tCM
	INNER JOIN [Raw].[CI_tbl_claims_det] AS tCD ON
		tCM.[claim_mst_id] = tCD.[claim_mst_id]
		AND tCM.[ETLInsertProjectExecutionID] = tCD.[ETLInsertProjectExecutionID]		
	INNER JOIN [Raw].[CI_tbl_claims_adj] AS tCA ON
		--tCM.[claim_mst_id] = tCA.[claim_mst_id]
		tCD.[claim_mst_id] = tCA.[claim_mst_id]
		AND tCD.[claim_det_id] = tCA.[claim_det_id]
		AND tCA.[current_xn] = 1
		--AND tCM.[ETLInsertProjectExecutionID] = tCA.[ETLInsertProjectExecutionID]
		AND tCD.[ETLInsertProjectExecutionID] = tCA.[ETLInsertProjectExecutionID]
		

where  tCM.[ETLInsertProjectExecutionID] = @etlProjectExecutionID


create index idxClaims on #Claims (client_id, claim_adj_id, adj_reason_cd, plan_id, check_id, ETLInsertProjectExecutionID)

Insert raw.TempClaims
(claim_mst_id, claim_det_id, claim_adj_id, create_dt, recd_dt, due_dt, claim_dt, prov_no, client_id, Diag1, Diag2, Diag3, Diag4, srvc_id, ServicesSK, claim_amt, adjusted_amt, adjudicated_amt, units, adjudicated_units, pos_id, ClinicianNPI, plan_id, region_id, orderPlan, updated_by_id, updated_dt, paid_amt, capitated_amt, credit_memo_apply_amt, paid_flag, is_capitated, adj_reason_cd, status_id, ref_no, resub_ref_no, gp_acct_id, deleted, PaidDate, check_id, source_adj_id, bill_type, client_srv_cat_id, cob_amt, contract_rate, rev_code, ModCode, claim_type, ConsumerLiabilityAmount, AdjudicationReasonAdjustedAmt, auth_id, Notes, SFL_NPI, SFL_Provider_ID, SFL_Provider_Name, SFL_Provider_Address, SFL_Provider_City, SFL_Provider_State, SFL_Provider_Zip, COBPlan, COBInsurance, hipaa_payer_id, regionid, MedicaidCategoryID,Taxonomy_code,IPRSSentDate,IPRSSentStatusCode,IPRSDiag_id,IPRSReasonCode, prov_npi_no, rendering_prov_npi)
SELECT Distinct  -- 8/10 DKB distinct is needed for matching on Ins_ID instead of Plan_ID on the client_Insurance could return multiple rows
	c.[claim_mst_id]
	,c.[claim_det_id]
	,c.[claim_adj_id]
	,c.create_dt
	,c.recd_dt
	,c.due_dt
	,c.claim_dt 
	,c.[prov_no]
	,c.[client_id]
	,c.Diag1
	,c.Diag2
	,c.Diag3
	,c.Diag4
	,c.[srvc_id]
	,ds.ServicesSK
	,c.[claim_amt]
	,c.[adjusted_amt]
	,c.[adjudicated_amt]
	,c.[units]
	,c.[adjudicated_units]
	,c.[pos_id]
	,ClinicianNPI
	,c.plan_id
	,0 as [region_id]
	,0 as orderPlan --case When tCI.[Plan_id] = c.[plan_id] then 1 else 2 end as orderPlan
	,c.updated_by_id
	,CONVERT(DATE,COALESCE(tCAR.create_dt,c.updated_dt)) AS updated_dt
	,c.[paid_amt]
	,c.[capitated_amt]
	,c.[credit_memo_apply_amt]
	,c.paid_flag
	,c.is_capitated
	,c.adj_reason_cd
	,c.status_id
	,c.[ref_no]
	,c.[resub_ref_no]
	,c.[gp_acct_id]
	,c.[deleted]
	,Case when tCKD.check_id = 8032 then convert(Date,tCMD.Create_dt) else convert(DATE,tCKD.[Create_dt]) end AS PaidDate  -- Per Dolores 7/10/2012 always take the Create date for credit Memo
	,tCKD.check_id
	,c.source_adj_id
	,bill_type,
	CASE fsg.client_srv_cat
		WHEN 'Basic Augmented Services' THEN CAST('0' as char(1))
		WHEN 'Basic Services' THEN CAST('1' as char(1))
		WHEN 'Enhanced Services' THEN CAST('2' as char(1))
		ELSE NULL
	END as client_srv_cat_id
	,c.cob_amt
	,c.contract_rate
	,rev_code
	,ModCode
	,[claim_type]
	,isnull(c.cob_amt,0) + isnull(tcar.adjusted_amt,0) as ConsumerLiabilityAmount
	
	/*Added Columns For Sprint 5: Frankie Timmons Jr 3/21/2013*/
	,isnull(tcar.adjusted_amt,0) as [AdjudicationReasonAdjustedAmt]
	--Added By Frankie Timmons Jr 5/9/2013
	,c.[auth_id]
	--
	,ltrim(rtrim(tCAR.notes)) as [Notes] 
	,c.[SFL_NPI]
	,c.[SFL_Provider_ID]
	,c.[SFL_Provider_Name]
	,c.[SFL_Provider_Address]
	,c.[SFL_Provider_City]
	,c.[SFL_Provider_State]
	,c.[SFL_Provider_Zip]
	/*Added Columns For Sprint 5: Frankie Timmons Jr 3/28/2013*/
	,ISNULL(cob.COB_Insurance,'Unknown') as COBPlan
	,ISNULL(cob.COB_Other_Insurance,'Unknown') as COBInsurance
    ,[hipaa_payer_id]
    ,region.regionid
	,ISNULL(region.MedicaidCategory,'UNK') as MedicaidCategoryID
	/*Added Columns relating to IPRS: Gokarna KC 8/7/2013 */
	,ltrim(rtrim(C.taxonomy_code)) as taxonomy_code
	,Convert(date,S.sent_dt) as IPRSSentDate
    ,S.[status] as IPRSSentStatusCode
    ,isnull(S.new_diag_id,'-1') as IPRSDiag_id
    ,S.reason_cd as IPRSReasonCode
    ,c.prov_npi_no
    ,c.rendering_prov_npi
FROM
	#Claims C
	LEFT OUTER JOIN raw.CI_tbl_claims_adj_reason tCAR ON 
		c.claim_adj_id = tCAR.claim_adj_id 
		AND c.adj_reason_cd = tCAR.adj_reason_cd
		AND c.[ETLInsertProjectExecutionID] = tCAR.[ETLInsertProjectExecutionID] 
	Left outer Join Raw.CI_tbl_ben_plans_to_insurance tBPI  -- DKB 8/27/2012 Changed to Left outer since there are PlanID of 0 and Null that would not match. 
		on c.plan_id = tBPI.plan_id
		and c.ETLInsertProjectExecutionID = tBPI.ETLInsertProjectExecutionID	
	LEFT OUTER JOIN [Raw].[CI_tbl_check_det] AS tCKD ON
		c.[check_id] = tCKD.[check_id]
		--AND tCA.[ETLInsertProjectExecutionID] = tCKD.[ETLInsertProjectExecutionID]
		and tCKD.voided <> 1
	left outer join raw.ci_tbl_IPRS_Claims_sent S on S.claim_adj_id =c.claim_adj_id and S.ETLInsertProjectExecutionID=c.ETLInsertProjectExecutionID
	LEFT OUTER JOIN (SELECT MIN(create_dt) as create_dt, apply_to_claim_adj_id, ETLInsertProjectExecutionID 
						FROM RAW.CI_tbl_credit_memo_det 
						GROUP BY apply_to_claim_adj_id, ETLInsertProjectExecutionID) tcmd On
		c.claim_adj_id = tcmd.apply_to_claim_adj_id
		--and tCA.[ETLInsertProjectExecutionID] = tcmd.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN raw.ci_tbl_report_fact_utilization_by_srvc_grouping fsg on
		c.claim_adj_id = fsg.claim_adj_id
	LEFT OUTER JOIN Raw.Client_COB_Lookup cob on cob.client_id = c.client_id
												and cob.Claim_Adj_ID = c.claim_adj_id

	LEFT OUTER JOIN (SELECT  
					c1.regionid,
					c1.clientid,
					ISNULL(c2.EndDate, '1900-01-01') as StartDate,
					c1.EndDate,
					c1.PlanID,
					c1.MedicaidCategory
					FROM #recs c1
					LEFT OUTER JOIN #recs c2 on
						c1.RowNum - 1 = c2.RowNum
						and c1.clientid = c2.clientid
						and c1.PlanID = c2.PlanID) region on
		C.client_id = region.clientid and
		C.plan_id = region.PlanID and
		CONVERT(DATE,C.claim_dt) between region.StartDate and region.EndDate
	LEFT OUTER JOIN biw.dw.dimProvider dp on 
		C.prov_no = dp.ProviderNK and
		C.claim_dt between dp.ETLEffectiveFrom and dp.ETLEffectiveTo
	LEFT OUTER JOIN ODS.ServicesICFFlagDependency icf ON
		ltrim(rtrim(C.srvc_code)) = icf.ServiceCode
	LEFT OUTER JOIN BIW.DW.dimServices ds on
		C.srvc_id = ds.ServicesNK AND
		CASE
			WHEN icf.ServiceCode IS NULL then 'False'
			when icf.ServiceCode in (SELECT ServiceCode from ODS.ServicesICFFlagDependency) and dp.ICF = 'True' then 'True'
			ELSE 'False'
		END = ds.ProviderICFFlag AND
		C.claim_dt BETWEEN ds.ETLEffectiveFrom and ds.ETLEffectiveTo
--WHERE tCM.[ETLInsertProjectExecutionID] = 882--@etlProjectExecutionID

Order by Plan_ID, Client_id
OPTION (FAST 50000)

END