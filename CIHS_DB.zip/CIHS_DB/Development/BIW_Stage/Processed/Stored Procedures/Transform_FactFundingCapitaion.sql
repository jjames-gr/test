﻿-- =============================================
-- Author:		Gokarna KC
-- Create date:  7/15/2013
-- Description:	Transform of factFundingCapition 
-- =============================================
CREATE PROCEDURE [Processed].[Transform_FactFundingCapitaion]
	-- Add the parameters for the stored procedure here

	@etlProjectExecutionID int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    /* Insert statements for procedure here */

--select funding_cap_id,srvc_ids_str
--into #s
-- from biw_stage.raw.CI_tbl_funding_capitation fc
--where srvc_ids_str = ' '


--select * from #s

--drop table #s


Truncate table ODS.FundingCapitation

/*Insert into table #Funding where the srvc_ids_str are not in elements  */
--Insert into ODS.FundingCapitation (Funding_cap_id, srvc_ids_str)
--Select Funding_Cap_id,Srvc_ids_str
--from Raw.Ci_tbl_funding_Capitation 
--where srvc_ids_str not like '%,%'
--and ETLInsertProjectExecutionID =@etlProjectExecutionID

select Funding_cap_id, srvc_ids_str,ETLInsertProjectExecutionID
into #Funding
from Raw.Ci_tbl_funding_Capitation 
where srvc_ids_str like '%,%'

--select * from #Funding  

Declare @cnt int,
 @srvc varchar(5000), 
 @Funding int,
@ETLInsertProjectExecutionID int
/*Set Count  */
Select @cnt = COUNT(*)  from #Funding
/*Create table #Funding1  */
Create table #Funding1
(Funding_Cap_id int,
srvc_ids_str varchar(5000)
,ETLInsertProjectExecutionID int
)

--select * from #Funding
--Drop table #Funding1


/*Loop  */
while @cnt >0
Begin

select Top 1 @srvc =Srvc_ids_str,
@Funding=funding_cap_id
--,@etlProjectExecutionID=ETLInsertProjectExecutionID
from #Funding
insert into #Funding1 
/*Split elements */
Select @Funding ,element,992 from [dbo].[cfn_split] (@srvc,',')
--Delete the record from table #Funding
Delete from #Funding where Funding_Cap_id =@Funding 

Set @cnt =@cnt-1

End

--select * from #Funding1


/*Get data into single table #t   */
select funding_cap_id,srvc_ids_str,ETLInsertProjectExecutionID
into #t
 from biw_stage.raw.CI_tbl_funding_capitation
where srvc_ids_str not like '%,%'
union all
select * from #Funding1
-------------------------------------------------------------------------
select t.funding_cap_id,t.srvc_ids_str,s.ServiceCode,t.ETLInsertProjectExecutionID
into #F
 from #t t
Join biw.dw.dimServices S on S.ServicesNK =t.srvc_ids_str

--select * from #F
select * from ODS.FundingCapitation

Select funding_cap_id--,ETLInsertProjectExecutionID
,Stuff((
Select distinct ',' +serviceCode 
from #F f
where (funding_cap_id=fd.funding_cap_id)
for XML Path (''))
,1,1,'') as Srvc_ID
into #R
from #F fd
group by Funding_cap_id

--Select * from #t
--Select * from #R
--Select * from #F
--select * from #Funding
--Select * from #Funding1

/*Drop  Table */

--Drop table #Funding
--Drop table #Funding1
--Drop Table #t
--Drop Table #F


END