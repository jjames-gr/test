﻿----------- =============================================
-- Author:		Gokarna KC
-- Create date: 7/9/2013
-- Description:	Transfrom of DimServices for BIW. Code exceeds 4000 characters.
--------- =============================================
CREATE PROCEDURE [Processed].[Transform_factGrievances]
	----- Add the parameters for the stored procedure here

	@etlProjectExecutionID int
AS
BEGIN
	----- SET NOCOUNT ON added to prevent extra result sets from
	---- interfering with SELECT statements.
	SET NOCOUNT ON;

    -------- Insert statements for procedure here

Select 
distinct
b.GrievanceResolutionTimeSK
,C.comp_id
,convert(date,C.RECV_DATE) as Recv_date
,Convert( char(8),convert(time,C.RECV_DATE)) as Recv_Time
,CONVERT(date,C.RESOLVE_DATE) as Resolve_Date
--,DATEDIFF(day,convert(date,C.Recv_Date),convert(date,C.Resolve_date)) as ResolutionTime
,DATEDIFF(DAY,convert(date,C.RECV_DATE),ISNULL(convert(date,C.Resolve_date),convert(date,C.recv_date))) as DaysGrievanceResolved
,C.User_ID
,P.ProviderSK
,isnull(C.Agent_ID,-1)  Agent_ID
,isnull(a.USER_ID,-1) as Agent_UserID
,C.taken_by_user_id
,C.COMP_ID  ComplaintProvider_ID
,C.COMP_ID  Complainant_ID
,ISNULL(C.PROV_ID,-1)  Prov_ID
,Convert(varchar(10),C.GrievanceId) as GrievanceId
,C.comp_type_pri
,C.comp_type_sec
,Convert(char(1),C.SUPPRESS_CODE) as SuppressCode
,Convert(char(1),C.SEVERITY_CODE) as SeverityCode
,Convert(varchar(10),C.type_of_service)  Type_of_Service
,Convert(char(1),C.ACTIVE) active
,Convert(char(1),C.other_prov_bit)  other_prov_bit
,Convert(char(1),C.comp_lme_bit) comp_lme_bit
,Convert(char(1),C.use_site_addr) use_site_addr
,Convert(char(1),C.investigation)  Investigation
,isnull(C.griev_id,-1)  Griev_ID
,Convert( varchar(10),C.medicaid_elig)  Medicaid_Elig
,Convert( varchar(10),C.svc_type_id)  Svc_Type_ID
,Convert( varchar(10),C.Source_ID)  Source_ID
,Convert( varchar(10), C.behalf_id )  Behalf_ID
,Convert(varchar(10),C.investigation_outcome)  Investigation_outcome
,Convert(varchar(10),C.SUBMIT_TYPE_ID)  SUBMIT_TYPE_ID
,Convert( varchar(10), isnull(CRT.RESOLVE_TYPE_ID,-1))  Resolve_Type_ID
,Convert(varchar(10),CC.COMPLAINT_CAT_ID)  Complaint_Cat_ID
,Convert( varchar(10), C.resolve_disposition_id)  Resolve_Disposition
,Convert(varchar(10), C.age_grp_id)  age_grp_id
,Convert( varchar(10), C.disability_type_id)  disability_type_id
,Convert( varchar(10),C.Comp_action_id)  Comp_action_id
,Convert(date,C.RESOLVE_FU_DATE) as Resolve_FU_Date
,Convert( varchar(10),C.ResolutionLetterMailed) ResolutionLetterMailed
,Convert( varchar(10),C.RESOLVE_FU_FORMAT) RESOLVE_FU_FORMAT
,Convert( varchar(10),C.griev_form_sent) griev_form_sent
,isnull(C.RESOLVE_BY_USER_ID,-1) as ResolveByUserID
,ISNULL(c.Department,-1) as Department
,C.ETLInsertProjectExecutionID
,C.ETLCreatedDate


FROM [Raw].[CI_tbl_Complaints]  C
left outer join Raw.CI_tbl_Agents A on A.AGENT_ID=c.AGENT_ID
inner join Raw.Ci_tbl_Complaint_sources  S  on S.source_id=C.SOURCE_ID and S.ETLInsertProjectExecutionID =C.ETLInsertProjectExecutionID
left outer  join raw.CI_tbl_Custom_Pick_List  CPL on CPL.key_id=C.behalf_id  and CPL.pick_list_id =57
left outer  join raw.CI_tbl_Custom_Pick_List  CPLS on CPLS.key_id=C.SUBMIT_TYPE_ID																	    and CPLS.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer  join raw.CI_tbl_Custom_Pick_List  CPLR on CPLR.key_id=C.RESOLVE_TYPE_ID																    and CPLR.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer JOIN Raw.CI_tbl_Complaint_Types CT ON C.comp_type_pri = CT.COMPLAINT_TYPE_ID														    and CT.ETLInsertProjectExecutionID =C.ETLInsertProjectExecutionID
left outer JOIN Raw.CI_tbl_Complaint_Category CC ON CT.COMPLAINT_CAT_ID = CC.COMPLAINT_CAT_ID  											    and CC.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID                /*data lost*/
left outer  join raw.CI_tbl_Custom_Pick_List  CPLI on CPLI.key_id=C.investigation_outcome and CPLI.pick_list_id =76            and CPLI.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer  join raw.CI_tbl_Custom_Pick_List  CPLRD on CPLRD.key_id=C.resolve_disposition_id and CPLRD.pick_list_id=62    and CPLRD.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer  join raw.CI_tbl_Custom_Pick_List  CPLA on CPLA.key_id=C.age_grp_id and CPLA.pick_list_id =59									and CPLA.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer  join raw.CI_tbl_Custom_Pick_List  CPLD on CPLD.key_id=C.disability_type_id and CPLD.pick_list_id=60							and CPLRD.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer join raw.CI_tbl_comp_taken_actions CTA on CTA.comp_action_id =C.comp_action_id																and CTA.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer join Raw.CI_tbl_submit_type  ST on ST.submit_type_id =C.submit_type_id																					and ST.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer Join Raw.CI_tbl_complaint_sources CS on CS.source_id=C.SOURCE_ID																							and CS.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer Join   Raw.CI_tbl_complaint_resolve_types  CRT on CRT.RESOLVE_TYPE_ID=C.RESOLVE_TYPE_ID											and CRT.ETLInsertProjectExecutionID=C.ETLInsertProjectExecutionID
left outer join BIW.DW.dimProvider P on P.ProviderNK=C.PROV_ID  and C.RECV_DATE between  p.ETLEffectiveFrom and p.ETLEffectiveTo
left outer join biw.dw.dimGrievanceResolutionTime b on isnull(DATEDIFF(DAY,RECV_DATE,RESOLVE_DATE),-1) between b.GrievanceResolutionTimeBeginRange and b.GrievanceResolutionTimeEndRange


WHERE
C.ACTIVE =1
and
C.[ETLInsertProjectExecutionID] = @etlProjectExecutionID


END