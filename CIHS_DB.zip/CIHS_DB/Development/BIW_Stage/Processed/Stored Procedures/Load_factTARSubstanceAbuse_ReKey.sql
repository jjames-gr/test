﻿/***===============================================================================================
== Name:		[Processed].[Load_factTARSubstanceAbuse_ReKey] 
== Created:		6/7/2013
== Author:		Frankie L Timmons Jr
== Description: Updates The TreatmentAuthorizationRequestSK in [BIW].[DW].[factTARSubstanceAbuse] to
==				reflect SK changes in [BIW].[DW].[factTreatmentAuthorizationRequest]                    
===================================================================================================
== Parameters:
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/
CREATE PROCEDURE [Processed].[Load_factTARSubstanceAbuse_ReKey]
AS
BEGIN
update [BIW].[DW].[factTARSubstanceAbuse]
set [TreatmentAuthorizationRequestSK] = ftar.[facttreatmentauthorizationrequestsk]
FROM [BIW].[DW].[factTARSubstanceAbuse] as ftsa inner join
     [pbhc-newreport].[QM].[dbo].[tbl_Client_TAR_SA] as tsa on tsa.tsa_id = ftsa.[TARSubstanceAbuseID] inner join
     [BIW].[DW].[factTreatmentAuthorizationRequest] as ftar on tsa.tar_id = ftar.tarid
where ftar.[facttreatmentauthorizationrequestsk] <> ftsa.[TreatmentAuthorizationRequestSK]
END