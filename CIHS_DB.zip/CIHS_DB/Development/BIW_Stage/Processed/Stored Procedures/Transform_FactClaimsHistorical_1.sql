﻿
CREATE PROCEDURE [Processed].[Transform_FactClaimsHistorical]
-- =============================================
-- Author:		Frankie L Timmons Jr
-- Create date: 03/27/2013
-- Description:	Transfrom of FactClaimsHistorical for BIW. Code exceeds 4000 characters.
--
-- Original Version - 03/27/2013
--
--	4/25/2013 - B. Lang	-	removed project ID from join for check detail and credit memo since checks and credit memo 
--							for a claim may not come in on the same project execution as the claim
--
--	4/30/2013 - B. Lang - incorporate temp table to store base claim data before left outer joining to other tables.  
--							This was implemented to eliminated a performance issue when loading issue
--
-- 5/4/2013		B. Lang		- changed reason code to be sourced from adj_reason table rather than adj table
--  5/25/2013 - B. Lang -  Change Diag 1 and Diag 2 codes to be based on claim detail first than use claim master

-- 5/29/2013	J. James	- changing cast type for client_srv_cat to be char(1) instead of char(3); 
--							  char(3) was causing Grouped Services for claims to not match
--	5/31/2013	J.James		Added new columns/logic for Medicaid County and Medicaid Category
-- 6/16/2013    B. Lang		Made following changes to improve performance:
--								-moved the Catchment data into a temp table and added indexes
--								-moved the lookup for Medicaid Aid into the second query
--	6/21/2013	J. James	Added logic for determining ServicesSK because dimServices is now a Type 2 dimension
--  7/18/2013   B. Lang		Moved the COB Plan and COB Insurance to the second query in the procedure to improve performance
--	7/30/2013	J. James	Added '0100' and '0183' to ODS.ServicesICFFlagDependency table because tbl_claims_det.srvc_code has leading '0'
--								which was not being accounted for before
--							Changed logic for join to DW.DimServices to check where icf.ServiceCode was in the table (to make the lookup dynamic)
--  8/7/2013 Gokarn KC  Added the logic to pull the records for Claims based on IPRS data group.
                           -- Added the logic by ci_tbl_IPRS_Claims_sent based on claim_adj_id.
--  8/12/2013	B. Lang		-  Changed ClinicianNPI to look at RenderingNPI first, then AttendingProviderNPI
--  8/15/2013	B. Lang		-  added BillingNPINumber and RenderingNPINumber
-- =============================================

	@etlProjectExecutionID int 

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--Truncates holding table
Truncate table raw.TempClaimsHistorical;

select
ROW_NUMBER() OVER (PARTITION BY ClientID, planid order by enddate) as RowNum
,CountyID as regionid
,CONVERT(VARCHAR(32),clientid) as clientid
,BeginDate
,enddate
,planid
,MedicaidCategory
into #recs
FROM Raw.Catchment

create index idxRecs on #recs(RowNum,RegionID, ClientID, PlanID,  EndDate)


--Pulls base claim record
SELECT Distinct 
	tCM.[claim_mst_id],
	tCD.[claim_det_id],
	tCA.[claim_adj_id],
	CONVERT(DATE,tCM.[create_dt]) AS create_dt,
	CONVERT(DATE,tCM.[recd_dt]) AS recd_dt
	,CONVERT(DATE,tCM.[due_dt]) AS due_dt,
	CONVERT(DATE,tCA.[claim_dt]) AS claim_dt,
	tCM.[prov_no],
	tCM.[client_id],
	COALESCE(tCD.[diag1],tCM.[prin_diag]) AS Diag1,
	COALESCE(tCD.[diag2],tCM.[adm_diag]) AS Diag2,
	tCM.[Other_diag1] AS Diag3,
	tCM.[Other_diag2] AS Diag4,
	tCD.[srvc_id],
	tCD.[srvc_code],
	tCA.[claim_amt],
	tCA.[adjusted_amt]
	,tCA.[adjudicated_amt],
	tCA.[units],
	tCA.[adjudicated_units],
	tCD.[pos_id],
	tca.check_id
	--,COALESCE(tCM.[prov_npi_no], tCD.[rendering_prov_npi]) AS ClinicianNPI
	,COALESCE(tCD.[rendering_prov_npi],tCM.[AttendingProviderNPI]) AS ClinicianNPI
	,ISNULL(tCA.[plan_id],-1) as plan_id
	,0 as [region_id]
	,0 as orderPlan 
	,COALESCE(tCA.[update_by_id],tCD.[update_by_id],tCM.[update_by_id],tCA.[create_by_id],tCD.[create_by_id],tCM.[create_by_id]) AS updated_by_id
	,CONVERT(DATE,COALESCE(tCA.[update_dt],tCD.[update_dt],tCM.[update_dt],tCA.[create_dt],tCD.[create_dt],tCM.[create_dt])) AS updated_dt
	,tCA.[paid_amt],
	tCA.[capitated_amt],
	tCA.[credit_memo_apply_amt],
	CONVERT(VARCHAR(64),tCA.[paid_flag]) AS paid_flag,
	CONVERT(VARCHAR(64),tCA.[is_capitated]) AS is_capitated
	,LTRIM(RTRIM(tCA.[adj_reason_cd])) AS adj_reason_cd,
	CONVERT(VARCHAR(64),tCA.[status_id]) AS status_id,
	tCM.[ref_no],
	tCM.[resub_ref_no],
	tCA.[gp_acct_id]
	,tCM.[deleted]
	,tCA.source_adj_id,
	case when ltrim(rtrim(tcm.bill_type)) IS null then '-1'else right(replicate('0000',4) + ltrim(rtrim(tcm.bill_type)),4)end as bill_type   
	,tca.cob_amt
	,tca.contract_rate
	,isnull(tcd.rev_code,'') as rev_code
	,CAST(ISNULL(tcd.mod1_id, '') AS VARCHAR(2)) + CAST(ISNULL(tcd.mod2_id, '') AS VARCHAR(2)) as ModCode
	,ltrim(rtrim(tcm.claim_type)) as [claim_type]
	,convert(bigint,tca.auth_id) as [auth_id]
	,tCM.[SFL_NPI],tCM.[SFL_Provider_ID],tCM.[SFL_Provider_Name],tCM.[SFL_Provider_Address],tCM.[SFL_Provider_City],tCM.[SFL_Provider_State],tCM.[SFL_Provider_Zip],
	--,convert(varchar(512),isnull(STUFF((SELECT DISTINCT ', ' + RTRIM(coi.cob_ins_name)
 --                  FROM  [Raw].[CI_tbl_cob] AS cob inner join 
 --                        [Raw].[CI_tbl_cob_insurers] coi on cob.[cob_ins_id] = coi.[cob_ins_id]
 --                  WHERE [cob].[client_Id] = tcm.client_Id  and 
 --                        tca.[claim_dt] between cob.[OTH_EFF_DATE] and isnull(cob.[OTH_EXP_DATE],'12/31/2999')
 --                  FOR XML PATH('')), 1, 1, ''),'Unknown'),0) as [COBPlan]
 --   ,convert(varchar(512),isnull(STUFF((SELECT DISTINCT ', ' + RTRIM(cob.[oth_insurance])
 --                  FROM  [Raw].[CI_tbl_cob] AS cob
 --                  WHERE cob.[client_Id] = tcm.[client_Id]and tca.[claim_dt] between cob.[OTH_EFF_DATE] and isnull(cob.[OTH_EXP_DATE],'12/31/2999')
 --                  FOR  XML PATH('')),1, 1, ''),'Unknown'),0) as [COBInsurance],
    tcm.[hipaa_payer_id],
    tCM.[ETLInsertProjectExecutionID],
    isnull(tcd.taxonomy_code,-1) taxonomy_code,
    tcm.prov_npi_no,
    tcd.rendering_prov_npi
    

into #ClaimsHistorical    
FROM [Raw].[CI_tbl_claims_master] AS tCM 
	INNER JOIN [Raw].[CI_tbl_claims_det] AS tCD ON tCM.[claim_mst_id] = tCD.[claim_mst_id] AND tCM.[ETLInsertProjectExecutionID] = tCD.[ETLInsertProjectExecutionID] 
	INNER JOIN [Raw].[CI_tbl_claims_adj] AS tCA ON tCM.[claim_mst_id] = tCA.[claim_mst_id] AND tCD.[claim_det_id] = tCA.[claim_det_id] AND tCM.[ETLInsertProjectExecutionID] = tCA.[ETLInsertProjectExecutionID] 
WHERE tCM.[ETLInsertProjectExecutionID] = @etlProjectExecutionID

--crates index
create index idxClaims on #ClaimsHistorical (client_id, claim_adj_id, adj_reason_cd, plan_id, check_id, ETLInsertProjectExecutionID)


--Inserts claim data into temp holding table
Insert raw.TempClaimsHistorical
(claim_mst_id, claim_det_id, claim_adj_id, create_dt, recd_dt, due_dt, claim_dt, prov_no, client_id, Diag1, Diag2, Diag3, Diag4, srvc_id, ServicesSK, claim_amt, adjusted_amt, adjudicated_amt, units, adjudicated_units, pos_id, ClinicianNPI, plan_id, Region_id, orderPlan, updated_by_id, updated_dt, paid_amt, capitated_amt, credit_memo_apply_amt, paid_flag, is_capitated, adj_reason_cd, status_id, ref_no, resub_ref_no, gp_acct_id, deleted, PaidDate, check_id, source_adj_id, bill_type, client_srv_cat_id, cob_amt, contract_rate, ConsumerLiabilityAmount, rev_code, AdjudicationReasonAdjustedAmt, ModCode, claim_type, auth_id, Notes, SFL_NPI, SFL_Provider_ID, SFL_Provider_Name, SFL_Provider_Address, SFL_Provider_City, SFL_Provider_State, SFL_Provider_Zip, COBPlan, COBInsurance, hipaa_payer_id, regionid, MedicaidCategoryID,Taxonomy_code,IPRSSentDate,IPRSSentStatusCode,IPRSDiag_id,IPRSReasonCode, prov_npi_no, rendering_prov_npi)

SELECT Distinct ch.[claim_mst_id],
	ch.[claim_det_id],
	ch.[claim_adj_id],
	ch.create_dt,
	ch.recd_dt
	,ch.due_dt,
	ch.claim_dt,
	ch.[prov_no],
	ch.[client_id],
	ch.Diag1
	,ch.Diag2,
	ch.Diag3,
	ch.Diag4,
	ch.[srvc_id],
	ds.ServicesSK,
	ch.[claim_amt],
	ch.[adjusted_amt]
	,ch.[adjudicated_amt],
	ch.[units],
	ch.[adjudicated_units],
	ch.[pos_id],
	ch.ClinicianNPI
	,ch.plan_id
	,ch.Region_id
	,ch.orderPlan 
	,ch.updated_by_id
	,CONVERT(DATE,COALESCE(tCAR.create_dt,ch.[updated_dt])) AS updated_dt
	,ch.[paid_amt],
	ch.[capitated_amt],
	ch.[credit_memo_apply_amt],
	ch.paid_flag,
	ch.is_capitated
	,tcar.adj_reason_cd,
	ch.status_id,
	ch.[ref_no],ch.[resub_ref_no],ch.[gp_acct_id]
	,ch.[deleted],
	Case when tCKD.check_id = 8032 then convert(Date,tCMD.Create_dt) else convert(DATE,tCKD.[Create_dt]) end AS PaidDate,
	tCKD.check_id
	,ch.source_adj_id,
	ch.bill_type   
	,CASE fsg.client_srv_cat
	 WHEN 'Basic Augmented Services' THEN CAST('0' as char(1))
	 WHEN 'Basic Services' THEN CAST('1' as char(1))
	 WHEN 'Enhanced Services' THEN CAST('2' as char(1)) ELSE NULL END as client_srv_cat_id,
	 ch.cob_amt,
	 ch.contract_rate
	,isnull(ch.cob_amt,0) + isnull(tcar.adjusted_amt,0) as ConsumerLiabilityAmount,
	rev_code,
	isnull(tcar.adjusted_amt,0) as [AdjudicationReasonAdjustedAmt]
	,ch. ModCode, 
	ch.[claim_type],
	convert(bigint, ch.[auth_id]) auth_id,
	ltrim(rtrim(tCAR.notes)) as [Notes] 
	,ch.[SFL_NPI],ch.[SFL_Provider_ID],ch.[SFL_Provider_Name],ch.[SFL_Provider_Address],ch.[SFL_Provider_City],ch.[SFL_Provider_State],ch.[SFL_Provider_Zip]
--	,ch.[COBPlan]
--    ,ch.[COBInsurance],
 	,convert(varchar(512),isnull(STUFF((SELECT DISTINCT ', ' + RTRIM(coi.cob_ins_name)
                   FROM  [Raw].[CI_tbl_cob] AS cob inner join 
                         [Raw].[CI_tbl_cob_insurers] coi on cob.[cob_ins_id] = coi.[cob_ins_id]
                   WHERE [cob].[client_Id] = ch.client_Id  and 
                         ch.[claim_dt] between cob.[OTH_EFF_DATE] and isnull(cob.[OTH_EXP_DATE],'12/31/2999')
                   FOR XML PATH('')), 1, 1, ''),'Unknown'),0) as [COBPlan]
    ,convert(varchar(512),isnull(STUFF((SELECT DISTINCT ', ' + RTRIM(cob.[oth_insurance])
                   FROM  [Raw].[CI_tbl_cob] AS cob
                   WHERE cob.[client_Id] = ch.[client_Id]and ch.[claim_dt] between cob.[OTH_EFF_DATE] and isnull(cob.[OTH_EXP_DATE],'12/31/2999')
                   FOR  XML PATH('')),1, 1, ''),'Unknown'),0) as [COBInsurance],
 
    ch.[hipaa_payer_id],
    region.regionid,
	ISNULL(region.MedicaidCategory,'UNK') as MedicaidCategoryID
		/*Added Columns relating to IPRS: Gokarna KC 8/7/2013 */
  ,ltrim(rtrim(ch.taxonomy_code)) as taxonomy_code
    ,Convert(date,S.sent_dt) as IPRSSentDate
    ,S.status as IPRSSentStatusCode
    ,isnull(S.new_diag_id,'-1') as IPRSDiag_id
    ,Isnull(S.reason_cd,'') as IPRSReasonCode
	,ch.prov_npi_no
	,ch.rendering_prov_npi
FROM #ClaimsHistorical ch
	Left outer join Raw.CI_tbl_claims_adj_reason tcar on tcar.claim_adj_id = ch.claim_adj_id
														and ch.[ETLInsertProjectExecutionID] = tCAR.[ETLInsertProjectExecutionID]

		left outer join raw.ci_tbl_IPRS_Claims_sent S on S.claim_adj_id =ch.claim_adj_id and S.ETLInsertProjectExecutionID=ch.ETLInsertProjectExecutionID

	--LEFT OUTER JOIN (select rsn.claim_adj_id, adjusted_amt, rsn.ETLInsertProjectExecutionID, notes, rsn.create_dt
	--					from Raw.CI_tbl_claims_adj_reason rsn inner join #claims_adj_temp clm
	--						on rsn.claim_adj_id = clm.claim_adj_id
	--							and rsn.create_dt = clm.max_create_dt
	--							and rsn.[ETLInsertProjectExecutionID] = clm.[ETLInsertProjectExecutionID]) tCAR
	--																										on tcar.claim_adj_id = ch.claim_adj_id
	--																											and ch.[ETLInsertProjectExecutionID] = tCAR.[ETLInsertProjectExecutionID]

	LEFT OUTER JOIN [Raw].CI_tbl_ben_plans_to_insurance tBPI on ch.plan_id = tBPI.plan_id	
									and ch.ETLInsertProjectExecutionID = tBPI.ETLInsertProjectExecutionID 
	LEFT OUTER JOIN [Raw].[CI_tbl_check_det] AS tCKD ON ch.[check_id] = tCKD.[check_id] 
								--AND ch.[ETLInsertProjectExecutionID] = tCKD.[ETLInsertProjectExecutionID] --Removed by B. Lang on 4/25/13
								and tCKD.voided <> 1 
	LEFT OUTER JOIN (SELECT MIN(create_dt) as create_dt, apply_to_claim_adj_id, ETLInsertProjectExecutionID 
						FROM RAW.CI_tbl_credit_memo_det 
					GROUP BY apply_to_claim_adj_id, ETLInsertProjectExecutionID) tcmd On ch.claim_adj_id = tcmd.apply_to_claim_adj_id 
																				--and ch.[ETLInsertProjectExecutionID] = tcmd.[ETLInsertProjectExecutionID]  --Removed by B. Lang on 4/25/2013
	LEFT OUTER JOIN [Raw].ci_tbl_report_fact_utilization_by_srvc_grouping fsg on ch.claim_adj_id = fsg.claim_adj_id    
	LEFT OUTER JOIN (SELECT		c1.regionid, 
							   c1.clientid, 
							   CASE 
								 WHEN Datediff(day, c2.enddate, c1.begindate) = 1 THEN c1.begindate 
								 ELSE Isnull(c2.enddate, '1900-01-01') 
							   END AS StartDate, 
							   CASE 
								 WHEN Datediff(day, c1.enddate, c3.begindate) = 1 THEN c1.enddate 
								 ELSE c1.enddate 
							   END AS EndDate, 
							   c1.planid, 
							   c1.medicaidcategory 
						FROM   #recs c1 
							   LEFT OUTER JOIN #recs c2 
											ON c1.rownum - 1 = c2.rownum 
											   AND c1.clientid = c2.clientid 
											   AND c1.planid = c2.planid 
							   LEFT OUTER JOIN #recs c3 
											ON c1.rownum + 1 = c3.rownum 
											   AND c1.clientid = c3.clientid 
											   AND c1.planid = c3.planid) region on
			ch.client_id = region.clientid and
			ch.plan_id = region.PlanID and
			CONVERT(DATE,ch.claim_dt) between region.StartDate and region.EndDate
	LEFT OUTER JOIN biw.dw.dimProvider dp on 
		ch.prov_no = dp.ProviderNK and
		ch.claim_dt between dp.ETLEffectiveFrom and dp.ETLEffectiveTo
	LEFT OUTER JOIN ODS.ServicesICFFlagDependency icf ON
		ltrim(rtrim(ch.srvc_code)) = icf.ServiceCode
	LEFT OUTER JOIN BIW.DW.dimServices ds on
		ch.srvc_id = ds.ServicesNK AND
		CASE
			WHEN icf.ServiceCode IS NULL then 'False'
			when icf.ServiceCode in (SELECT ServiceCode from ODS.ServicesICFFlagDependency) and dp.ICF = 'True' then 'True'
			ELSE 'False'
		END = ds.ProviderICFFlag AND
		ch.claim_dt BETWEEN ds.ETLEffectiveFrom and ds.ETLEffectiveTo

--Removing Order By clause, since it was only needed for the range lookup scripts in SSIS
--Order by ch.Plan_ID, Client_id


END