﻿CREATE PROCEDURE [Processed].[Transform_CountyCatchment]
-- =============================================
-- Author:		Justin James
-- Create date: 02/14/2012
-- Description:	Transfrom of CountyCatchment for BIW. Code exceeds 4000 characters.
-- =============================================

	@etlProjectExecutionID int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

TRUNCATE TABLE Raw.CountyCatchment_Holding

INSERT INTO Raw.CountyCatchment_Holding (
	ClientID,
	PlanID,
	DOS,
	CountyID,
	CountyCode,
	COA,
	County,
	CatchmentID,
	Catchment,
	ins_number,
	RecNum
)

SELECT 
		DISTINCT cm.client_id                                        AS ClientID, 
                ca.plan_id                                          AS PlanID, 
                ca.claim_dt                                         AS DOS, 
                Isnull(ci.region_id, 2)                             AS CountyID, 
                Isnull(Isnull(pcc.county_code, r.county_code), 'X') AS 
                CountyCode, 
                ISNULL(CASE ca.plan_id
						WHEN 1 then '99'
						else coa.cat_aid
					END,-1)			AS COA, 
                COALESCE(pcc.county, r.county, 'Unknown')           AS County, 
                ci.catchment_id                                     AS 
                CatchmentID, 
                cpl.pick_value                                      AS Catchment, 
                ci.ins_number,
                1 as recnum
FROM   raw.ci_tbl_claims_master AS cm 
       INNER JOIN raw.ci_tbl_claims_det AS cd WITH(nolock) 
               ON cm.claim_mst_id = cd.claim_mst_id 
                  AND cm.[etlinsertprojectexecutionid] = cd.[etlinsertprojectexecutionid] 
       INNER JOIN raw.ci_tbl_claims_adj AS ca WITH(nolock) 
               ON cd.claim_det_id = ca.claim_det_id 
                  AND ca.[etlinsertprojectexecutionid] = 
                      cm.[etlinsertprojectexecutionid] 
       LEFT OUTER JOIN raw.ci_tbl_client_insurance AS ci WITH(nolock) 
                    ON cm.client_id = ci.client_id 
                       AND ca.plan_id = ci.plan_id 
       LEFT OUTER JOIN (SELECT DISTINCT a.client_id, 
                               Substring(elig_coa, 1, 3) AS cat_aid, 
                               b.ins_id, 
                               b.plan_id,
                               elig_eff_dt, 
                               elig_exp_dt 
                        FROM   raw.ci_tbl_client_coa a WITH (nolock) 
                               INNER JOIN raw.ci_tbl_client_insurance b WITH (nolock) 
                                       ON a.client_id = b.client_id 
                        UNION
                        SELECT DISTINCT a.client_id, 
                               Substring(elig_coa, 1, 3) AS cat_aid, 
                               b.ins_id, 
                               b.plan_id,
                               CAST('1/1/1900' as datetime), 
                               c.elig_exp_dt
                        FROM   raw.ci_tbl_client_coa a WITH (nolock) 
                               INNER JOIN raw.ci_tbl_client_insurance b WITH (nolock) 
                                       ON a.client_id = b.client_id
                               INNER JOIN (SELECT client_id, MIN(elig_exp_dt) as elig_exp_dt FROM raw.ci_tbl_client_coa WITH (nolock) 
											GROUP BY client_id) c ON
									a.client_id = c.client_id and
									a.elig_exp_dt = c.elig_exp_dt
                       ) AS coa 
                    ON cm.client_id = coa.client_id 
                       AND ci.ins_id = coa.ins_id 
                       AND ca.claim_dt BETWEEN elig_eff_dt AND ISNULL(elig_exp_dt,'12/31/2099') 
       LEFT OUTER JOIN raw.ci_tbl_prov_catch_counties AS pcc WITH(nolock) 
                    ON ci.region_id = pcc.region_id 
       LEFT OUTER JOIN raw.ci_tbl_custom_pick_list AS cpl WITH(nolock) 
                    ON ci.catchment_id = cpl.[key_id] 
                       AND ca.[etlinsertprojectexecutionid] = 
                           cpl.[etlinsertprojectexecutionid] 
       LEFT OUTER JOIN raw.ci_tbl_regions AS R WITH (nolock) 
                    ON ci.region_id = R.region_id 
WHERE  ca.claim_dt BETWEEN ci.eff_dt AND Isnull(ci.exp_dt, '12/31/2099') 
       AND cm.[etlinsertprojectexecutionid] = @etlProjectExecutionID
       AND cpl.pick_list_id = 135 
       AND ci.create_dt = (SELECT Max(t1.create_dt) 
                           FROM   raw.ci_tbl_client_insurance t1 
                           WHERE  t1.client_id = ci.client_id 
                                  AND t1.plan_id = ci.plan_id 
                                  AND ca.claim_dt BETWEEN t1.eff_dt AND 
       Isnull(t1.exp_dt, '12/31/2099')) 
       AND ci.eff_dt = (SELECT Min(eff_dt) 
                        FROM   raw.ci_tbl_client_insurance t2 
                        WHERE  t2.client_id = ci.client_id 
                               AND t2.plan_id = ci.plan_id 
                               AND ca.claim_dt BETWEEN t2.eff_dt AND 
Isnull(t2.exp_dt, '12/31/2099'))

UNION

SELECT 
		DISTINCT cm.client_id                                        AS ClientID, 
                ca.plan_id                                          AS PlanID, 
                ca.claim_dt                                         AS DOS, 
                Isnull(ci.region_id, 2)                             AS CountyID, 
                Isnull(Isnull(pcc.county_code, r.county_code), 'X') AS 
                CountyCode, 
                ISNULL(CASE ca.plan_id
						WHEN 1 then '99'
						else coa.cat_aid
					END,-1)			AS COA, 
                COALESCE(pcc.county, r.county, 'Unknown')           AS County, 
                ci.catchment_id                                     AS 
                CatchmentID, 
                cpl.pick_value                                      AS Catchment, 
                ci.ins_number,
                CASE
					WHEN ci.client_id IS NULL THEN 1
					WHEN min_dt.client_id IS NULL THEN 0
					ELSE 
						CASE
							WHEN ca.claim_dt between ci.eff_dt AND Isnull(ci.exp_dt, '12/31/2099') THEN 1
							ELSE 0
						END
				END as recnum		         
FROM   raw.ci_tbl_claims_master AS cm 
       INNER JOIN raw.ci_tbl_claims_det AS cd WITH(nolock) 
               ON cm.claim_mst_id = cd.claim_mst_id 
                  AND cm.[etlinsertprojectexecutionid] = cd.[etlinsertprojectexecutionid] 
       INNER JOIN raw.ci_tbl_claims_adj AS ca WITH(nolock) 
               ON cd.claim_det_id = ca.claim_det_id 
                  AND ca.[etlinsertprojectexecutionid] = 
                      cm.[etlinsertprojectexecutionid] 
       LEFT OUTER JOIN raw.ci_tbl_client_insurance AS ci WITH(nolock) 
                    ON cm.client_id = ci.client_id 
                       AND ca.plan_id = ci.plan_id 
       LEFT OUTER JOIN (SELECT DISTINCT a.client_id, 
                               Substring(elig_coa, 1, 3) AS cat_aid, 
                               b.ins_id, 
                               b.plan_id,
                               elig_eff_dt, 
                               elig_exp_dt 
                        FROM   raw.ci_tbl_client_coa a WITH (nolock) 
                               INNER JOIN raw.ci_tbl_client_insurance b WITH (nolock) 
                                       ON a.client_id = b.client_id 
                        UNION
                        SELECT DISTINCT a.client_id, 
                               Substring(elig_coa, 1, 3) AS cat_aid, 
                               b.ins_id, 
                               b.plan_id,
                               CAST('1/1/1900' as datetime), 
                               c.elig_exp_dt
                        FROM   raw.ci_tbl_client_coa a WITH (nolock) 
                               INNER JOIN raw.ci_tbl_client_insurance b WITH (nolock) 
                                       ON a.client_id = b.client_id
                               INNER JOIN (SELECT client_id, MIN(elig_exp_dt) as elig_exp_dt FROM raw.ci_tbl_client_coa WITH (nolock) 
											GROUP BY client_id) c ON
									a.client_id = c.client_id and
									a.elig_exp_dt = c.elig_exp_dt
                       ) AS coa 
                    ON cm.client_id = coa.client_id 
                       AND ci.ins_id = coa.ins_id 
                       AND ca.claim_dt BETWEEN elig_eff_dt AND ISNULL(elig_exp_dt,'12/31/2099') 
       LEFT OUTER JOIN raw.ci_tbl_prov_catch_counties AS pcc WITH(nolock) 
                    ON ci.region_id = pcc.region_id 
       LEFT OUTER JOIN raw.ci_tbl_custom_pick_list AS cpl WITH(nolock) 
                    ON ci.catchment_id = cpl.[key_id] 
                       AND ca.[etlinsertprojectexecutionid] = 
                           cpl.[etlinsertprojectexecutionid] 
       LEFT OUTER JOIN raw.ci_tbl_regions AS R WITH (nolock) 
                    ON ci.region_id = R.region_id 
       LEFT OUTER JOIN (SELECT Min(eff_dt) as min_date, t2.client_id, t2.plan_id 
                        FROM   raw.ci_tbl_client_insurance t2 
                               GROUP BY t2.client_id, t2.plan_id) min_dt
                    ON cm.client_id = min_dt.client_id
						AND ci.plan_id = min_dt.plan_id
						AND ci.eff_dt = min_dt.min_date
WHERE  ca.claim_dt between ISNULL(coa.elig_eff_dt,'1/1/1900') and ISNULL(coa.elig_exp_dt,'12/31/2099')
       AND cm.[etlinsertprojectexecutionid] = @etlProjectExecutionID
       AND cpl.pick_list_id = 135              
END

SELECT 
	ClientID,
	PlanID,
	DOS,
	CountyID,
	CountyCode,
	COA,
	County,
	CatchmentID,
	Catchment,
	ins_number
FROM Raw.CountyCatchment_Holding
WHERE RecNum = 1