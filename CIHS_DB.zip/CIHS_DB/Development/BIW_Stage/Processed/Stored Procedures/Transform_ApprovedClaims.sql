﻿---Insert Comments Here

/***===============================================================================================
== Name:		Transfrom_ApprovedClaims 
== Created:		4/26/2013
== Author:		Bob Lang
== Description: Pulls together the approved claims with the claim historical data
==				When linking to the claims historical data, need to determine the effective date range
==				for an adjudication record based on the Adjudication Date
== Modified: 4/29/2013
== Modifier: Frankie L Timmons Jr.
== Change Description: Added Code Section To Pull Approved Claims records that have an orphan 
                      factClaimsHistoricalSK in order to be re-processed
== Modified: 5/2/2013
== Modifier: Frankie L Timmons Jr.
== Change Description: Added DexDateSK to TempApprovedClaims table
                     
== Modified: 7/16/2013
== Modifier: Frankie L Timmons Jr.
== Change Description: Added TableName column to TempApprovedClaims table; Added new filter criteria

== Modified: 8/15/2013
== Modifier: Gokarna KC
== Change Description: Added GLBatchNumber column to TempApprovedClaims Table
===================================================================================================
== Parameters:
==	@iExecutionProjectID - used to select the raw GL data
===================================================================================================
== Version:		1.0.000
== Revisions:	1
===============================================================================================***/

CREATE procedure [Processed].[Transform_ApprovedClaims]
	@iExecutionProjectID int
	
	with Recompile
as
Begin

--Pull GL Data for project id
select
	convert(bigint, GL_ClaimAdj) GL_ClaimAdj,
	TRXDATE,
	ApprovedClaimAmount,
	ApprovedClaimNK,
	DEX_ROW_TS,TableName
	,tmp.GLBatchNumber
into #GL
from
	(	select 
			REPLACE(REPLACE(REPLACE(GL2.ordocnum, 'C', ''), 'I',''), 'R', '')  GL_ClaimAdj,
			GL2.DEX_ROW_ID ApprovedClaimNK,
			convert(int, convert(varchar, trxdate,112))TRXDATE,
			sum(gl2.debitamt- gl2.crdtamnt) as ApprovedClaimAmount,
			CONVERT(INT, CONVERT(varchar, GL2.DEX_ROW_TS,112)) DEX_ROW_TS,'GL20000' as TableName
			,PM.BACHNUMB as GLBatchNumber
		from [RAW].[GP_GL20000] as GL2 
			INNER JOIN [Raw].[GP_GL00100] as GL1 ON GL2.actindx = GL1.actindx 
									AND GL2.ETLInsertProjectExecutionID = GL1.ETLInsertProjectExecutionID 
	    left outer join Raw.GP_PM30200 PM on PM.DOCNUMBR=GL2.ORDOCNUM and GL2.ORTRXSRC =PM.TRXSORCE and PM.ETLInsertProjectExecutionID =GL2.ETLInsertProjectExecutionID
		Where 
			GL1.actnumbr_2 between 0000 and 1110 
					
			AND (GL1.actnumbr_3 BETWEEN 5210 AND 5299  
					OR GL1.actnumbr_3 BETWEEN 5310 AND 5399 
					OR GL1.actnumbr_3 BETWEEN 5110 AND 5199)
										
			AND GL2.ormstrid LIKE 'CI%'
			AND GL2.ordocnum LIKE 'CI%'
			AND dscriptn = 'Purchases' 
			AND GL2.voided = 0 
			and GL2.[ETLInsertProjectExecutionID] = @iExecutionProjectID
		group by 
			REPLACE(REPLACE(REPLACE(GL2.ordocnum, 'C', ''), 'I',''), 'R', '') ,
			GL2.DEX_ROW_ID,
			convert(int, convert(varchar, trxdate,112)),
			CONVERT(INT, CONVERT(varchar, GL2.DEX_ROW_TS,112))
			,PM.BACHNUMB
		Union
		select 
			REPLACE(REPLACE(REPLACE(GL3.ordocnum, 'C', ''), 'I',''), 'R', '')  GL_ClaimAdj,
			GL3.DEX_ROW_ID ApprovedClaimNK,
			convert(int, convert(varchar, trxdate,112))TRXDATE,
			sum(GL3.debitamt- GL3.crdtamnt) as ApprovedClaimAmount,
			CONVERT(INT, CONVERT(varchar, GL3.DEX_ROW_TS,112)) DEX_ROW_TS,'GL30000' as TableName
			,PM.BACHNUMB as GLBatchNumber
		from [RAW].[GP_GL30000] as GL3 
			INNER JOIN [Raw].[GP_GL00100] as GL1 ON GL3.actindx = GL1.actindx 
												AND GL3.ETLInsertProjectExecutionID = GL1.ETLInsertProjectExecutionID 
	    left outer join Raw.GP_PM30200 PM on PM.DOCNUMBR=GL3.ORDOCNUM and GL3.ORTRXSRC =PM.TRXSORCE and PM.ETLInsertProjectExecutionID =GL3.ETLInsertProjectExecutionID

		Where 
			GL1.actnumbr_2 between 0000 and 1110 
			AND (GL1.actnumbr_3 BETWEEN 5210 AND 5299  
					OR GL1.actnumbr_3 BETWEEN 5310 AND 5399 
					OR GL1.actnumbr_3 BETWEEN 5110 AND 5199)
					
			AND GL3.ormstrid LIKE 'CI%'
			AND GL3.ordocnum LIKE 'CI%'
			AND dscriptn = 'Purchases' 
			AND GL3.voided = 0 
			and  GL3.[ETLInsertProjectExecutionID] = @iExecutionProjectID
		group by 
			REPLACE(REPLACE(REPLACE(GL3.ordocnum, 'C', ''), 'I',''), 'R', ''),
			GL3.DEX_ROW_ID,
			convert(int, convert(varchar, trxdate,112)),
			CONVERT(INT, CONVERT(varchar, GL3.DEX_ROW_TS,112))
			,PM.BACHNUMB
		) tmp

/*Added By Frankie Timmons Jr: Pull Approved Claims records that have an orphan factClaimsHistoricalSK in order to be re-processed*/

--Insert into #GL
--select
--	convert(bigint, GL_ClaimAdj) GL_ClaimAdj,
--	TRXDATE,
--	ApprovedClaimAmount,
--	ApprovedClaimNK,
--	DEX_ROW_TS
--from
--	(
--select REPLACE(REPLACE(REPLACE(GL3.ordocnum, 'C', ''), 'I',''), 'R', '')  GL_ClaimAdj,
--	   GL3.DEX_ROW_ID ApprovedClaimNK,
--	   convert(int, convert(varchar, trxdate,112))TRXDATE,
--	   sum(GL3.debitamt- GL3.crdtamnt) as ApprovedClaimAmount,
--	   CONVERT(INT, CONVERT(varchar, GL3.DEX_ROW_TS,112)) DEX_ROW_TS
--from [biw_stage].[RAW].[GP_GL30000] as GL3
--where GL3.DEX_ROW_ID in ( 
--Select a.[ApprovedClaimsNK]
--from biw.dw.factApprovedClaims as a left outer join
--     biw.dw.factClaimsHistorical as b on a.[factClaimsHistoricalSK] = b.[factClaimsHistoricalSK]
--where b.[factClaimsHistoricalSK] is null)
--group by 
--			REPLACE(REPLACE(REPLACE(GL3.ordocnum, 'C', ''), 'I',''), 'R', '') ,
--			GL3.DEX_ROW_ID,
--			convert(int, convert(varchar, trxdate,112)),
--			CONVERT(INT, CONVERT(varchar, GL3.DEX_ROW_TS,112))
			
--union
			
--select REPLACE(REPLACE(REPLACE(GL2.ordocnum, 'C', ''), 'I',''), 'R', '')  GL_ClaimAdj,
--			GL2.DEX_ROW_ID ApprovedClaimNK,
--			convert(int, convert(varchar, trxdate,112))TRXDATE,
--			sum(gl2.debitamt- gl2.crdtamnt) as ApprovedClaimAmount,
--			CONVERT(INT, CONVERT(varchar, GL2.DEX_ROW_TS,112)) DEX_ROW_TS
--		from [biw_stage].[RAW].[GP_GL20000] as GL2 
--where GL2.DEX_ROW_ID in ( 
--Select a.[ApprovedClaimsNK]
--from biw.dw.factApprovedClaims as a left outer join
--     biw.dw.factClaimsHistorical as b on a.[factClaimsHistoricalSK] = b.[factClaimsHistoricalSK]
--where b.[factClaimsHistoricalSK] is null)
--group by 
--			REPLACE(REPLACE(REPLACE(GL2.ordocnum, 'C', ''), 'I',''), 'R', '') ,
--			GL2.DEX_ROW_ID,
--			convert(int, convert(varchar, trxdate,112)),
--			CONVERT(INT, CONVERT(varchar, GL2.DEX_ROW_TS,112))
-- ) orp
/*End of changes - FT*/

create unique clustered index idxGL on #GL (GL_ClaimAdj, ApprovedClaimNK, DEX_ROW_TS)--TRXDATE)


--Pull Claims Historical Data and rank each claim adjudication number by adjudication date
select
	ch.factClaimsHistoricalSK,
	ch.AdjudicationDateSK AdjudicationBegDateSK,
	ch.ClaimAdjudicationNumber,
	ch.glaccountsk,
	ch.createdatesk,
	ch.providersk,
	ch.servicessk,
	ch.organizationsk,
	ch.BenefitPlanSK, 
	ch.diagnosis1sk, 
	ch.paidsk, 
	ch.capitatedsk,
	Row_Number()over(Partition By ClaimAdjudicationNumber order by AdjudicationDateSK, factClaimsHistoricalSK) CurRank
into #Rank
from
	biw.dw.factClaimsHistorical ch
where
	--only pull history records where gl data has a claim adj reocrd
	ClaimAdjudicationNumber in (select distinct GL_ClaimAdj from #GL)

create unique clustered index idxRank on #Rank(ClaimAdjudicationNumber, CurRank)


Insert raw.TempApprovedClaims
(
	factClaimsHistoricalSK,
	AdjudicationDateSK,
	ClaimAdjudicationNumber,
	GLAccountSK,
	CreateDateSK,
	ProviderSK,
	ServicesSK,
	OrganizationSK,
	BenefitPlanSK, 
	Diagnosis1SK, 
	PaidSK, 
	CapitatedSK,
	ApprovedClaimNK,
	TRXDate,
	ApprovedClaimAmount,
	DexDateSK,
	TableName,GLBatchNumber
)
select
	t.factClaimsHistoricalSK,
	t.AdjudicationDateSK,
	--t.ClaimAdjudicationNumber,
	gl.GL_ClaimAdj,
	t.GLAccountsk,
	t.CreateDateSK,
	t.ProviderSK,
	t.ServicesSK,
	t.OrganizationSK,
	t.BenefitPlanSK, 
	t.Diagnosis1SK, 
	t.PaidSK, 
	t.CapitatedSK,
	GL.ApprovedClaimNK,
	GL.TRXDate,
	GL.ApprovedClaimAmount,
	GL.DEX_ROW_TS, --Added Column: Frankie L Timmons Jr 5/2/2013
	GL.TableName,
	GL.GLBatchNumber
from #GL gl Left outer join 
    (select r.factClaimsHistoricalSK,
						r.AdjudicationBegDateSK AdjudicationDateSK,
						r.AdjudicationBegDateSK,
						isnull(r2.AdjudicationBegDateSK-1,99991231) AdjudicationEndDateSK,
						r.ClaimAdjudicationNumber,
						r.GLAccountsk,
						r.CreateDateSK,
						r.ProviderSK,
						r.ServicesSK,
						r.OrganizationSK,
						r.BenefitPlanSK, 
						r.Diagnosis1SK, 
						r.PaidSK, 
						r.CapitatedSK
					from #Rank r
					left outer join #Rank r2 on r2.ClaimAdjudicationNumber = r.ClaimAdjudicationNumber
					and r.CurRank = r2.CurRank - 1
				) t on gl.GL_ClaimAdj = t.ClaimAdjudicationNumber
						and gl.DEX_ROW_TS between t.AdjudicationBegDateSK and t.AdjudicationEndDateSK

end