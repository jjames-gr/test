﻿

-- =============================================
-- Author:		David Botzenhart
-- Create date: 09/17/2012
-- Description:	Transfrom of DimServices for BIW. Code exceeds 4000 characters.
--
-- =============================================
CREATE PROCEDURE [Processed].[Transform_tempdimServices]

	@etlProjectExecutionID int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT
	tS.[srvc_id]
	,tS.[srvc_code]
	,tS.[srvc_desc]
	,tS.[srvc_short_desc]
	,tS.[mod_id1]
	,tS.[mod_id2]
	,tS.[active]
	,ISNULL(tSTS.[SRVC_SUM_ID], -1) AS SRVC_SUM_ID
	,ISNULL(tSS.[SRVC_SUM_DESC], 'Unknown') AS SRVC_SUM_DESC
	,ISNULL(tSD.[srvc_def_id], -1) AS srvc_def_id
	,ISNULL(tSD.[srvc_def_desc], 'Unknown') AS srvc_def_desc	
	,CASE
		WHEN icf.ServiceCode IS NULL then 'False'
		WHEN icf.ServiceCode IS NOT NULL and tss.SRVC_SUM_DESC = 'ICF' then 'True'
		ELSE 'False'
	END as ProviderICFFlag
--	,case -- DKB 11/2012 removed because of Structure change of CI tbl_Service 
--	when tS.is_basic = 1 
--	then convert(varchar(8),'Basic') 
--	when tS.is_basic <> 1 and tS.srvc_id not in(1170,
--37,
--38,
--39,
--40,
--53,
--74,
--167,
--176) 
--then convert(varchar(8),'Enhanced') 
--end as IsBasic
FROM
	[Raw].[CI_tbl_services] AS tS
	LEFT OUTER JOIN [Raw].[CI_tbl_services_to_summary] AS tSTS ON
		ts.[srvc_id] = tSTS.[srvc_id]
		AND tSTS.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTS.[eff_dt], '1/1/1900') AND ISNULL(tSTS.[end_dt], '12/31/9999')
		AND ts.[ETLInsertProjectExecutionID] = tSTS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [Raw].[CI_tbl_Service_Summary] AS tSS ON
		tSTS.[SRVC_SUM_ID] = tSS.[SRVC_SUM_ID]
		AND tSTS.[ETLInsertProjectExecutionID] = tSS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [Raw].[CI_tbl_services_to_def] AS tSTD ON
		tS.[srvc_id] = tSTD.[srvc_id]
		AND tSTD.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTD.[eff_dt], '1/1/1900') AND ISNULL(tSTD.[end_dt], '12/31/9999')
		AND tS.[ETLInsertProjectExecutionID] = tSTD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [Raw].[CI_tbl_service_definitions] AS tSD ON
		tSTD.[srvc_def_id] = tSD.[srvc_def_id]
		AND tSTD.[eff_dt] BETWEEN ISNULL(tSD.[eff_dt], '1/1/1900') AND ISNULL(tSD.[end_dt], '12/31/9999')
		AND tSTD.[ETLInsertProjectExecutionID] = tSD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN ODS.ServicesICFFlagDependency icf ON
		ltrim(rtrim(ts.srvc_code)) = icf.ServiceCode
WHERE
	tS.[ETLInsertProjectExecutionID] = @etlProjectExecutionID
	and tS.srvc_id not in (1, -2) /* -2 All grouping */	
	
union	

SELECT distinct
	tS.[srvc_id]
	,tS.[srvc_code]
	,tS.[srvc_desc]
	,tS.[srvc_short_desc]
	,tS.[mod_id1]
	,tS.[mod_id2]
	,CAST('1' as BIT) as [active]		
	,CASE
		WHEN tSD.srvc_def_desc = 'INPATIENT HOSPITALIZATION' then 3
		WHEN tSD.srvc_def_desc = 'INTERMEDIATE CARE FACILITY (ICF)' then 5
	END as SRVC_SUM_ID
	,CASE
		WHEN tSD.srvc_def_desc = 'INPATIENT HOSPITALIZATION' then CAST('Inpatient' as varchar(250))
		WHEN tSD.srvc_def_desc = 'INTERMEDIATE CARE FACILITY (ICF)' then CAST('ICF' as varchar(250))
	END as SRVC_SUM_DESC
	,CASE
		WHEN tSD.srvc_def_desc = 'INPATIENT HOSPITALIZATION' then 45
		WHEN tSD.srvc_def_desc = 'INTERMEDIATE CARE FACILITY (ICF)' then 46
	END as srvc_def_id
	,CASE
		WHEN tSD.srvc_def_desc = 'INPATIENT HOSPITALIZATION' then CAST('Inpatient Hospitalization' AS varchar(50))
		WHEN tSD.srvc_def_desc = 'INTERMEDIATE CARE FACILITY (ICF)' then CAST('Intermediate Care Facility (ICF)' as varchar(50))
	END as srvc_def_desc	
	,CASE
		WHEN icf.ServiceCode IS NULL OR tsd.srvc_def_desc = 'INPATIENT HOSPITALIZATION' then 'False'
		WHEN icf.ServiceCode IS NOT NULL and (tss.SRVC_SUM_DESC = 'ICF' OR tsd.srvc_def_desc = 'INTERMEDIATE CARE FACILITY (ICF)') then 'True'
		ELSE 'False'
	END as ProviderICFFlag
FROM
	[Raw].[CI_tbl_services] AS tS
	LEFT OUTER JOIN [Raw].[CI_tbl_services_to_summary] AS tSTS ON
		ts.[srvc_id] = tSTS.[srvc_id]
		AND tSTS.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTS.[eff_dt], '1/1/1900') AND ISNULL(tSTS.[end_dt], '12/31/9999')
		AND ts.[ETLInsertProjectExecutionID] = tSTS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [Raw].[CI_tbl_Service_Summary] AS tSS ON
		tSTS.[SRVC_SUM_ID] = tSS.[SRVC_SUM_ID]
		AND tSTS.[ETLInsertProjectExecutionID] = tSS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [Raw].[CI_tbl_services_to_def] AS tSTD ON
		tS.[srvc_id] = tSTD.[srvc_id]
		AND tSTD.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTD.[eff_dt], '1/1/1900') AND ISNULL(tSTD.[end_dt], '12/31/9999')
		AND tS.[ETLInsertProjectExecutionID] = tSTD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [Raw].[CI_tbl_service_definitions] AS tSD ON
		tSTD.[srvc_def_id] = tSD.[srvc_def_id]
		AND tSTD.[eff_dt] BETWEEN ISNULL(tSD.[eff_dt], '1/1/1900') AND ISNULL(tSD.[end_dt], '12/31/9999')
		AND tSTD.[ETLInsertProjectExecutionID] = tSD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN ODS.ServicesICFFlagDependency icf ON
		ltrim(rtrim(ts.srvc_code)) = icf.ServiceCode
WHERE
	tS.[ETLInsertProjectExecutionID] = @etlProjectExecutionID
	and tS.srvc_id = 1	

Union

SELECT distinct 
	 convert(int,'-2'+CONVERT(varchar(4),tSD.[srvc_def_id])) as srvc_id
	,'-2' + CONVERT(varchar(4),tSD.[srvc_def_id])+ ' ' + tS.[srvc_code] as srvc_code
	,upper(rtrim(tS.[srvc_code]))+ ' ' + ltrim(tSD.[srvc_def_desc]) as srvc_desc
	,tS.[srvc_short_desc]
	,tS.[mod_id1]
	,tS.[mod_id2]
	,tS.[active]
	,ISNULL(x.[SRVC_SUM_ID], -1) AS SRVC_SUM_ID
	,ISNULL(x.[SRVC_SUM_DESC], 'Unknown') AS SRVC_SUM_DESC
	,ISNULL(tSD.[srvc_def_id], -1) AS srvc_def_id
	,ISNULL(tSD.[srvc_def_desc], 'Unknown') AS srvc_def_desc
	,CASE
		WHEN icf.ServiceCode IS NULL then 'False'
		WHEN icf.ServiceCode IS NOT NULL and tss.SRVC_SUM_DESC = 'ICF' then 'True'
		ELSE 'False'
	END as ProviderICFFlag
----	,case 
----	when tS.is_basic = 1 
----	then convert(varchar(8),'Basic') 
----	when tS.is_basic <> 1 and tS.srvc_id not in(1170,
----37,
----38,
----39,
----40,
----53,
----74,
----167,
----176) 
--then convert(varchar(8),'Enhanced') 
--end as IsBasic
FROM
	[raw].[CI_tbl_services] AS tS
	LEFT OUTER JOIN [raw].[CI_tbl_services_to_summary] AS tSTS ON
		ts.[srvc_id] = tSTS.[srvc_id]
		AND tSTS.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTS.[eff_dt], '1/1/1900') AND ISNULL(tSTS.[end_dt], '12/31/9999')
		AND ts.[ETLInsertProjectExecutionID] = tSTS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [raw].[CI_tbl_Service_Summary] AS tSS ON
		tSTS.[SRVC_SUM_ID] = tSS.[SRVC_SUM_ID]
		AND tSTS.[ETLInsertProjectExecutionID] = tSS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [raw].[CI_tbl_services_to_def] AS tSTD ON
		tS.[srvc_id] = tSTD.[srvc_id]
		AND tSTD.[active] = 1
		--AND tS.[eff_dt] BETWEEN ISNULL(tSTD.[eff_dt], '1/1/1900') AND ISNULL(tSTD.[end_dt], '12/31/9999')
		AND tS.[ETLInsertProjectExecutionID] = tSTD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [raw].[CI_tbl_service_definitions] AS tSD ON
		tSTD.[srvc_def_id] = tSD.[srvc_def_id]
		AND tSTD.[eff_dt] BETWEEN ISNULL(tSD.[eff_dt], '1/1/1900') AND ISNULL(tSD.[end_dt], '12/31/9999')
		AND tSTD.[ETLInsertProjectExecutionID] = tSD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN ODS.ServicesICFFlagDependency icf ON
		ts.srvc_code = icf.ServiceCode		
	left outer join (
		SELECT
	ISNULL(tSTS.[SRVC_SUM_ID], -1) AS SRVC_SUM_ID
	,ISNULL(tSS.[SRVC_SUM_DESC], 'Unknown') AS SRVC_SUM_DESC
	,ISNULL(tSD.[srvc_def_desc], 'Unknown') AS srvc_def_desc
FROM
	[raw].[CI_tbl_services] AS tS
	LEFT OUTER JOIN [raw].[CI_tbl_services_to_summary] AS tSTS ON
		ts.[srvc_id] = tSTS.[srvc_id]
		AND tSTS.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTS.[eff_dt], '1/1/1900') AND ISNULL(tSTS.[end_dt], '12/31/9999')
		AND ts.[ETLInsertProjectExecutionID] = tSTS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [raw].[CI_tbl_Service_Summary] AS tSS ON
		tSTS.[SRVC_SUM_ID] = tSS.[SRVC_SUM_ID]
		AND tSTS.[ETLInsertProjectExecutionID] = tSS.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [raw].[CI_tbl_services_to_def] AS tSTD ON
		tS.[srvc_id] = tSTD.[srvc_id]
		AND tSTD.[active] = 1
		AND tS.[eff_dt] BETWEEN ISNULL(tSTD.[eff_dt], '1/1/1900') AND ISNULL(tSTD.[end_dt], '12/31/9999')
		AND tS.[ETLInsertProjectExecutionID] = tSTD.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN [raw].[CI_tbl_service_definitions] AS tSD ON
		tSTD.[srvc_def_id] = tSD.[srvc_def_id]
		AND tSTD.[eff_dt] BETWEEN ISNULL(tSD.[eff_dt], '1/1/1900') AND ISNULL(tSD.[end_dt], '12/31/9999')
		AND tSTD.[ETLInsertProjectExecutionID] = tSD.[ETLInsertProjectExecutionID]	
		WHERE
	tS.srvc_id != -2
	AND tS.[ETLInsertProjectExecutionID] = @etlProjectExecutionID ) x
	on x.srvc_def_desc = tSD.[srvc_def_desc]

	
WHERE
	tS.srvc_id = -2	 and tsd.srvc_def_id is not null
	AND tS.[ETLInsertProjectExecutionID] = @etlProjectExecutionID	

END