﻿

-------------------------------------------------------------------------------------------
--Modifications:  8/5/2013	B. Lang		Added filter to auth rep and case head to ensure only pulling records for current project id 



-------------------------------------------------------------------------------------------




CREATE procedure [Processed].[Transform_dimConsumers] 
	 @ETLProcessWindowEnd datetime
	,@ETLProjectExecutionID INT
AS
BEGIN



SELECT
	tC.[sys_client_id]
    ,tc.update_prov_id	
    ,isnull(chp.PROV_ID,-1) clinical_home_id
    ,isnull(chp.PROV_NAME,'Unknown') clinical_home_name  
    ,lg.lang  
    ,isnull(pv.PROV_ID,-1) EnrollmentProviderNumber
    ,isnull(pv.PROV_NAME,'Unknown') EnrollmentProviderName
    ,tC.create_dt 
    ,tC.cli_decease_dt_update_dt 
    ,CONVERT(INT,tC.cli_decease_dt_update_by_id ) cli_decease_dt_update_by_id  
    ,tC.prov_enroll_ref_num 
    ,ISNULL(mm.[old_id],tC.client_id) as old_id
    ,ISNULL(mm.new_id,tC.[client_id]) as client_id
	,tC.[caller_id]
	,convert(date, tC.[enroll_dt]) enroll_dt
	,tC.[cli_last]
	,tC.[cli_first]
	,tC.[cli_middle]
	,tC.[cli_ssn]
	,tC.[cli_no_ssn_bit]
	,isnull(tC.EmailAddress,'-') as EmailAddress
	,isnull(tCL.no_mailings_bit,'False') as no_mailings_bit
    ,CONVERT(DATE,tC.[cli_dob]) AS cli_dob
    ,case when CONVERT(DATE,tC.[cli_decease_dt]) < CONVERT(DATE,tC.[cli_dob]) then null else CONVERT(DATE,tC.[cli_decease_dt]) end AS cli_decease_dt
    ,PL.[key_id] AS GenderID
    ,tC.[cli_gender] AS GenderCode
    ,PL.[pick_value] AS Gender
    ,tC.[cli_lang1_id]
    ,tC.[cli_lang2_id]
    ,CONVERT(INT,tC.[cli_race_id]) AS cli_race_id
    ,tC.[cli_marital_status_id]
    ,tC.[cli_ethnicity_id]
    ,tC.[cli_competency_id]
    ,tC.[cli_legal_guardian]
    ,tC.[cli_lguardian_relation_id]
    ,tC.[cli_vet_status_id]
    ,tC.[active]
    ,tC.[education_id]
    ,tC.[employment_id]
    ,tC.[pregnant_bit]
    ,tC.[refer_source_id]
    ,tC.[english_proficient]
    ,tC.[num_in_household]
    ,tC.[household_income]
    ,tCL.[addr]
    ,tCL.[addr2]
    ,tCL.[city]
    ,tCL.[state]
    ,tCL.[zip]
    ,tCL.[county]
	,tCL.location_type_id
	,isnull(tCL.phone1,'-') as PhoneNumber
    ,tC.[ETLInsertProjectExecutionID]
    ,tC.[ETLCreatedDate]
    ,aar.Auth_Rep_First as AuthRepFirstName
	,aar.Auth_Rep_Mid as AuthRepMiddleName
	,aar.Auth_Rep_Last as AuthRepLastName
	,aar.Auth_Rep_Addr1 as AuthRepAddressLine1
	,aar.Auth_Rep_Addr2 as AuthRepAddressLine2
	,aar.Auth_Rep_City as AuthRepCity
	,aar.Auth_Rep_State as AuthRepState
	,aar.Auth_Rep_Zip as AuthRepPostalCode
	,aar.Auth_Rep_Lang as AuthRepLanguage
	,aar.Auth_Rep_Rel_Ind as AuthRepRelationship			
	,aar.Auth_Rep_Phone as AuthRepPhone
	,ch.Case_Head_First as CaseHeadFirstName
	,ch.Case_Head_Mid as CaseHeadMiddleName
	,ch.Case_Head_Last as CaseHeadLastName
	,ch.Case_Head_Addr1 as CaseHeadAddressLine1
	,ch.Case_Head_Addr2 as CaseHeadAddressLine2
	,ch.Case_Head_City as CaseHeadCity
	,ch.Case_Head_State as CaseHeadState
	,ch.Case_Head_Zip as CaseHeadPostalCode
	,ch.Case_Head_Lang_Pref as CaseHeadLanguage
	,'' as CaseHeadRelationship
	,ch.Case_Head_Phone as CaseHeadPhone
FROM
   [Raw].[CI_tbl_Client] AS tC
   INNER JOIN [Raw].[CI_tbl_Custom_Pick_List] AS PL ON
                                tC.[cli_gender] = PL.[code]
                                AND tC.[ETLInsertProjectExecutionID] = PL.[ETLInsertProjectExecutionID]
								AND tC.active = 1
   INNER JOIN [Raw].[CI_tbl_Custom_Pick_List_Header] AS PLH ON
                                PL.[pick_list_id] = PLH.[pick_list_id]
                                AND PL.[ETLInsertProjectExecutionID] = PLH.[ETLInsertProjectExecutionID]
                                AND PLH.[descrip] = 'Gender'
   LEFT OUTER JOIN (Select cli_location_id, a.client_id, from_dt, end_dt, location_type_id, a.ETLInsertProjectExecutionID,
							addr, addr2, city, state, zip, county,no_mailings_bit,phone1
					FROM
					[Raw].[CI_tbl_Client_Location] a
					INNER JOIN (SELECT client_id, max_tcl.ETLInsertProjectExecutionID, max(max_tcl.cli_location_id) as max_cli_location_id 
							from raw.CI_tbl_Client_Location max_tcl
							where @ETLProcessWindowEnd 
							BETWEEN max_tcL.[from_dt] AND ISNULL(max_tcL.[end_dt],'12/31/9999')
							GROUP BY client_ID, max_tcl.ETLInsertProjectExecutionID) as max_cli_location on a.cli_location_id = max_cli_location_id
																										and a.ETLInsertProjectExecutionID = max_cli_location.ETLInsertProjectExecutionID
							)	AS tCL ON tC.[client_id] = tCL.[client_id]
					AND tCL.[location_type_id] <> -1  
					AND tC.[ETLInsertProjectExecutionID] = tCL.[ETLInsertProjectExecutionID]
	LEFT OUTER JOIN (SELECT  t1.new_id, t1.old_id, ETLInsertProjectExecutionID 
					FROM Raw.CI_tbl_client_merge_master t1
						INNER JOIN (Select new_id, MAX(create_dt) as max_dt
									FROM Raw.CI_tbl_client_merge_master t2
									GROUP BY new_id) maxdt on 	t1.new_id = maxdt.new_id 
																and	t1.create_dt = maxdt.max_dt
									) mm ON tc.client_id = mm.new_id 
											and tc.[ETLInsertProjectExecutionID] = mm.ETLInsertProjectExecutionID 
left join Raw.CI_tbl_Providers as pv on tC.prov_enroll_ref_num = pv.PROV_ID 
left join raw.CI_tbl_Call_Languages as lg on lg.lang_id = tc.cli_lang1_id   and lg.ETLInsertProjectExecutionID = tc.ETLInsertProjectExecutionID
left join Raw.CI_tbl_Providers as chp on chp.PROV_ID = tc.clinical_home_id 
--LEFT OUTER JOIN Raw.CI_tbl_Client_Case_Head ch on
--		ch.Client_ID = tc.client_id
--		and ch.end_date IS NULL
--B. Lang added the following critera to pull the most current case head when there are dup case head records in CI
left outer join 	(select tch.Case_Head_ID, Client_ID, Case_Head_First, Case_Head_Mid, Case_Head_Last, Case_Head_Suffix, Case_Head_Lang_Pref, Case_Head_Addr1, Case_Head_Addr2, Case_Head_City, Case_Head_State, Case_Head_Zip, Case_Head_Phone, effective_date, end_date, inserted_by, insertion_date, updated_by, update_date, active
		from Raw.CI_tbl_Client_Case_Head tch
			inner join (	select Case_Head_ID from (select client_id, Case_Head_ID, insertion_date,
																					ROW_NUMBER() over(partition by client_id order by insertion_date desc, client_id desc) CurrentRow
																from Raw.CI_tbl_client_case_head
																) tmp_max_case_head
								where CurrentRow = 1) max_case_head on tch.Case_Head_id = max_case_head.Case_Head_ID
															and tch.ETLInsertProjectExecutionID = @ETLProjectExecutionID
					)ch on ch.Client_ID = tc.client_id


		
	LEFT OUTER JOIN (Select 
					 ar.client_id 
					,ar.Auth_Rep_First
					,ar.Auth_Rep_Mid
					,ar.Auth_Rep_Last
					,ar.Auth_Rep_Addr1
					,ar.Auth_Rep_Addr2
					,ar.Auth_Rep_City
					,ar.Auth_Rep_State
					,ar.Auth_Rep_Zip
					,ar.Auth_Rep_Lang
					,ar.Auth_Rep_Rel_Ind						
					,ISNULL(ar.Auth_Rep_Phone,'') as Auth_Rep_Phone
					FROM Raw.CI_tbl_client_auth_rep ar
					Inner join (select Auth_rep_id from (select client_id, auth_rep_id, insertion_date,
														ROW_NUMBER() over(partition by client_id order by insertion_date desc, auth_rep_id desc) CurrentRow
														from Raw.CI_tbl_client_auth_rep
														) tmp_max_aut_rep
								where CurrentRow = 1) max_auth_rep on ar.Auth_Rep_ID = max_auth_rep.Auth_Rep_ID
					where ar.ETLInsertProjectExecutionID = @ETLProjectExecutionID
		) aar on aar.Client_ID = tc.client_id
			--below logic replaced by B. Lang on 6/8 with above Row_Number approach that solves issue
			-- of 2 records with identical inseration date date (ie, client ID 387767)
	--				INNER JOIN (Select client_id, MAX(insertion_date) as max_date from Raw.CI_tbl_client_auth_rep a
	--				WHERE GETDATE() between ISNULL(effective_date,cast('1/1/1900' as datetime)) AND ISNULL(end_date,CAST('12/31/2099' as datetime))
	--				GROUP BY Client_ID) max_auth_rep ON	max_auth_rep.Client_ID = ar.client_id and
	--							max_auth_rep.max_date = ar.insertion_date) aar on
	--aar.Client_ID = tc.client_id
WHERE              tC.[ETLInsertProjectExecutionID] = @ETLProjectExecutionID

END