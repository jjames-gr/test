﻿-- =============================================
-- Author:		Frankie Timmons Jr
-- Create date: 5/23/2013
-- Description:	Pulls Contact Data Related to TARs
-- =============================================
CREATE PROCEDURE [Processed].[Transform_dimTARContact]
	@ETLInsertProjectExecutionID int 
AS
BEGIN
select [TARContactNK],[TARContactTypeNK],[TARFirstName],[TARMiddleName],[TARLastName],[TARAddressLine1],[TARAddressLine2],
	   [TARCity],[TARState],[TARPostalCode],[TARLanguage],[TARRelationship],[TARPhone],[TARActive]
from (SELECT [Case_Head_ID] as [TARContactNK]
	  ,'Case Head' [TARContactTypeNK]
      ,[Case_Head_First] as [TARFirstName]
      ,[Case_Head_Mid] as [TARMiddleName] 
      ,[Case_Head_Last] as [TARLastName]     
      ,[Case_Head_Addr1] as [TARAddressLine1]
      ,[Case_Head_Addr2] as [TARAddressLine2]
      ,[Case_Head_City] as [TARCity]
      ,[Case_Head_State] as [TARState]
      ,[Case_Head_Zip] as [TARPostalCode]
      ,[Case_Head_Lang_Pref] as [TARLanguage]
      ,'' as [TARRelationship]
      ,isnull([Case_Head_Phone],'') as [TARPhone] 
      ,[active] as [TARActive]     
FROM [BIW_Stage].[Raw].[CI_tbl_Client_Case_Head]
WHERE [ETLInsertProjectExecutionID] = @ETLInsertProjectExecutionID

union

SELECT [Auth_Rep_ID] as [TARContactNK]
      ,'Authorized Rep' as [TARContactTypeNK]
      ,[Auth_Rep_First] as [TARFirstName]
      ,[Auth_Rep_Mid] as [TARMiddleName]
      ,[Auth_Rep_Last] as [TARLastName]
      ,[Auth_Rep_Addr1] as [TARAddressLine1]
      ,[Auth_Rep_Addr2] as [TARAddressLine2]
      ,[Auth_Rep_City] as [TARCity]
      ,[Auth_Rep_State] as [TARState]
      ,[Auth_Rep_Zip] as [TARPostalCode]      
      ,[Auth_Rep_Lang] as [TARLanguage]
      ,[Auth_Rep_Rel_Ind] as [TARRelationship]
      ,isnull([Auth_Rep_Phone],'') as [TARPhone]  
      ,[active] as [TARActive]
FROM [BIW_Stage].[Raw].[CI_tbl_client_auth_rep]
WHERE [ETLInsertProjectExecutionID] = @ETLInsertProjectExecutionID) as J  


END