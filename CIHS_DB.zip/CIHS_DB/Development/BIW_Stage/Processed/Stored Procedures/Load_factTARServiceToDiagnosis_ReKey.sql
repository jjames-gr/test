﻿/***===============================================================================================
== Name:		[Processed].[Load_factTARServiceToDiagnosis_ReKey] 
== Created:		6/7/2013
== Author:		Frankie L Timmons Jr
== Description: Updates The TreatmentAuthorizationRequestSK in [BIW].[DW].[factTARServiceToDiagnosis] to
==				reflect SK changes in [BIW].[DW].[factTreatmentAuthorizationRequest]                    
===================================================================================================
== Parameters:
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/
CREATE PROCEDURE [Processed].[Load_factTARServiceToDiagnosis_ReKey]
AS
BEGIN
update[BIW].[DW].[factTARServiceToDiagnosis]
set [TreatmentAuthorizationRequestSK] = ftar.[facttreatmentauthorizationrequestsk]
FROM [BIW].[DW].[factTARServiceToDiagnosis] as ftstd inner join
     [pbhc-newreport].[QM].[dbo].[tbl_Client_TAR_Services] as cts on ftstd.[TarServiceID] = cts.[tar_srvc_id] inner join
     [BIW].[DW].[factTreatmentAuthorizationRequest] as ftar on cts.tar_id = ftar.tarid
where ftar.[facttreatmentauthorizationrequestsk] <> ftstd.[TreatmentAuthorizationRequestSK]
END