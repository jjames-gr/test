﻿CREATE TABLE [Processed].[dimGrievanceType] (
    [GrievanceTypeSK]             INT           NULL,
    [GrievanceTypeNK]             INT           NOT NULL,
    [GrievanceTypeDescription]    VARCHAR (256) NULL,
    [CategoryID]                  INT           NULL,
    [CategoryDescription]         VARCHAR (256) NULL,
    [Active]                      BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);

