﻿CREATE TABLE [Processed].[dimDiagnosisClass] (
    [DiagnosisClassSK]            INT          NULL,
    [DiagnosisClassNK]            INT          NOT NULL,
    [DiagnosisClass]              VARCHAR (50) NOT NULL,
    [DiagnosisClassCode]          VARCHAR (3)  NOT NULL,
    [ActiveDiagnosisClass]        BIT          NOT NULL,
    [ETLInsertProjectExecutionID] INT          NOT NULL,
    [ETLCreatedDate]              DATETIME     NOT NULL,
    [ETLModifiedDate]             DATETIME     NOT NULL,
    [ETLChecksumType1]            VARCHAR (32) NOT NULL,
    [ETLCheckSumType2]            VARCHAR (32) NULL,
    [ETLCurrentRow]               BIT          NOT NULL,
    [ETLEffectiveFrom]            DATETIME     NOT NULL,
    [ETLEffectiveTo]              DATETIME     NOT NULL,
    [ETLUpdateProjectExecutionID] INT          NOT NULL,
    [ETLDMLOperation]             TINYINT      NOT NULL
);

