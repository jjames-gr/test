create table [Processed].[dimAdjudicationReasonNotes]
(
	[AdjudicationReasonNotesSK]   [int]              NULL,
	[AdjudicationReasonNotes]     [varchar](512) NOT NULL,
	[ETLCreatedDate]              [datetime]     NOT NULL,
	[ETLModifiedDate]             [datetime]     NOT NULL,
	[ETLChecksumType1]            [varchar](32)  NOT NULL,
	[ETLChecksumType2]            [varchar](32)      NULL,
	[ETLCurrentRow]               [bit]          NOT NULL,
	[ETLEffectiveFrom]            [datetime]     NOT NULL,
	[ETLEffectiveTo]              [datetime]     NOT NULL,
	[ETLInsertProjectExecutionID] [int]          NOT NULL,
	[ETLUpdateProjectExecutionID] [int]          NOT NULL,
	[ETLDMLOperation]             [tinyint]      NOT NULL
);