﻿CREATE TABLE [Processed].[dimBenefitPlan] (
    [BenefitPlanSK]               INT           NULL,
    [BenefitPlanNK]               INT           NOT NULL,
    [BenefitPlan]                 VARCHAR (256) NOT NULL,
    [BenefitPlanShort]            VARCHAR (32)  NOT NULL,
    [InsurerID]                   INT           NOT NULL,
    [Insurer]                     VARCHAR (256) NOT NULL,
    [InsurerShort]                VARCHAR (32)  NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);

