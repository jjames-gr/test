﻿CREATE TABLE [Processed].[dimProviderContract] (
    [ProviderContractSK]          INT            NULL,
    [ProviderContractNK]          INT            NOT NULL,
    [DaysAllowedClaimsSubmittal]  INT            NOT NULL,
    [ActiveContractFlag]          BIT            NOT NULL,
    [ProviderContractTypeID]      INT            NOT NULL,
    [ProviderContractTypeCode]    VARCHAR (10)   NOT NULL,
    [ProviderContractType]        VARCHAR (100)  NOT NULL,
    [ContractComments]            VARCHAR (2000) NOT NULL,
    [ContractTerminationDate]     DATETIME       NULL,
    [ContractEffectiveDate]       DATE           NOT NULL,
    [ContractExpirationDate]      DATE           NOT NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NULL,
    [ETLEffectiveFrom]            DATETIME       NULL,
    [ETLEffectiveTo]              DATETIME       NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    [ETLDMLOperation]             TINYINT        NOT NULL
);



