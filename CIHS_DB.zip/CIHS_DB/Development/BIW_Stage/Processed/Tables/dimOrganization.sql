﻿CREATE TABLE [Processed].[dimOrganization] (
    [OrganizationSK]              INT           NULL,
    [OrganizationNK]              INT           NOT NULL,
    [County]                      VARCHAR (256) NOT NULL,
    [CountyCode]                  CHAR (10)     NOT NULL,
    [CountyNumber]                VARCHAR (25)  NOT NULL,
    [CatchmentID]                 INT           NOT NULL,
    [Catchment]                   VARCHAR (256) NOT NULL,
    [CatchmentSequence]           INT           NOT NULL,
    [CatchmentOnlineDate]         DATE          NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);







