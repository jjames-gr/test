﻿CREATE TABLE [Processed].[dimProfessionalDesignation] (
    [ProfessionalDesignationSK]          INT           NOT NULL,
    [ProfessionalDesignationNK]          INT           NOT NULL,
    [ProfessionalDesignationCode]        VARCHAR (10)  NOT NULL,
    [ProfessionalDesignation]            VARCHAR (250) NOT NULL,
    [AbbreviatedProfessionalDesignation] VARCHAR (25)  NOT NULL,
    [ETLCreatedDate]                     DATETIME      NOT NULL,
    [ETLModifiedDate]                    DATETIME      NOT NULL,
    [ETLChecksumTYpe1]                   VARCHAR (32)  NOT NULL,
    [ETLChecksumTYpe2]                   VARCHAR (32)  NULL,
    [ETLCurrentRow]                      BIT           NOT NULL,
    [ETLEffectiveFrom]                   DATETIME      NOT NULL,
    [ETLEffectiveTo]                     DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID]        INT           NOT NULL,
    [ETLUpdateProjectExecutionID]        INT           NOT NULL,
    [ETLDMLOperation]                    TINYINT       NOT NULL
);

