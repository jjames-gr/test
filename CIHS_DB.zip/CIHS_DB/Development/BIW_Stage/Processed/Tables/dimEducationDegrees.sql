﻿CREATE TABLE [Processed].[dimEducationDegrees] (
    [EducationDegreeSK]           INT           NULL,
    [EducationDegreeNK]           INT           NOT NULL,
    [EductionDegreeType]          VARCHAR (5)   NOT NULL,
    [EducationDegree]             VARCHAR (100) NOT NULL,
    [EducationAbbreviatedDegree]  VARCHAR (25)  NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumTYpe1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumTYpe2]            VARCHAR (32)  NOT NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);



