﻿CREATE TABLE [Processed].[dimAppointmentCommentsTemp] (
    [AppointmentCommentsSK]       INT            NULL,
    [AppointmentCommentsNK]       INT            NOT NULL,
    [AppointmentComments]         VARCHAR (5000) NULL,
    [AppointmentDeclinedComments] VARCHAR (5000) NULL,
    [CommentsChkSum]              VARCHAR (5000) NULL,
    [DeclinedCommentsChkSum]      VARCHAR (5000) NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)   NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    [ETLDMLOperation]             TINYINT        NOT NULL
);

