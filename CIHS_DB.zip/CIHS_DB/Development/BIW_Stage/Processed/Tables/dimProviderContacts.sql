﻿CREATE TABLE [Processed].[dimProviderContacts] (
    [ProviderContactsSK]          INT           NULL,
    [ProviderContactsNK]          INT           NOT NULL,
    [ContactTypeID]               INT           NOT NULL,
    [ContactType]                 CHAR (255)    NULL,
    [ContactName]                 VARCHAR (100) NULL,
    [ContactEmail]                VARCHAR (100) NULL,
    [ContactFaxNumber]            VARCHAR (50)  NULL,
    [ContactPhoneNumber]          VARCHAR (50)  NULL,
    [MainContactFlag]             BIT           NULL,
    [ActiveProviderContactFlag]   BIT           NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);

