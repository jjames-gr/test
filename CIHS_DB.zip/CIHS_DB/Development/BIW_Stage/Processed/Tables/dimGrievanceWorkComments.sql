﻿CREATE TABLE [Processed].[dimGrievanceWorkComments] (
    [GrievanceWorkCommentsSK]     INT           NULL,
    [GrievanceWorkCommentsNK]     INT           NOT NULL,
    [GrievanceKeywords]           VARCHAR (255) NULL,
    [GrievanceWorkDescription]    VARCHAR (MAX) NULL,
    [GrievancesSK]                INT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);

