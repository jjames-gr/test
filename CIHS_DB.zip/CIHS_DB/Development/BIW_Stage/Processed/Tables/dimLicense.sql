﻿CREATE TABLE [Processed].[dimLicense] (
    [LicenseSK]                   INT           NULL,
    [LicenseID]                   INT           NOT NULL,
    [Licensecode]                 CHAR (10)     NOT NULL,
    [License]                     VARCHAR (250) NOT NULL,
    [Active]                      BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);

