﻿CREATE TABLE [Processed].[dimClinician] (
    [ClinicianSK]                 INT           NULL,
    [ClinicianNK]                 INT           NOT NULL,
    [Prefix]                      VARCHAR (16)  NOT NULL,
    [FirstName]                   VARCHAR (64)  NOT NULL,
    [LastName]                    VARCHAR (64)  NOT NULL,
    [MiddleName]                  VARCHAR (32)  NOT NULL,
    [AddressLine1]                VARCHAR (256) NULL,
    [AddressLine2]                VARCHAR (256) NULL,
    [City]                        VARCHAR (256) NULL,
    [State]                       VARCHAR (256) NULL,
    [PostalCode]                  VARCHAR (256) NULL,
    [County]                      VARCHAR (256) NULL,
    [Phone]                       VARCHAR (15)  NULL,
    [DOB]                         DATETIME      NULL,
    [SSN]                         VARCHAR (11)  NULL,
    [ClinicianEmail]              VARCHAR (50)  NULL,
    [NPI]                         VARCHAR (32)  NULL,
    [MCD]                         VARCHAR (16)  NULL,
    [Active]                      BIT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NOT NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);





