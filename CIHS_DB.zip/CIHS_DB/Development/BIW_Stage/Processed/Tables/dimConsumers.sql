﻿CREATE TABLE [Processed].[dimConsumers] (
    [ConsumerSK]                  BIGINT        NULL,
    [MasterConsumerSK]            BIGINT        NULL,
    [PreviousConsumerNK]          INT           NULL,
    [ConsumerNK]                  INT           NOT NULL,
    [EnrollmentProviderName]      VARCHAR (256) NULL,
    [EnrollmentProviderNumber]    VARCHAR (25)  NULL,
    [EnrollmentDate]              DATETIME      NULL,
    [LastName]                    VARCHAR (256) NOT NULL,
    [FirstName]                   VARCHAR (256) NOT NULL,
    [MiddleName]                  VARCHAR (256) NOT NULL,
    [DOB]                         DATE          NULL,
    [DOD]                         DATE          NULL,
    [SSN]                         VARCHAR (11)  NULL,
    [MissingSSNFlag]              BIT           NULL,
    [DoNotMailFlag]               BIT           NOT NULL,
    [PhoneNumber]                 VARCHAR (50)  NULL,
    [EmailAddress]                VARCHAR (50)  NULL,
    [LivingArrangementsID]        INT           NULL,
    [LivingArrangementsCode]      VARCHAR (16)  NULL,
    [LivingArrangements]          VARCHAR (80)  NULL,
    [AgeValue]                    INT           NULL,
    [GenderID]                    INT           NOT NULL,
    [GenderCode]                  VARCHAR (16)  NOT NULL,
    [Gender]                      VARCHAR (256) NOT NULL,
    [RaceID]                      INT           NOT NULL,
    [RaceCode]                    VARCHAR (16)  NOT NULL,
    [Race]                        VARCHAR (256) NOT NULL,
    [EthnicityID]                 INT           NOT NULL,
    [EthnicityCode]               VARCHAR (16)  NOT NULL,
    [Ethnicity]                   VARCHAR (256) NOT NULL,
    [MaritalStatusID]             INT           NOT NULL,
    [MaritalStatusCode]           VARCHAR (16)  NOT NULL,
    [MaritalStatus]               VARCHAR (256) NOT NULL,
    [CompetencyID]                INT           NOT NULL,
    [CompetencyCode]              VARCHAR (16)  NOT NULL,
    [Competency]                  VARCHAR (256) NOT NULL,
    [VeteranStatusID]             INT           NOT NULL,
    [VeteranStatusCode]           VARCHAR (16)  NOT NULL,
    [VeteranStatus]               VARCHAR (256) NOT NULL,
    [GuardianRelationshipID]      INT           NOT NULL,
    [GuardianRelationshipCode]    VARCHAR (16)  NOT NULL,
    [GuardianRelationship]        VARCHAR (256) NOT NULL,
    [Guardian]                    VARCHAR (256) NULL,
    [Active]                      BIT           NULL,
    [DeceasedUpdateDate]          DATETIME      NULL,
    [DeceasedUpdatedByEmployee]   VARCHAR (64)  NULL,
    [EducationID]                 INT           NOT NULL,
    [EducationCode]               VARCHAR (16)  NOT NULL,
    [Education]                   VARCHAR (256) NOT NULL,
    [EmploymentID]                INT           NOT NULL,
    [EmploymentCode]              VARCHAR (16)  NOT NULL,
    [Employment]                  VARCHAR (256) NOT NULL,
    [ReferralSourceID]            INT           NOT NULL,
    [ReferralSourceCode]          VARCHAR (16)  NOT NULL,
    [ReferralSource]              VARCHAR (256) NOT NULL,
    [AddressLine1]                VARCHAR (256) NULL,
    [AddressLine2]                VARCHAR (256) NULL,
    [City]                        VARCHAR (256) NULL,
    [State]                       VARCHAR (256) NULL,
    [PostalCode]                  VARCHAR (256) NULL,
    [County]                      VARCHAR (256) NULL,
    [Latitude]                    VARCHAR (64)  NULL,
    [Longitude]                   VARCHAR (64)  NULL,
    [GeoEntityType]               VARCHAR (64)  NULL,
    [GeoAddress]                  VARCHAR (512) NULL,
    [AuthRepFirstName]            VARCHAR (50)  NULL,
    [AuthRepMiddleName]           VARCHAR (50)  NULL,
    [AuthRepLastName]             VARCHAR (50)  NULL,
    [AuthRepAddressLine1]         VARCHAR (256) NULL,
    [AuthRepAddressLine2]         VARCHAR (256) NULL,
    [AuthRepCity]                 VARCHAR (50)  NULL,
    [AuthRepState]                VARCHAR (50)  NULL,
    [AuthRepPostalCode]           VARCHAR (50)  NULL,
    [AuthRepLanguage]             VARCHAR (2)   NULL,
    [AuthRepRelationship]         VARCHAR (1)   NULL,
    [AuthRepPhone]                VARCHAR (50)  NULL,
    [CaseHeadFirstName]           VARCHAR (50)  NULL,
    [CaseHeadMiddleName]          VARCHAR (50)  NULL,
    [CaseHeadLastName]            VARCHAR (50)  NULL,
    [CaseHeadAddressLine1]        VARCHAR (256) NULL,
    [CaseHeadAddressLine2]        VARCHAR (256) NULL,
    [CaseHeadCity]                VARCHAR (50)  NULL,
    [CaseHeadState]               VARCHAR (50)  NULL,
    [CaseHeadPostalCode]          VARCHAR (50)  NULL,
    [CaseHeadLanguage]            VARCHAR (2)   NULL,
    [CaseHeadRelationship]        VARCHAR (1)   NULL,
    [CaseHeadPhone]               VARCHAR (50)  NULL,
    [CreateDate]                  DATETIME      NOT NULL,
    [ClinicalHomeProviderNumber]  INT           NULL,
    [ClinicalHomeProviderName]    VARCHAR (256) NULL,
    [Language]                    VARCHAR (50)  NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NOT NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    [ETLDMLOperation]             TINYINT       NOT NULL
);


















GO



GO


