﻿CREATE TABLE [Processed].[dimCallCareNotes] (
    [CallCareNotesSK]             INT            NULL,
    [NoteID]                      BIGINT         NOT NULL,
    [CallID]                      INT            NOT NULL,
    [NoteType]                    VARCHAR (15)   NOT NULL,
    [Note]                        VARCHAR (8000) NULL,
    [ShortDescription]            VARCHAR (255)  NULL,
    [ETLCreatedDate]              DATETIME       NOT NULL,
    [ETLModifiedDate]             DATETIME       NULL,
    [ETLChecksumType1]            VARCHAR (32)   NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)   NULL,
    [ETLCurrentRow]               BIT            NOT NULL,
    [ETLEffectiveFrom]            DATETIME       NOT NULL,
    [ETLEffectiveTo]              DATETIME       NOT NULL,
    [ETLInsertProjectExecutionID] INT            NOT NULL,
    [ETLUpdateProjectExecutionID] INT            NOT NULL,
    [ETLDMLOperation]             TINYINT        NOT NULL
);



