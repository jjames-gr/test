﻿CREATE TABLE [ODS].[FundingCapitation] (
    [Funding_cap_id] INT            NULL,
    [ServiceCode]    VARCHAR (5000) NULL
);

