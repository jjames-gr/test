﻿CREATE TABLE [ODS].[DayTimeCalendar] (
    [TimeValue]                   CHAR (8)  NOT NULL,
    [MilitaryHour]                CHAR (2)  NOT NULL,
    [Hour]                        CHAR (2)  NOT NULL,
    [Minute]                      CHAR (2)  NOT NULL,
    [Second]                      CHAR (2)  NOT NULL,
    [AmPm]                        CHAR (2)  NOT NULL,
    [StandardTime]                CHAR (11) NOT NULL,
    [ETLInsertProjectExecutionID] INT       NOT NULL,
    [ETLCreatedDate]              DATETIME  NOT NULL
);

