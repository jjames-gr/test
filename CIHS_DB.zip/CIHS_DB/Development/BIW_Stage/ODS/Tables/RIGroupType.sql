﻿CREATE TABLE [ODS].[RIGroupType] (
    [ID]             INT          IDENTITY (1, 1) NOT NULL,
    [GroupType]      VARCHAR (50) NULL,
    [IncidentCodeID] INT          NULL
);

