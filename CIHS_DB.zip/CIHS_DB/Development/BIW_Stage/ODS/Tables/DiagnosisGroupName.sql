﻿CREATE TABLE [ODS].[DiagnosisGroupName] (
    [DiagnosisGroupNameID] INT           IDENTITY (1, 1) NOT NULL,
    [DiagnosisGroupCode]   VARCHAR (32)  NULL,
    [DiagnosisGroupName]   VARCHAR (32)  NULL,
    [CreatedDate]          DATETIME      CONSTRAINT [DF_DiagnosisGroupName_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]            VARCHAR (128) CONSTRAINT [DF_DiagnosisGroupName_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]         DATETIME      CONSTRAINT [DF_DiagnosisGroupName_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]           VARCHAR (128) CONSTRAINT [DF_DiagnosisGroupName_ModifiedBy] DEFAULT (suser_name()) NOT NULL
);

