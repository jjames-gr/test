﻿CREATE TABLE [ODS].[EstimatedCountyUninsured] (
    [County]              VARCHAR (30)   NULL,
    [EstPercentUninsured] DECIMAL (5, 3) NULL,
    [CreatedDate]         DATETIME       CONSTRAINT [DF_EstimatedCountyUninsured_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]           VARCHAR (128)  CONSTRAINT [DF_EstimatedCountyUninsured_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]        DATETIME       CONSTRAINT [DF_EstimatedCountyUninsured_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]          VARCHAR (128)  CONSTRAINT [DF_EstimatedCountyUninsured_ModifiedBy] DEFAULT (suser_name()) NOT NULL
);

