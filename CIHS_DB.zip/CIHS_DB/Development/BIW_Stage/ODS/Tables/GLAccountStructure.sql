﻿CREATE TABLE [ODS].[GLAccountStructure] (
    [GLAccountStructureID] INT           IDENTITY (1, 1) NOT NULL,
    [AccountCodeSegment]   VARCHAR (25)  NULL,
    [AccountSegmentValue]  VARCHAR (4)   NULL,
    [CodeValue]            VARCHAR (25)  NULL,
    [CodeValueNK]          INT           NULL,
    [CreatedDate]          DATETIME      CONSTRAINT [DF_GLAccountStructure_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]            VARCHAR (128) CONSTRAINT [DF_GLAccountStructure_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]         DATETIME      CONSTRAINT [DF_GLAccountStructure_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]           VARCHAR (128) CONSTRAINT [DF_GLAccountStructure_ModifiedBy] DEFAULT (suser_name()) NOT NULL
);

