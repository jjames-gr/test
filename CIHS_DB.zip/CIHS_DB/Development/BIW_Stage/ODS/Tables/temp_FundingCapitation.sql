﻿CREATE TABLE [ODS].[temp_FundingCapitation] (
    [Funding_Cap_id] INT            NULL,
    [Srvc_ids_str]   VARCHAR (10)   NULL,
    [ServiceCode]    VARCHAR (5000) NULL
);

