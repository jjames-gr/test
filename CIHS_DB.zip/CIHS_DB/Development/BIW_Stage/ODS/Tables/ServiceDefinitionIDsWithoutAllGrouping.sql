﻿CREATE TABLE [ODS].[ServiceDefinitionIDsWithoutAllGrouping] (
    [ServiceDefinitionID] INT          NULL,
    [Active]              TINYINT      NULL,
    [CreateDate]          DATETIME     NULL,
    [CreateUser]          VARCHAR (50) NULL
);

