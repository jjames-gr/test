﻿CREATE TABLE [ODS].[ClientCountyHistory] (
    [ClientCountyHistorySK]       INT          NOT NULL,
    [county]                      VARCHAR (30) NULL,
    [RegionID]                    INT          NULL,
    [PlanID]                      INT          NULL,
    [MedicaidCategory]            VARCHAR (10) NULL,
    [ClientID]                    INT          NULL,
    [BeginDate]                   DATE         NULL,
    [EndDate]                     DATE         NULL,
    [ETLCreateDate]               DATETIME     CONSTRAINT [DF_ClientCountyHistory_ETLCreateDate] DEFAULT (getdate()) NULL,
    [ETLModifiedDate]             DATETIME     CONSTRAINT [DF_ClientCountyHistory_ETLModifiedDate] DEFAULT (getdate()) NULL,
    [ETLCurrentRow]               BIT          CONSTRAINT [DF_ClientCountyHistory_ETLCurrentRow] DEFAULT ((0)) NULL,
    [ETLInsertProjectExecutionID] INT          NULL,
    [ETLUpdateProjectExecutionID] INT          NULL,
    [ETLDMLOperation]             TINYINT      NULL,
    [Source]                      INT          NULL,
    CONSTRAINT [PK_ClientCountyHistory] PRIMARY KEY NONCLUSTERED ([ClientCountyHistorySK] ASC)
);


GO
CREATE NONCLUSTERED INDEX [idx_ClientCountyHistory_ETLLookup]
    ON [ODS].[ClientCountyHistory]([PlanID] ASC, [ClientID] ASC, [BeginDate] ASC, [EndDate] ASC, [ETLCurrentRow] ASC)
    INCLUDE([RegionID], [MedicaidCategory]);

