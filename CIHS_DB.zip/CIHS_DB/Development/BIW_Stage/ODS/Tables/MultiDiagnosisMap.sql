﻿CREATE TABLE [ODS].[MultiDiagnosisMap] (
    [MultiDiagnosisMapID]     INT           IDENTITY (1, 1) NOT NULL,
    [DiagnosisGroupCode]      VARCHAR (32)  NOT NULL,
    [MultiDiagnosisGroupCode] VARCHAR (32)  NULL,
    [MultiDiagnosisGroupName] VARCHAR (64)  NULL,
    [CreatedDate]             DATETIME      CONSTRAINT [DF_MultiDiagnosisMap_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]               VARCHAR (128) CONSTRAINT [DF_MultiDiagnosisMap_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]            DATETIME      CONSTRAINT [DF_MultiDiagnosisMap_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]              VARCHAR (128) CONSTRAINT [DF_MultiDiagnosisMap_ModifiedBy] DEFAULT (suser_name()) NOT NULL
);

