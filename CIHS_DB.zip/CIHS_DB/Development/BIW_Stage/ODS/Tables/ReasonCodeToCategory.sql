﻿CREATE TABLE [ODS].[ReasonCodeToCategory] (
    [ReasonCodeToCategoryID] INT           NOT NULL,
    [ReasonCodeCategoryID]   INT           NOT NULL,
    [ReasonCodeID]           INT           NOT NULL,
    [CreatedDate]            DATETIME      CONSTRAINT [DF_ReasonCodeToCategory_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]              VARCHAR (128) CONSTRAINT [DF_ReasonCodeToCategory_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]           DATETIME      CONSTRAINT [DF_ReasonCodeToCategory_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]             VARCHAR (128) CONSTRAINT [DF_ReasonCodeToCategory_ModifiedBy] DEFAULT (suser_name()) NOT NULL,
    CONSTRAINT [PK_ReasonCodeToCategory] PRIMARY KEY CLUSTERED ([ReasonCodeToCategoryID] ASC)
);

