﻿CREATE TABLE [ODS].[CatchmentDates] (
    [CatchmentDateID] INT           IDENTITY (1, 1) NOT NULL,
    [CatchmentID]     INT           NULL,
    [Catchment]       VARCHAR (4)   NULL,
    [OnlineDate]      DATE          NULL,
    [CreatedDate]     DATETIME      CONSTRAINT [DF_CatchmentDates_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]       VARCHAR (128) CONSTRAINT [DF_CatchmentDates_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]    DATETIME      CONSTRAINT [DF_CatchmentDates_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]      VARCHAR (128) CONSTRAINT [DF_CatchmentDates_ModifiedBy] DEFAULT (suser_name()) NOT NULL
);

