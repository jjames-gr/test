﻿CREATE TABLE [ODS].[ReasonCodeCategories] (
    [ReasonCodeCategoryID] INT           IDENTITY (1, 1) NOT NULL,
    [Category]             VARCHAR (32)  NOT NULL,
    [CreatedDate]          DATETIME      CONSTRAINT [DF_ReasonCodeCategories_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]            VARCHAR (128) CONSTRAINT [DF_ReasonCodeCategories_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]         DATETIME      CONSTRAINT [DF_ReasonCodeCategories_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]           VARCHAR (128) CONSTRAINT [DF_ReasonCodeCategories_ModifiedBy] DEFAULT (suser_name()) NOT NULL,
    CONSTRAINT [PK_ReasonCodeCategories] PRIMARY KEY CLUSTERED ([ReasonCodeCategoryID] ASC)
);

