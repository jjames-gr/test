﻿CREATE TABLE [ODS].[GLMapping] (
    [GLMappingID]      INT           IDENTITY (1, 1) NOT NULL,
    [CatchmentID]      INT           NULL,
    [BenefitPlanNK]    INT           NULL,
    [ServiceSummaryID] INT           NULL,
    [GLAccountNK]      INT           NULL,
    [CreatedDate]      DATETIME      CONSTRAINT [DF_GLMapping_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]        VARCHAR (128) CONSTRAINT [DF_GLMapping_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]     DATETIME      CONSTRAINT [DF_GLMapping_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]       VARCHAR (128) CONSTRAINT [DF_GLMapping_ModifiedBy] DEFAULT (suser_name()) NOT NULL,
    CONSTRAINT [PK_GLMapping] PRIMARY KEY CLUSTERED ([GLMappingID] ASC)
);

