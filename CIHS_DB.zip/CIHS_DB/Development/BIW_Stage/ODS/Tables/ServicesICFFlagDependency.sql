﻿CREATE TABLE [ODS].[ServicesICFFlagDependency] (
    [ServicesNK]  INT          NOT NULL,
    [ServiceCode] VARCHAR (15) NOT NULL
);





