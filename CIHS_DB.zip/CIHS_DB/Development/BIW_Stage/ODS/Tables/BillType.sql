﻿CREATE TABLE [ODS].[BillType] (
    [BillTypeID]    INT           IDENTITY (1, 1) NOT NULL,
    [BillTypeCode]  VARCHAR (4)   NULL,
    [BillTypeGroup] VARCHAR (25)  NULL,
    [BillTypeName]  VARCHAR (25)  NULL,
    [CreatedDate]   DATETIME      CONSTRAINT [DF_BillType_CreatedDate] DEFAULT (getdate()) NOT NULL,
    [CreatedBy]     VARCHAR (128) CONSTRAINT [DF_BillType_CreatedBy] DEFAULT (suser_name()) NOT NULL,
    [ModifiedDate]  DATETIME      CONSTRAINT [DF_BillType_ModifiedDate] DEFAULT (getdate()) NOT NULL,
    [ModifiedBy]    VARCHAR (128) CONSTRAINT [DF_BillType_ModifiedBy] DEFAULT (suser_name()) NOT NULL
);

