﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
Create FUNCTION [dbo].[udfget_maxNumber](@STR VARCHAR(8000),@separator VARCHAR(16)=',') 
--(@text varchar(8000))

RETURNS INT
AS
BEGIN

DECLARE @Item VARCHAR(128), @pos INT, @MinValue int, @CurValue int

set @MinValue = 0 
WHILE DATALENGTH(@STR) > 0

BEGIN

SET @pos = CHARINDEX(@separator, @STR)

IF @pos = 0 SET @pos = DATALENGTH(@STR)+1 
 

SET @Item = LEFT(@STR, @pos -1 )

SET @CurValue = CAST(@Item as Int)

IF @CurValue >=@MinValue SET @MinValue = @CurValue 
 

SET @STR = SUBSTRING(@STR, @pos + DATALENGTH(@separator), 8000)

--INSERT INTO @TableArray (Item) VALUES(@Item)

END

 

RETURN @MinValue 
 


--declare @stringnum int
--	declare @t table ( Col1 varchar(250))
--
--INSERT INTO @t(col1) VALUES(@text)
--
--;WITH NumsCTE 
--AS 
--( 
--SELECT 1 as n 
--UNION ALL 
--SELECT n+1 FROM NumsCTE WHERE n<100 
--)  
--
--
--SELECT @stringnum = MAX(CAST (element as Int)) --as MaxNumber 
--FROM (SELECT n-len(REPLACE(LEFT(Col1,n),',',''))+1 as pos,
--SUBSTRING(Col1,n,charindex(',',Col1+',',n)-n) as element 
--FROM @t JOIN NumsCTE ON n<=len(Col1) AND SUBSTRING(','+Col1,n,1)=',' 
--) t 
--return @stringnum
END