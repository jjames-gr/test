﻿

CREATE FUNCTION [dbo].[cfn_split](@splitstr NVARCHAR(max), @splitchar CHAR(1))
		RETURNS @split_elements TABLE (eleno int identity(1,1), 
						element varchar(max))
AS
-- Custom function to split a string based on the delimiter
-- Accepts a string to be splitted & a delimitter
-- Returns a table with all split elements sorted in chronological order
BEGIN
	DECLARE @pos INT

	SELECT @pos = CHARINDEX ( @splitchar, @splitstr, 0 )
	WHILE @pos <> 0
	BEGIN
		INSERT @split_elements(element) SELECT SUBSTRING(@splitstr, 1, @pos - 1)
		SELECT @splitstr = SUBSTRING(@splitstr, @pos + 1, LEN(@splitstr) + 1)
		SELECT @pos = CHARINDEX ( @splitchar, @splitstr, 0 )
	END
	INSERT @split_elements(element) VALUES(@splitstr)

	RETURN
END