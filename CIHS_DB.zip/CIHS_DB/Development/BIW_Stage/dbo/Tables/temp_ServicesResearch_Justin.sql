﻿CREATE TABLE [dbo].[temp_ServicesResearch_Justin] (
    [srvc_id]         INT           NOT NULL,
    [srvc_code]       CHAR (15)     NOT NULL,
    [srvc_desc]       VARCHAR (250) NOT NULL,
    [srvc_short_desc] VARCHAR (25)  NULL,
    [mod_id1]         CHAR (5)      NULL,
    [mod_id2]         CHAR (5)      NULL,
    [active]          BIT           NULL,
    [SRVC_SUM_ID]     INT           NOT NULL,
    [SRVC_SUM_DESC]   VARCHAR (50)  NOT NULL,
    [srvc_def_id]     INT           NOT NULL,
    [srvc_def_desc]   VARCHAR (250) NOT NULL,
    [ProviderICFFlag] INT           NOT NULL
);

