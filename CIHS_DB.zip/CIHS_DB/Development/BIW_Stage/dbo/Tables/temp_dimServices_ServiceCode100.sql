﻿CREATE TABLE [dbo].[temp_dimServices_ServiceCode100] (
    [ServicesSK]       INT NULL,
    [ServiceSummaryID] INT NULL
);

