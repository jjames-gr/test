﻿CREATE TABLE [dbo].[temp_processedfactclaims_holding] (
    [claim_mst_id]    INT NULL,
    [claim_det_id]    INT NULL,
    [claim_adj_id]    INT NULL,
    [DateOfServiceSK] INT NULL,
    [ServicesSK]      INT NULL
);

