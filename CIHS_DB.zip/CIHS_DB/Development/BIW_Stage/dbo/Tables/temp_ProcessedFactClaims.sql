﻿CREATE TABLE [dbo].[temp_ProcessedFactClaims] (
    [claim_mst_id]    INT NULL,
    [claim_det_id]    INT NULL,
    [claim_adj_id]    INT NULL,
    [ServicesSK]      INT NULL,
    [DateOfServiceSK] INT NULL
);

