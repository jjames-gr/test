﻿CREATE TABLE [dbo].[temp_dimServices_ServiceCode100_New] (
    [ServicesSK]       INT NULL,
    [ServiceSummaryID] INT NULL
);

