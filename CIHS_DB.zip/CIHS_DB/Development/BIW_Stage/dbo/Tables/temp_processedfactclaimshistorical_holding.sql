﻿CREATE TABLE [dbo].[temp_processedfactclaimshistorical_holding] (
    [claim_mst_id]    INT  NULL,
    [claim_det_id]    INT  NULL,
    [claim_adj_id]    INT  NULL,
    [updated_dt]      DATE NULL,
    [DateOfServiceSK] INT  NULL,
    [ServicesSK]      INT  NULL
);

