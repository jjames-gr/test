﻿CREATE TABLE [Processed].[Reports] (
    [ReportSK]                    INT              NULL,
    [ReportID]                    UNIQUEIDENTIFIER NOT NULL,
    [InstanceName]                NVARCHAR (128)   NULL,
    [Path]                        NVARCHAR (512)   NOT NULL,
    [Site]                        NVARCHAR (512)   NULL,
    [Library]                     NVARCHAR (512)   NULL,
    [Name]                        NVARCHAR (512)   NOT NULL,
    [ReportName]                  NVARCHAR (512)   NULL,
    [ReportTypeID]                INT              NOT NULL,
    [ReportType]                  NVARCHAR (32)    NULL,
    [ETLCreatedDate]              DATETIME         NOT NULL,
    [ETLModifiedDate]             DATETIME         NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)     NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)     NULL,
    [ETLCurrentRow]               BIT              NOT NULL,
    [ETLEffectiveFrom]            DATETIME         NOT NULL,
    [ETLEffectiveTo]              DATETIME         NOT NULL,
    [ETLInsertProjectExecutionID] INT              NOT NULL,
    [ETLUpdateProjectExecutionID] INT              NOT NULL,
    [ETLDMLOperation]             TINYINT          NOT NULL
);

