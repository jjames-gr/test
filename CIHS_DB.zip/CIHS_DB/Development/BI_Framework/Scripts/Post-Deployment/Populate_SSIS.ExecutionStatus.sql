﻿USE [BI_Framework];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [SSIS].[ExecutionStatus]([ExecutionStatusID], [StatusCode], [StatusName], [CreatedDate], [CreatedBy], [ModifiedDate], [ModifiedBy])
SELECT -1, N'U', N'Unknown', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 1, N'P', N'Primer', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 2, N'E', N'Executing', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 3, N'C', N'Completed', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 4, N'F', N'Failed', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe', '20120206 10:49:32.717', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 5, N'A', N'Aborted', '20120206 10:49:32.720', N'PBHC\Ben.Holcombe', '20120206 10:49:32.720', N'PBHC\Ben.Holcombe'
COMMIT;
RAISERROR (N'[SSIS].[ExecutionStatus]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

