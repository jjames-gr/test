﻿USE [BI_Framework];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [SSIS].[SSISConfigurations]([ConfigurationFilter], [ConfiguredValue], [PackagePath], [ConfiguredValueType])
SELECT N'ADO_CI', N'Data Source=PBHC-NEWREPORT;Initial Catalog=QM;Integrated Security=True;Connect Timeout=300;Application Name=BIW;', N'\Package.Connections[ADO_CI].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'etlSSASConnectionString', N'Data Source=BLUE212;Initial Catalog=BIW;Provider=MSOLAP.4;Integrated Security=SSPI;', N'\Package.Variables[User::etlSSASConnectionString].Properties[Value]', N'String' UNION ALL
SELECT N'OLEDB_GP', N'Data Source=PBHC-GPSVRBU;Initial Catalog=PBLME;Provider=SQLNCLI10.1;Integrated Security=SSPI;Auto Translate=False;Application Name=BIW;', N'\Package.Connections[OLEDB_GP].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'DefaultEffectiveFrom', N'1/1/1900 12:00:00 AM', N'\Package.Variables[User::etlDefaultEffectiveFrom].Properties[Value]', N'DateTime' UNION ALL
SELECT N'DefaultEffectiveTo', N'12/31/9999 12:00:00 AM', N'\Package.Variables[User::etlDefaultEffectiveTo].Properties[Value]', N'DateTime' UNION ALL
SELECT N'BingKey', N'AvwjIJ1qLWoXSZaG7hn5sTg053z1PUwPz2Xylr7Fupa-slFUOdOPqRq0B_R2V2dt', N'\Package.Variables[User::etlBingMapsKey].Properties[Value]', N'String' UNION ALL
SELECT N'ADO_BIW', N'Data Source=BLUE212;Initial Catalog=BIW;Integrated Security=True;Connect Timeout=600;Application Name=BIW;', N'\Package.Connections[ADO_BIW].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'CommonConnections', N'Data Source=BLUE212;Initial Catalog=msdb;Provider=SQLNCLI10.1;Integrated Security=SSPI;Application Name=BIW;Auto Translate=False;', N'\Package.Connections[SSIS_Package_Store].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'DaysOfExtraction', N'1', N'\Package.Variables[User::etlProcessIncrement].Properties[Value]', N'1' UNION ALL
SELECT N'OLEDB_CI_ReportCube', N'Data Source=PBHC-NewReport;Initial Catalog=CI_ReportCube;Provider=SQLNCLI10.1;Integrated Security=SSPI;Auto Translate=False;Application Name=BIW;', N'\Package.Connections[OLEDB_CI_ReportCube].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'SSAS_BIW', N'Data Source=BLUE212;Initial Catalog=BIW;Provider=MSOLAP.4;Integrated Security=SSPI;Impersonation Level=Impersonate;', N'\Package.Connections[SSAS_BIW].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'OLEDB_AS_BIW', N'Data Source=BLUE212;Initial Catalog=BIW;Provider=MSOLAP.4;Integrated Security=SSPI;Format=Tabular;', N'\Package.Connections[OLEDB_AS_BIW].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'ADO_Raw', N'Data Source=BLUE212;Initial Catalog=BIW_Stage;Integrated Security=True;Connect Timeout=300;Application Name=BIW;', N'\Package.Connections[ADO_Raw].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'CommonConnections', N'Data Source=BLUE212;Initial Catalog=BIW_Stage;Provider=SQLNCLI10.1;Integrated Security=SSPI;Application Name=BIW;Auto Translate=False;', N'\Package.Connections[OLEDB_Raw].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'CommonConnections', N'Data Source=BLUE212;Initial Catalog=BIW_Stage;Provider=SQLNCLI10.1;Integrated Security=SSPI;Application Name=BIW;Auto Translate=False;', N'\Package.Connections[OLEDB_Processed].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'CommonConnections', N'Data Source=PBHC-NEWREPORT;Initial Catalog=QM;Provider=SQLNCLI10.1;Integrated Security=SSPI;Application Name=BIW;Auto Translate=False;', N'\Package.Connections[OLEDB_CI].Properties[ConnectionString]', N'String' UNION ALL
SELECT N'CommonConnections', N'Data Source=BLUE212;Initial Catalog=BIW;Provider=SQLNCLI10.1;Integrated Security=SSPI;Application Name=BIW;Auto Translate=False;', N'\Package.Connections[OLEDB_BIW].Properties[ConnectionString]', N'String'
COMMIT;
RAISERROR (N'[SSIS].[SSISConfigurations]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

