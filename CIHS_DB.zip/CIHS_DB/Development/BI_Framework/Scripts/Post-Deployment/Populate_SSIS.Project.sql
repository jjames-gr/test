﻿USE [BI_Framework];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

SET IDENTITY_INSERT [SSIS].[Project] ON;

BEGIN TRANSACTION;
INSERT INTO [SSIS].[Project]([ProjectID], [ProjectName], [RegisteredDate], [CreatedDate], [CreatedBy], [ModifiedDate], [ModifiedBy])
SELECT -1, N'Unknown', '20120206 00:00:00.000', '20120206 10:49:32.720', N'PBHC\Ben.Holcombe', '20120206 10:49:32.720', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 1, N'BIW', '20120206 00:00:00.000', '20120206 10:57:18.677', N'PBHC\Ben.Holcombe', '20120206 10:57:18.677', N'PBHC\Ben.Holcombe' UNION ALL
SELECT 2, N'SSRS Execution History', '20120320 00:00:00.000', '20120320 10:30:13.043', N'PBHC\Ben.Holcombe', '20120320 10:30:13.043', N'PBHC\Ben.Holcombe'
COMMIT;
RAISERROR (N'[SSIS].[Project]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

SET IDENTITY_INSERT [SSIS].[Project] OFF;

