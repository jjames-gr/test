﻿CREATE TABLE [SSRS].[FormatTypes] (
    [FormatTypeSK]                INT           NOT NULL,
    [Format]                      NVARCHAR (32) NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL,
    [ETLModifiedDate]             DATETIME      NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)  NOT NULL,
    [ETLChecksumType2]            VARCHAR (32)  NULL,
    [ETLCurrentRow]               BIT           NOT NULL,
    [ETLEffectiveFrom]            DATETIME      NOT NULL,
    [ETLEffectiveTo]              DATETIME      NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLUpdateProjectExecutionID] INT           NOT NULL,
    CONSTRAINT [PK_FormatTypes] PRIMARY KEY CLUSTERED ([FormatTypeSK] ASC)
);

