﻿CREATE TABLE [SSRS].[ExecutionParameters] (
    [ExecutionParameterSK]        BIGINT          NOT NULL,
    [ExecutionLogSK]              BIGINT          NOT NULL,
    [MachineSK]                   INT             NOT NULL,
    [ParameterName]               NVARCHAR (2000) NOT NULL,
    [ParameterValue]              NVARCHAR (MAX)  NOT NULL,
    [ETLCreatedDate]              DATETIME        NOT NULL,
    [ETLModifiedDate]             DATETIME        NOT NULL,
    [ETLChecksumType1]            VARCHAR (32)    NOT NULL,
    [ETLInsertProjectExecutionID] INT             NOT NULL,
    [ETLUpdateProjectExecutionID] INT             NOT NULL,
    CONSTRAINT [PK_ExecutionParameters] PRIMARY KEY CLUSTERED ([ExecutionParameterSK] ASC)
);

