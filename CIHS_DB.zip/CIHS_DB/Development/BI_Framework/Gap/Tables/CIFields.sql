﻿CREATE TABLE [Gap].[CIFields] (
    [ReportID]            INT           NULL,
    [AnalysisOwner]       VARCHAR (7)   NULL,
    [Title]               VARCHAR (150) NULL,
    [ReportDesc]          VARCHAR (300) NULL,
    [GAPAnalysisPriority] VARCHAR (15)  NULL,
    [ReportGroup]         VARCHAR (38)  NULL,
    [SubjectID]           INT           NULL,
    [ReportName]          VARCHAR (75)  NULL,
    [ReportFile]          VARCHAR (75)  NULL,
    [StoredProc]          VARCHAR (75)  NULL,
    [TableName]           VARCHAR (75)  NULL,
    [FieldName]           VARCHAR (75)  NULL,
    [Active]              INT           NULL,
    [ReportFrequency]     VARCHAR (50)  NULL,
    [ReportDatabase]      VARCHAR (20)  NULL,
    [ReportPriority]      VARCHAR (30)  NULL,
    [ReportDataGroup]     VARCHAR (50)  NULL,
    [TableDataGroup]      VARCHAR (50)  NULL
);

