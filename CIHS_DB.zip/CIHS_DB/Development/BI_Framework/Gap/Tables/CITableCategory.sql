﻿CREATE TABLE [Gap].[CITableCategory] (
    [Category]  VARCHAR (25) NULL,
    [TableName] VARCHAR (50) NULL
);

