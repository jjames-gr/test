﻿CREATE TABLE [Gap].[BIWFields] (
    [SourceTable]  VARCHAR (100) NULL,
    [SourceColumn] VARCHAR (100) NULL,
    [TargetTable]  VARCHAR (100) NULL,
    [TargetColumn] VARCHAR (100) NULL
);

