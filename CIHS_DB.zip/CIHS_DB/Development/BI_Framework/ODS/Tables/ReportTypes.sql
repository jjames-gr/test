﻿CREATE TABLE [ODS].[ReportTypes] (
    [ReportType] INT           NOT NULL,
    [Name]       NVARCHAR (32) NOT NULL
);

