﻿

CREATE VIEW [DW].[LastProjectExecution] AS

SELECT
	PkgE.[PackageName]
	,PkgE.[ExecutionStatusID]
	,PkgE.[ExecutionAttempt]
	,PkgE.[PackageVersion]
	,PkgE.[ExecutionStartTime]
	,CONVERT(DATETIME,ISNULL(PkgE.[ExecutionEndTime],GETDATE()) - PkgE.[ExecutionStartTime]) AS Duration
	,PkgE.[RowsRead]
	,PkgE.[RowsInserted]
	,PkgE.[RowsUpdated]
	,PkgE.[RowsDeleted]
	,PkgE.[RowsDisposed]
	,PkgE.[RowsErrored]
	,PkgE.[ExecutionGUID]
FROM
	[SSIS].[PackageExecution] AS PkgE
WHERE
	[ProjectExecutionID] = (SELECT MAX(ProjectExecutionID) FROM [SSIS].[ProjectExecution] WHERE [ProjectID] = (SELECT [ProjectID] FROM [SSIS].[Project] WHERE [ProjectName] = 'BIW'))