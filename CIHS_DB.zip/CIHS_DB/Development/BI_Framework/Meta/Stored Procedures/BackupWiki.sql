﻿CREATE procedure [Meta].[BackupWiki] 

as


declare @dtBackupDate as int

set @dtBackupDate = CONVERT(int, convert(varchar, getdate(),112))


Delete from BI_Framework.Meta.AttributesBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.AttributesHierarchyBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.AttributesMeasureGroupBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.AttributesReportsBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.AttributesTablesBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.CubeHierarchyBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.CubeMeasureGroupBackup where BackupDate = @dtBackupDate

Delete from BI_Framework.Meta.TablesBackup where BackupDate = @dtBackupDate


--insert records into backup table for current day

Insert BI_Framework.Meta.AttributesBackup
(BackupDate, AttributeID, AttributeName, AttributeBusinessName, AttributeDataType, AttributeDefinition, AttributeSpecialRules, AttributeTypeID, CubeOnlyAttributeFlag, ReportOnlyAttributeFlag, InCubeFlag, ActiveFlag, InWikiFlag, ApprovedFlag, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
Select
@dtBackupDate, AttributeID, AttributeName, AttributeBusinessName, AttributeDataType, AttributeDefinition, AttributeSpecialRules, AttributeTypeID, CubeOnlyAttributeFlag, ReportOnlyAttributeFlag, InCubeFlag, ActiveFlag, InWikiFlag, ApprovedFlag, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from
	BI_Framework.Meta.Attributes


Insert BI_Framework.Meta.AttributesHierarchyBackup
	(BackupDate, AttributeID, HierarchyID, AttributeOrder, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
select
	@dtBackupDate, AttributeID, HierarchyID, AttributeOrder, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from 
	BI_Framework.Meta.AttributesHierarchy

Insert BI_Framework.Meta.AttributesMeasureGroupBackup
	(BackupDate, AttributeID, MeasureGroupID, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
select
	@dtBackupDate, AttributeID, MeasureGroupID, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from
	BI_Framework.Meta.AttributesMeasureGroup
	

insert BI_Framework.Meta.AttributesReportsBackup
	(BackupDate, AttributeID, ReportID, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
select
	@dtBackupDate, AttributeID, ReportID, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from
	BI_Framework.Meta.AttributesReports


insert BI_Framework.Meta.AttributesTablesBackup
	(BackupDate, AttributeID, TableID, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
select
	@dtBackupDate, AttributeID, TableID, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from
	BI_Framework.Meta.AttributesTables
	

Insert BI_Framework.Meta.CubeHierarchyBackup
	(BackupDate, HierarchyID, Hierarchy, ActiveFlag, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
select
	@dtBackupDate, HierarchyID, Hierarchy, ActiveFlag, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from
	BI_Framework.Meta.CubeHierarchy


Insert BI_Framework.Meta.CubeMeasureGroupBackup
	(BackupDate, MeasureGroupID, MeasureGroup, ActiveFlag, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy)
select
	@dtBackupDate, MeasureGroupID, MeasureGroup, ActiveFlag, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy
from
	BI_Framework.Meta.CubeMeasureGroup


Insert BI_Framework.Meta.TablesBackup
	(BackupDate, TableID, TableDBObjectID, TableName, TableSchema, TableDefinition, TableSpecialRules, TableType, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy, ActiveFlag)
select
	@dtBackupDate, TableID, TableDBObjectID, TableName, TableSchema, TableDefinition, TableSpecialRules, TableType, ETLCreateDate, ETLCreateBy, ETLUpdateDate, ETLUpdateBy, ActiveFlag	
from
	BI_Framework.Meta.Tables