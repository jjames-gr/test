﻿
CREATE view [Meta].[WikiTableList]
as
Select
	at.AttributeID,
	t.TableID, 
	TableName, 
	TableSchema, 
	TableDefinition, 
	TableSpecialRules, 
	TableType, 
	ActiveFlag
from
	Meta.Tables t
	Inner join Meta.AttributesTables at on t.TableID = at.TableID
where
	ActiveFlag = 1
	and TableType <> 'Unknown'