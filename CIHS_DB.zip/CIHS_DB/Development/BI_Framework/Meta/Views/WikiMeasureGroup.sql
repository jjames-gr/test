﻿
CREATE view [Meta].[WikiMeasureGroup] as
Select
	AttributeID,
	m.MeasureGroupID,
	MeasureGroup,
	ActiveFlag
from
	Meta.CubeMeasureGroup m
	inner join Meta.AttributesMeasureGroup AM on m.MeasureGroupID = am.MeasureGroupID
where
	ActiveFlag = 1