﻿
CREATE view [Meta].[WikiHierarchyList] as
SELECT
	ah.AttributeID,
	h.HierarchyID,
	h.Hierarchy
from
	MEta.CubeHierarchy h
	inner join Meta.AttributesHierarchy ah on h.HierarchyID = ah.HierarchyID
where
	ActiveFlag = 1