﻿
CREATE VIEW [Meta].[WikiAttributeList] as
SELECT
	AttributeID, 
	AttributeName,
	AttributeBusinessName,
	AttributeDataType, 
	AttributeDefinition,
	AttributeSpecialRules, 
	AttributeType,
	CubeOnlyAttributeFlag,
	ReportOnlyAttributeFlag, 
	InCubeFlag, 
	ActiveFlag, 
	InWikiFlag, 
	ApprovedFlag
from
	Meta.Attributes A
	inner join Meta.AttributeType AT on a.AttributeTypeID = AT.AttributeTypeID
where
	ActiveFlag = 1
	and InWikiFlag = 1