﻿
CREATE view [Meta].[WikiReportList] as
select 
	AR.AttributeID,
	REPORT_ID ReportID,
	rg.rpt_group_name CIReportGroupName,
	rg.rpt_group_short_name CIReportShortGroupName,
	rs.DESCRIPTION Subject ,
	FILE_NAME ReportFileName, 
	TITLE ReportTitle, 
	r.DESCRIPTION ReportDescprition, 
	--USER_ID, 
	r.ACTIVE ActiveFlag
from
	[PBHC-NEWREPORT].qm.dbo.tbl_reports r
	inner join [PBHC-NEWREPORT].qm.dbo.tbl_Report_Subject rs on r.SUBJECT_ID = rs.SUBJECT_ID
	inner join [PBHC-NEWREPORT].qm.dbo.tbl_Report_Groups rg on r.rpt_grp_id = rg.rpt_grp_id
	inner join Meta.AttributesReports AR on Ar.ReportID = R.Report_ID
where
	r.Active = 1