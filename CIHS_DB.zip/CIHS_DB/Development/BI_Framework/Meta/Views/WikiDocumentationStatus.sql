﻿CREATE view [Meta].[WikiDocumentationStatus]
as
select
	case when InWikiFlag = 0 then 'Developer Use Only' else 'Wiki' end WikiStatus,
	case when nullif(AttributeDefinition,'') IS not null then 'Defined' else 'To Be Defined' end DefinitionStatus,
	case when ApprovedFlag = 0 then 'Not Approved' else 'Approved' end ApprovedStatus,
	case when ActiveFlag = 0 then 'Not Active\Deleted Attribute' else 'Active Attribute' end ActiveStatus,
	at.AttributeType,
	AttributeID, AttributeName, AttributeBusinessName, AttributeDataType, AttributeDefinition, AttributeSpecialRules, CubeOnlyAttributeFlag, ReportOnlyAttributeFlag, InCubeFlag, ActiveFlag, InWikiFlag, ApprovedFlag, a.ETLCreateDate, a.ETLCreateBy, a.ETLUpdateDate, a.ETLUpdateBy
from
	Meta.Attributes A
	inner join Meta.AttributeType AT on a.AttributeTypeID = at.AttributeTypeID