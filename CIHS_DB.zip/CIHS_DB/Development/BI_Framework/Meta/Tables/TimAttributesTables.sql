﻿CREATE TABLE [Meta].[TimAttributesTables] (
    [AttributesTablesID] INT          IDENTITY (1, 1) NOT NULL,
    [AttributeID]        INT          NOT NULL,
    [TableID]            INT          NOT NULL,
    [ETLCreateDate]      DATETIME     NULL,
    [ETLCreateBy]        VARCHAR (50) NULL,
    [ETLUpdateDate]      DATETIME     NULL,
    [ETLUpdateBy]        VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([AttributesTablesID] ASC),
    CONSTRAINT [FK_AttributeID] FOREIGN KEY ([AttributeID]) REFERENCES [Meta].[TimAttributes] ([AttributeID]),
    CONSTRAINT [FK_TableID] FOREIGN KEY ([TableID]) REFERENCES [Meta].[TimTables] ([TableID])
);

