﻿CREATE TABLE [Meta].[AttributesTables] (
    [AttributeID]   INT          NOT NULL,
    [TableID]       INT          NOT NULL,
    [ETLCreateDate] DATETIME     NULL,
    [ETLCreateBy]   VARCHAR (50) NULL,
    [ETLUpdateDate] DATETIME     NULL,
    [ETLUpdateBy]   VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([AttributeID] ASC, [TableID] ASC)
);

