﻿CREATE TABLE [Meta].[AttributesOld] (
    [AttributeID]         INT           IDENTITY (1, 1) NOT NULL,
    [AttributeName]       VARCHAR (50)  NULL,
    [AttributeDataType]   VARCHAR (20)  NULL,
    [AttributeDefinition] VARCHAR (500) NULL,
    [AttributeType]       VARCHAR (20)  NULL,
    [InCubeFlag]          BIT           NULL,
    [ETLCreateDate]       DATETIME      NULL,
    [ETLCreateBy]         VARCHAR (50)  NULL,
    [ETLUpdateDate]       DATETIME      NULL,
    [ETLUpdateBy]         VARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([AttributeID] ASC)
);

