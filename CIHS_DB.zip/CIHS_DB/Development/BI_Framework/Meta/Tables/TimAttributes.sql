﻿CREATE TABLE [Meta].[TimAttributes] (
    [AttributeID]         INT           IDENTITY (1, 1) NOT NULL,
    [AttributeName]       VARCHAR (50)  NULL,
    [AttributeDataType]   VARCHAR (20)  NULL,
    [AttributeDefinition] VARCHAR (500) NULL,
    [AttributeType]       VARCHAR (20)  NULL,
    [InCubeFlag]          BIT           NULL,
    [ActiveFlag]          INT           NOT NULL,
    [InWikiFlag]          INT           NOT NULL,
    [ETLCreateDate]       DATETIME      NULL,
    [ETLCreateBy]         VARCHAR (50)  NULL,
    [ETLUpdateDate]       DATETIME      NULL,
    [ETLUpdateBy]         VARCHAR (50)  NULL,
    CONSTRAINT [PK_AttributeID] PRIMARY KEY CLUSTERED ([AttributeID] ASC)
);

