﻿CREATE TABLE [Meta].[TablesBackup] (
    [BackupDate]        INT            NULL,
    [TableID]           INT            NOT NULL,
    [TableDBObjectID]   INT            NULL,
    [TableName]         VARCHAR (50)   NULL,
    [TableSchema]       VARCHAR (10)   NULL,
    [TableDefinition]   VARCHAR (2000) NULL,
    [TableSpecialRules] VARCHAR (2000) NULL,
    [TableType]         VARCHAR (20)   NULL,
    [ETLCreateDate]     DATETIME       NULL,
    [ETLCreateBy]       VARCHAR (50)   NULL,
    [ETLUpdateDate]     DATETIME       NULL,
    [ETLUpdateBy]       VARCHAR (50)   NULL,
    [ActiveFlag]        BIT            NULL
);

