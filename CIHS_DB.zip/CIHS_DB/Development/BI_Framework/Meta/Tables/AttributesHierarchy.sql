﻿CREATE TABLE [Meta].[AttributesHierarchy] (
    [AttributeID]    INT          NOT NULL,
    [HierarchyID]    INT          NOT NULL,
    [AttributeOrder] INT          NOT NULL,
    [ETLCreateDate]  DATETIME     NULL,
    [ETLCreateBy]    VARCHAR (50) NULL,
    [ETLUpdateDate]  DATETIME     NULL,
    [ETLUpdateBy]    VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([AttributeID] ASC, [HierarchyID] ASC)
);

