﻿CREATE TABLE [Meta].[Attributes] (
    [AttributeID]             INT            IDENTITY (1, 1) NOT NULL,
    [AttributeName]           VARCHAR (50)   NULL,
    [AttributeBusinessName]   VARCHAR (50)   NULL,
    [AttributeDataType]       VARCHAR (20)   NULL,
    [AttributeDefinition]     VARCHAR (2000) NULL,
    [AttributeSpecialRules]   VARCHAR (2000) NULL,
    [AttributeTypeID]         INT            NULL,
    [CubeOnlyAttributeFlag]   BIT            NULL,
    [ReportOnlyAttributeFlag] BIT            NULL,
    [InCubeFlag]              BIT            NULL,
    [ActiveFlag]              INT            NOT NULL,
    [InWikiFlag]              INT            NOT NULL,
    [ApprovedFlag]            BIT            NULL,
    [ETLCreateDate]           DATETIME       NULL,
    [ETLCreateBy]             VARCHAR (50)   NULL,
    [ETLUpdateDate]           DATETIME       NULL,
    [ETLUpdateBy]             VARCHAR (50)   NULL,
    PRIMARY KEY CLUSTERED ([AttributeID] ASC)
);

