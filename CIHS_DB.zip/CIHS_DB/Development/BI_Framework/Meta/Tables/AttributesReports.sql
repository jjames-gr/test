﻿CREATE TABLE [Meta].[AttributesReports] (
    [AttributeID]   INT          NOT NULL,
    [ReportID]      INT          NOT NULL,
    [ETLCreateDate] DATETIME     NULL,
    [ETLCreateBy]   VARCHAR (50) NULL,
    [ETLUpdateDate] DATETIME     NULL,
    [ETLUpdateBy]   VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([AttributeID] ASC, [ReportID] ASC)
);

