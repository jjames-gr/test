﻿CREATE TABLE [Meta].[CubeMeasureGroup] (
    [MeasureGroupID] INT          IDENTITY (1, 1) NOT NULL,
    [MeasureGroup]   VARCHAR (50) NULL,
    [ActiveFlag]     BIT          NULL,
    [ETLCreateDate]  DATETIME     NULL,
    [ETLCreateBy]    VARCHAR (50) NULL,
    [ETLUpdateDate]  DATETIME     NULL,
    [ETLUpdateBy]    VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([MeasureGroupID] ASC)
);

