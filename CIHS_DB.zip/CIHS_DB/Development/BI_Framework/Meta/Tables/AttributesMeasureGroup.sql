﻿CREATE TABLE [Meta].[AttributesMeasureGroup] (
    [AttributeID]    INT          NOT NULL,
    [MeasureGroupID] INT          NOT NULL,
    [ETLCreateDate]  DATETIME     NULL,
    [ETLCreateBy]    VARCHAR (50) NULL,
    [ETLUpdateDate]  DATETIME     NULL,
    [ETLUpdateBy]    VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([AttributeID] ASC, [MeasureGroupID] ASC)
);

