﻿CREATE TABLE [Meta].[AttributeType] (
    [AttributeTypeID] INT          IDENTITY (1, 1) NOT NULL,
    [AttributeType]   VARCHAR (20) NULL,
    [ETLCreateDate]   DATETIME     NULL,
    [ETLCreateBy]     VARCHAR (50) NULL,
    [ETLUpdateDate]   DATETIME     NULL,
    [ETLUpdateBy]     VARCHAR (50) NULL
);

