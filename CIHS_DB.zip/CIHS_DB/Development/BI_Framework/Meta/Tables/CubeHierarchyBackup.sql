﻿CREATE TABLE [Meta].[CubeHierarchyBackup] (
    [BackupDate]    INT          NULL,
    [HierarchyID]   INT          NOT NULL,
    [Hierarchy]     VARCHAR (25) NULL,
    [ActiveFlag]    BIT          NULL,
    [ETLCreateDate] DATETIME     NULL,
    [ETLCreateBy]   VARCHAR (50) NULL,
    [ETLUpdateDate] DATETIME     NULL,
    [ETLUpdateBy]   VARCHAR (50) NULL
);

