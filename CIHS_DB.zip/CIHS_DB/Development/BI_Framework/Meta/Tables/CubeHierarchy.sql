﻿CREATE TABLE [Meta].[CubeHierarchy] (
    [HierarchyID]   INT          IDENTITY (1, 1) NOT NULL,
    [Hierarchy]     VARCHAR (25) NULL,
    [ActiveFlag]    BIT          NULL,
    [ETLCreateDate] DATETIME     NULL,
    [ETLCreateBy]   VARCHAR (50) NULL,
    [ETLUpdateDate] DATETIME     NULL,
    [ETLUpdateBy]   VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([HierarchyID] ASC)
);

