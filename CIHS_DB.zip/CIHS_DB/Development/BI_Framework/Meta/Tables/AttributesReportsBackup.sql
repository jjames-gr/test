﻿CREATE TABLE [Meta].[AttributesReportsBackup] (
    [BackupDate]    INT          NULL,
    [AttributeID]   INT          NOT NULL,
    [ReportID]      INT          NOT NULL,
    [ETLCreateDate] DATETIME     NULL,
    [ETLCreateBy]   VARCHAR (50) NULL,
    [ETLUpdateDate] DATETIME     NULL,
    [ETLUpdateBy]   VARCHAR (50) NULL
);

