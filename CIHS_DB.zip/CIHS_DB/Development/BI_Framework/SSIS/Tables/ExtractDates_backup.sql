﻿CREATE TABLE [SSIS].[ExtractDates_backup] (
    [ExtractDateID]   INT          IDENTITY (1, 1) NOT NULL,
    [TableName]       VARCHAR (50) NULL,
    [LastExtractDate] DATETIME     NULL
);

