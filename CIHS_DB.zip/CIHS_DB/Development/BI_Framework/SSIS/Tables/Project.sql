﻿CREATE TABLE [SSIS].[Project] (
    [ProjectID]      INT           IDENTITY (1, 1) NOT NULL,
    [ProjectName]    VARCHAR (128) NOT NULL,
    [RegisteredDate] DATE          NOT NULL,
    [CreatedDate]    DATETIME      NOT NULL,
    [CreatedBy]      VARCHAR (128) NOT NULL,
    [ModifiedDate]   DATETIME      NOT NULL,
    [ModifiedBy]     VARCHAR (128) NOT NULL,
    CONSTRAINT [PK_Project] PRIMARY KEY CLUSTERED ([ProjectID] ASC)
);

