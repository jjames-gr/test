﻿CREATE TABLE [SSIS].[ExecutionStatus] (
    [ExecutionStatusID] INT           NOT NULL,
    [StatusCode]        CHAR (1)      NOT NULL,
    [StatusName]        VARCHAR (128) NOT NULL,
    [CreatedDate]       DATETIME      NOT NULL,
    [CreatedBy]         VARCHAR (128) NOT NULL,
    [ModifiedDate]      DATETIME      NOT NULL,
    [ModifiedBy]        VARCHAR (128) NOT NULL,
    CONSTRAINT [PK_ExecutionStatus] PRIMARY KEY CLUSTERED ([ExecutionStatusID] ASC)
);

