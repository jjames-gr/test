﻿CREATE TABLE [SSIS].[ProjectExecution] (
    [ProjectExecutionID] INT           IDENTITY (1, 1) NOT NULL,
    [ProjectID]          INT           NOT NULL,
    [ExecutionStatusID]  INT           NOT NULL,
    [ExecutionStartTime] DATETIME      NOT NULL,
    [ExecutionEndTime]   DATETIME      NULL,
    [ProcessWindowStart] DATETIME2 (7) NOT NULL,
    [ProcessWindowEnd]   DATETIME2 (7) NOT NULL,
    [ExecutionAttempt]   SMALLINT      NOT NULL,
    [CreatedDate]        DATETIME      NOT NULL,
    [CreatedBy]          VARCHAR (128) NOT NULL,
    [ModifiedDate]       DATETIME      NOT NULL,
    [ModifiedBy]         VARCHAR (128) NOT NULL,
    CONSTRAINT [PK_ProjectExecution] PRIMARY KEY CLUSTERED ([ProjectExecutionID] ASC),
    CONSTRAINT [FK_ProjectExecution_ExecutionStatus] FOREIGN KEY ([ExecutionStatusID]) REFERENCES [SSIS].[ExecutionStatus] ([ExecutionStatusID]),
    CONSTRAINT [FK_ProjectExecution_Project] FOREIGN KEY ([ProjectID]) REFERENCES [SSIS].[Project] ([ProjectID])
);

