﻿CREATE TABLE [SSIS].[Event] (
    [EventID]            INT            IDENTITY (1, 1) NOT NULL,
    [ExecutionGUID]      VARCHAR (64)   NOT NULL,
    [EventType]          VARCHAR (64)   NULL,
    [SourceGUID]         VARCHAR (64)   NULL,
    [SourceName]         VARCHAR (256)  NULL,
    [MachineName]        VARCHAR (128)  NULL,
    [UserName]           VARCHAR (128)  NULL,
    [CodeVersion]        VARCHAR (24)   NULL,
    [TaskName]           VARCHAR (128)  NULL,
    [MessageCode]        INT            NULL,
    [MessageDescription] VARCHAR (2048) NULL,
    [MessageTime]        DATETIME       NULL,
    CONSTRAINT [PK_Error] PRIMARY KEY CLUSTERED ([EventID] ASC)
);


GO
CREATE NONCLUSTERED INDEX [IX_Test]
    ON [SSIS].[Event]([EventType] ASC);

