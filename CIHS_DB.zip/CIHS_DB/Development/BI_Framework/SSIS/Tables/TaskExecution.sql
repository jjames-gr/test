﻿CREATE TABLE [SSIS].[TaskExecution] (
    [TaskExecutionID]    BIGINT        IDENTITY (1, 1) NOT NULL,
    [ExecutionStatusID]  INT           NOT NULL,
    [ExecutionGUID]      VARCHAR (64)  NOT NULL,
    [TaskName]           VARCHAR (256) NULL,
    [TaskGUID]           VARCHAR (64)  NOT NULL,
    [ExecutionStartTime] DATETIME      NOT NULL,
    [ExecutionEndTime]   DATETIME      NULL,
    [CreatedDate]        DATETIME      NOT NULL,
    [CreatedBy]          VARCHAR (128) NOT NULL,
    [ModifiedDate]       DATETIME      NOT NULL,
    [ModifiedBy]         VARCHAR (128) NOT NULL,
    CONSTRAINT [PK_TaskExecution] PRIMARY KEY CLUSTERED ([TaskExecutionID] ASC)
);

