﻿CREATE TABLE [SSIS].[ExtractDates] (
    [ExtractDateID]   INT          IDENTITY (1, 1) NOT NULL,
    [TableName]       VARCHAR (50) NULL,
    [LastExtractDate] DATETIME     NULL
);

