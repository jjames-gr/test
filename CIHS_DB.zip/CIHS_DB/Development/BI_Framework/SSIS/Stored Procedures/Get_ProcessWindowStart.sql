﻿
/***===============================================================================================
== Name:		Get_ProcessWindowStart 
== Created:		4/26/2013
== Author:		Bob Lang
== Description: Used to get the ProcessWindowStart date for Incremental refresh
===================================================================================================
== Parameters:
==	@bIncrementalExtract - indicates if the table passed into the procedure is a full or incremental refresh
==	@sTableName - the name of the table that needs the process date pulled from the table 
==  @LastExtractDate - the date the table was last extracted - it is stored in the ssis.ExtractDates table
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE procedure [SSIS].[Get_ProcessWindowStart] 
	@bIncrementalExtract bit,
	@sTableName varchar(50),
	@ProcessWindowStart datetime output
 as

if @bIncrementalExtract = 1
	begin

		if exists(select * from ssis.ExtractDates where TableName = @sTableName)
			begin
				--table has been extracted in past - returns the last extract date and adds 1 second for the start date.
				set @ProcessWindowStart = convert(datetime, (select dateadd(SS, 1, LastExtractDate) from ssis.ExtractDates nolock where TableName = @sTableName))
			end
		else
			begin
				--table has not been extracted in past - creates record and sets data to 1/1/1900
				insert ssis.ExtractDates 
				(TableName, LastExtractDate) 
				values (@sTableName, '1/1/1900')
			
				set @ProcessWindowStart = convert(datetime, '1/1/1900')
			end
	End

select ProcessWindowStart = @ProcessWindowStart

return