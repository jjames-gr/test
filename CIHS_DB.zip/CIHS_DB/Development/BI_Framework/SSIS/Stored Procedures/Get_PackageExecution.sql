﻿

/***===============================================================================================
== Name:		Get_PackageExecution
== Created:		09-28-2011
== Author:		Benjamin Holcombe
== Description: Used to get the PackageExecutionID
===================================================================================================
== Parameters:
==	@ProjectName
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[Get_PackageExecution]
	@PackageName VARCHAR(256)
	,@ProjectExecutionID INT
	,@ExecutionGUID VARCHAR(64)
	,@PackageGUID VARCHAR(64)
	,@PackageVersion VARCHAR(16)
	,@UserName VARCHAR(128)
	,@MachineName VARCHAR(256)
	,@ProcessWindowStart DATETIME2
	,@ProcessWindowEnd DATETIME2
	,@ExecutionStatusID INT OUTPUT

AS
BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';

	--Procedure Variables
	DECLARE @ExecutionStatus VARCHAR(16) = NULL;
	DECLARE @PackageExecutionID INT;
	
	BEGIN TRY
		SET @TaskName = 'Querying Package Execution';
		--Obtain the last execution ignoring aborted executions.
		SELECT TOP 1
			@PackageExecutionID = PE.[PackageExecutionID]
			,@ExecutionStatusID = PE.[ExecutionStatusID]
			,@ExecutionStatus = ES.[StatusName]
		FROM
			[SSIS].[PackageExecution] AS PE
			INNER JOIN [SSIS].[ExecutionStatus] AS ES ON
				PE.[ExecutionStatusID] = ES.[ExecutionStatusID]
		WHERE
			PE.[ProjectExecutionID] = @ProjectExecutionID
			AND PE.[PackageName] = @PackageName
			AND PE.[ExecutionStatusID] <> 5
		ORDER BY
			PE.[PackageExecutionID] DESC
		
		IF @PackageExecutionID IS NOT NULL
			BEGIN
				IF @ExecutionStatusID = 1
				--Code 1 Primer
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						SET @ExecutionStatusID = 2;
						UPDATE [SSIS].[PackageExecution]
						SET
							[ExecutionStatusID] = @ExecutionStatusID
							,[ExecutionGUID] = @ExecutionGUID
							,[PackageVersion] = @PackageVersion
							,[ProcessWindowStart] = @ProcessWindowStart
							,[ProcessWindowEnd] = @ProcessWindowEnd
						WHERE
							[PackageExecutionID] = @PackageExecutionID
						RETURN
					END
				ELSE IF @ExecutionStatusID = 2
				--Code 2 Executing
				--This should occur when a hard error occurred leaving the Project execution in an unknown state
				--Since the prior execution did not complete we need to treat this as an error and cleanup the prior execution of the package
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						SET @ExecutionStatusID = 4;
						UPDATE [SSIS].[PackageExecution]
						SET
							[ExecutionStatusID] = @ExecutionStatusID
							,[ExecutionAttempt] = [ExecutionAttempt] + 1
							,[ExecutionGUID] = @ExecutionGUID
							,[PackageVersion] = @PackageVersion
							,[ProcessWindowStart] = @ProcessWindowStart
							,[ProcessWindowEnd] = @ProcessWindowEnd
						WHERE
							[PackageExecutionID] = @PackageExecutionID
						RETURN
					END
				ELSE IF @ExecutionStatusID = 3
				--Code 3 Completed
				--Package has already completed in a prior execution of the Project execution instance and there is no work for the package to perform
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						RETURN
					END
				ELSE IF @ExecutionStatusID = 4
				--Code 4 Failed
				--Restart the package and increment the execution attempt
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						UPDATE [SSIS].[PackageExecution]
						SET
							[ExecutionStatusID] = @ExecutionStatusID
							,[ExecutionAttempt] = [ExecutionAttempt] + 1
							,[ExecutionGUID] = @ExecutionGUID
							,[PackageVersion] = @PackageVersion
							,[ProcessWindowStart] = @ProcessWindowStart
							,[ProcessWindowEnd] = @ProcessWindowEnd
						WHERE
							[PackageExecutionID] = @PackageExecutionID
						RETURN
					END
				ELSE
					BEGIN
						SET @TaskName = 'Invalid Package Execution Status';
						RETURN
					END
			END
		SET @ExecutionStatusID = 2;
		INSERT INTO [SSIS].[PackageExecution]
		(
			[ProjectExecutionID]
			,[ExecutionStatusID]
			,[ExecutionGUID]
			,[PackageName]
			,[PackageGUID]
			,[PackageVersion]
			,[UserName]
			,[MachineName]
			,[ExecutionStartTime]
			,[ExecutionEndTime]
			,[ProcessWindowStart]
			,[ProcessWindowEnd]
			,[ExecutionAttempt]
			,[RowsRead]
			,[RowsInserted]
			,[RowsUpdated]
			,[RowsDeleted]
			,[RowsDisposed]
			,[RowsErrored]
			,[CreatedDate]
			,[CreatedBy]
			,[ModifiedDate]
			,[ModifiedBy]
		)
		VALUES
		(
			@ProjectExecutionID
			,@ExecutionStatusID
			,@ExecutionGUID
			,@PackageName
			,@PackageGUID
			,@PackageVersion
			,@UserName
			,@MachineName
			,GETDATE()
			,NULL
			,@ProcessWindowStart
			,@ProcessWindowEnd
			,1
			,0
			,0
			,0
			,0
			,0
			,0
			,GETDATE()
			,SYSTEM_USER
			,GETDATE()
			,SYSTEM_USER
		)

		SET @PackageExecutionID = SCOPE_IDENTITY();
	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();
				
		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = @ExecutionGUID
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END