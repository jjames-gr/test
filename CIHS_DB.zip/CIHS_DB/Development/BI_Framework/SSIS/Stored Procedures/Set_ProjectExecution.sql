﻿/***===============================================================================================
== Name:		Set_ProjectExecution
== Created:		10-06-2011
== Author:		Benjamin Holcombe
== Description: Used to set the ProjectExecutionID
===================================================================================================
== Parameters:
==	@ProjectName
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[Set_ProjectExecution]
	@ProjectExecutionID INT
	,@ExecutionStatusID INT
	,@ExecutionGUID VARCHAR(64)
AS
BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @MachineName VARCHAR(128);
	DECLARE @UserName VARCHAR(128);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';
	
	--Procedure Variables
	DECLARE @ExecutionStatus VARCHAR(16) = NULL;

	BEGIN TRY
		SET @TaskName = 'Updating Project Execution';
		
		IF @ExecutionStatusID <> 4
		--Code 3 Completed
			BEGIN
				SET @TaskName = 'Updating Execution Status' + @ExecutionStatus;
				UPDATE [SSIS].[ProjectExecution]
				SET
					ExecutionStatusID = 3
					,ExecutionEndTime = GETDATE()
				WHERE
					[ProjectExecutionID] = @ProjectExecutionID
				RETURN
			END
		ELSE IF @ExecutionStatusID = 4
		--Code 4 Failed
			BEGIN
				SET @TaskName = 'Updating Execution Status' + @ExecutionStatus;
				UPDATE [SSIS].[ProjectExecution]
				SET
					ExecutionStatusID = 4
					,ExecutionEndTime = GETDATE()
				WHERE
					[ProjectExecutionID] = @ProjectExecutionID
				RETURN
			END
		ELSE
			BEGIN
				SET @TaskName = 'Updating Execution Status Unknown';
				RETURN
			END

	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();
				
		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = @ExecutionGUID
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END