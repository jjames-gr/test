﻿/***===============================================================================================
== Name:		Get_Project
== Created:		09-23-2011
== Author:		Benjamin Holcombe
== Description: Used to get the ProjectID
===================================================================================================
== Parameters:
==	@ProjectName
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[Get_Project]
	@ProjectName VARCHAR(128) = 'Unknown'
	,@ProjectID INT OUTPUT

AS
BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @MachineName VARCHAR(128);
	DECLARE @UserName VARCHAR(128);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';
	
	BEGIN TRY
		SET @TaskName = 'Registering Project';
		SELECT @ProjectID = [ProjectID] FROM [SSIS].[Project] WHERE [ProjectName] = @ProjectName;
		
		IF @ProjectID IS NOT NULL
			BEGIN
				RETURN
			END
		ELSE
			INSERT INTO [SSIS].[Project]
			(
				[ProjectName]
				,[RegisteredDate]
				,[CreatedDate]
				,[CreatedBy]
				,[ModifiedDate]
				,[ModifiedBy]
			)
			VALUES
			(
				@ProjectName
				,GETDATE()
				,GETDATE()
				,SYSTEM_USER
				,GETDATE()
				,SYSTEM_USER
			)

		SET @ProjectID = SCOPE_IDENTITY()
	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();
				
		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = -1
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END