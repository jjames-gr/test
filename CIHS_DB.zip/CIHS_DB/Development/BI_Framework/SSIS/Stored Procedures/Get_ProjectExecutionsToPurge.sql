﻿
/***===============================================================================================
== Name:		Get_ProjectExecutionsToPurge
== Created:		11-04-2011
== Author:		Benjamin Holcombe
== Description: Used to get the ProjectExecutionID's that need to be purged from the Raw environment
===================================================================================================
== Parameters:
==	@ProjectID					ID of the Project
==	@ProjectExecutionsToPurge	Delimited string of ID's that need to be purged.
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[Get_ProjectExecutionsToPurge]
	@ProjectID INT = 0,
	@ProjectExecutionID INT = 0,
	@ProjectExecutionsToPurge VARCHAR(8000) OUTPUT
AS

BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @MachineName VARCHAR(128);
	DECLARE @UserName VARCHAR(128);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';
	
	BEGIN TRY
		SET @TaskName = 'Obtaining Project Executions to Purge';

		WITH

		PE (ProjectExecutionID) AS 
		(
			SELECT TOP (30)
				ProjectExecutionID
			FROM
				[SSIS].[ProjectExecution]
			WHERE
				[ProjectID] = @ProjectID
				AND ProjectExecutionID <> @ProjectExecutionID
			ORDER BY
				ProjectExecutionID DESC
		)

		,
		 ProjectExecutions (RowNum, ProjectExecutionID) AS
		(
			SELECT TOP (30)
				1
				,CAST('0,' AS VARCHAR(8000)) 
			UNION ALL
			SELECT 
				B.RowNum + 1
				,B.ProjectExecutionID + '' + A.ProjectExecutionID + ','
			FROM
				(SELECT
					Row_Number() OVER (ORDER BY ProjectExecutionID) AS RowNum
					,CONVERT(VARCHAR(32),ProjectExecutionID) AS ProjectExecutionID
				FROM
					PE) AS A 
			INNER JOIN ProjectExecutions AS B ON
				A.RowNum = B.RowNum
		)

		SELECT @ProjectExecutionsToPurge = (
			SELECT TOP 1
				LEFT(ProjectExecutionID, LEN(ProjectExecutionID)-1) AS ProjectExecutionsToPurge
			FROM
				ProjectExecutions
			ORDER BY
				RowNum DESC)

	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();
				
		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = -1
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END