﻿/***===============================================================================================
== Name:		OnPostExecute
== Created:		10-11-2011
== Author:		Benjamin Holcombe
== Description: Used to handle the events that occur when the OnPostExecute Event Handler is fired.
===================================================================================================
== Parameters:
== Scope
== SourceGUID
== SourceName
== ProjectExecutionID
== ExecutionGUID
== UserName
== MachineName
== PackageVersion
== PackageExecutionID
== ExecutionStatusID
== TaskExecutionID
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[OnPostExecute]
	@Scope VARCHAR(16)
	,@SourceGUID VARCHAR(64) = NULL
	,@ProjectExecutionID INT
	,@ExecutionGUID VARCHAR(64) = NULL
	,@ExecutionStatusID INT
	,@RowsRead BIGINT = NULL
	,@RowsInserted BIGINT = NULL
	,@RowsUpdated BIGINT = NULL
	,@RowsDeleted BIGINT = NULL
	,@RowsDisposed BIGINT = NULL
	,@RowsErrored BIGINT = NULL

AS
BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @MachineName VARCHAR(128);
	DECLARE @UserName VARCHAR(128);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';

	BEGIN TRY
	SET @TaskName = 'Executing OnPostExecute for ' + @Scope;
	IF @Scope = 'Project'
		BEGIN
			EXEC [SSIS].[Set_ProjectExecution]
				@ProjectExecutionID
				,@ExecutionStatusID
				,@ExecutionGUID
			EXEC [SSIS].[Set_PackageExecution]
				@ProjectExecutionID
				,@ExecutionGUID
				,@SourceGUID
				,@ExecutionStatusID;
		END
	IF @Scope = 'Package'
		BEGIN
			EXEC [SSIS].[Set_PackageExecution]
				@ProjectExecutionID
				,@ExecutionGUID
				,@SourceGUID
				,@ExecutionStatusID
				,@RowsRead
				,@RowsInserted
				,@RowsUpdated
				,@RowsDeleted
				,@RowsDisposed
				,@RowsErrored;
		END
	IF @Scope = 'Task'
		BEGIN
			EXEC [SSIS].[Set_TaskExecution]
				@ProjectExecutionID
				,@ExecutionGUID
				,@SourceGUID
				,@ExecutionStatusID;
		END
	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();

		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = @ExecutionGUID
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END