﻿
/***===============================================================================================
== Name:		OnPreExecute
== Created:		10-10-2011
== Author:		Benjamin Holcombe
== Description: Used to handle the events that occur when the OnPreExecute Event Handler is fired.
===================================================================================================
== Parameters:
== Scope
== SourceGUID
== SourceName
== ProjectExecutionID
== ExecutionGUID
== UserName
== MachineName
== PackageVersion
== ExecutionStatusID
== TaskExecutionID
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[OnPreExecute]
	@Scope VARCHAR(16)
	,@SourceGUID VARCHAR(64) = NULL
	,@SourceName VARCHAR(128) = NULL
	,@PackageName VARCHAR(128) = NULL
	,@ProjectName VARCHAR(128) = NULL
	,@ProjectExecutionID INT OUTPUT
	,@ExecutionGUID VARCHAR(64) = NULL
	,@UserName VARCHAR(128) = NULL
	,@MachineName VARCHAR(256) = NULL
	,@PackageVersionMajor INT = NULL
	,@PackageVersionMinor INT = NULL
	,@PackageVersionBuild INT = NULL
	,@ProcessIncrement INT = NULL
	,@ProcessWindowStart DATETIME2 = NULL OUTPUT
	,@ProcessWindowEnd DATETIME2 = NULL OUTPUT
	,@ExecutionStatusID INT = NULL OUTPUT
	,@ProjectExecutionsToPurge VARCHAR(8000) = NULL OUTPUT

AS
BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';

	--Procedure Variables
	DECLARE @ProjectID INT;
	DECLARE @PackageVersion VARCHAR(16);

	BEGIN TRY
	SET @TaskName = 'Executing OnPreExecute for ' + @Scope;
	SET @PackageVersion = CONVERT(VARCHAR(8), @PackageVersionMajor) 
		+ '.' + CONVERT(VARCHAR(8), @PackageVersionMinor) 
		+ '.' + CONVERT(VARCHAR(8), @PackageVersionBuild);

	IF @Scope = 'Project'
		BEGIN
			EXEC [SSIS].[Get_Project] @ProjectName, @ProjectID OUT;
			EXEC [SSIS].[Get_ProjectExecution]
				@ProjectID
				,@ProcessIncrement
				,@ProjectExecutionID OUT
				,@ExecutionStatusID OUT
				,@ProcessWindowStart OUT
				,@ProcessWindowEnd OUT
				,@ExecutionGUID
			EXEC [SSIS].[Get_ProjectExecutionsToPurge]
				@ProjectID
				,@ProjectExecutionID
				,@ProjectExecutionsToPurge OUT
			EXEC [SSIS].[Get_PackageExecution]
				@SourceName
				,@ProjectExecutionID
				,@ExecutionGUID
				,@SourceGUID
				,@PackageVersion
				,@UserName
				,@MachineName
				,@ProcessWindowStart
				,@ProcessWindowEnd;
		END
	IF @Scope = 'Package'
		BEGIN
			EXEC [SSIS].[Get_PackageExecution]
				@SourceName
				,@ProjectExecutionID
				,@ExecutionGUID
				,@SourceGUID
				,@PackageVersion
				,@UserName
				,@MachineName
				,@ProcessWindowStart
				,@ProcessWindowEnd
				,@ExecutionStatusID OUT;
		END
	IF @Scope = 'Task'
		BEGIN
			EXEC [SSIS].[Get_TaskExecution]
				@SourceGUID
				,@SourceName
				,@ExecutionGUID
				,@ProjectExecutionID
				,@ExecutionStatusID

		END
	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();

		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = @ExecutionGUID
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END