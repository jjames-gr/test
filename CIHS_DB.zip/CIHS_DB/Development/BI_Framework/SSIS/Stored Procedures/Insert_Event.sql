﻿/***===============================================================================================
== Name:		Insert_Event
== Created:		09-23-2011
== Author:		Benjamin Holcombe
== Description: Used to insert error into the Event table
===================================================================================================
== Parameters:
==	@ProjectID
==	@ErrorType
==	@PackageName
==	@MachineName
==	@UserName
==	@CodeVersion
==	@TaskName
==	@ErrorCode
==	@ErrorDescription
===================================================================================================
== Version:		1.0.000
== Revisions:	
===============================================================================================***/

CREATE PROCEDURE [SSIS].[Insert_Event]
	@ExecutionGUID VARCHAR(64) = NULL
	,@EventType VARCHAR(64) = NULL
	,@ComponentGUID VARCHAR(64) = NULL
	,@ComponentName VARCHAR(256) = NULL
	,@MachineName VARCHAR(128) = NULL
	,@UserName VARCHAR(128) = NULL
	,@CodeVersion VARCHAR(32) = NULL
	,@TaskName VARCHAR(128) = NULL
	,@MessageCode INT = NULL
	,@MessageDescription NVARCHAR(2048) = NULL

AS
BEGIN

	SET NOCOUNT ON;

	SET @ExecutionGUID = ISNULL(@ExecutionGUID, -1);
	SET @EventType = ISNULL(@EventType, 'Unknown Error Type');
	SET @ComponentGUID = ISNULL(@ComponentGUID, 'Unknown GUID');
	SET @ComponentName = ISNULL(@ComponentName, 'Unknown Package');
	SET @MachineName = ISNULL(@MachineName, HOST_NAME());
	SET @UserName = ISNULL(@UserName, SYSTEM_USER);
	SET @CodeVersion = ISNULL(@CodeVersion, 'Unknown Version');
	SET @TaskName = ISNULL(@TaskName, 'Unknown Task');
	SET @MessageCode = ISNULL(@MessageCode, -1);
	SET @MessageDescription = ISNULL(@MessageDescription, 'Unknown Error');
	

	INSERT INTO [SSIS].[Event]
	(
		[ExecutionGUID]
		,[EventType]
		,[SourceGUID]
		,[SourceName]
		,[MachineName]
		,[UserName]
		,[CodeVersion]
		,[TaskName]
		,[MessageCode]
		,[MessageDescription]
		,[MessageTime]
	)
	VALUES (
		@ExecutionGUID
		,@EventType
		,@ComponentGUID
		,@ComponentName
		,@MachineName
		,@UserName
		,@CodeVersion
		,@TaskName
		,@MessageCode
		,@MessageDescription
		,GetDate()
	)

END