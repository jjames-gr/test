﻿
/***===============================================================================================
== Name:		Get_ProjectExecution
== Created:		09-27-2011
== Author:		Benjamin Holcombe
== Description: Used to get the ProjectExecutionID
===================================================================================================
== Parameters:
==	@ProjectName
===================================================================================================
== Version:		1.0.000
== Revisions:	
	JJ 12/6/12: Updated ProcessWindowEnd to do a DateDiff in days instead of minutes
===============================================================================================***/

CREATE PROCEDURE [SSIS].[Get_ProjectExecution]
	@ProjectID INT
	,@ProcessIncrement INT
	,@ProjectExecutionID INT OUTPUT
	,@ExecutionStatusID INT OUTPUT
	,@ProcessWindowStart DATETIME2 OUTPUT
	,@ProcessWindowEnd DATETIME2 OUTPUT
	,@ExecutionGUID VARCHAR(64)

AS
BEGIN
	SET NOCOUNT ON;
	--Error Handling Variables
	DECLARE @TaskName VARCHAR(64);
	DECLARE @CodeVersion VARCHAR(24);
	DECLARE @ComponentName VARCHAR(64);
	DECLARE @MachineName VARCHAR(128);
	DECLARE @UserName VARCHAR(128);
	DECLARE @ErrorDescription VARCHAR(2048);

	SET @CodeVersion = '1.0.000';
	
	--Procedure Variables
	DECLARE @ExecutionStatus VARCHAR(16) = 'Unknown';
		
	BEGIN TRY
		SET @TaskName = 'Querying Project Execution';
		--Obtain the last execution ignoring aborted executions.
		SELECT TOP 1
			@ProjectExecutionID = SE.[ProjectExecutionID]
			,@ProcessWindowStart = SE.ProcessWindowStart
			,@ProcessWindowEnd = SE.ProcessWindowEnd
			,@ExecutionStatusID = SE.ExecutionStatusID
			,@ExecutionStatus = ES.StatusName
		FROM
			[SSIS].[ProjectExecution] AS SE
			INNER JOIN [SSIS].[ExecutionStatus] AS ES ON
				SE.[ExecutionStatusID] = ES.[ExecutionStatusID]
		WHERE
			SE.[ProjectID] = @ProjectID
			AND SE.[ExecutionStatusID] <> 5
		ORDER BY
			SE.[ProjectExecutionID] DESC
		
		IF @ProjectExecutionID IS NOT NULL
			BEGIN
				IF @ExecutionStatusID = 1
				--Code 1 Primer
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						SET @ExecutionStatusID = 2;
						UPDATE [SSIS].[ProjectExecution]
						SET ExecutionStatusID = @ExecutionStatusID
						WHERE [ProjectExecutionID] = @ProjectExecutionID
						RETURN
					END
				ELSE IF @ExecutionStatusID = 2
				--Code 2 Executing
				--Existing Project execution is either currently running or exited in an unknown state.  Abort current execution
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						SET @ExecutionStatusID = 5;
						RETURN
					END
				ELSE IF @ExecutionStatusID = 3
				--Code 3 Completed
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						SET @ProcessWindowStart = DATEADD(SS, 1, @ProcessWindowEnd)
						SET @ProcessWindowEnd = DATEADD(DD, @ProcessIncrement, @ProcessWindowEnd)
						SET @ExecutionStatusID = 2;
							INSERT INTO [SSIS].[ProjectExecution]
							(
								[ProjectID]
								,ExecutionStatusID
								,ExecutionStartTime
								,ExecutionAttempt
								,ProcessWindowStart
								,ProcessWindowEnd
								,CreatedDate
								,CreatedBy
								,ModifiedDate
								,ModifiedBy
							)
							VALUES
							(
								@ProjectID
								,@ExecutionStatusID
								,GETDATE()
								,1
								,@ProcessWindowStart
								,@ProcessWindowEnd
								,GETDATE()
								,SYSTEM_USER
								,GETDATE()
								,SYSTEM_USER
							)

							SET @ProjectExecutionID = SCOPE_IDENTITY()
						RETURN
					END
				ELSE IF @ExecutionStatusID = 4
				--Code 4 Failed
					BEGIN
						SET @TaskName = 'Executing Execution Status ' + @ExecutionStatus;
						SET @ExecutionStatusID = 2;
						UPDATE [SSIS].[ProjectExecution]
						SET
							ExecutionStatusID = @ExecutionStatusID
							,ExecutionAttempt = ExecutionAttempt + 1
						WHERE [ProjectExecutionID] = @ProjectExecutionID
						RETURN
					END
				ELSE
					BEGIN
						SET @TaskName = 'Invalid Project Execution Status';
						RETURN
					END
			END
		ELSE
			BEGIN
				SET @TaskName = 'No Prior Execution for ProjectID '+ CONVERT(VARCHAR(16), @ProjectID);
				RAISERROR(@TaskName, 16,1);
			END
	END TRY
	
	BEGIN CATCH
		SET @ComponentName = ERROR_PROCEDURE();
		SET @MachineName = HOST_NAME();
		SET @UserName = SYSTEM_USER;
		SET @ErrorDescription =
			'BI Framework Error Number: ' + CAST(ERROR_NUMBER() AS VARCHAR(12)) +
			';Severity: ' + CAST(ERROR_SEVERITY() AS VARCHAR(12)) +
			';State: ' + CAST(ERROR_STATE() AS VARCHAR(12)) +
			';Procedure: ' + ERROR_PROCEDURE() +
			';Line: ' + CAST(ERROR_LINE() AS VARCHAR(12)) +
			';Message: ' + ERROR_MESSAGE();
				
		EXECUTE [SSIS].[Insert_Event]
			@ExecutionGUID = @ExecutionGUID
			,@EventType = 'Error - SQL Stored Procedure'
			,@ComponentName = @ComponentName
			,@MachineName = @MachineName
			,@UserName = @UserName
			,@CodeVersion = @CodeVersion
			,@TaskName = @TaskName
			,@MessageCode = 70000
			,@MessageDescription = @ErrorDescription;

	END CATCH

END