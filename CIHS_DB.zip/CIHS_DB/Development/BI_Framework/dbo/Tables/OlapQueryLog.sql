﻿CREATE TABLE [dbo].[OlapQueryLog] (
    [MSOLAP_Database]   NVARCHAR (255)  NULL,
    [MSOLAP_ObjectPath] NVARCHAR (4000) NULL,
    [MSOLAP_User]       NVARCHAR (255)  NULL,
    [Dataset]           NVARCHAR (4000) NULL,
    [StartTime]         DATETIME        NULL,
    [Duration]          BIGINT          NULL
);

