﻿CREATE SCHEMA [Processed]
    AUTHORIZATION [dbo];

