﻿CREATE TABLE [Raw].[CI_tbl_Tax_Status] (
    [TAX_STATUS_ID]               INT           NOT NULL,
    [DESCRIPTION]                 VARCHAR (255) NULL,
    [ECURA_ID]                    INT           NOT NULL,
    [ETLInsertProjectExecutionID] INT           NOT NULL,
    [ETLCreatedDate]              DATETIME      NOT NULL
);

